#BERT
from summarizer import Summarizer,TransformerSummarizer
import  pandas as pd

df = pd.read_excel("C:/Users/sravan.kumar.panasa/Documents/POC_Task/amazon_review_summarization/reviews.xlsx")
reviews=str(df['Review'])

bert_model = Summarizer()
bert_summary = ''.join(bert_model(reviews, min_length=20))
print(bert_summary)

GPT2_model = TransformerSummarizer(transformer_type="GPT2",transformer_model_key="gpt2-medium")
full = ''.join(GPT2_model(reviews, min_length=20))
print(full)

model = TransformerSummarizer(transformer_type="XLNet",transformer_model_key="xlnet-base-cased")
full = ''.join(model(reviews, min_length=60))
print(full)