<template>
  <!-- <img alt="Vue logo" src="./assets/logo.png"> -->
  <ReceiptsPage/>
</template>

<script>
import "@/assets/styles.scss";
import ReceiptsPage from './components/ReceiptsPage'

export default {
  name: 'App',
  components: {
    ReceiptsPage
  }
}
</script>

<style>
#app {
  font-family: Avenir, Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
