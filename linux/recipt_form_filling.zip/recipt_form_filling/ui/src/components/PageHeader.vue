<template>
  <section class="hero is-dark">
    <div class="hero-body">
      <div class="container">
        <slot></slot>
      </div>
    </div>
  </section>
  <br>
</template>

<script>
export default {
  name: "PageHeader"
}
</script>

<style scoped>

</style>