from __future__ import division
from __future__ import print_function

import json
import glob
import logging
import multiprocessing
import os
import re
import string
import threading
import time
import json
import datetime
import tifffile as tiff
import ntpath

from flask import Flask
from flask_cors import CORS, cross_origin
from flask import render_template, redirect
from flask import request
from keras import backend as K
from flask import send_file,jsonify
from wtforms import ValidationError
import numpy as np
from object_detection.my_utils.config import UPLOAD_PATH
#from main import objects

import cv2
import numpy as np
import scipy
import scipy.misc
import tensorflow as tf
from keras import backend as K
## Added for prffffffffeprocessing - color space, bright, contrast etc
# Added for preprocessing --- color space, bright, contrast etc
from PIL import Image
from flask import Flask, render_template, request, send_from_directory, send_file
from flask_restful import Resource, Api
from flask_uploads import configure_uploads
from flask_uploads import patch_request_class
from flask import Response,redirect,url_for, flash
# from flask import Response
from src.apis import ImgClassification
from src.apis import img_processing_api as imgenh_api
from src.apis import train_inception_api as im
from src.apis import ImageExtensionValidator as img_val
from src.conf import ImgClassification_Config
from src.conf import app_config
from src.conf import file_upload_config
from src.conf import img_processing_config as ip_config
from src.conf import inception_config
from src.utils import db
from src.utils import img_util
from src.utils.img_util import ImageUtils
from src.apis import train_vgg_resnet_api
from src.apis import classify_vgg_resnet_api
from src.apis import train_resnet_api
from src.apis import classify_resnet_api
from keras import backend as K
from werkzeug import secure_filename

# Satellite workbench

#from Satelllite_WB.src.colour_composition_api import Colour_Composition
from Satelllite_WB.src.colour_composition_api_new import Colour_Composition
from Satelllite_WB.src.gen_iou_api import Gen_IOU 
from Satelllite_WB.src.satellite_process_api import Satellite_Process
from Satelllite_WB.src import pred_pow
from Satelllite_WB.src import pred_demo
from Satelllite_WB.src.pre_analysis import Satellite_PreAnalysis


from Satelllite_WB.src.display_result_api import Display
from Satelllite_WB.src.display_models_api import Display_Models

from Satelllite_WB.src.gdalinfo_parser_api import parsing_gdalinfo
from Satelllite_WB.src.indices_api import calc_indices
from Satelllite_WB.src.multipagetif_api import multipage
#from Satelllite_WB.src.annotation_pipeline_batch_api import annotation_pipeline

from Satelllite_WB.src.annotation_pipeline_till_jpegs import Annotations1
from Satelllite_WB.src.annotation_pipeline_after_labelme import Annotations2

from Satelllite_WB.src.create_folder import folder
#from Satelllite_WB.src.#_api import indices
from Satelllite_WB.src import train_unet
from Satelllite_WB.src.unet_model_deeper import *
from Satelllite_WB.src.gen_patches import *
from Satelllite_WB.src.pansharpening import do_pansharpen as pan
from Satelllite_WB.src.gen_patches import *
from Satelllite_WB.src.split_train import train_test_split
from Satelllite_WB.src.split_test import train_test_split as annotation_split
from Satelllite_WB.src import vec_on_raster



# Medical Workbench
'''
from Medical_WB.src.folder_creation import folder
from Medical_WB.src.analyze import Analyze
'''
#from medical_wb.extract import extract_data, clear_dir
#from medical_wb.create_data import gen_data, preprocess_image, preprocess_image_test, preprocess_mask, img_name, dir_check
from medical_wb.gen_mask import from_json, gen_blank, gen_blank_train 
#from medical_wb.extract_demo import make_folders
from medical_wb.demo_predict import predict_medical_demo
from medical_wb.train import train_medical_unet
from medical_wb.predict import predict_medical
from medical_wb.post_processing import accuracy_assessment

# Medical workbench
from medical_wb.extract import extract_data, clear_dir, check_del
from medical_wb.create_data import gen_data, preprocess_image, preprocess_image_test, preprocess_mask, img_name, dir_check
from medical_wb.gen_mask import from_json, gen_blank, gen_blank_train 
from medical_wb.extract_demo import make_folders
from medical_wb.demo_predict import predict_medical_demo
from medical_wb.train import train_medical_unet
from medical_wb.predict import predict_medical
from medical_wb.post_processing import accuracy_assessment
from tensorflow.keras import backend as K

# Biometrics
from biometrics_wb import video_encoding
from biometrics_wb import image_encoding

# object detection 
from object_detection.resources.train_ssd import Train_Ssd
from object_detection.resources.retrain_ssd import Retrain_Ssd
from object_detection.resources.classify_ssd import Classify_Ssd
from object_detection.resources.train_MapScore import Train_MapScore
from object_detection.resources.classify_ssd_map import Classify_Ssd_map
from object_detection.resources.test_ssd_map import Test_Ssd_map
from object_detection.resources.classify_ssd_video import Classify_Ssd_video
from object_detection.resources.depth_dis_OD import Classify_Ssd_video_depth
from object_detection.resources.display_depth_video import Process_video_depth

# For instance segmentation
from instance_segmentation.mrcnn.config import Config
from instance_segmentation.mrcnn import model as modellib, utils
from instance_segmentation.samples.custom_train import custom_data_train
from instance_segmentation.samples import custom_demo
from src.utils import db
from src.conf import inception_config

#For Scene recongnition
from scene_recognition.api_train_sr import train_sr
from scene_recognition.api_captionGenerator import caption_generator
from scene_recognition.api_evaluateModel import model_evaluation

#For Face mask detection
from face_mask_detection.yolo_detection import yolo_face_detection
#import face_mask_detection.utils

import json
import traceback


import base64
import tempfile
import os
import logging
import requests
from flask import Flask
from flask import render_template
from flask import request, jsonify
from flask_wtf.file import FileField
from werkzeug.datastructures import CombinedMultiDict
from wtforms import Form
from wtforms import ValidationError

from custom_projects.resources.lits_3d.LiTS.dataprocess.vnet3d_predict import gif_lits
#from custom_projects.resources.CBIR.search import recommend
from custom_projects.resources.VisualSearch_MXNet_master.testing_manual import visualsearch
from custom_projects.resources.barcode_detection.barcode_detect import detect
#from custom_projects.resources.vqa import VQA_Demo
#from custom_projects.resources.vqa.VQA_Demo import answer_generator
from custom_projects.resources.crowd_estimate.demo import crowd_estimate
from custom_projects.resources.gender_age_prediction.gender_age_detection import gender_age
#from custom_projects.resources.cracks_classification.cracks_classification_1 import classify_image
from custom_projects.resources.cracks_classification.cracks_classification import classify_image_cracks
from custom_projects.resources.skin_lesion_classification.lesion_classification import classify_image_lesion
from custom_projects.resources.brain_tumour_classification.config import Config
import custom_projects.resources.face_license_detection.new_detect_face
from custom_projects.resources.religion_mask.Step_1_Deskew import preprocess
from custom_projects.resources.image_summary.scene_recog1 import scene_rec
from custom_projects.resources.motion_detection.motion_detector import motion_detector
from custom_projects.resources.Drowsiness_Detection.Drowsiness_Detection import drowsiness_detection
from custom_projects.resources.face_mask_detection import detect_mask
from custom_projects.resources.temperature_detection import measure_temp
from custom_projects.resources.vessel_contents.RunPredictionOnImage import pred_image
#from custom_projects.resources.GAN.cloth import PixelDTGAN
#from custom_projects.resources.VisualSearch_MXNet_master import testing
#from custom_projects.resources.AttnGAN_master.code import main_test
import SimpleITK as sitk

from s3_import import check_s3
import traceback


# app = Flask(__name__, template_folder='src/ui/templates')

# ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
APP_ROOT = os.path.dirname(os.path.abspath(__file__))
basepath="/home/ubuntu/cv_workspace/data"
logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
logger.addHandler(app_config.log_handler)

## template path for custom projects ####
TEMPLATE_PATH = "custom_projects/templates"

enc="utf-8"
app = Flask(__name__, template_folder=TEMPLATE_PATH)
api = Api(app)
app.config['DEBUG'] = True
pwd = os.path.dirname(__file__)
app.config['SECRET_KEY'] = 'I have a dream'
# app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024
app.config['UPLOADED_PHOTOS_DEST'] = file_upload_config.UPLOADED_PHOTOS_DEST
app.config['UPLOADED_ARCHIVES_DEST'] = file_upload_config.UPLOADED_ARCHIVES_DEST

configure_uploads(app, (file_upload_config.photos, file_upload_config.archives)) #
patch_request_class(app, file_upload_config.MAX_UPLOAD_SIZE)

#This path will be used to save the uploaded image
img_input_dir = file_upload_config.UPLOADED_PHOTOS_DEST

#This path will be used to save the pre-processed images
img_save_dir = ip_config.IMG_SAVE_DIR
img_temp_dir = ip_config.IMG_TEMP_DIR



SUCCESS = "Success"
DURATION = "Duration"
TMPTRN_DIR = "tmptrn"

class ScaleImage(Resource):
    def get(self, baseheight=None):
        for image_file in os.listdir(img_input_dir):
            print (image_file)
            image_path = os.path.join(img_input_dir, image_file)
            iu = ImageUtils(image_path)
            image_resized = iu.resize_image(baseheight)
            scaled_image_path = iu.save_image(image_resized, image_file + "_resized.png", img_save_dir)
            break

        if scaled_image_path:
            return send_file(scaled_image_path, mimetype='image/png')


@app.route('/upload_training', methods=['GET', 'POST'])
def upload_training():
    """
    The Data Ingestion Archive Upload API for Training
    """
    from src.apis import file_upload_api

    form, success = file_upload_api.upload_archives()
    return render_template('training.html', form=form, success=success)

@app.route('/upload_classification', methods=['GET', 'POST'])
def upload_classification():
    """
    The Data Ingestion Images Upload API for Classification
    """
    from src.apis import file_upload_api

    form, success = file_upload_api.upload_images()
    return render_template('classification.html', form=form, success=success)

@app.route('/manage')
def manage_file():
    files_list = os.listdir(app.config['UPLOADED_PHOTOS_DEST'])
    return render_template('manage.html', files_list=files_list)
#
# @app.route('/open/<filename>')
# def open_file(filename):
#     file_url = photos.url(filename)
#     return render_template('browser.html', file_url=file_url)
#
# @app.route('/delete/<filename>')
# def delete_file(filename):
#     file_path = photos.path(filename)
#     os.remove(file_path)
#     return redirect(url_for('manage_file'))

@app.route('/canny_edge_detect', methods=['POST'])
def doCannyEdgeDetection():
    """
    API for canny edge detection. Retrieves image name and thresholds from the user request and calls preprocessing API.
    Returns a json object containing path to the saved preprocessed image.
    """
    logger.info("doCannyEdgeDetection")
    ## Initialize variables
    jsondata = {}
    errorFlag = False
    low = None
    high = None
    req_json = get_json_from_request(request)
    for jsonObj in req_json:

        try:
            errorFlag = False
            ##  Check that mandatory parameter image name has been passed
            # filename = request.form[ip_config.input_img_name]
            ##  Check that specified image name exists
            # filename = getReqeuestParam(jsonObj, "filename")
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            className = getReqeuestParam(jsonObj, "className")
            dataType = getReqeuestParam(jsonObj, "dataType")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath")
            jsonObj[SUCCESS] = "0"
            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName

            # imgpath ]= os.path.join(img_input_dir, filename)
            img = img_util.validate_input(image_path)
            if img is None:
                jsondata["Img"] = "Image uploading  Failed!!!"
                errorFlag = True

            # Optional parameters: If user provides thresholds, check for  their validity else flag error
            lowThresh = (getReqeuestParam(jsonObj, "lowThresh"))
            # inputVar1 = request.form[ip_config.input_low_thresh]
            if lowThresh:
                if lowThresh.isnumeric() and isinstance(int(lowThresh), int):
                    low = int(lowThresh)
                else:
                    jsondata["lowThresh"] = "Invalid value for threshold"
                    errorFlag = True

            # inputVar = request.form[ip_config.input_high_thresh]
            highThresh = (getReqeuestParam(jsonObj, "highThresh"))
            if highThresh:
                if highThresh.isnumeric() and isinstance(int(highThresh), int):
                    high = int(highThresh)
                else:
                    jsondata["highThresh"] = "Invalid value for threshold"
                    errorFlag = True

            if not errorFlag:
                processed_image = imgenh_api.cannyEdgeDetect(image_path, lowThresh=low, highThresh=high)
                logger.info("Saving processed image")
                # destination = os.path.join(img_save_dir, filename)

                # remove previous copy of the same file if any
                # if os.path.isfile(save_image_path):
                # os.remove(save_image_path)

                # cv2.imwrite(destination, processed_image)
                cv2.imwrite(save_image_path, processed_image)
                # jsondata["processed_img_path"] = destination
                # if os.path.isfile(save_image_path): jsonObj["SUCCESS"] = "1"
                if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                    jsonObj[SUCCESS] = "1"
                elif os.path.isfile(save_image_path):
                    os.remove(save_image_path)
                # return send_image(img_save_dir, filename)

            else:
                logger.info("Error")
                # return json.dumps(jsondata)


        except Exception as e:
            logger.error("Error while Pre processing canny_edge detect: " + str(e) + " input: " + str(jsonObj))
            # jsondata["error"] = "Error Occured while prcessing image"
    return json.dumps(req_json)
    # return json.dumps(jsondata)


@app.route("/create_jpegs_satellite", methods=["POST"])
def create_jpegs_satellite():
    logger.info("In create_jpegs_satellite api")
    logger.info(request.data)
    jsonObj = get_json_from_request(request)
    #logger.info(" Json request " + str(jsonObj))
    project_id = jsonObj["usecaseid"]
    errorFlag = False
    K.clear_session()
    try:
        if (not project_id or project_id == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if not errorFlag:
            logger.info("going to preanalysis file")
            obj = Satellite_PreAnalysis()
            output = obj.annotation_allfuns(project_id)
            logger.info("result: %s", output)
            result = {}
            result["message"] = output
    except Exception as e:
        logger.error("Error while doing this: " + str(e) + " input: " + str(jsonObj))
    return json.dumps(result)


@app.route('/log_edge_detect', methods=['POST'])
def doLogEdgeDetection():
    """
    API for laplacian of gaussian edge detection. Retrieves image name and thresholds from the user request and calls
    preprocessing API.
    Returns a json object containing path to the saved preprocessed image.
    """

    logger.info("doLogEdgeDetection")

    ## Initialize variables
    jsondata = {}

    gaussian_ksize = ip_config.gaussian_ksize
    sigma = ip_config.sigma
    laplacian_ksize = ip_config.laplacian_ksize
    req_json = get_json_from_request(request)
    for jsonObj in req_json:

        try:
            errorFlag = False
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            className = getReqeuestParam(jsonObj, "className")
            dataType = getReqeuestParam(jsonObj, "dataType")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")

            jsonObj[SUCCESS] = "0"
            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName

            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName

            ##  Check for mandatory parameters - image file name
            # filename = request.form[ip_config.input_img_name]
            ##  Check that specified image name exists
            # imgpath = os.path.join(img_input_dir, filename)
            img = img_util.validate_input(image_path)
            if img is None:
                jsondata["Img"] = "Image uploading  Failed!!!"
                errorFlag = True

            # Optional parameters: Check the validity for user inputs and flag error
            gaussian_ksize = getReqeuestParam(jsonObj, "gaussian_ksize")
            # inputVar = request.form[ip_config.input_gaussian_ksize]
            # only positive and odd integers are allowed
            if gaussian_ksize:
                if gaussian_ksize.isnumeric() and isinstance(int(gaussian_ksize), int) and int(gaussian_ksize) > 0 and int(
                        gaussian_ksize) % 2 != 0:
                    gaussian_ksize = int(gaussian_ksize)
                else:
                    jsondata["GKsize"] = "Invalid value for Gaussian Ksize"
                    errorFlag = True

            # inputVar = request.form[ip_config.input_laplacian_ksize]
            laplacian_ksize = getReqeuestParam(jsonObj, "laplacian_ksize")
            # only positive and odd integers are allowed
            if laplacian_ksize:
                if laplacian_ksize.isnumeric() and isinstance(int(laplacian_ksize), int) and int(laplacian_ksize) > 0 \
                        and int(laplacian_ksize) < 33 and int(laplacian_ksize) % 2 != 0:
                    laplacian_ksize = int(laplacian_ksize)
                    logger.info(laplacian_ksize)
                else:
                    jsondata["LKsize"] = "Invalid value for Laplacian Ksize"
                    errorFlag = True

            sigma = getReqeuestParam(jsonObj, "sigma")
            # inputVar = request.form[ip_config.input_sigma]
            if sigma:
                try:
                    sigma = float(sigma)
                    logger.info(sigma)
                except ValueError:
                    jsondata["Sigma"] = "Sigma should be integer or float"
                    errorFlag = True

            if not errorFlag:
                processed_image = imgenh_api.laplacianOfGaussian(image_path, gaussian_ksize=gaussian_ksize, sigma=sigma,
                                                                 laplacian_ksize=laplacian_ksize)
                logger.info("Saving processed image")
                # destination = os.path.join(img_save_dir, filename)

                # remove previous copy of the same file if any
                # if os.path.isfile(destination):
                # os.remove(destination)

                # cv2.imwrite(destination, processed_image)
                cv2.imwrite(save_image_path, processed_image)
                # if os.path.isfile(save_image_path): jsonObj["SUCCESS"] = "1"
                if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                    jsonObj[SUCCESS] = "1"
                elif os.path.isfile(save_image_path):
                    os.remove(save_image_path)
                # jsondata["processed_img_path"] = destination
                # return send_image(img_save_dir, filename)
            else:
                logger.info("Error")
                # return json.dumps(jsondata)


        except Exception as e:
            logger.error("Error while Pre processing log_edge detect: " + str(e) + " input: " + str(jsonObj))
            # logger.exception(e)
            # return ip_config.IMG_PROCESSING_ERR_MSG
    return json.dumps(req_json)


# Change brightness based on given percentage
@app.route("/bright", methods=["POST"])
def bright():
    """Brightness Transformation on images.
    Retrieves i) image name and ii) percentage from the user request and calls preprocessing API.
    Returns path to the saved preprocessed image.
    """
    logger.info("Brightness Transformation")

    # retrieve parameters from html form
    # per value should come from slider.
    # So slider should limit value as min= -100 to max =100
    # Update parameters from User request
    req_json = get_json_from_request(request)
    for jsonObj in req_json:
        try:
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            dataType = getReqeuestParam(jsonObj, "dataType")
            per = getReqeuestParam(jsonObj, "brightnessPercentage")
            className = getReqeuestParam(jsonObj, "className")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")
            jsonObj[SUCCESS] = "0"

            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if(not ipPath==""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName

            st = time.time()
            img = imgenh_api.bright(image_path, int(per))
            img.save(save_image_path)
            en = time.time()
            jsonObj[DURATION] = str(int(en - st))
            #if os.path.isfile(save_image_path): jsonObj[SUCCESS] = "1"
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            logger.info("Brightness completed")
        except Exception as e:
            logger.error("Error while Pre processing brightness: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)

# Change Image contrast based on given percentage
@app.route("/contrast", methods=["POST"])
def contrast():
    """Contrast Transformation on images.
    Retrieves i) image name and ii) percentage from the user request and calls preprocessing API.
    Returns path to the saved preprocessed image.
    """
    logger.info("Contrast Transformation")

    # retrieve parameters from html form
    # per value should come from slider.
    # So slider should limit value as min= -100 to max =100
    req_json = get_json_from_request(request)
    for jsonObj in req_json:
        try:
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            dataType = getReqeuestParam(jsonObj, "dataType")
            per = getReqeuestParam(jsonObj, "contrastPercentage")
            className = getReqeuestParam(jsonObj, "className")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")
            jsonObj[SUCCESS] = "0"
            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName

            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName

            st = time.time()
            img = imgenh_api.contrast(image_path, int(per))
            img.save(save_image_path)
            en = time.time()
            jsonObj[DURATION] = str(int(en - st))
            #if os.path.isfile(save_image_path): jsonObj[SUCCESS] = "1"
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            logger.info("Contrast completed")
        except Exception as e:
            logger.error("Error while Pre processing contrast: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)


# Perform Histogram Equalization on Image
@app.route("/histogrameq", methods=["POST"])
def he():
    logger.info("Histogram Equalization")
    req_json = get_json_from_request(request)
    for jsonObj in req_json:
        try:
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            dataType = getReqeuestParam(jsonObj, "dataType")
            className = getReqeuestParam(jsonObj, "className")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")
            jsonObj[SUCCESS] = "0"
            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName

            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName

            st = time.time()
            img = imgenh_api.HE(image_path)
            img.save(save_image_path)
            en = time.time()
            jsonObj[DURATION] = str(int(en - st))
            #if os.path.isfile(save_image_path): jsonObj[SUCCESS] = "1"
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            logger.info("Histogram Equalization completed")
        except Exception as e:
            logger.error("Error while Pre processing histogram: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)

# Change color space to given model
@app.route("/rgb2gray", methods=["POST"])
def rgb2gray():
    filterName="rgb2gray"
    return color_space_filter(filterName)

@app.route("/rgb2hsv", methods=["POST"])
def rgb2hsv():
    filterName = "rgb2hsv"
    return color_space_filter(filterName)

@app.route("/rgb2ycbcr", methods=["POST"])
def rgb2ycbcr():
    filterName = "rgb2ycbcr"
    return color_space_filter(filterName)

def color_space_filter(filterName):
    # filename = request.form['image']

    # define complete path based on img input dir
    # here we assume that images after upload are getting saved at img_input_dir
    # jsondata = {}
    # Update parameters from User request
    # req_json = request.get_json()
    # if (req_json is None):
    # data = request.jsondata
    # jsondata = json.loads(data)
    req_json = get_json_from_request(request)  # expected jsonArray

    for jsonObj in req_json:
        try:
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            dataType = getReqeuestParam(jsonObj, "dataType")
            className = getReqeuestParam(jsonObj, "className")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName")
            opPath = getReqeuestParam(jsonObj, "opPath")
            ipPath = getReqeuestParam(jsonObj, "ipPath")
            #filterName = getReqeuestParam(jsonObj, "filterName")
            jsonObj[SUCCESS] = "0"

            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName

            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName

            img = imgenh_api.colour_space(image_path,filterName)
            # save processed image
            logger.info("Saving color model transformed image")
            # destination = os.path.join(img_input_dir,useCaseId,opPath,dataType,className,opImgName)
            #  remove previous copy of the same file if any
            # destination = os.path.join(img_temp_dir, filename)
            # remove previous copy of the same file if any
            # if os.path.isfile(save_image_path): os.remove(save_image_path)

            img_np = np.array(img)
            img_PIL = Image.fromarray(np.uint8(img_np))
            img_PIL.save(save_image_path)
            #jsonObj["path"] = save_image_path
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            #jsonObj[SUCCESS] = "1"
        # return destination
        # return send_image(img_save_dir, filename)
        except Exception as e:
            logger.exception("Error: " + json.dumps(jsonObj) + "\n" + str(e))
            jsonObj[SUCCESS] = "0"
    return json.dumps(req_json)

@app.route("/train_vgg", methods=["POST"])
def train_vgg_resnet():
    logger.info("Training VGG and Resnet Model")
    jsonObj = get_json_from_request(request)
    # logger.info(" Json type>>>>>>>>>>>>>>>>>>> ", type(jsonObj))
    # logger.info(" Json request>>>>>>>>>>>>>>>>>>> " + str(jsonObj))
    # Read  the model parameter dictionary with default parameters from config
    # def_args = inception_config.args
    # args = def_args.copy()
    try:
        # logger.info("Checking in comp vision>>>>>>>>>>>>>>>>>>>>>>>>>")
        ob = train_vgg_resnet_api.Train_resnet_vgg(jsonObj)
        status = ob.allFunctionCalls()
        logger.info("result: %s", status)
        
    except Exception as e:
        logger.error("Error while doing this: " + str(e) + " input: " + str(jsonObj))
    return status


@app.route("/classify_vgg", methods=["POST"])
def classify_vgg_resnet():
    logger.info("Classifying VGG and Resnet Model")
    jsonObj = get_json_from_request(request)
    logger.info(" Json request " + str(jsonObj))
    # errorFlag = False
    # Read  the model parameter dictionary with default parameters from config
    # def_args = inception_config.args
    # args = def_args.copy()
    K.clear_session()
    try:
        object = classify_vgg_resnet_api.classification_vgg_resnet(jsonObj)
        output = object.classification()
        logger.info("result: %s", output)
    except Exception as e:
        logger.error("Error while doing this: " + str(e) + " input: " + str(jsonObj))
    return json.dumps(jsonObj)

@app.route("/train_resnet", methods=["POST"])
def train_resnet():
    logger.info("Training ResNet Model")
    jsonObj = get_json_from_request(request)
    # logger.info(" Json type>>>>>>>>>>>>>>>>>>> ", type(jsonObj))
    # logger.info(" Json request>>>>>>>>>>>>>>>>>>> " + str(jsonObj))
    # Read  the model parameter dictionary with default parameters from config
    # def_args = inception_config.args
    # args = def_args.copy()
    try:
        # logger.info("Checking in comp vision>>>>>>>>>>>>>>>>>>>>>>>>>")
        obj = train_resnet_api.Train_resnet(jsonObj)
        result = obj.allFunctionCalls()
        logger.info("result: %s", result)
        
    except Exception as e:
        logger.error("Error while doing this: " + str(e) + " input: " + str(jsonObj))
    return result

@app.route("/classify_resnet", methods=["POST"])
def classify_resnet():
    logger.info("Classifying ResNet Model")
    jsonObj = get_json_from_request(request)
    logger.info(" Json request " + str(jsonObj))
    # errorFlag = False
    # Read  the model parameter dictionary with default parameters from config
    # def_args = inception_config.args
    # args = def_args.copy()
    K.clear_session()
    try:
        object = classify_resnet_api.classification_resnet(jsonObj)
        result_resnet = object.classification()
        logger.info("result: %s", result_resnet)
    except Exception as e:
        logger.error("Error while doing this: " + str(e) + " input: " + str(jsonObj))
    return json.dumps(jsonObj)


# Edge Computing API for IC
@app.route('/get_apk_ic', methods=['POST', 'GET'])
def get_apk_ic():
    print("in get apk api for IC")
    jsonObj = request.get_json()
    useCaseId = jsonObj['useCaseId']
    from edge_computing import edge_img_classification

    output = edge_img_classification.apk_img_classification(useCaseId)
    result = {}
    result["message"] = output

    return json.dumps(result)


# Edge computing API for OD
def getting_od_apk(useCaseId, url):
    try:
        result = {}
        # URL = "http://127.0.0.1:7000/apk_object_detection"

        headers = {
            "Content-Type": "application/json",
            'Cache-Control': "no-cache"
        }
        data = {'useCaseId': useCaseId}
        # print("data: ", data)
        response_req = requests.post(url, json=data, headers=headers)
        print("response_req", response_req)
        return response_req
    except Exception as e:
        print(e)


@app.route('/get_apk_od', methods=['POST', 'GET'])
def get_apk_od():
    try:
        print("in get apk api for OD")
        jsonObj = request.get_json()
        useCaseId = jsonObj["useCaseId"]

        URL = "http://127.0.0.1:7000/apk_object_detection"

        result = getting_od_apk(useCaseId, URL)
        print("result is ", result)

        if result.status_code == 200:
            print(result.text)
        else:
            print("Error")

    except Exception as e:
        print(e)

    return result.text


#Robust AI and Tf2.0 end points
@app.route('/train_image_classification_tf2', methods=['GET','POST'])
def train_image_classification_tf2():
    print("In the Tf2 training api")
    jsonObj = get_json_from_request(request)
    # logger.info("json object : " + str(jsonObj))
    K.clear_session()
    try:
        URL = "http://127.0.0.1:5002/train_tf2_classification"
        headers = {
            "Content-Type": "application/json",
            'Cache-Control': "no-cache"
        }
        #data = {'usecaseid': usecaseid1,'eps' : eps1,'iterations' : iterations1,'eps_steps' : eps_step1}
        data =jsonObj
        # print("data: ", data)
        result = requests.post(URL, json=data, headers=headers)
        print("result is ", result.text)
        K.clear_session()
    except Exception as e:
        print(e)

    return result.text

@app.route('/classify_image_classification_tf2', methods=['GET','POST'])
def classify_image_classification_tf2():
    print("In the Tf2 classify api")
    jsonObj = get_json_from_request(request)
    # logger.info("json object : " + str(jsonObj))
    K.clear_session()
    try:
        URL = "http://127.0.0.1:5002/predict"
        headers = {
            "Content-Type": "application/json",
            'Cache-Control': "no-cache"
        }
        data =jsonObj
        # print("data: ", data)
        result = requests.post(URL, json=data, headers=headers)
        print("result is ", result.text)
        K.clear_session()
    except Exception as e:
        print(e)

    return result.text


@app.route('/train_robust_model', methods=['GET','POST'])
def train_image_classification_robust_ai():
    print("In the robust model training api")
    jsonObj = get_json_from_request(request)
    # logger.info("json object : " + str(jsonObj))
    K.clear_session()
    try:
        URL = "http://127.0.0.1:5002/train_robust_model_api"
        headers = {
            "Content-Type": "application/json",
            'Cache-Control': "no-cache"
        }
        #data = {'usecaseid': usecaseid1,'eps' : eps1,'iterations' : iterations1,'eps_steps' : eps_step1}
        data =jsonObj
        # print("data: ", data)
        result = requests.post(URL, json=data, headers=headers)
        print("result is ", result.text)
        K.clear_session()
    except Exception as e:
        print(e)

    return result.text

@app.route('/proactive_robustness', methods=['GET','POST'])
def proactive_robustness_check_robust_ai():
    logger.info("In the robust model proactive prediction api")
    jsonObj = get_json_from_request(request)
    # logger.info("json object : " + str(jsonObj))
    K.clear_session()
    try:
        URL = "http://127.0.0.1:5002/test_robust_api"
        headers = {
            "Content-Type": "application/json",
            'Cache-Control': "no-cache"
        }
        data =jsonObj
        # print("data: ", data)
        result = requests.post(URL, json=data, headers=headers)
        print("result is ", result.text)
        K.clear_session()
    except Exception as e:
        print(e)

    return result.text


### Robust AI reactive part endpooints
@app.route('/adv_generate', methods=['GET','POST'])
def adv_generate():
    print("In Robust AI Ist api")
    jsonObj = get_json_from_request(request)
    # logger.info("json object : " + str(jsonObj))
    K.clear_session()
    try:
        usecaseid1 = jsonObj['usecaseid']
        eps1 = jsonObj['eps']
        iterations1 = jsonObj['max_iterations']
        eps_step1 = jsonObj['eps_steps']
        model=jsonObj['modelName']

        print("usecase_id : ",usecaseid1)
        URL = "http://127.0.0.1:5002/adv_generate"
        headers = {
            "Content-Type": "application/json",
            'Cache-Control': "no-cache"
        }
        data = {'usecaseid': usecaseid1,'eps' : eps1,'iterations' : iterations1,'eps_steps' : eps_step1,'modelName':model}
        # print("data: ", data)
        result = requests.post(URL, json=data, headers=headers)
        print("result is ", result.text)
        K.clear_session()
    except Exception as e:
        print(e)

    return result.text

@app.route('/adv_metrics', methods=['GET','POST'])
def adv_metrics():
    print("In Robust AI 2nd api")
    jsonObj = get_json_from_request(request)
    # logger.info("json object : " + str(jsonObj))
    K.clear_session()
    try:
        usecaseid1 = jsonObj['usecaseid']
        model = jsonObj['modelName']
        print("usecase_id : ",usecaseid1)
        URL = "http://127.0.0.1:5002/adv_metrics"
        headers = {
            "Content-Type": "application/json",
            'Cache-Control': "no-cache"
        }
        data = {'usecaseid': usecaseid1,'modelName':model}
        # print("data: ", data)
        result = requests.post(URL, json=data, headers=headers)
        print("result is ", result.text)
        K.clear_session()
    except Exception as e:
        print(e)

    return result.text

@app.route('/def_generate', methods=['GET','POST'])
def def_generate():
    print("In Robust AI 3rd api")
    jsonObj = get_json_from_request(request)
    # logger.info("json object : " + str(jsonObj))
    K.clear_session()
    try:
        usecaseid1 = jsonObj['usecaseid']
        print("usecase_id : ",usecaseid1)
        URL = "http://127.0.0.1:5002/def_generate"
        headers = {
            "Content-Type": "application/json",
            'Cache-Control': "no-cache"
        }
        data = {'usecaseid': usecaseid1}
        # print("data: ", data)
        result = requests.post(URL, json=data, headers=headers)
        print("result is ", result.text)
        K.clear_session()
    except Exception as e:
        print(e)

    return result.text

@app.route('/def_metrics', methods=['GET','POST'])
def def_metrics():
    print("In Robust AI 4th api")
    jsonObj = get_json_from_request(request)
    # logger.info("json object : " + str(jsonObj))
    K.clear_session()
    try:
        usecaseid1 = jsonObj['usecaseid']
        model = jsonObj['modelName']
        print("usecase_id : ",usecaseid1)
        URL = "http://127.0.0.1:5002/def_metrics"
        headers = {
            "Content-Type": "application/json",
            'Cache-Control': "no-cache"
        }
        data = {'usecaseid': usecaseid1,'modelName':model}
        # print("data: ", data)
        result = requests.post(URL, json=data, headers=headers)
        print("result is ", result.text)
        K.clear_session()
    except Exception as e:
        print(e)

    return result.text

# End poo=ints for Satellite Imagery
@app.route("/generate_iou", methods=["POST"])
def generate_iou():
    logger.info("In Generate IOU")
    jsonObj = get_json_from_request(request)
    print("json object : ", jsonObj)
    # logger.info(" Json type>>>>>>>>>>>>>>>>>>> ", type(jsonObj))
    # logger.info(" Json request>>>>>>>>>>>>>>>>>>> " + str(jsonObj))
    # Read  the model parameter dictionary with default parameters from config
    # def_args = inception_config.args
    # args = def_args.copy()
    K.clear_session()
    try:
        project_id = jsonObj['usecaseid']
        weights_path = jsonObj['weights_path']
        N_CLASSES = jsonObj['N_CLASSES']
        classes = jsonObj["classes_list"]

        #gt_folder = jsonObj['gt_folder']        
        errorFlag = False
        if (not project_id or project_id == None):
            logger.info("Please provide the project id predicted mask images")
            errorFlag = True
        if not errorFlag:
            logger.info("going to generate_iou file")
            obj = Gen_IOU()
            output = obj.allFunctionCalls(project_id,weights_path,N_CLASSES,classes)
            base_path1 = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)
            data_path1 = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)+ "/data_dir"
            only_plots = "/home/ubuntu/cv-asset/Satelllite_WB/"+ str(project_id)+ "/model_dir/plots"
            thumbnail_plots = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)+ "/data_dir/thumbnails/plots"
            if not os.path.exists(base_path1):
                logger.info("Stuck in  Line no 750")
                os.mkdir(base_path1)
            if not os.path.exists(data_path1):
                logger.info("Stuck in  Line no 750")
                os.mkdir(data_path1)
            if not os.path.exists(thumbnail_plots):
                logger.info("Stuck in  Line no 750")
                os.mkdir(thumbnail_plots)
            output2 = create_thumbnail_jpegs(thumbnail_plots,only_plots)
            logger.info("result: %s", output)
            result={}
            result["message"] = "success"
        
    except Exception as e:
        logger.error("Error while doing this: " + str(e) + " input: " + str(jsonObj))
    return json.dumps(result)

@app.route("/satellite_process", methods=["POST"])
def satellite_process():
    logger.info("In Satellite Process")
    jsonObj = get_json_from_request(request)
    logger.info("json object : " + str(jsonObj))
    # logger.info(" Json type>>>>>>>>>>>>>>>>>>> ", type(jsonObj))
    # logger.info(" Json request>>>>>>>>>>>>>>>>>>> " + str(jsonObj))
    # Read  the model parameter dictionary with default parameters from config
    # def_args = inception_config.args
    # args = def_args.copy()
    K.clear_session()
    try:
        dataset = jsonObj['dataset']
        latitude = jsonObj['latitude']
        longitude = jsonObj['longitude']
        start_date = jsonObj['start_date']
        end_date = jsonObj['end_date']
        max_cloud_cover = jsonObj['max_cloud_cover']
        scene_name = jsonObj['scenename']
        project_id = jsonObj['usecaseid']
        logger.info("id----%s"%str(project_id))
        usecase_params6 = {}
        from Satelllite_WB.src import db4
        usecase_params6['status'] = "Download_In_Progress"
        db4.updateUseCase(usecase_params6, project_id)
        errorFlag = False
        if (not dataset or dataset == None):
            logger.info("Please provide dataset for satellite processing")
            errorFlag = True
        if (not latitude or latitude == None):
            logger.info("Please provide latitude value")
            errorFlag = True
        if (not longitude or longitude == None):
            logger.info("Please provide longitude value")
            errorFlag = True
        if (not start_date or start_date == None):
            logger.info("Please provide the start_date")
            errorFlag = True
        if (not end_date or end_date == None):
            logger.info("Please provide the end_date")
            errorFlag = True
        if (not max_cloud_cover or max_cloud_cover == None):
            logger.info("Please provide max_cloud_cover value")
            errorFlag = True
        if (not project_id or project_id == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True        
        if not errorFlag:
            logger.info("going to satellite_process_api file")
            ob = Satellite_Process()
            clip_dir = ob.allFunctionCalls(dataset,latitude,longitude,start_date,end_date,max_cloud_cover,project_id)
            # logger.info("result: %s", result)
            #ob_pan = pan(project_id,clip_dir)
            result = {}
            output = "Success"
            result["message"] = output
            usecase_params6 = {}
            from Satelllite_WB.src import db4
            usecase_params6['status'] = "Download_Completed"
            db4.updateUseCase(usecase_params6, project_id)
            #logger.info("result with pan: %s", output)                
    except Exception as e:
        logger.error("Error while doing this: " + str(e) + " input: " + str(jsonObj))
        usecase_params6 = {}
        from Satelllite_WB.src import db4
        usecase_params6['status'] = ""
        db4.updateUseCase(usecase_params6, project_id)

    return json.dumps(result)

@app.route("/display_result", methods=["POST"])
def display_result():
    logger.info("In display_result_api")
    jsonObj = get_json_from_request(request)
    logger.info(" Json request " + str(jsonObj))
    # errorFlag = False
    # Read  the model parameter dictionary with default parameters from config
    # def_args = inception_config.args
    # args = def_args.copy()
    K.clear_session()
    try:
        threshold = jsonObj['threshold']
        project_id = jsonObj["usecaseid"]
        weights_path = jsonObj["weights_path"]
        errorFlag = False
        if (not threshold or threshold == None):
            logger.info("Please provide threshold value")
            errorFlag = True
        if (threshold<=0 or threshold>1):
            #verify the limits (should be in intervals 0.1,0.2 to 0.9)
            logger.info("invalid parameter, please check") 
            errorFlag = True
        if not errorFlag:
            logger.info("going to display_result_api file")
            res = vec_on_raster.result_raster(project_id,weights_path,threshold)
            logger.info("res---%s"%res)
            #/home/ubuntu/cv-asset/Satelllite_WB/6/model_dir/plots
            #output1 = create_thumbnail_jpegs(thumbnail_indices,indices_color)
            base_path1 = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)
            data_path1 = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)+ "/data_dir"
            model_name = path_leaf(weights_path).replace('.hdf5','')
            raster_path = "/home/ubuntu/cv-asset/Satelllite_WB/"+ str(project_id)+"/data_dir/pred_masks/"+str(model_name)+'/'+str(threshold)
            thumbnail_rasters = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)+ "/data_dir/thumbnails/rasters"
            only_rasters = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)+ "/data_dir/thumbnails/only_rasters/"
            raster_jpeg = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)+ "/data_dir/thumbnails/rasters_jpegs"
            output_jpegs = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)+ "/data_dir/thumbnails/output_jpegs"
            if not os.path.exists(base_path1):
                logger.info("Stuck in  Line no 847")
                os.mkdir(base_path1)
            if not os.path.exists(data_path1):
                logger.info("Stuck in  Line no 847")
                os.mkdir(data_path1)
            if not os.path.exists(thumbnail_rasters):
                logger.info("Stuck in  Line no 847")
                os.mkdir(thumbnail_rasters)
            if not os.path.exists(only_rasters):
                logger.info("Stuck in  Line no 850")
                os.mkdir(only_rasters)
            if not os.path.exists(raster_jpeg):
                logger.info("Stuck in  Line no 853")
                os.mkdir(raster_jpeg)
            if not os.path.exists(output_jpegs):
                logger.info("creating output jpegs folder")
                os.mkdir(output_jpegs)
            results = os.listdir(raster_path)
            logger.info("Results-------%s"%results)
            results1 = [x for x in results if x.startswith('raster')]
            logger.info("Results1-------%s"%results1)
            import shutil
            from shutil import copyfile
            #copyfile(src, dst)
            for img in results1:
                copyfile(raster_path+"/"+img,only_rasters +img)
                #n= tiff.imread(raster_path+"/"+img)
                #mg = path_leaf(img)
                #logger.info("i-------%s"%str(raster_path+"/"+img))
                #logger.info("Stuck in  writing satellite jpegs to folder")
                #cv2.imwrite(only_rasters +img,n)
            output = create_thumbnail_tiff(thumbnail_rasters,only_rasters,raster_jpeg)
            obj = Display()
            # rgb_files, result_tiffs = obj.display_result(threshold)
            if output:
                res_list = obj.display_result(threshold,project_id,weights_path)
            #res_list = str(res_list)
        
    except Exception as e:
        logger.error("Error while doing display result api: " + str(e) + " input: " + str(jsonObj))
    return json.dumps(res_list)  


@app.route("/display_model", methods=["POST"])
def display_model():
    logger.info("In display_models_api")
    jsonObj = get_json_from_request(request)
    logger.info(" Json request " + str(jsonObj))
    # errorFlag = False
    # Read  the model parameter dictionary with default parameters from config
    # def_args = inception_config.args
    # args = def_args.copy()
    K.clear_session()
    try:
        project_id = jsonObj["usecaseid"]
        errorFlag = False
        if (not project_id or project_id == None):
            logger.info("Please provide project_id value")
            errorFlag = True
        if not errorFlag:
            logger.info("going to display_models_api file")
            obj = Display_Models()
            # rgb_files, result_tiffs = obj.display_result(threshold)
            result = obj.display_models(project_id)
            #result = str(result)
            output = {}
            output["model list"] = result
        
    except Exception as e:
        logger.error("Error while doing display result api: " + str(e) + " input: " + str(jsonObj))
    return json.dumps(output)   




@app.route("/gdalinfo_parser", methods=["POST"])
def gdalinfo_parser():
    logger.info("In gdalinfo_parser api")
    jsonObj = get_json_from_request(request)
    logger.info(" Json request " + str(jsonObj))
    errorFlag = False
    # Read  the model parameter dictionary with default parameters from config
    # def_args = inception_config.args
    # args = def_args.copy()
    K.clear_session()
    try:
        project_id = jsonObj["usecaseid"]
        errorFlag = False
        if (not project_id or project_id == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if not errorFlag:
            logger.info("going to gdalinfo_parser_api file")
            obj = parsing_gdalinfo()
            output = obj.gdalinfo(project_id)
            logger.info("result: %s", output)
    except Exception as e:
        logger.error("Error while doing parsing gdalinfo api: " + str(e) + " input: " + str(jsonObj))
    return json.dumps(output)

@app.route("/multipagetif", methods=["POST"])
def multipagetif():
    from Satelllite_WB.src import satellite_config
    logger.info("In multipagetif api")
    jsonObj = get_json_from_request(request)
    logger.info(" Json request " + str(jsonObj))
    # errorFlag = False
    # Read  the model parameter dictionary with default parameters from config
    # def_args = inception_config.args
    # args = def_args.copy()
    K.clear_session()
    try:
        project_id = jsonObj["usecaseid"]
        classes_raw_bands = jsonObj["classes_raw_bands"]
        errorFlag = False
        if (not project_id or project_id == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if not errorFlag:
            logger.info("going to multipagetif_api file")
            obj = multipage()
            output = obj.to_multipage(project_id,classes_raw_bands)
            logger.info("result: %s", output)
    except Exception as e:
        logger.error("Error while doing this: " + str(e) + " input: " + str(jsonObj))
    return json.dumps(str(output))


@app.route("/annotations1", methods=["POST"])
def annotations1():
    # from Satelllite_WB.src import satellite_config
    # from Satelllite_WB.Landsat_8Bands.config_dir import data_config_land

    logger.info("In annotations1 api")
    logger.info(request.data)
    jsonObj = get_json_from_request(request)
    logger.info(" Json request " + str(jsonObj))
    project_id = jsonObj["usecaseid"]
    errorFlag = False
    # Read  the model parameter dictionary with default parameters from config
    # def_args = inception_config.args
    # args = def_args.copy()
    K.clear_session()
    try:
        if (not project_id or project_id == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if not errorFlag:
            logger.info("going to annotations1 file")
            '''

            dict_classes = {"class": ["vegetation", "water"]}
            classes = dict_classes["class"]
            data_dir = "/home/ubuntu/cv-asset/Satelllite_WB/"+str(project_id)+"/data_dir"
            input_rgb_dir_name = "rgb_mband"
            input_dir_name = "pan_mband"
            mask_dir_single = "gt_mband_classes"
            mask_dir_name = "gt_mband"
            stacked_dir_name = "stacked"
            jpegs_dir_name = "jpegs"
            '''
            obj = Annotations1()           
            output = obj.annotation_allfuns(project_id)
            logger.info("result: %s", output)

            obj_indices = calc_indices()
            indices_raw_dir = obj_indices.indices_all(project_id)
            logger.info("Indices calculation done")

            obj_color = Colour_Composition()
            output_color = obj_color.colourcomposition(project_id,indices_raw_dir)
            logger.info("Color composition done")

            
            result = {}
            result["message"]= output
    except Exception as e:
        logger.error("Error while doing this: " + str(e) + " input: " + str(jsonObj))
    return json.dumps(result)

@app.route("/annotations2", methods=["POST"])
def annotations2():
    # from Satelllite_WB.src import satellite_config
    # from Satelllite_WB.Landsat_8Bands.config_dir import data_config_land

    logger.info("In annotations2 api")
    jsonObj = get_json_from_request(request)
    logger.info(" Json request " + str(jsonObj))
    project_id = jsonObj["usecaseid"]
    classes = jsonObj["classes_list"]
    errorFlag = False
    # Read  the model parameter dictionary with default parameters from config
    # def_args = inception_config.args
    # args = def_args.copy()
    K.clear_session()
    try:
        if (not project_id or project_id == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if not errorFlag:
            logger.info("going to annotations2 file")
            '''
            dict_classes = {"class": ["vegetation", "water"]}
            classes = dict_classes["class"]
            data_dir = "/home/ubuntu/cv-asset/Satelllite_WB/"+str(project_id)+"/data_dir"
            input_rgb_dir_name = "rgb_mband"
            input_dir_name = "pan_mband"
            mask_dir_single = "gt_mband_classes"
            mask_dir_name = "gt_mband"
            stacked_dir_name = "stacked"
            jpegs_dir_name = "jpegs"
            '''
            obj = Annotations2()
            #output_anno =obj = Annotations1.annotation_pipeline()           
            output_anno = obj.annotation_allfuns(project_id,classes)
            logger.info("result: %s", output_anno)

            
            result = {}
            output = "success"
            result["message"]=output

            

    except Exception as e:
        logger.error("Error while doing this: " + str(e) + " input: " + str(jsonObj))
    return json.dumps(result)

import ntpath
def path_leaf(path):
    # to get the name of the weights
    head, tail = ntpath.split(path)
    return tail or ntpath.basename(head)

@app.route("/demo_satellite", methods=["POST"])
def demo_satellite_complete():
    logger.info("In Demo sat api")
    K.clear_session()
    jsonObj = get_json_from_request(request)
    #print("json object : ", jsonObj)
    weights_path = jsonObj["weights_path"] 
    project_id = jsonObj["usecaseid"]
    img_path = jsonObj["img_path"]
    N_CLASSES = jsonObj["N_CLASSES"]
    dict_model = jsonObj["dict_model"]
    dict_classes = jsonObj["dict_classes"]
    logger.info("Object--%s"%jsonObj)
    #thres_required = jsonObj["thres_required"] 
    #print("wp---",wp)
    errorFlag = False
    try:
        if (not project_id or project_id == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if not errorFlag:
            logger.info("going to main predict file")
            model_name = path_leaf(weights_path).replace('.hdf5','')
            threshold = 0.5
            demo_path = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)+"/data_dir/demo_images"
            image_test = path_leaf(img_path)
            for i in os.listdir(demo_path):
                if not(i == image_test ):
                    os.remove(demo_path+"/"+i)

            raster_path = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)+"/data_dir/pred_masks/"+str(model_name)+'/'+str(threshold)
            thumbnail_rasters = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)+ "/data_dir/thumbnails/demo_output"
            only_demo_rasters = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)+ "/data_dir/thumbnails/demo_rasters/"
            demo_final = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(project_id)+ "/data_dir/thumbnails/demo_final"
            #output_jpegs = "/home/ubuntu/cv_worksp#ace/data/Satelllite_WB/"+ str(project_id)+ "/data_dir/thumbnails/output_jpegs"
            if not os.path.exists(thumbnail_rasters):
                logger.info("Stuck in  Line no 847")
                os.mkdir(thumbnail_rasters)
            if not os.path.exists(only_demo_rasters):
                logger.info("Stuck in  Line no 848")
                os.mkdir(only_demo_rasters)
            if not os.path.exists(demo_final):
                logger.info("Stuck in  Line no 849")
                os.mkdir(demo_final)
            #global updated_weights_path
            #return_prediction
            out,response_dict = pred_demo.return_prediction(weights_path,project_id,img_path,N_CLASSES,dict_model,dict_classes)
            raster_comp = pred_demo.result_raster(project_id,weights_path,0.5,img_path)
            logger.info("Completed making raster file")
            
            
            results = os.listdir(raster_path)
            logger.info("Results-------%s"%results)
            results1 = [x for x in results if x.startswith('raster')]
            logger.info("Results1-------%s"%results1)
            import shutil
            from shutil import copyfile
            #copyfile(src, dst)
            for img in results1:
                copyfile(raster_path+"/"+img,only_demo_rasters +img)
            output = create_thumbnail_tiff(thumbnail_rasters,only_demo_rasters,demo_final)
            if out:
                output = {}
                output["message"]= "success"
                output["Path_of_rasters"]= (os.listdir(thumbnail_rasters)[0])#thumbnail_rasters + "/"+(os.listdir(thumbnail_rasters)[0])
                output["color_values"] = response_dict
            #logger.info("result: %s", output)
            logger.info("Demo api completed")
    
        
    except Exception as e:
        logger.error("Error while Prediction API: " + str(e) )

    return  json.dumps(output)

@app.route("/predict_mask", methods=["POST"])
def predict_mask():
    logger.info("In Pred Mask api")
    K.clear_session()
    jsonObj = get_json_from_request(request)
    #print("json object : ", jsonObj)
    weights_path = jsonObj["weights_path"] 
    project_id = jsonObj["usecaseid"]
    N_CLASSES = jsonObj["N_CLASSES"]
    dict_model = jsonObj["dict_model"]
    dict_classes = jsonObj["dict_classes"]
    logger.info("Object--%s"%jsonObj)
    #img_path = jsonObj["img_path"] 
    #thres_required = jsonObj["thres_required"] 
    #print("wp---",wp)
    errorFlag = False
    try:
        if (not project_id or project_id == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if not errorFlag:
            logger.info("going to main predict file")
            #global updated_weights_path
            out,response_dict = pred_pow.return_prediction(weights_path,project_id,N_CLASSES,dict_model,dict_classes)
            if out:
                output = {}
                output["message"]= "success"
                output["Path of mask files"]= out
                output["color_values"] = response_dict
            #logger.info("result: %s", output)
            logger.info("Prediction api completed")
    
        
    except Exception as e:
        logger.error("Error while Prediction API: " + str(e) )

    return  json.dumps(output)


@app.route("/get_classes", methods=["POST"])
def get_class():
    logger.info("In get classes api for Satellite Processng")
    jsonObj = get_json_from_request(request)
    #print("json object : ", jsonObj)
    class_array= jsonObj["classes"] 
    project_id = jsonObj["usecaseid"]
    #input_type = jsonObj["input_type"] 
    #img_path = jsonObj["img_path"] 
    #thres_required = jsonObj["thres_required"] 
    #print("wp---",wp)
    errorFlag = False
    try:
        if (not class_array or class_array == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if (not project_id or project_id == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if not errorFlag:
            logger.info("In get_classes method")
            parent_dir1 = "/home/ubuntu/cv-asset/Satelllite_WB/"+str(project_id)
            config_dir = parent_dir1 +"/config_dir"
            config_file = config_dir + "/data_config1"+".py"
            # write to config file
            logger.info("Line no 1182")
            dict2 = {'class':class_array}
            #write_vars_to_file(sys.stdout, dict1)
            logger.info("Line no 1185")
            file1 = open(config_file, 'a')
            logger.info("Line no 1188")
            file1.write('\ndict_classes = ' + json.dumps(dict2)+"\n")
            file1.close()            
            output = "Success"
            result = {}
            result["message"] = output      
    except Exception as e:
        logger.error("Error in get_classes api: " + str(e) )

    return json.dumps(result)

@app.route("/create_folder", methods=["POST"])
def create():
    logger.info("In create folder api")
    jsonObj = get_json_from_request(request)
    #print("json object : ", jsonObj)
    project_name= jsonObj["proj_name"] 
    project_id =jsonObj["usecaseid"] 
    input_type = jsonObj["input_type"] 
    #img_path = jsonObj["img_path"] 
    #thres_required = jsonObj["thres_required"] 
    #print("wp---",wp)
    errorFlag = False
    try:
        if (not project_name or project_name == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if (not project_id or project_id == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if (not input_type or input_type == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if (not(input_type == "raw" or input_type =="multiple")):
            #verify the upper limit
            logger.info("Invalid parameter, please check") 
            errorFlag = True
        if not errorFlag:
            logger.info("going to createfolder.py")
            #global updated_weights_path
            output = folder(input_type,project_name,project_id)
            logger.info("result: %s", output)
            result = {}
            result["message"]=output
            logger.info(" api completed")
    except Exception as e:
        logger.error("Error while creating  folders: " + str(e) )

    return json.dumps(result)



def tojpg(imag,path):
    logger.info("Stuck in Line no 1249")
    logger.info("converting to jpg")
    logger.info("Imag------------%s"%imag)
    logger.info("path------------%s"%path)
    logger.info("name of image--------%s"%glob.glob(imag))
    from PIL import Image
    #import imageio
    #image = imageio.imread('example.tif')
    import subprocess

    for name in glob.glob(imag):
        logger.info("name----%s"%name)
        image_in = name       
        logger.info("In line no 1271")
        e = path_leaf(name)
        logger.info("e-------%s"%str(e))
        if(e.endswith('tif')):
            logger.info("It ends with small tif")
            b = e.replace('.tif', '')
        else:
            logger.info("It ends with big TIF")
            b = e.replace('.TIF', '')
        #b = e.replace('.TIF', '')
        #im = Image.open(image_in)
        #logger.info("opened tiff file")
        image_out = path +"/"+ b + '.png'
        #rgbimg = Image.new("RGBA", im.size)
        #rgbimg.paste(im)
        #rgbimg.save(str(image_out))
        #subprocess.call(["gdal_translate","-co", "TILED=YES", "-co", "COMPRESS=LZW","-ot", "Byte", "-scale", image_in,str(image_out)  ])
        subprocess.call(["gdal_translate","-co", "TILED=YES", "-co", "COMPRESS=LZW","-ot", "Byte", "-scale", image_in,str(image_out)  ])
        #subprocess.call(["gdal_translate","-strict", "-ot", "Byte", "-scale", image_in,str(image_out)])
        logger.info("In line no 1268")
    logger.info("Conversion from tif/tiff to jpg completed!")

def create_thumbnail_tiff(thumbnail_clipped,clipped_bands,clipped_jpegs):
    clipped_images = os.listdir(clipped_bands)
    try:
        for i in clipped_images:
            tojpg(clipped_bands + i,clipped_jpegs) 
            logger.info("Jpeg conversion done")     
            #image_path = clipped_jpegs + "/"+ str(i).rstrip(".TIF")+".png"
            #e = path_leaf(name)
            #logger.info("e-------%s"%str(e))
            if(i.endswith('tif')):
                logger.info("It ends with small tif")
                b = i.replace('.tif', '')
            else:
                logger.info("It ends with big TIF")
                b = i.replace('.TIF', '')
            image_path = clipped_jpegs + "/"+ b+".png"
            #logger.info("name-----%s"%str(name))
            img = cv2.imread(image_path)
            logger.info("Image path----%s"%image_path)
            logger.info('Original Dimensions 1 : %s'%img.shape[1])
            logger.info('Original Dimensions 0: %s'%img.shape[0])
            scale_percent = 100 # percent of original size
            width = int(img.shape[1] * scale_percent / 100)
            height = int(img.shape[0] * scale_percent / 100)
            dim = (width, height)
            resized = cv2.resize(img, dim, interpolation = cv2.INTER_AREA)
            cv2.imwrite(thumbnail_clipped + "/"+ b+".jpg",resized)
            #return thumbnail_clipped
    except Exception as e:
        logger.error("Error in create thumbnail tiff" +  str(e))
    return thumbnail_clipped

def create_thumbnail_jpegs(thumbnail_indices,indices_color):
    jpeg_images = os.listdir(indices_color)
    try:
        for i in jpeg_images:
            #tojpg(clipped_bands + i,clipped_jpegs) 
            logger.info("Already in png format")     
            #image_path = clipped_jpegs + "/"+ str(i).rstrip(".TIF")+".png"
            #e = path_leaf(name)
            #logger.info("e-------%s"%str(e))
            #b = i.replace('.png', '')
            image_path = indices_color + "/"+ i
            #logger.info("name-----%s"%str(name))
            img = cv2.imread(image_path)
            logger.info("Image path----%s"%image_path)
            logger.info('Original Dimensions 1 : %s'%img.shape[1])
            logger.info('Original Dimensions 0: %s'%img.shape[0])
            scale_percent = 100 # percent of original size
            width = int(img.shape[1] * scale_percent / 100)
            height = int(img.shape[0] * scale_percent / 100)
            dim = (width, height)
            resized = cv2.resize(img, dim, interpolation = cv2.INTER_AREA)
            cv2.imwrite(thumbnail_indices + "/"+i ,resized)
            #return thumbnail_clipped
    except Exception as e:
        logger.error("Error in create thumbnail jpegs")
    return thumbnail_indices


@app.route("/thumbnail_satellite", methods=["POST"])
def create_tumbnail():
    req_json = get_json_from_request(request) # exected jsonArray
    try:
        useCaseId=req_json['usecaseid']
        logger.info("Line no 1253")
        base_path1 = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(useCaseId)
        data_path1 = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(useCaseId)+ "/data_dir"
        clipped_bands = "/home/ubuntu/cv-asset/Satelllite_WB/"+ str(useCaseId)+ "/data_dir/clippedbands/01/"     
        thumbnail_dir = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(useCaseId)+ "/data_dir/thumbnails"
        clipped_jpegs = "/home/ubuntu/cv-asset/Satelllite_WB/"+ str(useCaseId)+ "/data_dir/thumbnails/clipped_jpegs"
        thumbnail_clipped = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(useCaseId)+ "/data_dir/thumbnails/clippedbands"
        thumbnail_indices = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(useCaseId)+ "/data_dir/thumbnails/indices_color"
        indices_color = "/home/ubuntu/cv-asset/Satelllite_WB/"+ str(useCaseId)+"/data_dir/indices_color/01"
        jpegs = "/home/ubuntu/cv-asset/Satelllite_WB/"+ str(useCaseId)+"/data_dir/jpegs"
        only_jpegs = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(useCaseId)+ "/data_dir/thumbnails/only_jpegs"
        thumbnail_jpegs = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(useCaseId)+ "/data_dir/thumbnails/jpegs"
        rgb_jpegs="/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(useCaseId)+ "/data_dir/thumbnails/rgb_jpegs"
        demo_folder = "/home/ubuntu/cv_workspace/data/Satelllite_WB/"+ str(useCaseId)+ "/data_dir/demo_images"


        if not os.path.exists(base_path1):
            logger.info("Stuck in  Line no 1283")
            os.mkdir(base_path1)
        if not os.path.exists(data_path1):
            logger.info("Stuck in  Line no 1283")
            os.mkdir(data_path1)
        if not os.path.exists(thumbnail_dir):
            logger.info("Stuck in  Line no 1283")
            os.mkdir(thumbnail_dir)
        if not os.path.exists(thumbnail_clipped):
            logger.info("Stuck in  Line no 1286")
            os.mkdir(thumbnail_clipped)
        if not os.path.exists(clipped_jpegs):
            logger.info("Stuck in  Line no 1289")
            os.mkdir(clipped_jpegs)
        if not os.path.exists(thumbnail_indices):
            logger.info("Stuck in  Line no 1292")
            os.mkdir(thumbnail_indices)
        if not os.path.exists(only_jpegs):
            logger.info("Stuck in  Line no 1295")
            os.mkdir(only_jpegs)
        if not os.path.exists(thumbnail_jpegs):
            logger.info("Stuck in  Line no 1298")
            os.mkdir(thumbnail_jpegs)
        if not os.path.exists(rgb_jpegs):
            logger.info("Stuck in  Line no 1298")
            os.mkdir(rgb_jpegs)
        if not os.path.exists(demo_folder):
            logger.info("Stuck in  Line no 1301")
            os.mkdir(demo_folder)
        for img in glob.glob(jpegs+"/*.jpg"):
            n= cv2.imread(img)
            img = path_leaf(img)
            logger.info("i-------%s"%img)
            logger.info("Stuck in  writing satellite jpegs to folder")
            cv2.imwrite(only_jpegs +"/"+img,n)




        output = create_thumbnail_tiff(thumbnail_clipped,clipped_bands,clipped_jpegs)
        output1 = create_thumbnail_jpegs(thumbnail_indices,indices_color)
        output2 = create_thumbnail_jpegs(thumbnail_jpegs,only_jpegs)

        dir1 = thumbnail_clipped + '/'
        file_tif = os.listdir(dir1)
        for files in file_tif:
            if files.endswith("B1.jpg"):
                src= dir1 +str(files)
                dst = dir1+"B1.jpg"
                os.rename(src, dst)
            elif files.endswith("B2.jpg"):
                src= dir1 +str(files)
                dst =dir1 + "B2.jpg"
                os.rename(src, dst)
            elif files.endswith("B3.jpg"):
                src= dir1 +str(files)
                dst =dir1 +"B3.jpg"
                os.rename(src, dst)
            elif files.endswith("B4.jpg"):
                src= dir1 +str(files)
                dst =dir1 +"B4.jpg"
                os.rename(src, dst)
            elif files.endswith("B5.jpg"):
                src= dir1 +str(files)
                dst =dir1 +"B5.jpg"
                os.rename(src, dst)
            elif files.endswith("B6.jpg"):
                src= dir1 +str(files)
                dst =dir1 +"B6.jpg"
                os.rename(src, dst)
            elif files.endswith("B7.jpg"):
                src= dir1 +str(files)
                dst =dir1 +"B7.jpg"
                os.rename(src, dst)
            elif files.endswith("B8.jpg"):
                src= dir1 +str(files)
                dst =dir1 +"B8.jpg"
                os.rename(src, dst)
            elif files.endswith("B9.jpg"):
                src= dir1 +str(files)
                dst =dir1 +"B9.jpg"
                os.rename(src, dst)
            elif files.endswith("B10.jpg"):
                src=dir1 +str(files)
                dst =dir1 +"B10.jpg"
                os.rename(src, dst)
            elif files.endswith("B11.jpg"):
                src= dir1 +str(files)
                dst =dir1 +"B11.jpg"
                os.rename(src, dst)
            elif files.endswith("BQA.jpg"):
                src= dir1 +str(files)
                dst =dir1 +"BQA.jpg"
                os.rename(src, dst)



        files_rb = os.listdir(thumbnail_jpegs)
        files_rgb = [x for x in files_rb if x.startswith('01')]
        import shutil
        for file_1 in files_rgb:
            logger.info("forming rgb jpegs")
            shutil.copy(thumbnail_jpegs + '/' + file_1, rgb_jpegs+'/'+ "RGB.jpg" )
        
        x_b8 = os.listdir(thumbnail_clipped)
        file_not_reqd = [x for x in x_b8 if x not in ["B1.jpg","B2.jpg","B3.jpg","B4.jpg","B5.jpg","B6.jpg","B7.jpg"]]
        logger.info(file_not_reqd)
        if(file_not_reqd):
            for i in file_not_reqd:
                os.remove(thumbnail_clipped+"/"+i) 


        result = {}
        result['message']= "success"
        result["clipped bands thumbnails"]= output
        result["colored indicesthumbnails"]= output1
        result["jpegs thumbnails"]= rgb_jpegs
    except Exception as e:
        logger.error("Error while Iconizing satellite images: "+str(e)+" input: "+str(req_json))
        #jsonObj['Success']="0"
    return json.dumps(result)


@app.route("/train_unet", methods=["POST"])
def training_unet(): #path/x.hdf5
    logger.info("In Training")
    #logger.info("path in train----%s"% sys.path)
    K.clear_session()
    jsonObj = get_json_from_request(request)
    print("json object : ", jsonObj)
    from Satelllite_WB.src import satellite_config
    from Satelllite_WB.src.satellite_config import weights_path
    #if not os.path.exists(weights_path):
    #open(weights_path, 'a').close()
    try:
        N_EPOCHS = jsonObj["N_EPOCHS"] 
        PATCH_SZ = jsonObj["PATCH_SZ"]  # should divide by 16 #160
        BATCH_SIZE = jsonObj["BATCH_SIZE"] #threshold = 67
        TRAIN_SZ = jsonObj["TRAIN_SZ"]
        VAL_SZ = jsonObj["VAL_SZ"]
        classes_raw_bands = jsonObj["classes_raw_bands"]
        project_id = jsonObj["usecaseid"]
        #train_size = jsonObj["train_size"]
        test_size = jsonObj["test_size"]
        N_CLASSES = jsonObj["N_CLASSES"]
        VAL_SZ = (TRAIN_SZ * VAL_SZ)/100
        logger.info("Valsize-----------%s"%VAL_SZ)
        
        resumption_flag = 0
        errorFlag = False
        if (not project_id or project_id == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if (not test_size or test_size == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if (not N_EPOCHS or N_EPOCHS == None):
            logger.info("we are using  default value beacuse your input in None")
            N_EPOCHS = satellite_config.N_EPOCHS
            #errorFlag = True
        if (N_EPOCHS and not isinstance(int(N_EPOCHS), int)):
            logger.info("invalid N_EPOCHS type please enter numeric")
            errorFlag = True
        if (N_EPOCHS<=0 or N_EPOCHS>200):
            #verify the upper limit
            logger.info("invalid parameter, please check") 
            errorFlag = True
        if (not PATCH_SZ or PATCH_SZ == None):
            logger.info("we are using  default value beacuse your input in None")
            PATCH_SZ = satellite_config.PATCH_SZ
            #errorFlag = True
        if (PATCH_SZ and not isinstance(int(PATCH_SZ), int)):
            logger.info("invalid PATCH_SZ type please enter numeric")
            errorFlag = True
        if (PATCH_SZ<=0 or ((PATCH_SZ%16)!=0)):
            logger.info("invalid parameter, please check, Enter in multiples of 16") 
            errorFlag = True
        if (not BATCH_SIZE or BATCH_SIZE == None):
            logger.info("we are using  default value beacuse your input in None")
            BATCH_SIZE = satellite_config.BATCH_SIZE
            #errorFlag = True
        if (BATCH_SIZE and not isinstance(int(BATCH_SIZE), int)):
            logger.info("invalid BATCH_SIZE type please enter numeric")
            errorFlag = True
        if (BATCH_SIZE<=0):
            logger.info("invalid parameter, please check the value") 
            errorFlag = True
        if (not TRAIN_SZ or TRAIN_SZ == None):
            logger.info("we are using  default value beacuse your input in None")
            TRAIN_SZ = satellite_config.TRAIN_SZ
            #errorFlag = Teeerue
        if (TRAIN_SZ and not isinstance(int(TRAIN_SZ), int)):
            logger.info("invalid TRAIN_SZ type please enter numeric")
            errorFlag = True
        if (TRAIN_SZ<=0):
            logger.info("invalid parameter, please check") 
            errorFlag = True
        if (not VAL_SZ or VAL_SZ == None):
            logger.info("we are using  default value beacuse your input in None")
            VAL_SZ = satellite_config.VAL_SZ
            #errorFlag = True
        if (VAL_SZ and not isinstance(int(VAL_SZ), int)):
            logger.info("invalid VAL_SZ type please enter numeric")
            errorFlag = True
        if (VAL_SZ<=0):
            logger.info("invalid parameter, please check") 
            errorFlag = True
        if not errorFlag:
            logger.info("going to main train file")
            previous_weights_path = None  
            #global updated_weights_path
            if(resumption_flag ==1):
                logger.info(" need to resume training")
                previous_weights_path = None
                logger.info("part A")
                obj = multipage()
                mband_dir = obj.to_multipage(project_id,classes_raw_bands)
                o1 = train_test_split(test_size,project_id)
                o2 = annotation_split(test_size,project_id)
                N_BANDS = len(classes_raw_bands)
                output = train_unet.start_training(N_BANDS,N_CLASSES,N_EPOCHS,PATCH_SZ,BATCH_SIZE,TRAIN_SZ,VAL_SZ,previous_weights_path,project_id,mband_dir)
            else:
                logger.info("part B")
                logger.info("len---%d"%len(classes_raw_bands))
                #if(len(classes_raw_##bands))
                if (len(classes_raw_bands)>=1):
                    obj = multipage()
                    logger.info("multipaging started")
                    mband_dir = obj.to_multipage(project_id,classes_raw_bands)
                    logger.info("splitting train test")
                    logger.info("through this part")
                    #mband_dir = "/home/ubuntu/cv-asset/Satelllite_WB/" + str(project_id) + "/data_dir/mband/"

                    o1 = train_test_split(test_size,project_id)
                    o2 = annotation_split(test_size,project_id)
                    logger.info("splitting done")

                    N_BANDS = len(classes_raw_bands)
                    logger.info("bands--%s"%N_BANDS)
                    output = train_unet.start_training(N_BANDS,N_CLASSES,N_EPOCHS,PATCH_SZ,BATCH_SIZE,TRAIN_SZ,VAL_SZ,previous_weights_path,project_id,mband_dir,test_size)
                else :
                    input_type = "raw"
                    logger.info("came in this loop")
                    if(input_type == "raw"):
                        logger.info("came here")
                        
                        classes_raw_bands =  ["B1","B2","B3","B4","B5","B6","B10"]
                        obj = multipage()
                        #mband_dir = obj.to_multipage(project_id,classes_raw_bands)
                        mask_dir = "/home/ubuntu/cv-asset/Satelllite_WB/"+str(project_id)+"/data_dir/mband"
                        mband_dir = {"mask_dir":mask_dir}
                        logger.info("part second of B")
                        o1 = train_test_split(test_size,project_id)
                        o2 = annotation_split(test_size,project_id)
                        N_BANDS = len(classes_raw_bands)
                        logger.info("bands------%s"%N_BANDS)
                        output = train_unet.start_training(N_BANDS,N_CLASSES,N_EPOCHS,PATCH_SZ,BATCH_SIZE,TRAIN_SZ,VAL_SZ,previous_weights_path,project_id,mband_dir,test_size)
            logger.info("result: %s", output)
            logger.info("Training api completed")
    except Exception as e:
        from Satelllite_WB.src import db2
        usecase_params = {}
        usecase_params['status'] = "training_error"
        usecase_params6 = {}
        from Satelllite_WB.src import db4
        usecase_params6['status'] = ""
        db4.updateUseCase(usecase_params6, project_id)
        db2.updateUseCase(usecase_params, project_id)
        logger.error("Error while processing Training api: " + str(e) + " input: " + str(jsonObj))
        #output = str(e)

    return json.dumps(output)
@app.route("/pansharpen", methods=["POST"])
def pansharpening():
    logger.info("In the pan sharpening api")
    jsonObj = get_json_from_request(request)
    print("json object : ", jsonObj)
    from Satelllite_WB.src.satellite_config import directory_pan
    #if not os.path.exists(weights_path):
    #open(weights_path, 'a').close()
    #directory_pan = jsonObj["directory_pan"] 
    if not os.path.exists(directory_pan):
        os.makedirs(directory_pan)

    try:
        logger.info("going to main file")
        #global updated_weights_path
        output = pan(jsonObj)
        logger.info("result: %s", output)
        
    except Exception as e:
        logger.error("Error while doing this: " + str(e) + " input: " + str(output))
    return output


@app.route("/folder_creation", methods=["POST"])
def folder_create():
    logger.info("In folder creation api end point of Medical WB")
    jsonObj = get_json_from_request(request)
    #print("json object : ", jsonObj)
    project_id =jsonObj["usecaseid"] 
    # input_type = jsonObj["input_type"] 
    errorFlag = False
    try:
        if (not project_id or project_id == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        # if (not input_type or input_type == None):
        #     logger.info("Invalid value for this parameter")
        #     errorFlag = True
        # if (not(input_type == "dicom" or input_type =="nii")):
        #     #verify the upper limit
        #     logger.info("Invalid parameter, please check") 
        #     errorFlag = True
        if not errorFlag:
            logger.info("going to folder_creation api")
            output = folder(project_id)
            logger.info("result: %s", output)
            result = {}
            result["message"]=output
            logger.info("folder_creation api completed")
    except Exception as e:
        logger.error("Error while creating  folders: " + str(e) )

    return json.dumps(result)



@app.route("/analyzation", methods=["POST"])
def analyzation():
    logger.info("In analyze api end point of Medical WB")
    jsonObj = get_json_from_request(request)
    #print("json object : ", jsonObj)
    project_id =jsonObj["usecaseid"] 
    # input_type = jsonObj["input_type"] 
    errorFlag = False
    try:
        if (not project_id or project_id == None):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        # if (not input_type or input_type == None):
        #     logger.info("Invalid value for this parameter")
        #     errorFlag = True
        # if (not(input_type == "dicom" or input_type =="nii")):
        #     #verify the upper limit
        #     logger.info("Invalid parameter, please check") 
        #     errorFlag = True
        if not errorFlag:
            logger.info("going to folder_creation api")
            obj = Analyze()
            output = obj.allfunctioncalls(project_id)
            logger.info("result: %s", output)
            result = {}
            result["message"]=output
            logger.info("analyzation api completed")
    except Exception as e:
        logger.error("Error while creating  folders: " + str(e) )

    return json.dumps(result)

#medical workbench 

# Medical IS
@app.route("/extract",methods=['POST'])
def extract():
    baseheight = app_config.baseheight
    jsonObj = request.json
    useCaseId=jsonObj['useCaseId']
    is_mask=jsonObj['is_mask']
    annotations=jsonObj['annotations']
    if annotations == 'False':
        if is_mask =='False':
            input_type = 'train'
            folder_path = os.path.join(basepath, useCaseId, 'datasets', input_type)
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)
            try:
                logger.info('Extaction start')
                ext = extract_data(folder_path)
                logger.info('Extaction done')

                logger.info('Thumbnail start')
                # Create thumbnail folder
                thumbnail_path = os.path.join(basepath, useCaseId, 'thumbnail','datasets','train')
                if not os.path.exists(thumbnail_path):
                    os.makedirs(thumbnail_path)
                img_save_dir = os.path.join(basepath, useCaseId, 'thumbnail','datasets','train')
                print('Extraction done')
                
                # Thumbnail
                for filename in glob.glob(os.path.join(folder_path,'*')):
                    basename = os.path.basename(filename)
                    if not filename.endswith(('.rar','.tar','.zip','.gz')):
                        l = []
                        if filename.endswith('.png'):
                            logger.info('In Thumbnail png')
                            image = filename
                            imageid = os.path.basename(image)
                            l.append(image)
                            iu = ImageUtils(image)
                            image_resized = iu.resize_image(baseheight)
                            save_image_path = basename
                            scaled_image_path = iu.save_image(image_resized, save_image_path, img_save_dir)
                        else:
                            logger.info('In Thumbnail rar')
                            for image in glob.glob(os.path.join(folder_path,filename,'*')):
                                imageid = os.path.basename(image)
                                l.append(image)
                                iu = ImageUtils(image)
                                image_resized = iu.resize_image(baseheight)
                                save_image_path = basename+'_'+imageid
                                scaled_image_path = iu.save_image(image_resized, save_image_path, img_save_dir)
                
                # Get images out of folder
                filename = glob.glob(os.path.join(folder_path,'*'))
                if not filename[0].endswith('.png'):
                    folder_preprocess = os.path.join(basepath, useCaseId, 'datasets')
                    preprocess_image(folder_preprocess)
                            # print(save_image_path)
                logger.info('Thumbnail done')
                logger.info('Ext is:')
                logger.info(ext)
                response = {"status":"Success", "thumbnail_path":img_save_dir,"datatype":ext}
            except Exception as e:
                input_type = 'train'
                folder_path = os.path.join(basepath, useCaseId, 'datasets', input_type)
                # Delete rar files in usecase
                clear_dir(folder_path)
                response = {"status":"Error in Image extraction"}

        elif is_mask == 'True':
            input_type = 'train_mask'
            folder_path = os.path.join(basepath, useCaseId, 'datasets', input_type)
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)
            try:
                # Create mask path
                mask_path = os.path.join(basepath, useCaseId, 'datasets','train_mask')
                if not os.path.exists(mask_path):
                    os.makedirs(mask_path)
                print('Extraction started')
                ext = extract_data(folder_path)
                print('Extraction done')
                
                # Check count
                data_dir = {}
                data_dir["folder_path_image"] = os.path.join(basepath, useCaseId, 'datasets', 'train')
                data_dir["folder_path_mask"] = os.path.join(basepath, useCaseId, 'datasets', 'train_mask')
                count_dir = []
                for obj in data_dir:
                    obj_count = {}
                    for patient in glob.glob(os.path.join(data_dir[obj],'*')):
                        basename = os.path.basename(patient) 
                        if not patient.endswith('.rar'):
                            obj_count[basename]=len(glob.glob(os.path.join(patient,'*')))
                    count_dir.append(obj_count)
                
                folder_preprocess = os.path.join(basepath, useCaseId, 'datasets')
                preprocess_mask(folder_preprocess)

                # Check count of mask and images
                folder_path_image = glob.glob(os.path.join(basepath, useCaseId, 'datasets', 'train','*.png'))
                folder_path_mask = glob.glob(os.path.join(basepath, useCaseId, 'datasets', 'train_mask','*.png'))
                folder_path_image.sort()
                folder_path_mask.sort()

                l1 = []
                l2 = []

                for i in folder_path_image:
                    l1.append(os.path.basename(i))
                
                for i in folder_path_mask:
                    l2.append(os.path.basename(i))

                logger.info(l1)
                logger.info(l2)
                if l1 == l2:
                    response = {"status":"Success","datatype":ext}
                else:
                    response = {"message":"Image and Mask name mismatch"}

                # if count_dir[0]!=count_dir[1]:
                #     response = {"Status":"Failure","error":"Image and Mask mismatch","datatype":ext}
                # else:
                #     response = {"status":"Success","datatype":ext}
            except Exception as e:
                input_type = 'train_mask'
                folder_path = os.path.join(basepath, useCaseId, 'datasets', input_type)
                # Delete rar files in usecase
                clear_dir(folder_path)
                response = {"status":"Error in Mask extraction"}
    elif annotations =='True':
        if is_mask =='False':
            input_type = 'test'
            folder_path = os.path.join(basepath, useCaseId, 'datasets', input_type)
            if not os.path.exists(folder_path):
                os.makedirs(folder_path)
            try:
                ext = extract_data(folder_path)

                # Create thumbnail folder
                thumbnail_path = os.path.join(basepath, useCaseId, 'thumbnail','datasets','test')
                if not os.path.exists(thumbnail_path):
                    os.makedirs(thumbnail_path)
                img_save_dir = os.path.join(basepath, useCaseId, 'thumbnail','datasets','test')
                print('Extraction done')
                
                # Thumbnail
                for filename in glob.glob(os.path.join(folder_path,'*')):
                    basename = os.path.basename(filename)
                    if not filename.endswith(('.rar','.tar','.zip','.gz')):
                        l = []
                        if filename.endswith('.png'):
                            if not filename.endswith(('_mask.png','_predict.png')):
                                logger.info('In Thumbnail png')
                                image = filename
                                imageid = os.path.basename(image)
                                l.append(image)
                                iu = ImageUtils(image)
                                image_resized = iu.resize_image(baseheight)
                                save_image_path = basename
                                scaled_image_path = iu.save_image(image_resized, save_image_path, img_save_dir)
                        else:
                            logger.info('In Thumbnail rar')
                            for image in glob.glob(os.path.join(folder_path,filename,'*')):
                                imageid = os.path.basename(image)
                                l.append(image)
                                iu = ImageUtils(image)
                                image_resized = iu.resize_image(baseheight)
                                save_image_path = basename+'_'+imageid
                                scaled_image_path = iu.save_image(image_resized, save_image_path, img_save_dir)
                # Get images out of folder
                # filename = glob.glob(os.path.join(folder_path,'*'))
                # if not filename[0].endswith('.png'):
                folder_preprocess = os.path.join(basepath, useCaseId, 'datasets')
                preprocess_image_test(folder_preprocess)
                response = {"status":"Success", "thumbnail_path":img_save_dir,"datatype":ext}
            except Exception as e:
                input_type = 'test'
                folder_path = os.path.join(basepath, useCaseId, 'datasets', input_type)
                # Delete rar files in usecase
                clear_dir(folder_path)
                response = {"status":"Error in Image extraction"}
    else:
        response = {"status":"Failure"}
    return jsonify(response)

@app.route("/clear_masks", methods=['POST'])
def clear_masks():
    jsonObj = request.json
    useCaseId=jsonObj['useCaseId']
    folder_path = os.path.join(basepath, useCaseId, 'datasets', 'train_mask')
    try:
        clear_dir(folder_path)
        response = {"Status":"Success"}
    except:
        response = {"Status":"Error"}
    return jsonify(response)

@app.route("/pre_analysis", methods=['POST'])
def pre_analysis():
    jsonObj = request.json
    # Files to be deleted from this folder path
    rem_files = jsonObj['imageName']
    useCaseId=jsonObj['useCaseId']   
    folder_path = os.path.join(basepath, useCaseId, 'datasets')
    try:
        try:
            # Delete in train
            print('Pre_analysis in train')
            for file in rem_files:
                print(file)
                # Delete train image and mask
                del_image = os.path.join(folder_path,'train',file)
                os.remove(del_image)
                del_mask = os.path.join(folder_path,'train_mask',file)
                os.remove(del_mask)

                # Delete thumbnail
                del_image = os.path.join(basepath, useCaseId, 'thumbnail', 'datasets', 'train', file)
                os.remove(del_image)
        except:
            # Delete in test
            print('Pre_analysis in test')
            for file in rem_files:
                print(file)
                # Delete train image and mask
                del_image = os.path.join(folder_path,'test',file)
                os.remove(del_image)
                # Delete thumbnail
                del_image = os.path.join(basepath, useCaseId, 'thumbnail', 'datasets', 'test', file)
                os.remove(del_image)

        response = {"Status":"Success"}
    except:
        response = {"Status":"Error"}
    return jsonify(response)


# Preprocessing flip and rotate
@app.route("/preprocess_medical", methods=["POST"])
def Flipfilter():
    jsonObj = request.json
    useCaseId=jsonObj[0]['useCaseId']
    folder_path = os.path.join(basepath, useCaseId, 'datasets')
    img_save_dir = os.path.join(basepath, useCaseId, 'thumbnail','datasets','train')
    res = []
    for key in jsonObj:
        print(key)
        print(jsonObj)
        try:
            imgName =key["imgName"]
            basename = imgName.split('.')
            filterName = key["filterName"]
            logger.info('Inside preprocess')
            image_path = os.path.join(folder_path,'train',imgName)
            mask_path = os.path.join(folder_path, 'train_mask', imgName)
            print(filterName)
            # Check type of filter
            if filterName == 'flip_filter':
                flip_method = key["flip_method"]
                if (flip_method !="vertical" and flip_method !="horizontal" and flip_method !="both_side"):
                    print("invalid flip_method type please choose one")
                if(flip_method =="vertical"):
                    logger.info("Vertical flip")
                    flipCode=0
                    name = 'v'
                if(flip_method =="horizontal"):
                    logger.info("Horizontal flip")
                    flipCode=5
                    name = 'h'
                if(flip_method =="both_side"):
                    logger.info("Both side flip")
                    flipCode=-5
                    name = 'b'
                flipfunction = imgenh_api.flip_filter(image_path, flipCode)
                cv2.imwrite(os.path.join(folder_path, 'train', basename[0]+'_'+name+'.png'), flipfunction)
                

                # Flip mask file
                if os.path.exists(mask_path):
                    flipfunction = imgenh_api.flip_filter(mask_path, flipCode)
                    cv2.imwrite(os.path.join(folder_path,'train_mask', basename[0]+'_'+name+'.png'), flipfunction)
                response = {"imgName": imgName, "useCaseId": useCaseId, "flip_method": flip_method, "dataType": "datasets/train", "module": "Instance Segmentation", "filterName": filterName, "className": "", "opImgName": basename[0]+'_'+name+'.png', "opPath": "tmp", "Success": "1", "Duration": "0"}
                res.append(response)
                
            if filterName == "rotate_filter":
                print('Inside rotate')
                angle = key["angle"]
                print('angle:', angle)
                rotatefunction = imgenh_api.rotate_filter(image_path, angle)
                print(os.path.join(folder_path, 'train', basename[0]+'_'+str(angle)+'.png'))
                print('rotation done')
                cv2.imwrite(os.path.join(folder_path, 'train', basename[0]+'_'+str(angle)+'.png'), rotatefunction)

                print('Rotate image write')
                logger.info('In rotate')
                # Rotate mask file
                if os.path.exists(mask_path):
                    rotatefunction = imgenh_api.rotate_filter(mask_path, angle)
                    cv2.imwrite(os.path.join(folder_path,'train_mask', basename[0]+'_'+str(angle)+'.png'), rotatefunction)
                print('Rotate write done')
                response = {"imgName": imgName, "useCaseId": useCaseId, "angle": angle, "dataType": "datasets/train", "module": "Instance Segmentation", "filterName": filterName, "className": "", "opImgName": basename[0]+'_'+str(angle)+'.png', "opPath": "tmp", "Success": "1", "Duration": "0"}
                res.append(response)
        except Exception as e:
            response  = {"status":"Error"}
            res.append(response)
    # Thumbnail
    print('Inside thumbnail')
    baseheight = app_config.baseheight
    print(folder_path)
    for image in glob.glob(os.path.join(folder_path, 'train','*.png')):
        imageid = os.path.basename(image)
        iu = ImageUtils(image)
        image_resized = iu.resize_image(baseheight)
        save_image_path = imageid
        scaled_image_path = iu.save_image(image_resized, save_image_path, img_save_dir)
    print('Thumbnail done')
    return jsonify(res)

# Annotations
@app.route("/annotations", methods=['POST'])
def annotations():
    jsonObj = request.json
    useCaseId = jsonObj['useCaseId']
    istrain = jsonObj['isTrain']
    if istrain =='True':
        output_dir = os.path.join(basepath, useCaseId, 'datasets','train_mask')
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        json_dir = glob.glob(os.path.join(basepath, useCaseId, 'datasets','train','*.json'))
        try:
            for jf in json_dir:
                from_json(jf, output_dir)
            response = {'Status':'Success'}
        except:
            response = {'Status':'Error'}

    # For test annotations
    # Saving _mask in same test dir as no splitting required
    if istrain =='False':
        output_dir = os.path.join(basepath, useCaseId, 'datasets','test')
        if not os.path.exists(output_dir):
            os.makedirs(output_dir)
        json_dir = glob.glob(os.path.join(basepath, useCaseId, 'datasets','test_annotated','*.json'))
        try:
            for jf in json_dir:
                from_json(jf, output_dir)
            response = {'Status':'Success'}
        except:
            response = {'Status':'Error'}
    return jsonify(response)

@app.route("/demo_extract", methods=["POST"])
def demo_extract_medical():
    logger.info("In Medical wb demo_extract api")
    JsonObj = get_json_from_request(request)
    logger.info(" Json request " + str(JsonObj))
    K.clear_session()
    try:
        useCaseId = JsonObj["useCaseId"]
        extract_file = JsonObj["imageName"]
        
        errorFlag = False
        if(not useCaseId):
            logger.info("Invalid value for this parameter")
            errorFlag = True
        if not errorFlag:
            logger.info("going to extract_demo file")
            img_name, output = make_folders(extract_file,str(useCaseId))
            logger.info("result: %s", output)
            JsonObj["imageName"] = img_name
            JsonObj["output"] = output
            if(JsonObj["output"]== "Extraction successful"):
                JsonObj["status"] = "success" 
            else:
                JsonObj["status"] = "failed"
    except Exception as e:
        logger.error("Error while doing demo_extract api: " + str(e) + " input: " + str(JsonObj))
    return jsonify(JsonObj)

@app.route("/demo_predict", methods=["POST"])
def demo_predict_medical():
    from tensorflow.keras import backend as K
    ress = []
    K.clear_session()
    logger.info("In Medical wb demo_predict api")
    JsonObj = get_json_from_request(request)
    logger.info(" Json request " + str(JsonObj))
    
    try:
        logger.info("inside try")
        useCaseId = JsonObj["usecaseid"]
        input_type = JsonObj["imageName"]
        
        
        logger.info("going to demo_predict file")
        K.clear_session()
        output = predict_medical_demo(input_type, str(useCaseId))
        K.clear_session()
        logger.info("result: %s", output)
        JsonObj["imageName"] = output
        JsonObj["detectionResult"] = {}
        #logger.info("done")
        ress.append(JsonObj)
    
            
    except Exception as e:
        logger.error("Error while doing demo_extract api: " + str(e) + " input: " + str(JsonObj))
    return jsonify(ress)

# OVerlay medical
@app.route("/overlay", methods=['POST'])
def overlay_med():
    baseheight = app_config.baseheight
    jsonObj = request.json
    useCaseId = jsonObj['useCaseId']
    folder_path = os.path.join(basepath, useCaseId, 'datasets')
    image = glob.glob(os.path.join(folder_path,'train','*.png'))
    mask = glob.glob(os.path.join(folder_path,'train_mask','*.png'))

    print(len(image),len(mask))
    try:
        # Create overlay folder
        overlay_path = os.path.join(folder_path,'overlay')
        if not os.path.exists(overlay_path):
            os.makedirs(overlay_path)

        for i in range(len(image)):
            basename = os.path.basename(image[i])
            img = cv2.imread(image[i])
            msk = cv2.imread(mask[i])
            # Create green mask
            mask_image_gray = cv2.cvtColor(msk, cv2.COLOR_BGR2GRAY)
            mask_a = cv2.bitwise_and(msk, msk, mask=mask_image_gray)
            mask_coord = np.where(mask_a!=[0,0,0])
            mask_a[mask_coord[0],mask_coord[1],:]=[0,255,0]
            overlay = cv2.addWeighted(img,1, mask_a, 0.3, 0)
            cv2.imwrite(os.path.join(overlay_path,basename), overlay)
        
        # Thumbnails   
        thumbnail_path = os.path.join(basepath, useCaseId, 'thumbnail','datasets','overlay')
        if not os.path.exists(thumbnail_path):
            os.makedirs(thumbnail_path)
        img_save_dir = thumbnail_path
        for image in glob.glob(os.path.join(overlay_path,'*.png')):
            imageid = os.path.basename(image)
            iu = ImageUtils(image)
            image_resized = iu.resize_image(baseheight)
            save_image_path = imageid
            scaled_image_path = iu.save_image(image_resized, save_image_path, img_save_dir)
            # print(save_image_path)
        response = {"Status":"Success"}
    except:
        response = {"Status":"Error occured"}
    return jsonify(response)

# Training Medical
@app.route("/train_medical", methods=['POST'])
def train_medical():
    jsonObj = request.json
    useCaseId = jsonObj['useCaseId']
    batch_size = jsonObj['batch_size']
    lr = jsonObj['learning_rate']
    epochs = jsonObj['nos_of_epochs']
    # Files to be deleted from this folder path
    folder_path = os.path.join(basepath, useCaseId, 'datasets')

    # Create masks from json
    output_dir = os.path.join(basepath, useCaseId, 'datasets','train_mask')
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    
    json_dir = glob.glob(os.path.join(basepath, useCaseId, 'datasets','train','*.json'))
    with open(json_dir[0]) as f:    # check if json is not empty
        data = json.load(f)
        if len(data)>0:
            for jf in json_dir:
                if os.path.exists(jf):
                    gen_blank_train(folder_path)
                from_json(jf, output_dir)

    #update database with train status before starting to train.
    usecase_params = {}
    usecase_params['status'] = inception_config.DB_STATUS_PROGRESS
    usecase_params['testaccuracy'] = -1
    usecase_params['trainaccuracy'] = -1
    usecase_params['valaccuracy'] = -1
    print(" ======> ", usecase_params, " ======> ", useCaseId)
    db.updateUseCase(usecase_params, useCaseId)

    # Training starts
    # Create data for preprocessing
    gen_data(folder_path)

    response = train_medical_unet(folder_path, batch_size, lr, epochs)
    try:
        #update DB with train stats
        training_status = None
        if  response['status'] == "SUCCESS":
            usecase_params = {}
            usecase_params['status'] = inception_config.DB_STATUS_COMPLETE
            usecase_params['testaccuracy'] = -1
            usecase_params['trainaccuracy'] = response['Train accuracy']
            usecase_params['valaccuracy'] = response['Validation accuracy']
            print(" ======> ", usecase_params, " ======> ", useCaseId)
            db.updateUseCase(usecase_params, useCaseId)
            training_status = "Training completed"
        else:
            usecase_params = {}
            usecase_params['status'] = ""
            #usecase_params['testaccuracy'] = 0
            #usecase_params['trainaccuracy'] = 0
            #usecase_params['valaccuracy'] = 0
            print(" ======> ", usecase_params, " ======> ", useCaseId)
            db.updateUseCase(usecase_params, useCaseId)
            training_status = "Training ended with error"

        # Training status
        #return training_status

    except Exception as e:
        logger.info("Error updating train status in DB ")
        logger.error(e)
        usecase_params = {}
        usecase_params['status'] = ""
        # usecase_params['testaccuracy'] = 0
        # usecase_params['trainaccuracy'] = 0
        # usecase_params['valaccuracy'] = 0
        print(" ======> ", usecase_params, " ======> ", useCaseId)
        db.updateUseCase(usecase_params, useCaseId)

        # Training status
        training_status = "Training ended with error."
        #return training_status

    # Delete augmentation folder
    check_del(os.path.join(folder_path, 'segmentation', 'train', 'augmentation'))

    message = {"status":training_status}
    return jsonify(message)


@app.route("/predict", methods=['POST'])
def predict():
    K.clear_session()
    jsonObj = request.json
    useCaseId = jsonObj['useCaseId']
    # weights_path = jsonObj['weights_path']
    folder_path = os.path.join(basepath, useCaseId, 'datasets')

    # # Create blank masks
    # gen_blank(os.path.join(folder_path,'test'))

    # Create masks
    output_dir = os.path.join(basepath, useCaseId, 'datasets','test')
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    json_dir = glob.glob(os.path.join(basepath, useCaseId, 'datasets','test_annotated','*.json'))  # test_annotated location to be checked
    for jf in json_dir:
        from_json(jf, output_dir)

    # Predict
    print('folder path')
    print(folder_path)
    test_dir = predict_medical(folder_path)
    try:
        logger.info('IOU from JSON')
        iou = accuracy_assessment(test_dir)
        iou = str(iou)
    except:
        logger.info('Default IOU')
        iou = str(0)
    response = {"IOU":iou}
    return jsonify(response)


@app.route("/mean_filter", methods=["POST"])
def meanFilter():

    logger.info("Median filter")
    req_json = get_json_from_request(request)
    for jsonObj in req_json:
        try:
            errorFlag= False
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            dataType = getReqeuestParam(jsonObj, "dataType")
            className = getReqeuestParam(jsonObj, "className")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")
            H1_filter = getReqeuestParam(jsonObj, "H1_filter", "")
            H2_filter = getReqeuestParam(jsonObj, "H2_filter", "")
            # only odd values
            templateWindowSize = getReqeuestParam(jsonObj, "templateWindowSize", "")
            # only odd values
            searchWindowSize = getReqeuestParam(jsonObj, "searchWindowSize", "")
            jsonObj[SUCCESS] = "0"
            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName
            if os.path.isfile(image_path):
                image = cv2.imread(image_path)
                if len(image.shape) != 3:
                    logger.info("please upload RGB image ")
                    errorFlag = True
            else:
                logger.info('Image uploading  Failed!!!')
                errorFlag = True

            if (H1_filter and not isinstance(int(H1_filter), int)):
                logger.info("invalid H1_filter type please enter numeric")
                errorFlag = True
            if (not H1_filter or H1_filter == None):
                H1_filter = ip_config.H1_filter  # 25
                logger.info("we are using H1_filter default value beacuse your input in None")

            if (H2_filter and not isinstance(int(H2_filter), int)):
                logger.info("invalid H2_filter type please enter numeric")
                errorFlag = True

            if (not H2_filter or H2_filter == None):
                H2_filter = ip_config.H2_filter  # 25
                logger.info("we are using H2_filter default value beacuse your input in None")

            if (templateWindowSize and not isinstance(int(templateWindowSize), int)):
                logger.info("invalid templateWindowSize type please enter numeric")
                errorFlag = True

            if (not templateWindowSize or templateWindowSize == None):
                templateWindowSize = ip_config.templateWindowSize
                logger.info("we are using templateWindowSize default value beacuse your input in None")

            if (searchWindowSize and not isinstance(int(searchWindowSize), int)):
                logger.info("invalid searchWindowSize type please enter numeric")
                errorFlag = True

            if (not searchWindowSize or searchWindowSize == None):
                searchWindowSize = ip_config.searchWindowSize  # 25
                logger.info("we are using searchWindowSize default value beacuse your input in None")

            st = time.time()
            if not errorFlag:
                Meanfuncation = imgenh_api.denoise_fastNlMeansColored(image_path, int(H1_filter), int(H2_filter),
                                                                      int(templateWindowSize),
                                                                      int(searchWindowSize))
                cv2.imwrite(save_image_path, Meanfuncation)
            en = time.time()
            jsonObj[DURATION] = str(int(en - st))
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            logger.info("Median filter completed")
        except Exception as e:
            logger.error("Error while Pre processing median filter: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)


@app.route("/wiener_filter", methods=["POST"])
def wienerfilter():
    logger.info("Wiener Filter")
    req_json = get_json_from_request(request)  # expected jsonArray

    for jsonObj in req_json:
        try:
            errorFlag = False
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            dataType = getReqeuestParam(jsonObj, "dataType")
            className = getReqeuestParam(jsonObj, "className")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName")
            opPath = getReqeuestParam(jsonObj, "opPath")
            np_oneX1 = getReqeuestParam(jsonObj, "np_oneX1")
            np_oneX2 = getReqeuestParam(jsonObj, "np_oneX2")
            np_one_denominator = getReqeuestParam(jsonObj, "np_one_denominator")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")
            jsonObj[SUCCESS] = "0"

            # useCaseId = jsonObj["useCaseId"]
            # dataType = ""
            # if ("dataType" in jsonObj): dataType = jsonObj["dataType"]
            # className = ""
            # if ("className" in jsonObj): className = jsonObj["className"]
            # imgName = jsonObj["imgName"]
            # opImgName = imgName
            # if ("opImgName" in jsonObj): opImgName = jsonObj["opImgName"]
            # opPath = ""
            # if ("opPath" in jsonObj): opPath = jsonObj["opPath"]
            # filterName = ""
            # if ("filterName" in jsonObj): filterName = jsonObj["filterName"]
            # np_oneX1 = ""
            # if ("np_oneX1" in jsonObj): np_oneX1 = jsonObj["np_oneX1"]
            # np_oneX2 = ""
            # if ("np_oneX2" in jsonObj): np_oneX2 = jsonObj["np_oneX2"]
            # np_one_denominator = ""
            # if ("np_one_denominator" in jsonObj): np_one_denominator = jsonObj["np_one_denominator"]

            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
            save_image_path = image_path
            # logger.info(image_path)
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName

            # save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName
            img = img_util.validate_input(image_path)
            if img is None:
                logger.info("Image uploading  Failed!!!")
                errorFlag = True

            # if (np_oneX1 and not isinstance(int(np_oneX1), int)):
            # return ("invalid type please enter numeric")

            if (not np_oneX1 or np_oneX1 == None):
                np_oneX1 = ip_config.np_oneX1
                logger.info("we are using default value beacuse your input in None")

            if (np_oneX2 and not isinstance(int(np_oneX2), int)):
                logger.info("invalid type please enter numeric")
                errorFlag = True

            if (not np_oneX2 or np_oneX2 == None):
                np_oneX2 = ip_config.np_oneX2  # 25
                logger.info("we are using default value beacuse your input in None")

            if (np_one_denominator and not isinstance(int(np_one_denominator), int)):
                logger.info("invalid type please enter numeric")
                errorFlag = True

            if (not np_one_denominator or np_one_denominator == None):
                np_one_denominator = ip_config.np_one_denominator  # 25
                logger.info("we are using default value beacuse your input in None")

            if (int(np_oneX1) < 1 or int(np_oneX2) < 1 or int(np_one_denominator) < 1):
                logger.info("Please try value greater than 0")
                errorFlag = True

            if not errorFlag:
                Wienerfunction = imgenh_api.wiener_filter(image_path, int(np_oneX1), int(np_oneX2),
                                                          int(np_one_denominator))

                logger.info("Saving processed image")

                # destination = os.path.join(img_save_dir, imgName)

                # remove previous copy of the same file if any
                # if os.path.isfile(save_image_path):
                # os.remove(save_image_path)

                # cv2.imwrite(destination, Wienerfuncation)
                scipy.misc.imsave(save_image_path, Wienerfunction)
                if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                    jsonObj[SUCCESS] = "1"
                elif os.path.isfile(save_image_path):
                    os.remove(save_image_path)
                # jsonObj[SUCCESS] = "1"
            # return destination
            # return send_image(img_save_dir, filename)

        except Exception as e:
            logger.error("Error while Pre processing wiener: " + str(e) + " input: " + str(jsonObj))
            jsonObj[SUCCESS] = "0"

    return json.dumps(req_json)

@app.route("/richardson_filter", methods=["POST"])
def richardsonfilter():
    try:
        np_oneX1 = ip_config.np_oneX1
        np_oneX2 = ip_config.np_oneX2
        np_one_denominator = ip_config.np_one_denominator
        filename = request.form["image"]

        imgpath = os.path.join(img_input_dir, filename)
        img = img_util.validate_input(imgpath)
        if img is None:
            return ('Image uploading  Failed!!!')

        np_oneX1 = request.form["x1"]  # user input
        np_oneX2 = request.form["x2"]
        np_one_denominator = request.form["x3"]

        if (np_oneX1 and not isinstance(int(np_oneX1), int)):
            return("invalid type please enter numaric")

        if (not np_oneX1 or np_oneX1 == None):
            np_oneX1 = ip_config.np_oneX1
            logger.info("we are using default value beacuse your input in None")

        if (np_oneX2 and not isinstance(int(np_oneX2), int)):
            return("invalid type please enter numaric")

        if (not np_oneX2 or np_oneX2 == None):
            np_oneX2 = ip_config.np_oneX2  # 25
            logger.info("we are using default value beacuse your input in None")

        if (np_one_denominator and not isinstance(int(np_one_denominator), int)):
            return("invalid type please enter numaric")

        if (not np_one_denominator or np_one_denominator == None):
            np_one_denominator = ip_config.np_one_denominator  # 25
            logger.info("we are using default value beacuse your input in None")

        if (int(np_oneX1) < 1 or int(np_oneX2) < 1 or int(np_one_denominator) < 1):
            return("Please try value greater than 0")

        richardsonfuncation = imgenh_api.richardson_filter(imgpath, int(np_oneX1), int(np_oneX2), int(np_one_denominator))

        logger.info("Saving processed image")
        destination = os.path.join(img_save_dir, filename)

        # remove previous copy of the same file if any
        if os.path.isfile(destination):
            os.remove(destination)

        # cv2.imwrite(destination, richardsonfuncation)
        scipy.misc.imsave(destination, richardsonfuncation)

        # return destination
        return send_image(img_save_dir, filename)

    except Exception as e:
        logger.exception(e)
        return("Something went wrong!")


@app.route("/gaussian_filter", methods=["POST"])
def Gaussianfilter():
    logger.info("Gaussian filter")
    req_json = get_json_from_request(request)
    for jsonObj in req_json:
        try:
            errorFlag = False
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            dataType = getReqeuestParam(jsonObj, "dataType")
            className = getReqeuestParam(jsonObj, "className")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")
            # positive and odd
            x1 = getReqeuestParam(jsonObj, "kernal_h", "")
            x2 = getReqeuestParam(jsonObj, "kernal_w", "")
            x3 = getReqeuestParam(jsonObj, "sigmaX", "")
            jsonObj[SUCCESS] = "0"
            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName
            img = img_util.validate_input(image_path)
            if img is None:
                errorFlag = True
            if (x1 and not isinstance(int(x1), int) and x1 != None):
                logger.info("invalid x1 type please enter numeric")
                errorFlag = True
            if (not x1 or x1 == None):
                x1 = ip_config.x1  # 25
                # print ("x1 ===",x1)
                logger.info("we are using x1 default value beacuse your input in None")
            if (x2 and not isinstance(int(x2), int) and x2 != None):
                errorFlag = True
                logger.info("invalid x2 type please enter numeric")
            if (not x2 or x2 == None):
                x2 = ip_config.x2  # 25
                # print ("H1_filter ===",H1_filter)
                logger.info("we are using x2 default value beacuse your input in None")
            if (x3 and not isinstance(int(x3), int) and x3 != None):
                errorFlag = True
                logger.info("invalid x3 type please enter numeric")
            if (not x3 or x3 == None):
                x3 = ip_config.x3  # 25
                # print ("H1_filter ===",H1_filter)
                logger.info("we are using x3 default value beacuse your input in None")
            if (int(x1) < 1 or int(x2) < 1):
                # np_oneX1=ip_config.np_oneX1
                errorFlag = True
                logger.info("Please try value greater than 0")

            st = time.time()
            if not errorFlag:
                Gaussian_blurfuncation = imgenh_api.Gaussian_blur_filter(image_path, int(x1), int(x2), int(x3))
                cv2.imwrite(save_image_path, Gaussian_blurfuncation)
            en = time.time()
            jsonObj[DURATION] = str(int(en - st))
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            logger.info("Gaussian filter completed")
        except Exception as e:
            logger.error("Error while Pre processing gaussian filter: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)

@app.route("/median_blur_filter", methods=["POST"])
def Medianfilter():
    logger.info("Median blurring filter")
    req_json = get_json_from_request(request)
    for jsonObj in req_json:
        try:
            errorFlag = False
            jsonObj_new=check_filter_parameter(jsonObj)
            path=json.loads(jsonObj_new)
            image_path=path["image_path"]
            save_image_path=path["save_image_path"]
            img = img_util.validate_input(image_path)
            # positive and odd
            k_size = getReqeuestParam(jsonObj, "k_size", "")
            if img is None:
                errorFlag = True
            if (k_size and not isinstance(int(k_size), int) and k_size != None):
                logger.info("invalid k_size type please enter numeric")
                errorFlag = True
            if (not k_size or k_size == None):
                k_size = ip_config.k_size  # 5
                # print ("k_size ===",k_size)
                logger.info("we are using k_size default value beacuse your input in None")
            if (int(k_size) < 2):
                # k_size=ip_config.k_size
                errorFlag = True
                logger.info("Please try value greater than 1")
            if (int(k_size) % 2==0):
                # k_size=ip_config.k_size
                errorFlag = True
                logger.info("Please try odd values for k_size")

            st = time.time()
            if not errorFlag:
                Median_blurfuncation = imgenh_api.Median_blur_filter(image_path, int(k_size))
                cv2.imwrite(save_image_path, Median_blurfuncation)
            en = time.time()
            jsonObj[DURATION] = str(int(en - st))
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            logger.info("Median blur filter completed")
        except Exception as e:
            logger.error("Error while Pre processing median blur filter: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)

@app.route("/blur_filter", methods=["POST"])
def blurfilter():
    logger.info("Blurring")
    req_json = get_json_from_request(request)
    for jsonObj in req_json:
        try:
            errorFlag = False
            jsonObj_new=check_filter_parameter(jsonObj)
            path=json.loads(jsonObj_new)
            image_path=path["image_path"]
            save_image_path=path["save_image_path"]
            img = img_util.validate_input(image_path)
            # positive
            kernal_height = getReqeuestParam(jsonObj, "kernal_height", "")
            kernal_width = getReqeuestParam(jsonObj, "kernal_width", "")
            if img is None:
                errorFlag = True
            if (kernal_height and not isinstance(int(kernal_height), int) and kernal_height != None):
                logger.info("invalid kernal_height type please enter numeric")
                errorFlag = True
            if (not kernal_height or kernal_height == None):
                kernal_height = ip_config.kernal_height  # 5
                # print ("kernal_h ===",kernal_h)
                logger.info("we are using kernal_height default value beacuse your input in None")
            if (kernal_width and not isinstance(int(kernal_width), int) and kernal_width != None):
                errorFlag = True
                logger.info("invalid kernal_width type please enter numeric")
            if (not kernal_width or kernal_width == None):
                kernal_width = ip_config.kernal_width  # 5
                # print ("kernal_w ===",kernal_w)
                logger.info("we are using kernal_width default value beacuse your input in None")
            if (int(kernal_height) < 1 or int(kernal_width) < 1):
                errorFlag = True
                logger.info("Please try value greater than 0")

            st = time.time()
            if not errorFlag:
                blurfuncation = imgenh_api.blur_filter(image_path, int(kernal_height), int(kernal_width))
                cv2.imwrite(save_image_path, blurfuncation)
            en = time.time()
            jsonObj[DURATION] = str(int(en - st))
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            logger.info("Blurring completed")
        except Exception as e:
            logger.error("Error while Pre processing blur filter: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)

@app.route("/flip_filter", methods=["POST"])
def flipfilter():
    logger.info("Flip filter started")
    req_json = get_json_from_request(request)
    for jsonObj in req_json:
        try:
            errorFlag = False
            jsonObj_new=check_filter_parameter(jsonObj)
            path=json.loads(jsonObj_new)
            image_path=path["image_path"]
            save_image_path=path["save_image_path"]
            img = img_util.validate_input(image_path)
            # can be positive,negative or 0.
            flip_method = getReqeuestParam(jsonObj, "flip_method", "")
            img = img_util.validate_input(image_path)
            if img is None:
                errorFlag = True
            if (flip_method !="vertical" and flip_method !="horizontal" and flip_method !="both_side"):
                logger.info("invalid flip_method type please choose one")
                errorFlag = True
            if(flip_method =="vertical"):
                logger.info("Vertical flip")
                flipCode=0
            if(flip_method =="horizontal"):
                logger.info("Horizontal flip")
                flipCode=5
            if(flip_method =="both_side"):
                logger.info("Both side flip")
                flipCode=-5

            st = time.time()
            if not errorFlag:
                flipfuncation = imgenh_api.flip_filter(image_path, int(flipCode))
                cv2.imwrite(save_image_path, flipfuncation)
            en = time.time()
            jsonObj[DURATION] = str(int(en - st))
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            logger.info("Flip filter completed")
        except Exception as e:
            logger.error("Error while Pre processing flip filter: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)
@app.route("/rotate_filter", methods=["POST"])
def Rotatefilter():
    logger.info("Rotate filter started")
    req_json = get_json_from_request(request)
    for jsonObj in req_json:
        try:
            errorFlag = False
            jsonObj_new=check_filter_parameter(jsonObj)
            path=json.loads(jsonObj_new)
            image_path=path["image_path"]
            save_image_path=path["save_image_path"]
            img = img_util.validate_input(image_path)
            angle = getReqeuestParam(jsonObj, "angle", "")
            if img is None:
                errorFlag = True
            if (angle and not isinstance(int(angle), int) and angle != None):
                logger.info("invalid angle type please enter numeric")
                errorFlag = True
            if (not angle or angle == None):
                angle = ip_config.angle  # 90
                # print ("angle ===",angle)
                logger.info("we are using angle default value beacuse your input in None")

            st = time.time()
            if not errorFlag:
                rotatefuncation = imgenh_api.rotate_filter(image_path, int(angle))
                cv2.imwrite(save_image_path, rotatefuncation)
            en = time.time()
            jsonObj[DURATION] = str(int(en - st))
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            logger.info("Rotate filter completed")
        except Exception as e:
            logger.error("Error while Pre processing Rotate filter: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)

@app.route("/image_dilation", methods=["POST"])
def imageDilation():
    logger.info("image dilation filter")
    req_json = get_json_from_request(request)
    for jsonObj in req_json:
        try:
            errorFlag = False
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            dataType = getReqeuestParam(jsonObj, "dataType")
            className = getReqeuestParam(jsonObj, "className")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")
            kernal_h = getReqeuestParam(jsonObj, "kernal_h", "")
            kernal_w = getReqeuestParam(jsonObj, "kernal_w", "")
            iteration_num = getReqeuestParam(jsonObj, "iteration_num", "")
            jsonObj[SUCCESS] = "0"
            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName
            img = img_util.validate_input(image_path)
            if img is None:
                errorFlag = True
                logger.info('Image uploading  Failed!!!')
            if (kernal_h and not isinstance(int(kernal_h), int) and kernal_h != None):
                errorFlag = True
                logger.info("invalid kernal_h type please enter numeric")

            if (not kernal_h or kernal_h == None):
                kernal_h = ip_config.kernal_h  # 25
                # print("kernal_h ===", kernal_h)
                logger.info("we are using kernal_h default value beacuse your input in None")
            if (kernal_w and not isinstance(int(kernal_w), int) and kernal_w != None):
                errorFlag = True
                logger.info("invalid kernal_w type please enter numeric")
            if (not kernal_w or kernal_w == None):
                kernal_w = ip_config.kernal_w  # 25
                # print ("H1_filter ===",H1_filter)
                logger.info("we are using kernal_w default value beacause your input in None")
            if (iteration_num and not isinstance(int(iteration_num), int) and iteration_num != None):
                errorFlag = True
                logger.info("invalid iteration_num type please enter numeric")

            if (not iteration_num or iteration_num == None):
                iteration_num = ip_config.iteration_num  # 25
                # print ("H1_filter ===",H1_filter)
                logger.info("we are using iteration_num default value beacuse your input in None")

            st = time.time()
            if not errorFlag:
                Dilationfuncation = imgenh_api.img_Dilation(image_path, int(kernal_h), int(kernal_w),
                                                            int(iteration_num))
                cv2.imwrite(save_image_path, Dilationfuncation)
            en = time.time()
            jsonObj[DURATION] = str(int(en - st))
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            logger.info("image dilation filter completed")
        except Exception as e:
            logger.error("Error while Pre processing image dilation filter: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)


@app.route("/image_erosion", methods=["POST"])
def imageErosion():
    req_json = get_json_from_request(request)
    for jsonObj in req_json:

        try:
            errorFlag = False
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            className = getReqeuestParam(jsonObj, "className")
            dataType = getReqeuestParam(jsonObj, "dataType")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")
            kernal_h = getReqeuestParam(jsonObj, "kernal_h", "")
            kernal_w = getReqeuestParam(jsonObj, "kernal_w", "")
            iteration_num = getReqeuestParam(jsonObj, "iteration_num", "")

            jsonObj[SUCCESS] = "0"
            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName

            # imgpath = os.path.join(img_input_dir, filename)
            img = img_util.validate_input(image_path)
            if img is None:
                jsonObj["Img"] = "Image uploading  Failed!!!"
                errorFlag = True

            if (kernal_h and not isinstance(int(kernal_h), int) and kernal_h != None):
                logger.info("invalid type please enter numeric")
                errorFlag = True

            if (not kernal_h or kernal_h == None):
                kernal_h = ip_config.kernal_h  # 25
                # print ("kernal_h ===",kernal_h)
                logger.info("we are using default value beacuse your input in None")

            if (kernal_w and not isinstance(int(kernal_w), int) and kernal_w != None):
                errorFlag = True

            if (not kernal_w or kernal_w == None):
                kernal_w = ip_config.kernal_w  # 25
                # print ("H1_filter ===",H1_filter)
                logger.info("we are using default value beacuse your input in None")

            if (iteration_num and not isinstance(int(iteration_num), int) and iteration_num != None):
                errorFlag = True

            if (not iteration_num or iteration_num == None):
                iteration_num = ip_config.iteration_num  # 25
                # print ("H1_filter ===",H1_filter)
                logger.info("we are using default value beacuse your input in None")

            if not errorFlag:
                Erosionfuncation = imgenh_api.img_Erosion(image_path, int(kernal_h), int(kernal_w), int(iteration_num))
                logger.info("Saving processed image")

                # destination = os.path.join(img_save_dir, filename)

                # remove previous copy of the same file if any
                # if os.path.isfile(save_image_path):
                # os.remove(save_image_path)

                # cv2.imwrite(destination, processed_image)
                cv2.imwrite(save_image_path, Erosionfuncation)
                # jsondata["processed_img_path"] = destination
                # if os.path.isfile(save_image_path): jsonObj["SUCCESS"] = "1"
                if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                    jsonObj[SUCCESS] = "1"
                elif os.path.isfile(save_image_path):
                    os.remove(save_image_path)
                    # return send_image(img_save_dir, filename)

                else:
                    logger.info("Error")
                    # return json.dumps(jsondata)


        except Exception as e:
            logger.error("Error while Pre processing Erosion: " + str(e) + " input: " + str(jsonObj))
            # jsondata["error"] = "Error Occured while prcessing image"
    return json.dumps(req_json)

@app.route("/area_open", methods=["POST"])
def imageAreaOpen():
    req_json = get_json_from_request(request)
    for jsonObj in req_json:

        try:
            errorFlag = False
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            className = getReqeuestParam(jsonObj, "className")
            dataType = getReqeuestParam(jsonObj, "dataType")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")
            kernal_h = getReqeuestParam(jsonObj, "kernal_h", "")
            kernal_w = getReqeuestParam(jsonObj, "kernal_w", "")
            iteration_num = getReqeuestParam(jsonObj, "iteration_num", "")
            jsonObj[SUCCESS] = "0"

            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName

            # imgpath = os.path.join(img_input_dir, filename)
            img = img_util.validate_input(image_path)
            if img is None:
                jsonObj["Img"] = "Image uploading  Failed!!!"
                errorFlag = True

            if (kernal_h and not isinstance(int(kernal_h), int) and kernal_h != None):
                logger.info("invalid type please enter numeric")
                errorFlag = True

            if (not kernal_h or kernal_h == None):
                kernal_h = ip_config.kernal_h  # 25
                # print ("kernal_h ===",kernal_h)
                logger.info("we are using default value beacuse your input in None")

            if (kernal_w and not isinstance(int(kernal_w), int) and kernal_w != None):
                errorFlag = True

            if (not kernal_w or kernal_w == None):
                kernal_w = ip_config.kernal_w  # 25
                # print ("H1_filter ===",H1_filter)
                logger.info("we are using default value beacuse your input in None")

            if (iteration_num and not isinstance(int(iteration_num), int) and iteration_num != None):
                errorFlag = True

            if (not iteration_num or iteration_num == None):
                iteration_num = ip_config.iteration_num  # 25
                # print ("H1_filter ===",H1_filter)
                logger.info("we are using default value beacuse your input in None")

            if not errorFlag:
                AreaOpenfuncation = imgenh_api.img_AreaOpen(image_path, int(kernal_h), int(kernal_w))
                logger.info("Saving processed image")

                # destination = os.path.join(img_save_dir, filename)

                # remove previous copy of the same file if any
                # if os.path.isfile(save_image_path):
                # os.remove(save_image_path)

                # cv2.imwrite(destination, processed_image)
                cv2.imwrite(save_image_path, AreaOpenfuncation)
                # jsondata["processed_img_path"] = destination
                # if os.path.isfile(save_image_path): jsonObj["SUCCESS"] = "1"
                if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                    jsonObj[SUCCESS] = "1"
                elif os.path.isfile(save_image_path):
                    os.remove(save_image_path)
                    # return send_image(img_save_dir, filename)

                else:
                    logger.info("Error")
                    # return json.dumps(jsondata)


        except Exception as e:
            logger.error("Error while Pre processing Erosion: " + str(e) + " input: " + str(jsonObj))
            # jsondata["error"] = "Error Occured while prcessing image"
    return json.dumps(req_json)


@app.route("/area_close", methods=["POST"])
def imageAreaClose():
    logger.info("Area Close filter")
    req_json = get_json_from_request(request)
    for jsonObj in req_json:
        try:
            errorFlag = False
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            dataType = getReqeuestParam(jsonObj, "dataType")
            className = getReqeuestParam(jsonObj, "className")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")
            kernal_h = getReqeuestParam(jsonObj, "kernal_h", "")
            kernal_w = getReqeuestParam(jsonObj, "kernal_w", "")
            jsonObj[SUCCESS] = "0"
            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName

            if (kernal_h and not isinstance(int(kernal_h), int) and kernal_h != None):
                errorFlag = True
                logger.info("invalid kernal_h type please enter numaric")

            if (not kernal_h or kernal_h == None):
                kernal_h = ip_config.kernal_h  # 25
                # print ("kernal_h ===",kernal_h)
                logger.info("we are using kernal_h default value beacuse your input in None")
            if (kernal_w and not isinstance(int(kernal_w), int) and kernal_w != None):
                errorFlag = True
                logger.info("invalid kernal_w type please enter numaric")
            if (not kernal_w or kernal_w == None):
                kernal_w = ip_config.kernal_w  # 25
                # print ("H1_filter ===",H1_filter)
                logger.info("we are using kernal_w default value beacuse your input in None")

            st = time.time()
            if not errorFlag:
                AreaClosefuncation = imgenh_api.img_AreaClose(image_path, int(kernal_h), int(kernal_w))
                cv2.imwrite(save_image_path, AreaClosefuncation)
            en = time.time()
            jsonObj[DURATION] = str(int(en - st))
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            logger.info("Area Close filter completed")
        except Exception as e:
            logger.error("Error while Pre processing Area Close filter: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)


def trainInception_p(args, id):
    logger.info("Started new process for Inception Training")
    name = multiprocessing.current_process().name
    logger.info ("Starting %s\n" %name)
    logger.info("Params used: \n"+str(args))
    try:
        logger.info('in try for trying ****')
        usecase_params = {}
        usecase_params['status'] = inception_config.DB_STATUS_PROGRESS
        usecase_params['testaccuracy'] = 0
        usecase_params['trainaccuracy'] = 0
        usecase_params['valaccuracy'] = 0
        db.updateUseCase(usecase_params, id)


        #call the training function to start train
        acc_test, acc_train, acc_val = im.runTraining(args)

        # logger.info('return values >>>>>>>>..')
        # logger.info ('return values >>>>>>>>..'+str(acc_test))
        # logger.info('return values >>>>>>>>..'+str(acc_train))

        #### Added check if training is not completed successfully. In that case, update DB status parameter as empty string
        if acc_test == "TRAIN ENDED WITH ERROR" or acc_train == "TRAIN ENDED WITH ERROR" or acc_val == "TRAIN ENDED WITH ERROR":
            usecase_params['status'] = ''
            usecase_params['testaccuracy'] = -1
            usecase_params['trainaccuracy'] = -1
            usecase_params['valaccuracy'] = -1
            #if (not acc_test is None): logger.info("Model updated: " + str(args["--output_graph"]))
            db.updateUseCase(usecase_params, id)
        else :
            usecase_params['status'] = inception_config.DB_STATUS_COMPLETE
            usecase_params['testaccuracy'] = acc_test
            usecase_params['trainaccuracy'] = acc_train
            usecase_params['valaccuracy'] = acc_val
            if(not acc_test is None): logger.info("Model updated: "+str(args["--output_graph"]))
            db.updateUseCase(usecase_params, id)

    except Exception as e:
        logger.exception(e)
        # in case of error reset status
        usecase_params['status'] = '' #inception_config.DB_STATUS_ERROR
        usecase_params['testaccuracy'] = -1
        usecase_params['trainaccuracy'] = -1
        usecase_params['valaccuracy'] = -1
        db.updateUseCase(usecase_params, id)
    #Remove Tmp directory after training
    try:
        tmpDir=args['--bottleneck_dir']
        tmpDir=tmpDir[0:str(tmpDir).index(TMPTRN_DIR)+len(TMPTRN_DIR)]
        logger.info("Deleting tmp files %s \n" % tmpDir)
        import shutil
        shutil.rmtree(tmpDir, ignore_errors=True)
    except Exception as e:
        logger.exception(str(e))
    logger.info ("Exiting %s \n" %name)
    # try:
    #     if(not multiprocessing.current_process() is None and
    #            multiprocessing.current_process().is_alive()): multiprocessing.current_process().terminate()
    # except AttributeError:
    #     logger.debug("Ignoring terminate error for AttributeError")



@app.route('/train_inception/train', methods=['POST'])
def doInceptionTraining():
    """
    API that calls the method for Inception training model. Retrieves the relevant paramaters from user input and calls
    training API.
    Returns a json object with the accuracy of the trained model.
    :return:
    """
    logger.info("doInceptionTraining")
    jsondata = {}
    errorFlag = False
    # Read  the model parameter dictionary with default parameters from config
    def_args = inception_config.args
    args = def_args.copy()
    try:
        # Update parameters from User request
        data = request.get_json()
        if (data is None):
            data1 = request.data
            data = json.loads(data1)

        useCaseId = data['useCaseId']

        if 'rndBrightness' in data and data['rndBrightness'] != "" and data['rndBrightness'] != "0":
            args['--random_brightness'] = int(data['rndBrightness'])

        if 'rndScale' in data and data['rndScale'] != "" and data['rndScale'] != "0":
            args['--random_scale'] = int(data['rndScale'])

        if 'rndCrop' in data and data['rndCrop'] != "" and data['rndCrop'] != "0":
            args['--random_crop'] = int(data['rndCrop'])

        if 'flipLeftToRight' in data and (data['flipLeftToRight'] == "1" or data['flipLeftToRight'] == "true"):
            args['--flip_left_right'] = "True"

        if 'validationBatchSize' in data and data['validationBatchSize'] != "" and data['validationBatchSize'] != "0":
            args['--validation_batch_size'] = int(data['validationBatchSize'])

        if 'testBatchSize' in data and data['testBatchSize'] != "" and data['testBatchSize'] != "0":
            args['--test_batch_size'] = int(data['testBatchSize'])

        if 'trainBatchSize' in data and data['trainBatchSize'] != "" and data['trainBatchSize'] != "0":
            args['--train_batch_size'] = int(data['trainBatchSize'])

        if 'evalStepInterval' in data and data['evalStepInterval'] != "" and data['evalStepInterval'] != "0":
            args['--eval_step_interval'] = int(data['evalStepInterval'])

        if 'testingPercentage' in data and data['testingPercentage'] != "" and data['testingPercentage'] != "0":
            args['--testing_percentage'] = int(data['testingPercentage'])

        if 'validationPercentage' in data and data['validationPercentage'] != "" and data['validationPercentage'] != "0":
            args['--validation_percentage'] = int(data['validationPercentage'])

        if 'learningRate' in data and data['learningRate'] != "" and data['learningRate'] != "0":
            args['--learning_rate'] = float(data['learningRate'])

        if 'trainingSteps' in data and data['trainingSteps'] != "" and data['trainingSteps'] != "0":
            args['--how_many_training_steps'] = int(data['trainingSteps'])

        args['--image_dir'] = basepath+"/"+str(useCaseId)+"/train" # data['trngImgDir']
        args['--output_labels'] = basepath+"/"+str(useCaseId)+"/"+str(useCaseId)+".txt" #data['labelFile']
        args['--output_graph'] = basepath+"/"+str(useCaseId)+"/"+str(useCaseId)+".pb" #data['modelFile']
        args['--bottleneck_dir'] = basepath + "/" + str(useCaseId) + "/"+TMPTRN_DIR+"/bottleneck"
        args['--intermediate_output_graphs_dir']= basepath + "/" + str(useCaseId) + "/"+TMPTRN_DIR+"/intermediate_graph"
        args['--summaries_dir'] = basepath+"/retrain_logs"+"/"+str(useCaseId)#+"/"+TMPTRN_DIR




        os.makedirs(basepath+"/retrain_logs", mode=0o777, exist_ok=True)
        #args['--model_dir'] # Read from Inception Config file

        # acc_test, acc_train, acc_val = im.runTraining(args)
        # print(acc_test, acc_train, acc_val)

        # Inception_Training_process = multiprocessing.Process \
        #     (name='Inception_Training_process', \
        #      target=trainInception_p, args=(args,useCaseId))
        #
        # Inception_Training_process.daemon = False
        # Inception_Training_process.start()

        #jsondata["Status"] = inception_config.TRAINING_STARTED_MSG


        trainInception_p(args, useCaseId)

    except Exception as e:
        logger.error(e)
        jsondata["Error"] = inception_config.TRAINING_ERR_MSG+":"+str(e)
    return json.dumps(jsondata)

#---Avadhut AWS Integration

def getReqeuestParam(req, param, default="", cls=str, errDefault=None, min_value=None, max_value=None):
    isErrVal = False
    val = ""
    if (param in req): #req could be request.get_json or request.form
        try:
            val=cls(req[param])
            if (not isinstance(val, cls)):
                isErrVal=True
            elif (not min_value is None and val<min_value):
                isErrVal = True
            elif (not max_value is None and val > max_value):
                isErrVal = True
        except ValueError as e:
            isErrVal = True
        if(isErrVal):
            import inspect
            curframe = inspect.currentframe()
            calframe = inspect.getouterframes(curframe, 2)
            caller=str(calframe[1][3]) #'caller name:',
            msg="ERR: Invalid value - " +param + ":" + str(val)+" [method: "+caller+"]"
            print(msg)
            logging.info(msg)
            #if(not errDefault is None): msg=errDefault
            return errDefault
        else:
            return val
    else:
        return default

@app.route("/classify_inception/classify_single", methods=["POST"])
def classify_image():
    return classify_bulk()

@app.route("/classify_inception/classify", methods=["POST"])
def classify_bulk():
    #files, model_file, label_file, imgpath=None, num_top_result=5, input_opearation="Mul", output_operation="softmax", fileids=None):
    req_json = get_json_from_request(request)  # expected jsonArray
    isSingle=False
    if(isinstance(req_json, dict)):
        isSingle=True
        req_json=[req_json]
    errMsg=""
    useCaseId=""
    model_file=""
    label_file=""
    num_top_result=10
    input_operation="softmax"
    output_operation="final_result"
    #Read first object for common details
    try:
        for jsonObj in req_json:
            try:
                useCaseId = getReqeuestParam(jsonObj, "useCaseId")
                model_file = basepath + "/" + str(useCaseId) + "/" + str(useCaseId) + ".pb"
                label_file = basepath + "/" + str(useCaseId) + "/" + str(useCaseId) + ".txt"
                num_top_result = getReqeuestParam(req_json, 'num_top_result', ImgClassification_Config.num_top_result, int, errDefault=5)
                input_operation = getReqeuestParam(req_json, 'input_operation', None, errDefault=None)
                output_operation = getReqeuestParam(req_json, 'output_operation', None, errDefault=None)
            except Exception as e:
                logger.error(str(e))
            break
        idx=0

        #with tf.Graph().as_default():
        if (not tf.gfile.Exists(model_file)): raise Exception("Invalid model file")
        if (not tf.gfile.Exists(label_file)): raise Exception("Invalid label file")
        tf_graph=ImgClassification.create_graph(model_file)
        # with tf.Session().as_default() as sess:
        sess=tf.Session(graph=tf_graph)
        #with tf.Session(graph=tf_graph) as sess: #.as_default()
        logger.info("Processing  files")
        for jsonObj in req_json:
            if(idx>0 and idx%50==0):
                sess.close()
                sess = tf.Session(graph=tf_graph)
                logger.info(str(idx) + " files processed")

            filename = jsonObj["imageName"]
            relpath=""
            #relpath = jsonObj["relPath"]
            relpath = getReqeuestParam(jsonObj, "relPath")
            #if("relPath" in jsonObj): relpath = jsonObj["relPath"]
            relpathPrefix = "/classify/"
            #logger.error(">>relPath: "+filename+":"+relpath+":"+jsonObj["relPath"]+"\n"+str(jsonObj))
            if (not relpath.startswith(relpathPrefix)): relpath = relpathPrefix + relpath
            if (not relpath.endswith("/")): relpath = relpath + "/"
            target = (basepath + "/" + str(useCaseId) + "/" + relpath)#.replace("//","/")
            # target = getReqeuestParam(req_json, 'testdir', "")
            imgfile = os.path.normpath(target + "/" + filename)
            try:
                st = time.time()
                # op=classifyImage(imgfile, model_file, label_file, imgpath, num_top_result, input_opearation,
                # output_operation, load_graph=False, fileid=fileids[files.index(imgfile)])
                op = ImgClassification.classifyImageInSess(imgfile, model_file, label_file, target, num_top_result,
                                                           input_operation, output_operation, tf_session=sess)


                if(not op is None):
                    jsonObj["identifiedClass"]=op["identifiedClass"]
                    jsonObj["Score"] = (op["Score"])
                    jsonObj["classificationResult"] = op["classificationResult"]
                else:
                    jsonObj["ERR"]="Error reading image or model"
                en = time.time()
                jsonObj["duration"] = str(int(en - st))
                #logger.info(str(jsonObj))
            except Exception as ex:
                jsonObj["ERR"] = str(ex) #imgfile + " : " + str(ex)
                logger.error("Error: " + str(ex) + " : " + imgfile)
            idx=idx+1
        sess.close()
    except Exception as ex1:
        logger.error("Error: " + str(ex1) + " : " + str(req_json))
        if (isSingle):
            jsonObj["ERR"]=str(ex1)
        else:
            req_json.append({"ERR": str(ex1)})
    if(isSingle): req_json=req_json[0]
    #logger.info(json.dumps(req_json))#, cls=NumpyEncoder
    return json.dumps(req_json)#, cls=NumpyEncoder

#@app.route('/static/images/<filename>')
def send_image(dir, filename):
    return send_from_directory(dir, filename)

@app.route("/graph_cut", methods=["POST"])
def graph_cut():
    # from src.conf import graph_cut_config as ip_config
    logger.info("graph Cut")
    req_json = get_json_from_request(request)
    for jsonObj in req_json:
        try:
            errorFlag = False
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            dataType = getReqeuestParam(jsonObj, "dataType")
            className = getReqeuestParam(jsonObj, "className")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")
            x = getReqeuestParam(jsonObj, "xval", ip_config.x, int, errDefault=ip_config.x)
            y = getReqeuestParam(jsonObj, "yval", ip_config.y, int, errDefault=ip_config.y)
            wd = getReqeuestParam(jsonObj, "wdval", ip_config.wd, int, errDefault=ip_config.wd)
            ht = getReqeuestParam(jsonObj, "htval", ip_config.ht, int, errDefault=ip_config.ht)
            it = getReqeuestParam(jsonObj, "iterations", ip_config.iterations, int, errDefault=ip_config.iterations)
            jsonObj[SUCCESS] = "0"
            if (not x or None is x):
                x = ip_config.x
            if (not isinstance(int(x), int) or int(x) < 0):
                errorFlag = True
                logger.info("Invalid value for x")
            if (not y or None is y):
                y = ip_config.y
            if (not isinstance(int(y), int) or int(y) < 0):
                errorFlag = True
                logger.info("Invalid value for y")
            if (not wd or None is wd):
                wd = ip_config.wd
            if (not isinstance(int(wd), int)):
                errorFlag = True
                logger.info("Invalid value for wd")
            if (not ht or None is ht):
                ht = ip_config.ht
            if (not isinstance(int(ht), int)):
                errorFlag = True
                logger.info("Invalid value for ht")
            if (not it or None is it):
                it = ip_config.iterations
            if (not isinstance(int(it), int)):
                errorFlag = True
                logger.info("Invalid value for it")
            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName

            st = time.time()
            if not errorFlag:
                img = imgenh_api.doFilter(image_path, savefile_name=None, maskfile_name=None, x=x, y=y, wd=wd, ht=ht,
                                          iterations=it)
                cv2.imwrite(save_image_path, img)
            en = time.time()
            jsonObj[DURATION] = str(int(en - st))
            print(os.path.getsize(save_image_path))
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            logger.info("Graph cut completed")
        except Exception as e:
            logger.error("Error while Pre processing graph cut: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)


@app.route("/otsu", methods=["POST"])
def otsu():
    # from src.conf import ip_config
    logger.info("OTSU")
    req_json = get_json_from_request(request)
    for jsonObj in req_json:
        try:
            errorFlag = False
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            dataType = getReqeuestParam(jsonObj, "dataType")
            className = getReqeuestParam(jsonObj, "className")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")
            x = getReqeuestParam(jsonObj, "block_size_x", ip_config.block_size_x, int,
                                 errDefault=ip_config.block_size_x,
                                 min_value=1, max_value=255)
            y = getReqeuestParam(jsonObj, "block_size_y", ip_config.block_size_y, int,
                                 errDefault=ip_config.block_size_y)
            w = getReqeuestParam(jsonObj, "max_value_for_adaptive_threshold",
                                 ip_config.max_value_for_adaptive_threshold, int,
                                 errDefault=ip_config.max_value_for_adaptive_threshold)
            z = getReqeuestParam(jsonObj, "min_value_for_adaptive_threshold",
                                 ip_config.min_value_for_adaptive_threshold, int,
                                 errDefault=ip_config.min_value_for_adaptive_threshold)

            jsonObj[SUCCESS] = "0"
            if (not x or None is x):
                x = ip_config.block_size_x
            if (not isinstance(int(x), int) or int(x) < 0):
                errorFlag = True
                logger.info("Invalid value x")
            if (not y or None is y):
                y = ip_config.block_size_y
            if (not isinstance(int(y), int) or int(y) < 0):
                errorFlag = True
                logger.info("Invalid value y")
            if (not w or None is w):
                w = ip_config.max_value_for_adaptive_threshold
            if (not isinstance(int(w), int)):
                errorFlag = True
                logger.info("Invalid value w")
            if (not z or None is z):
                z = ip_config.min_value_for_adaptive_threshold
            if (not isinstance(int(z), int)):
                errorFlag = True
                logger.info("Invalid value z")

            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName

            st = time.time()
            if not errorFlag:
                img = imgenh_api.otsu_thresholding(image_path, min_value_for_adaptive_threshold=z,
                                                   max_value_for_adaptive_threshold=w, block_size_x=x, block_size_y=y)
                cv2.imwrite(save_image_path, img)
            en = time.time()
            jsonObj[DURATION] = str(int(en - st))
            if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                jsonObj[SUCCESS] = "1"
            elif os.path.isfile(save_image_path):
                os.remove(save_image_path)
            logger.info("OTSU completed")
        except Exception as e:
            logger.error("Error while Pre processing OTSU: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)


@app.route("/adaptive", methods=["POST"])
def adaptive():
    logger.info("Adaptive")
    jsondata = {}

    req_json = get_json_from_request(request)
    for jsonObj in req_json:

        try:
            errorFlag = False
            useCaseId = getReqeuestParam(jsonObj, "useCaseId")
            className = getReqeuestParam(jsonObj, "className")
            dataType = getReqeuestParam(jsonObj, "dataType")
            imgName = getReqeuestParam(jsonObj, "imgName")
            opImgName = getReqeuestParam(jsonObj, "opImgName", "")
            opPath = getReqeuestParam(jsonObj, "opPath", "")
            ipPath = getReqeuestParam(jsonObj, "ipPath", "")
            #x = getReqeuestParam(jsonObj, "x", 0, int)
            block_size_x = getReqeuestParam(jsonObj, "block_size_x", ip_config.block_size_x, int,
                                 errDefault=ip_config.block_size_x)
            #y = getReqeuestParam(jsonObj, "y", 0, int)
            block_size_y = getReqeuestParam(jsonObj, "block_size_y", ip_config.block_size_y, int,
                                 errDefault=ip_config.block_size_y)
            #z = getReqeuestParam(jsonObj, "z", 0, int)
            noise_level_medianblur = getReqeuestParam(jsonObj, "noise_level_for_median_blur", ip_config.noise_level_for_median_blur, int,
                                 errDefault=ip_config.noise_level_for_median_blur)
            #w = getReqeuestParam(jsonObj, "w", 255, int)
            max_threshold = getReqeuestParam(jsonObj, "max_value_for_adaptive_threshold", ip_config.max_value_for_adaptive_threshold, int,
                                 errDefault=ip_config.max_value_for_adaptive_threshold)
            jsonObj[SUCCESS] = "0"
            image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
            if (not ipPath == ""):
                image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
            save_image_path = image_path
            if (not opImgName == ""):
                os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                            exist_ok=True)
                save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName

            # imgpath = os.path.join(img_input_dir, filename)
            img = img_util.validate_input(image_path)

            if img is None:
                jsondata["Img"] = "Image uploading  Failed!!!"
                errorFlag = True

            if (not block_size_x or None is block_size_x):
                block_size_x = ip_config.block_size_x
            if (not isinstance(int(block_size_x), int) or int(block_size_x) < 0):
                logger.info("invalid type please enter numeric")
                errorFlag = True
            if (not block_size_y or None is block_size_y):
                block_size_y = ip_config.block_size_y
            if (not isinstance(int(block_size_y), int) or int(block_size_y) < 0):
                logger.info("invalid type please enter numeric")
                errorFlag = True
            if (not noise_level_medianblur or None is noise_level_medianblur):
                noise_level_medianblur = ip_config.noise_level_for_median_blur
            if (not isinstance(int(noise_level_medianblur), int)):
                logger.info("invalid type please enter numeric")
                errorFlag = True
            if (not max_threshold or None is max_threshold):
                max_threshold = ip_config.max_value_for_adaptive_threshold
            if (not isinstance(int(max_threshold), int)):
                logger.info("invalid type please enter numeric")
                errorFlag = True
            # logger.info("invalid ")
            if not errorFlag:
                img = imgenh_api.adaptive_thresholding(imgName, noise_level_for_median_blur=noise_level_medianblur,
                                                       max_value_for_adaptive_threshold=max_threshold, block_size_x=block_size_x,
                                                       block_size_y=block_size_y)
                logger.info("Saving processed image")
                # destination = os.path.join(img_save_dir, filename)
                cv2.imwrite(save_image_path, img)
                # jsondata["processed_img_path"] = destination
                if os.path.isfile(save_image_path) and os.path.getsize(save_image_path) != 0:
                    jsonObj[SUCCESS] = "1"
                elif os.path.isfile(save_image_path):
                    os.remove(save_image_path)

                # return send_image(img_save_dir, filename)

                else:
                    logger.info("Error")
                # remove previous copy of the same file if any
                # if os.path.isfile(destination):
                # os.remove(destination)

                # cv2.imwrite(destination, img)

                # return destination
                # return send_image(img_save_dir, filename)
                # img binary object to be saved with cv2 api
        except Exception as e:
            logger.error("Error while Pre processing adaptive: " + str(e) + " input: " + str(jsonObj))

    return json.dumps(req_json)

#---Avadhut AWS Integration complete

api.add_resource(ScaleImage, '/ScaleImage/', '/ScaleImage/<baseheight>', endpoint = "ScaleImage")

@app.route('/test_service', methods=['GET', 'POST'])
def test_service():
    return "Service running"

# api.add_resource(ScaleImage, '/ScaleImage/', '/ScaleImage/<baseheight>', endpoint = "ScaleImage")
@app.route("/iconize", methods=["POST"])
def iconize_image():
    req_json = get_json_from_request(request) # exected jsonArray
    baseheight = app_config.baseheight

    for jsonObj in req_json:
        try:
            useCaseId=jsonObj['useCaseId']
            dataType = ""
            if ('dataType' in jsonObj): dataType = jsonObj['dataType']
            className = ""
            if('className' in jsonObj): className = jsonObj['className']
            imgName = jsonObj['imgName']
            image_path = basepath+"/"+useCaseId+"/"+dataType+"/"+className+"/"+imgName
            os.makedirs(basepath+"/"+useCaseId+"/thumbnail/"+dataType+"/"+className, mode=0o777, exist_ok=True)
            #os.chmod(basepath, 0o777)
            save_image_path = basepath+"/"+useCaseId+"/thumbnail/"+dataType+"/"+className+"/"+imgName
            iu = ImageUtils(image_path)
            image_resized = iu.resize_image(baseheight)
            scaled_image_path = iu.save_image(image_resized, save_image_path, img_save_dir)
            jsonObj['Success']=("1" if (scaled_image_path) else "0")
            #thrd=threading.Thread(target=chmod, args=(basepath))
            #thrd.start()
        except Exception as e:
            logger.error("Error while Iconizing: "+str(e)+" input: "+str(jsonObj))
            jsonObj['Success']="0"
    return json.dumps(req_json)

@app.route("/doChmod", methods=["GET"])
def doChmod():
    thrd = threading.Thread(target=chmod, args=(basepath))
    thrd.start()
    return str({"Success":"1"})

@app.route("/databackup", methods=["POST"])
def doBackup():
    return "Success"

api.add_resource(Train_Ssd,'/trainssd',methods=['POST'])
api.add_resource(Retrain_Ssd,'/retrainssd',methods=['POST'])
api.add_resource(Classify_Ssd,'/classifyssd',methods=['POST'])
api.add_resource(Classify_Ssd_map,'/map_metric',methods=['POST'])
api.add_resource(Test_Ssd_map,'/test_map_metric',methods=['POST'])
api.add_resource(Classify_Ssd_video,'/classifyssdvideo',methods=['POST'])
api.add_resource(Classify_Ssd_video_depth,'/depth_dis_OD',methods=['POST'])
api.add_resource(Process_video_depth,'/display_depth',methods=['POST'])


#Scene Recognition API

api.add_resource(train_sr,'/train_sr',methods=['POST'])
api.add_resource(caption_generator,'/caption_generator',methods=['POST'])
api.add_resource(model_evaluation,'/model_evaluation',methods=['POST'])


#### API for generating map score
api.add_resource(Train_MapScore,'/getMapScore',methods=['POST','GET'])

#### API for validating images
@app.route("/imageValidator",methods = ['POST'])
def imageValidator():
    return img_val.checkAndConvert()

def iconize_image_old():
    req_json = request.get_json(silent=True)
    if (req_json is None):
        req_json = request.data
        req_json = req_json.decode(enc, 'ignore')
        req_json = req_json[req_json.index("{"):]  # Remove b' from start
        req_json = re.sub(r'[^' + string.printable + ']', '', req_json)
        # req_json = re.sub(r'[' + string.whitespace + ']', ' ', req_json)
        req_json = json.loads(req_json)
    img_input_dir = file_upload_config.UPLOADED_PHOTOS_DEST
   #use_case = getReqeuestParam(req_json, 'useCaseId', "")
    #baseheight = getReqeuestParam(req_json, 'baseheight', "")
    use_case =  req_json['useCaseId']
    baseheight = req_json['baseheight']
    for image_file in os.listdir(img_input_dir):
        print(image_file)
        image_path = os.path.join(img_input_dir, image_file)
        iu = ImageUtils(image_path)
        image_resized = iu.resize_image(baseheight)
        scaled_image_path = iu.save_image(image_resized, image_file + "_resized.png", img_save_dir)
        break

    if scaled_image_path:
        return send_file(scaled_image_path, mimetype='image/png')

def get_json_from_request(req):
    req_json = req.get_json(silent=True)
    if (req_json is None):
        req_json = req.data
        req_json = req_json.decode(enc, 'ignore')
        #req_json = req_json[req_json.index("{"):]  # Remove b' from start
        #req_json = re.sub(r'[^' + string.printable + ']', '', req_json)
        # req_json = re.sub(r'[' + string.whitespace + ']', ' ', req_json)
        req_json = json.loads(req_json)
    return req_json

def chmod(path):
    #if(os.name=="posix"):
    for root, dirs, files in os.walk(path):
        for d in dirs:
            os.chmod(os.path.join(root, d), 777)
        for f in files:
            os.chmod(os.path.join(root, f), 777)


@app.before_request
#@requires_auth
def before_request():
  pass

content_types = {'jpg': 'image/jpeg', 'jpeg': 'image/jpeg', 'mp4': 'video/mp4','png': 'image/png','bmp': 'image/bmp', 'tif': 'image/tif','gif':'image/gif' }
extensions = sorted(content_types.keys())

logging.basicConfig(filename='ui_log.log',level=logging.DEBUG)

def is_image():
  def _is_image(form, field):
    if not field.data:
      raise ValidationError()
    elif field.data.filename.split('.')[-1].lower() not in extensions:
      raise ValidationError()

  return _is_image


class PhotoForm(Form):
  input_photo = FileField(
      # 'File extension should be: %s (case-insensitive)' % ', '.join(extensions),
	  #"* Disclaimer: Some of the contents being used for testing purposes may contain confidential information, and, therefore, the regions that are likely to violate data privacy are masked.","",
      validators=[is_image()])
  input_video = FileField(
      # 'File extension should be: %s (case-insensitive)' % ', '.join(extensions),
      )

@app.route('/')
def upload():
  photo_form = PhotoForm(request.form)
  return render_template('index_2.html', photo_form=photo_form, result={})

def detect_barcode(image_path):
   try:
      result={}
      result_req = detect.decode(image_path)
      image_p = open(image_path, 'rb')
      image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
      imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
      result['original'] = imgstr
      if len(result_req) == 0:
          result['type']="Barcode Type not Identified"
          result['data'] = "Barcode Data not Identified"
      else:
          result['type'] = result_req['type']
          result['data'] = result_req['data']
      return result
   except Exception as e:
       print(e)


@app.route('/barcode', methods=['GET', 'POST'])
def barcode():
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f = os.path.join(TEMPLATE_PATH, file_p.filename)
        file_p.save(f)
        result = detect_barcode(f)
      return render_template('barcode.html',photo_form=photo_form, result=result)
    elif request.method == 'POST':
        data = request.get_json()
        result = detect.decode(data['input_image'])
        return jsonify(result)
    else:
      return render_template('barcode.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)

def generate_answer(image_path):
   K.clear_session()
   try:
      result={}
      image_p = open(image_path, 'rb')
      image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
      imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
      result['original'] = imgstr
      quest = request.form['Ques']
      from custom_projects.resources.vqa.VQA_Demo import answer_generator
      result_req = answer_generator.getGeneratedAnswer(image_path,quest)
      result['q2']=quest
      result['q1']="Question asked  "
      result['q3']="Answer generated  "
      logger.info('Question:%s',quest)
      logger.info('Result:%s',result_req)
      result['q4'] = result_req['label']
      result['q5']="Confidence score   "
      result['q6']=np.trim_zeros(result_req['percent'])
      return result
      ##K.clear_session()
   except Exception as e:
       print(e)

@app.route('/vqa', methods=['GET', 'POST'])
def vqa_ui():
  K.clear_session()
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f = os.path.join(TEMPLATE_PATH, file_p.filename)
        file_p.save(f)
        result = generate_answer(f)
        quest = request.form['Ques']
      return render_template('vqa.html', photo_form=photo_form, result=result)
    else:
      return render_template('vqa.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)
from face_mask_detection.yolo_detection import yolo_face_detection
def predict_face_mask(image_path,img_name):
    logger.info("In predict facemsk method")
    print("image path",image_path)
    print("image name",img_name)
    obj=yolo_face_detection()
    print("obj resolved")
    try:
      result={}
      logger.info("In method")
      print("obj created")
      res=obj.yoloDetection(img_name)
      print(len(res))
      result_req = []
      print(result_req)
      logger.info("Out of method")
      image_p = open("face_mask_detection/out/"+img_name, 'rb')
      image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
      imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
      result['original'] = imgstr
      '''
      if len(result_req) == 0:
          result['confidence_score']=[]
          result['gender'] = "Gender not Identified"
      else:
          result['age'] = result_req['Age']
          result['gender'] = result_req['gender']
      '''
      return result
    except Exception as e:
        print(e)


def detect_gender_age(image_path):
   try:
      result={}
      logger.info("In method")
      result_req = gender_age.getGenderAge(image_path)
      logger.info("Out of method")
      image_p = open(image_path, 'rb')
      image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
      imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
      result['original'] = imgstr
      if len(result_req) == 0:
          result['age']="Age not Identified"
          result['gender'] = "Gender not Identified"
      else:
          result['age'] = result_req['Age']
          result['gender'] = result_req['gender']
      return result
   except Exception as e:
       print(e)

@app.route('/predict_face_mask', methods=['GET', 'POST'])
def face_mask_predict():
  print("IN Face_maskprediction..!!")
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f=os.path.join("face_mask_detection/input/",file_p.filename)
        file_p.save(f)
        result = predict_face_mask(f,file_p.filename)
      return render_template('yolo_face_mask_detection.html',photo_form=photo_form, result=result)

    elif request.method == 'POST':
        data = request.get_json()
        result = gender_age.getGenderAge(data['input_image'])
        return jsonify(result)
    else:
      return render_template('yolo_face_mask_detection.html', photo_form=photo_form,  result={})
  except Exception as e:
      print(e)

from yolo_ssd_detection.yolo_detection.convert_txt_2_xml import write_to_xml_yolo
from yolo_ssd_detection.ssd_object_detection.convert_txt_2_xml import write_to_xml_ssd
from yolo_ssd_detection.ssd_object_detection.classify_ssd import Classify_Ssd
from flask import Flask, request, jsonify
from yolo_ssd_detection.yolo_detection.yolo_detector import yolo_face_detection
import filtering_images.filtering_uncertainity_score
#app = Flask(__name__)
#obj=yolo_face_detection()
model_path=[]
input_image=[]
detection_model_name=[]
labels_path=[]
def yolo_detection(model_path,input_image,labels_path):
    #obj=yolo_face_detection()
    #logger.info("In method")
    print("obj created")
    res=obj_yolo.yoloDetection(input_image)
    return res

yolo_model_path=""
ssd_model_path=""
model_path_temp=""
def yolo_detector(model_path,input_image,labels_path):
    #  input_json = request.get_json(force=True) 
    #  print(input_json)
    #  if (obj.model_path!="yolo_detection/models/"+input_json['model_path'] ):
    #      print("New Model")
     global obj_yolo,model_path_temp
     print("model_path is",model_path_temp)
     if (model_path_temp!=model_path):
        #yolo_model_path =model_path
        print ("New model path..Creating a new object with new model")
        obj_yolo=yolo_face_detection(model_path)
        #obj.model_path=model_path
        model_path_temp=model_path
        obj_yolo.class_names_file_path=labels_path
     #obj.model=obj.load_model(obj.model_path)
     res=yolo_detection(model_path,input_image,labels_path)
     #print(res) 
     image_file_name =input_image.split("/")[len(input_image.split("/"))-1]
     xml_path=write_to_xml_yolo(image_file_name)  
     #out_dict={'xml_path':xml_path}
             
     #out_dict={'message':"success"}
    
     return (xml_path)

def ssd_object_detection(model_path,input_image,labels_path):
        print("Hitting the method")
        global model_path_temp,obj_ssd
        print("model path is",model_path_temp)
        if (model_path_temp!=model_path):
            obj_ssd = Classify_Ssd(model_path)
            model_path_temp=model_path
        #try:
        output=obj_ssd.classify_ssd(model_path,input_image,labels_path)
        
        return output  
def ssd_object_detector(model_path,input_image,labels_path):
    #  input_json = request.get_json(force=True) 
    #  print(input_json)
     ssd_object_detection(model_path,input_image,labels_path)
     print("End of detection")
     image_name =input_image.split("/")[len(input_image.split("/"))-1]
     res=write_to_xml_ssd(image_name)
                 
     #out_dict={'image':input_json['input_image'],'predictions':res}
     return res

@app.route('/object_detection_active_learning', methods=["POST"])
def object_detection():
    print("inside_object_detection")
    input_json = request.get_json(force=True) 
    print(input_json)
    model_path=input_json['model_path']
    input_image=input_json['input_image']
    detection_model_name=input_json["model_name"]
    labels_path=input_json['labels_path']#"C:/Users/s.lathikumari.nair/Downloads/IASP/cv-asset/object_detection/yolo_ssd_detection/yolo_detection/config/custom.names"
    # model_path="C:/Users/s.lathikumari.nair/Downloads/IASP/cv-asset/object_detection/inference_graph/frozen_inference_graph.pb"
    # input_image="C:/Users/s.lathikumari.nair/Downloads/IASP/cv-asset/object_detection/Dataset/test/test2.jpg"
    # labels_path="C:/Users/s.lathikumari.nair/Downloads/IASP/cv-asset/object_detection/yolo_ssd_detection/config/custom_classes.txt"
    # detection_model_name="SSD"
    xml_path=""
    if detection_model_name=="Yolo":
        print("yolo detection")
        xml_path=yolo_detector(model_path,input_image,labels_path)
        if xml_path!=None:
        	xml_path=xml_path
        print(xml_path)
    else :
        print("ssd detection")
        #input_json = request.get_json(force=True) 
        xml_path=ssd_object_detector(model_path,input_image,labels_path)
        if xml_path!=None:
        	xml_path=xml_path
    #  print(input_json)
    if xml_path==None:
        out_dict={'xml_path':"No xml created.Please rerun...."}
    else:
    	out_dict={'xml_path':str(xml_path)}
    return (jsonify(out_dict))

@app.route('/unceratinity_based_filtering', methods=["POST"])
def filter_images_avg_confidence_score():
    input_json = request.get_json(force=True) 
    print(input_json)
    avg_threshold=input_json["threshold_score"]
    files_list=input_json["images_data"]
    filtered_data_list=[]
    for files in files_list:
        images_path=files[0]
        labels_path=files[1]
        conf_scores=filtering_images.filtering_uncertainity_score.read_xml(labels_path)
        filtered_data_path=filtering_images.filtering_uncertainity_score.process_test_image(labels_path,images_path,conf_scores,avg_threshold)
        filtered_data_list.append(filtered_data_path)
    # process_test_image(labels_path,images_path,conf_scores,avg_threshold)
    # confidence_score=filtering_uncertainity_score.read_xml(input_json["label_path"])
    # filtered_image_path=filtering_uncertainity_score.process_test_image("input/4.xml",confidence_score,input_json["avg_confidence_threshold"])
    out_dict={'threshold_score':avg_threshold,"images_to_be_filtered_path":filtered_data_list}
    #return (out_dict)
    return (jsonify(out_dict))
        
@app.route('/gender_age_predict', methods=['GET', 'POST'])
def gender_age_predict():
  print("IN GENDER_AGE..!!")
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f = os.path.join(TEMPLATE_PATH, file_p.filename)
        file_p.save(f)
        result = detect_gender_age(f)
      return render_template('age_gender.html',photo_form=photo_form, result=result)

    elif request.method == 'POST':
        data = request.get_json()
        result = gender_age.getGenderAge(data['input_image'])
        return jsonify(result)
    else:
      return render_template('age_gender.html', photo_form=photo_form,  result={})
  except Exception as e:
      print(e)

def sr(image_path):
    # K.clear_session()
    try:


        result = {}
        image_p = open(image_path, 'rb')
        image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
        imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
        result['original'] = imgstr

        #from scene_recog import scene_rec
        result_req = scene_rec(image_path)
        logger.info("result request>>>>", result_req)
		
        if len(result_req) == 0:
            # result['type'] = "Scene Type not Identified"
            result['type'] = "Scene not Identified"
        else:
            # result['type'] = result_req['type']
            result['type'] = result_req['type']
            result['categories'] = result_req['categories']
            result['attributes'] = result_req['attributes']
            #print("result>", result)
        return result
    except Exception as e:
        print(e)

@app.route('/image_summary', methods=['GET', 'POST'])
def sr_ui():
    # K.clear_session()
    try:
        dirname, basename = os.path.split(TEMPLATE_PATH)
        #dirname, basename = os.path.split('templates')
        form = PhotoForm(CombinedMultiDict((request.files, request.form)))
        photo_form = PhotoForm(request.form)
        logger.info(photo_form)
        
        if request.method == 'POST' and form.validate():
            with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
                file_p = request.files['input_photo']
                #print("template path>>>>>>>>>>>>>>>>>>>>>>>>>", TEMPLATE_PATH)
                #print("File_p filepath>>>>>>>>>>>>>>>>>>>>", file_p.filename)
                f = os.path.join(TEMPLATE_PATH, file_p.filename)
                #f = os.path.join('templates', file_p.filename)
                file_p.save(f)
                #print("img file path>>>>>>>>>>>>>>>>>>>>",f)
                result = sr(f)
                #print("result2>>>>", result)
                # quest = request.form['Ques']
            return render_template('image_summary.html', photo_form=photo_form, result=result)
        else:
            return render_template('image_summary.html', photo_form=photo_form, result={})
        # K.clear_session()
        '''
        jsonObj = request.json
        image_path = jsonObj['image_path']
        result,SceneCategories,SceneAttributes = scene_rec(image_path)
        print("result2>>>>", result)
        print("SceneCategories>>>>", SceneCategories)
        print("SceneAttributes>>>>", SceneAttributes)
        
        return result
        '''
    except Exception as e:
        print(e)

 
def detect_from_crowd(image_path):
   try:
      result={}
      result_req = crowd_estimate.getestimate(image_path)
      image_p = open(image_path, 'rb')
      image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
      imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
      result['original'] = imgstr
      if len(result_req) == 0:
          result['estimate']="Estimate not Identified"
      else:
          result['estimate'] = result_req['count']
      return result
   except Exception as e:
       print(e)

@app.route('/crowd_count', methods=['GET', 'POST'])
def crowd_count():
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f = os.path.join(TEMPLATE_PATH, file_p.filename)
        file_p.save(f)
        result = detect_from_crowd(f)
      return render_template('crowd_count.html', photo_form=photo_form, result=result)
    elif request.method == 'POST':
        data = request.get_json()
        result = crowd_estimate.getestimate(data['input_image'])
        return jsonify(result)
    else:
      return render_template('crowd_count.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)

@app.route('/pii_anonymize', methods=['GET', 'POST'])
def pii_anonymize():
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f = os.path.join(TEMPLATE_PATH, file_p.filename)
        file_p.save(f)
        file = open("testfile.txt", "w")
        filename = (file_p.filename)
        file.write(filename)
        file.close()
        result={}
        image_p = open(f, 'rb')
        image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
        imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
        result['original'] = imgstr
      return render_template('license_plate.html',
                             photo_form=photo_form , result=result)
    else:
      return render_template('license_plate.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)

@app.route('/blur', methods=['GET', 'POST'])
def blur():
    photo_form = PhotoForm(request.form)
    file = open('testfile.txt', 'r')
    message = file.read()
    file.close()
    result={}
    path = custom_projects.resources.face_license_detection.new_detect_face.image_blur(message)
    image_p = open(path, 'rb')
    image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
    imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
    result['original'] = imgstr
    return render_template('license_plate.html', photo_form=photo_form, result=result)

def detect_from_url_cracks(image_path):
   try:
      result = {}
      print("Inside detect from url",image_path)
      #classify_image.classify_doc(image_path)
      result_req = classify_image_cracks.classify_doc(image_path)
      #result_req = detect_cracks.decode(image_path)
      print("result_req",result_req)
      image_p = open(image_path, 'rb')
      image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
      imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
      result['original'] = imgstr
      if len(result_req) == 0:
          result['classification_score']="Score not Identified"
          result['classification_label'] = "Label not Identified"
      else:
          result['classification_score'] = format(100*float(result_req['classification_score']), '.2f') + "%"
          result['classification_label'] = result_req['classification_label']
      return result
   except Exception as e:
       print(e)


def detect_from_url_vessel(image_path):
   try:
      result = {}
      print("Inside detect from url",image_path)
      #classify_image.classify_doc(image_path)
      result_req = pred_image(image_path)
      #result_req = detect_cracks.decode(image_path)
      print("result_req",result_req)
      image_path = result_req["image_path"]
      image_p = open(image_path, 'rb')
      image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
      imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
      result['original'] = imgstr
      if len(result_req) == 0:
          result['filled_percentage']="Score not Identified"
      else:
          result['filled_percentage'] = str(result_req["filled_percentage"]) + "%"
      return result
   except Exception as e:
       print(e)


@app.route('/cracks', methods=['GET', 'POST'])
def cracks():
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f = os.path.join(TEMPLATE_PATH, file_p.filename)
        file_p.save(f)
        result = detect_from_url_cracks(f)
      return render_template('runway_cracks.html',photo_form=photo_form, result=result)
    elif request.method == 'POST':
        data = request.get_json()
        result = classify_image_cracks.classify_doc(data['input_image'])
        return jsonify(result)
    else:
      return render_template('runway_cracks.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)


@app.route('/vessel_contents', methods=['GET', 'POST'])
def vessel_contents():
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f = os.path.join(TEMPLATE_PATH, file_p.filename)
        file_p.save(f)
        result = detect_from_url_vessel(f)
      return render_template('vessel_contents.html',photo_form=photo_form, result=result)
    elif request.method == 'POST':
        data = request.get_json()
        result = pred_image(data['input_image'])
        return jsonify(result)
    else:
      return render_template('vessel_contents.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)


def detect_from_url_lesion(image_path):
   try:
      result = {}
      print("Inside detect from url",image_path)
      #classify_image.classify_doc(image_path)
      result_req = classify_image_lesion.classify_doc(image_path)
      #result_req = detect_cracks.decode(image_path)
      print("result_req",result_req)
      image_p = open(image_path, 'rb')
      image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
      imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
      result['original'] = imgstr
      if len(result_req) == 0:
          result['classification_score']="Score not Identified"
          result['classification_label'] = "Label not Identified"
      else:
          result['classification_score'] = format(100*float(result_req['classification_score']), '.2f') + "%"
          result['classification_label'] = result_req['classification_label']
      return result
   except Exception as e:
       print(e)

@app.route('/skin_lesion', methods=['GET', 'POST'])
def skin_lesion():
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f = os.path.join(TEMPLATE_PATH, file_p.filename)
        file_p.save(f)
        result = detect_from_url_lesion(f)
      return render_template('skin_lesion_classification.html',photo_form=photo_form, result=result)
    elif request.method == 'POST':
        data = request.get_json()
        result = classify_image_lesion.classify_doc(data['input_image'])
        return jsonify(result)
    else:
      return render_template('skin_lesion_classification.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)




def read_img(img_path):
    return sitk.GetArrayFromImage(sitk.ReadImage(img_path))


@app.route('/index_brain_tumour', methods=['GET','POST'])
def index_brain_tumour():
    print("in routes")
    UPLOAD_FOLDER = TEMPLATE_PATH
    print("in brain tumour")
    files = [file for file in os.listdir(UPLOAD_FOLDER)
             if file.endswith('.mmri')]
    print("after files in brain tumour")
    return render_template('index_brain_tumour.html', title='Home', files=files)


@app.route('/upload_brain_tumour')
def upload_file_brain_tumour():
    return render_template('upload_brain_tumour.html', title='Upload the MRI files')


@app.route('/uploader', methods=['GET','POST'])
def upload_file_():
    UPLOAD_FOLDER = TEMPLATE_PATH
    cause = ''  # For catching specific cause of error
    modalities = ['t1', 't2w', 't1ce', 'flair']
    pat = re.compile(r'[^\.]*\.(.*)')
    formats = {m: pat.findall(request.files[m].filename)[0] for m in modalities}
    if request.method == 'POST':
        try:
            cause = 'while uploading the files. Ensure that the files'
            ' are accessible and try again. '
            for m in modalities:
                f = request.files[m]
                f.save(
                 os.path.join(
                   UPLOAD_FOLDER,
                   secure_filename(f"{request.form['name']}_{m}.{formats[m]}")
                   )
                )
            #flash('Files were uploaded succesfully.')

            cause = 'while exporting the files into a single multimodal-MRI'
            ' (.mmri) file. Make sure the uploaded files are valid MRI files'
            ' and try again.'
            img = np.array(
             [
               read_img(
                 os.path.join(
                   UPLOAD_FOLDER,
                   secure_filename(f"{request.form['name']}_{m}.{formats[m]}")
                 )
               )
               for m in modalities
             ]
            )

            np.save(os.path.join(
              UPLOAD_FOLDER,
              secure_filename(f"{request.form['name']}")
            ), img)

            os.rename(
                os.path.join(
                    UPLOAD_FOLDER,
                    secure_filename(f"{request.form['name']}.npy")
                    ),
                os.path.join(
                    UPLOAD_FOLDER,
                    secure_filename(f"{request.form['name']}.mmri")
                    )
                )
            cause = 'while cleaning up the temporary files. Make sure this '
            f'path is accessible and try again:{UPLOAD_FOLDER}'
            [os.remove(
              os.path.join(
                UPLOAD_FOLDER,
                f'{request.form["name"]}_{m}.{formats[m]}'
                )
            ) for m in modalities]

            cause = None

        except Exception as e:
            flash(
                f'An error occured {cause}' if cause is not None else
                'An unknown error occured.')
            return f"""<div class="w3-container">
              <h1 class="w3-xxxlarge w3-text-black"><b>Sorry Something Went Wrong.</b></h1>
              <hr style="width:50px;border:5px solid red" class="w3-round">
              <p>An error occured while uploading the MRI files. See below for more info.</p>
              <br />
              <h3 class="w3-xlarge w3-text-black"><b>Error Text:</b></h3>
              <hr>
              <p> {e} </p>
              <a href='/upload'><h3 class="w3-xlarge w3-text-black">
                <b>&lt; Go back and try again.</b></h3></a>
            </div>"""
        #return redirect(url_for('../index_brain_tumour'))
        files = [file for file in os.listdir(TEMPLATE_PATH) if file.endswith('.mmri')]
        return render_template('index_brain_tumour.html', title='Home', files=files)
    #return redirect(url_for('../index_brain_tumour'))
    files = [file for file in os.listdir(TEMPLATE_PATH) if file.endswith('.mmri')]
    return render_template('index_brain_tumour.html', title='Home', files=files)

def send_request_brain(image_path,url):
    # image = open(file, 'rb')
    # image_64_encoded = base64.b64encode(image.read()).decode("utf-8")
    # image.close()
    # data to be sent to api
    #data = {'image_path': image_path}

    headers = {
            'Content-Type': "application/json",
            'Cache-Control': "no-cache",
    }
    # sending post request and saving response as response object
    response_req = requests.request("POST", url=url, json=image_path, headers=headers)
    print(response_req)
    response = json.loads(response_req.text)
    # extracting response text
    #server_url = response.text
    print("  The server response is: %s" % response)
    return response

@app.route('/analyze', methods=['GET', 'POST'])
def analyze():
    UPLOAD_FOLDER = TEMPLATE_PATH
    if request.method == 'POST':
        file = request.form.get('files_dropdown')
        print(file)
        print(UPLOAD_FOLDER)
        # try:
        URL="http://0.0.0.0:5011/make_gif"
        out_file = send_request_brain(file,URL)
        #out_file = make_gif(file)
        success = True
        error = None
        # except Exception as e:
        #     success = False
        #     error = str(e)

        return render_template('analyze.html', title='Results', success=success,
                               file=out_file, error=error, folder=UPLOAD_FOLDER)
    elif request.method == 'GET':
        if TESTING_ANALYZE:
            return render_template('analyze.html', title='Testing Analyze', success=True,
                                   file='Test', error='error', folder=UPLOAD_FOLDER)
        else:
            flash('Select a MMRI file from the list or add your own to get the prediction result.')
            return redirect(url_for('index'))


@app.route('/download-mask/<file>/<mod>', methods=['GET','POST'])
def download(file, mod):
    UPLOAD_FOLDER = TEMPLATE_PATH
    if request.method == 'GET':
        mods = {'t1': 0, 't2': 1, 't1ce': 2, 'flair':3}

        img = np.load(f'{UPLOAD_FOLDER}/{file}.npy')
        save = img[mods[mod]]
        name = f'{file[:-5]}_{mod}.nii.gz'
        save_nii(save, name)
        return redirect(url_for('static', filename=EXPORT_FOLDER_REL+name), code=301)



## Adding code for IS training,clasification & map score calculation
@app.route("/train_instance_segmentation", methods=["POST"])
def train_instance_segment():
    # read the input params from input json
    data = request.get_json()
    num_classes = data["train"]["num_classes"]
    learning_rate = data["train"]["learning_rate"]
    nos_of_epochs = data["train"]["nos_of_epochs"]
    usecaseid = data["train"]["usecaseid"]
    class_info_file = os.path.join(basepath, str(usecaseid), "class_info_" + str(usecaseid) + ".json")
    class_name= {}
    with open(class_info_file) as f:
        data = json.load(f)
        for classes,id  in data.items():
            class_name[classes] = id

    #update database with train status before starting to train.
    usecase_params = {}
    usecase_params['status'] = inception_config.DB_STATUS_PROGRESS
    usecase_params['testaccuracy'] = -1
    usecase_params['trainaccuracy'] = -1
    usecase_params['valaccuracy'] = -1
    print(" ======> ", usecase_params, " ======> ", usecaseid)
    db.updateUseCase(usecase_params, usecaseid)

    # Call custom dataset class with input params
    custom_data_train.CustomDataset(class_name, usecaseid)

    print("out of f1")

    # Call train function to start training the model with the input parameters
    train_model = custom_data_train.Train()
    print("out of f2")
    status = train_model.train_model(learning_rate, basepath, class_name, num_classes,
                                     nos_of_epochs, usecaseid)
    #calculate the mAP score on validation data & update DB
    print("out of f3")
    try:

        # obj_map = custom_demo.Segmentation()
        # map = obj_map.calculate_map_score(usecaseid, basepath, "val", class_name)
        # map = json.loads(map.get_data().decode("utf-8"))
        # map = map['mAP']

    #update DB with train stats
        training_status = None
        if status == "SUCCESS":
            usecase_params = {}
            usecase_params['status'] = inception_config.DB_STATUS_COMPLETE
            usecase_params['testaccuracy'] = -1
            usecase_params['trainaccuracy'] = -1 ## update map score on val data
            usecase_params['valaccuracy'] = -1
            print(" ======> ", usecase_params, " ======> ", usecaseid)
            db.updateUseCase(usecase_params, usecaseid)
            training_status = "Training completed successfully."
        elif status == "ERROR":
            usecase_params = {}
            usecase_params['status'] = ""
            #usecase_params['testaccuracy'] = 0
            #usecase_params['trainaccuracy'] = 0
            #usecase_params['valaccuracy'] = 0
            print(" ======> ", usecase_params, " ======> ", usecaseid)
            db.updateUseCase(usecase_params, usecaseid)
            training_status = "Training ended with error."

        # Training status
        return training_status

    except Exception as e:
        logger.info("Error updating train status in DB ")
        logger.error(e)
        usecase_params = {}
        usecase_params['status'] = ""
        # usecase_params['testaccuracy'] = 0
        # usecase_params['trainaccuracy'] = 0
        # usecase_params['valaccuracy'] = 0
        print(" ======> ", usecase_params, " ======> ", usecaseid)
        db.updateUseCase(usecase_params, usecaseid)

        # Training status
        training_status = "Training ended with error."
        return training_status


@app.route("/prediction", methods=["POST"])
def segmentation():
    # read the input params from input json
    data = request.get_json()
    usecaseid = data["classify"]["usecaseid"]

    #get all the classes and ids from the file in which annotate output is stored
    class_info_file = os.path.join(basepath, str(usecaseid), "class_info_" + str(usecaseid) + ".json")
    with open(class_info_file) as f:
        data = json.load(f)
        class_name = {}
        for classes, id in data.items():
            class_name[classes] = id

   # Initialize class for prediction
    obj_detect = custom_demo.Segmentation()
    predictions = obj_detect.segmentation(usecaseid, basepath,class_name)
    predictions = json.dumps(predictions)
    return predictions

@app.route("/calculate_map", methods=["POST"])
def calculate_map():
    # read the input params from input json
    data = request.get_json()
    usecaseid = data["mAP"]["usecaseid"]
    partition = data["mAP"]["partition"]

    ## read class info file for class names
    class_info_file = os.path.join(basepath, str(usecaseid), "class_info_" + str(usecaseid) + ".json")
    with open(class_info_file) as f:
        data = json.load(f)
        class_name = {}
        for classes, id in data.items():
            class_name[classes] = id

    #Initialise class for Map calculation
    obj_map = custom_demo.Segmentation()
    map = obj_map.calculate_map_score(usecaseid, basepath, partition,class_name)
    return map

@app.route('/detect', methods=['GET', 'POST'])
def post():
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    print("in post")
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f = os.path.join(TEMPLATE_PATH, file_p.filename)
        file_p.save(f)
        print(f)
        file = open("testfile.txt", "w")
        filename = (file_p.filename)
        file.write(filename)
        file.close()
        result={}
        image_p = open(f, 'rb')
        image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
        imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
        result['original'] = imgstr
        print("in post :" , result)
      return render_template('demo_burgan.html',
                             photo_form=photo_form , result=result)
    else:
      return render_template('demo_burgan.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)

@app.route('/preprocess', methods=['GET', 'POST'])
def mask():
    photo_form = PhotoForm(request.form)
    print("Into Blur")
    file = open('testfile.txt', 'r')
    message = file.read()
    file.close()
    result={}
    path = preprocess(message)
    print("Path in UI ",path)
    image_p = open(path, 'rb')
    image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
    imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
    result['original'] = imgstr
    return render_template('demo_burgan.html', photo_form=photo_form, result=result)

@app.route('/motion_detection', methods=['GET', 'POST'])
def upload_fil():
  photo_form = PhotoForm(request.form)
  return render_template('zone_access.html', photo_form=photo_form, result={})

@app.route('/video_feed',methods=['GET', 'POST'])
def video_feed():
    """Video streaming route. Put this in the src attribute of an img tag."""
    #return Response(gen(Camera()), mimetype='multipart/x-mixed-replace; boundary=frame')
    result = {}
    photo_form = PhotoForm(request.form)
    motion_detector.get_frame()
    result["type"] = "video/avi"
    result["original"] = "./static/motion_detector.mp4"
    return render_template('zone_access.html', photo_form=photo_form, result=result)


def check_filter_parameter(jsonObj):
    try:
        useCaseId = getReqeuestParam(jsonObj, "useCaseId")
        dataType = getReqeuestParam(jsonObj, "dataType")
        className = getReqeuestParam(jsonObj, "className")
        imgName = getReqeuestParam(jsonObj, "imgName")
        opImgName = getReqeuestParam(jsonObj, "opImgName", "")
        opPath = getReqeuestParam(jsonObj, "opPath", "")
        ipPath = getReqeuestParam(jsonObj, "ipPath", "")
        jsonObj[SUCCESS] = "0"
        image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
        if (not ipPath == ""): 
            image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
        save_image_path = image_path
        if (not opImgName == ""):
            os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                                    exist_ok=True)
            save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName
            #image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName
        filterJson={'image_path': image_path,'save_image_path':save_image_path,
                                     'useCaseId': useCaseId,'dataType': dataType,'className': className,'imgName': imgName,'opImgName': opImgName,
                                      'opPath': opPath,'ipPath': ipPath}
    except Exception as e:
            logger.error("Error while providing inputs to the filter: " + str(e) + " input: " + str(jsonObj))
    
    return json.dumps(filterJson)


@app.route('/depth_detect',methods=['GET', 'POST'])
def depth_detect():
    photo_form = PhotoForm(request.form)
    return render_template('depth_detect1.html', photo_form=photo_form, result={})

@app.route('/social_distancing',methods=['GET', 'POST'])
def social_distancing():
    photo_form = PhotoForm(request.form)
    return render_template('social_distancing.html', photo_form=photo_form, result={})

@app.route('/ppe_monitoring',methods=['GET', 'POST'])
def ppe_monitoring():
    photo_form = PhotoForm(request.form)
    return render_template('ppe_monitoring.html', photo_form=photo_form, result={})


@app.route('/drowsyy_detection',methods=['GET', 'POST'])
def upload_file():
  photo_form = PhotoForm(request.form)
  return render_template('drowsiness_detect.html', photo_form=photo_form, result={})

@app.route('/drowsiness_detect',methods=['GET', 'POST'])
def drowsy_ui():
    """Video streaming route. Put this in the src attribute of an img tag."""
    #return Response(gen(Camera()), mimetype='multipart/x-mixed-replace; boundary=frame')
    result = {}
    photo_form = PhotoForm(request.form)
    #drowsiness_detection.drowsy_detect()
    result["type"] = "video/avi"
    result["final"] = "./static/finalout.mp4"
    # result["original"] = "./static/Frame2.mp4"
    return render_template('drowsiness_detect.html', photo_form=photo_form, result=result)
    
    
@app.route('/sign_language',methods=['GET', 'POST'])
def upload_video():
  photo_form = PhotoForm(request.form)
  return render_template('sign.html', photo_form=photo_form, result={})

@app.route('/gesture_predicted',methods=['GET', 'POST'])
def h2s_ui():
    """Video streaming route. Put this in the src attribute of an img tag."""
    #return Response(gen(Camera()), mimetype='multipart/x-mixed-replace; boundary=frame')
    result = {}
    photo_form = PhotoForm(request.form)
    #drowsiness_detection.drowsy_detect()
    
    result["type"] = "video/avi"
    result["original"] = "./static/slgr203.mp4"
    # result["original"] = "./static/Frame2.mp4"
    return render_template('sign.html', photo_form=photo_form, result=result)
def satellite_img(image_path):
   try:
      result={}
      image_p = open(image_path, 'rb')
      image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
      imgstr = 'data:image/tif;base64,{:s}'.format(image_64_encoded)
      logger.info("Reached ui2method")
      img1 = satellite_image(image_path)
      logger.info(str(img1))
      logger.info("Got img1")
      image_p1 = open(img1, 'rb')
      image_64_encoded1 = base64.b64encode(image_p1.read()).decode("utf-8")
      imgstr1 = 'data:image/png;base64,{:s}'.format(image_64_encoded1)
      result['original'] = imgstr1
      return result
      ##K.clear_session()
   except Exception as e:
       print(e)

@app.route('/sat', methods=['GET', 'POST'])
def sat_ui():
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f = os.path.join(TEMPLATE_PATH, file_p.filename)
        file_p.save(f)
        logger.info("Reached ui1method")
        result = satellite_img(f)
      return render_template('sat.html', photo_form=photo_form, result=result)
    else:
      return render_template('sat.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)

def lits3D(image_path):
   try:
      print("image_path",image_path)
      result={}
      output = []
      inp = []
      logger.info("in lits3D function")
      for image in image_path:
        
          image_p = open(image, 'rb')
          #image_p = Image.open(image)
          image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
          #print("****1111",image_p)
          imgstr = 'data:image/bmp;base64,{:s}'.format(image_64_encoded)
          #logger.info("Reached ui2method")
          inp.append(imgstr)
         
      gif_path = gif_lits(image_path)

      for out in gif_path:
        logger.info(out)
        image_p1 = open(out, 'rb')
        image_64_encoded1 = base64.b64encode(image_p1.read()).decode("utf-8")
        imgstr1 = 'data:image/gif;base64,{:s}'.format(image_64_encoded1)
        #result['original'] = imgstr1
        output.append(imgstr1)

      return output
      ##K.clear_session()
   except Exception as e:
       print("in exception")
       print(e)

@app.route('/lits_3d', methods=['GET', 'POST'])
def ui_3d():
  try:
    K.clear_session()
    #file_p =[]
    logger.info("inside 3D")
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    #logger.info("crossing form")
    photo_form = PhotoForm(request.form)
    #logger.info("crossing photoform")
    img_saved = []
    logger.info("images uploaded")
    if request.method == 'POST':
        logger.info("in post")
        file_p = request.files.getlist('file[]')
        for f in file_p:
            f1 = os.path.join(os.path.join(TEMPLATE_PATH,"input"), f.filename)
            #print("********",f1)
            img_saved.append(f1)
            f.save(f1)
            #print("file saved")
        logger.info("Reached ui1method")
        output = lits3D(img_saved)
        return render_template('lits_3d.html', photo_form=photo_form, result=output)
    else:
        logger.info("in else")
        return render_template('lits_3d.html', photo_form=photo_form, result=[])
  except Exception as e:
      print(e)

@app.route("/view_nii")
def index():
   return render_template("nii_viewer.html")
def check_filter_parameter(jsonObj):
    try:
        useCaseId = getReqeuestParam(jsonObj, "useCaseId")
        dataType = getReqeuestParam(jsonObj, "dataType")
        className = getReqeuestParam(jsonObj, "className")
        imgName = getReqeuestParam(jsonObj, "imgName")
        opImgName = getReqeuestParam(jsonObj, "opImgName", "")
        opPath = getReqeuestParam(jsonObj, "opPath", "")
        ipPath = getReqeuestParam(jsonObj, "ipPath", "")
        jsonObj[SUCCESS] = "0"
        image_path = basepath + "/" + useCaseId + "/" + dataType + "/" + className + "/" + imgName
        if (not ipPath == ""): 
            image_path = basepath + "/" + useCaseId + "/" + ipPath + "/" + dataType + "/" + className + "/" + imgName
        save_image_path = image_path
        if (not opImgName == ""):
            os.makedirs(basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className, mode=755,
                                    exist_ok=True)
            save_image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName
            #image_path = basepath + "/" + useCaseId + "/" + opPath + "/" + dataType + "/" + className + "/" + opImgName
        filterJson={'image_path': image_path,'save_image_path':save_image_path,
                                     'useCaseId': useCaseId,'dataType': dataType,'className': className,'imgName': imgName,'opImgName': opImgName,
                                      'opPath': opPath,'ipPath': ipPath}
    except Exception as e:
            logger.error("Error while providing inputs to the filter: " + str(e) + " input: " + str(jsonObj))
    
    return json.dumps(filterJson)

def detect_from_cloth(image_path):
   try:
      result = {}
      print("Inside detect from url",image_path)
      image_p = open(image_path, 'rb')
      image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
      imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
      result['original'] = imgstr
      pixel_DT_result = PixelDTGAN.cloth_predictor(image_path)
      print("PIXEL DT Result----:",pixel_DT_result)
      result_req = testing.execute_visualsearch(pixel_DT_result)
    #   print("result_req---------",result_req)
      for x in range(0,6):
          image_p = open(result_req[x], 'rb')
          image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
          imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
          result['predicted'+str(x)] = imgstr 
      return result
   except Exception as e:
       print(e)

@app.route('/pixeldt', methods=['GET', 'POST'])
def pixel_search():
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    print("In the api method")
    print("form--",photo_form)
    if request.method == "POST":
        print("In post")
        quest1 = request.form['Ques']
        #quest2 = request.files.get(['Ques'])
        #result = detect_from_cloth(quest)
        print("Ques1-------",quest1)
        print("Ques2-------",quest2)
        #print("Out of Visual Search by cloth")
        return render_template('pixel.html',photo_form=photo_form, result=result)
    else:
        return render_template('pixel.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)
def detect_from_person(image_path):
   try:
      result = {}
      print("Inside detect from url",image_path)
      image_p = open(image_path, 'rb')
      image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
      imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
      result['original'] = imgstr
      result_req = testing.execute_visualsearch(image_path)
    #   print("result_req---------",result_req)
      for x in range(0,12):
          image_p = open(result_req[x], 'rb')
          image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
          imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
          result['predicted'+str(x)] = imgstr 
      return result
   except Exception as e:
       print(e)

@app.route('/visual_search', methods=['GET', 'POST'])
def visual_direct():
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f = os.path.join(TEMPLATE_PATH, file_p.filename)
        file_p.save(f)
        result = detect_from_person(f)
        print("Out of Visual Search by Image")
      return render_template('visual.html',photo_form=photo_form, result=result)
    else:
      return render_template('visual.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)

def text_optimize(text_caption):
          text_path = "custom_projects/resources/AttnGAN_master/code/1.txt"
          text_file=open(text_path,'w')
          text_file.write(text_caption)
          text_file.close()
          result_attn1 = main_test.execute_attngan(text_path)
        #   print("result_Attn 1---",result_attn1)
          attnGAN_result1 = result_attn1[2]     
          result_req1= testing.execute_visualsearch(attnGAN_result1)
          return result_req1
'''
def search_by_text(quest):
   K.clear_session()
   try:
      result={}
      text_caption = quest  
      list1=["i do not want a long sleeve blouse","i do not want shorts",
      "i do not want a floral print top","i do not want a sleeveless dress","i am not looking for printed jacket",
      "i am not looking for Baggy jacket","i am not looking for crop top","i am not looking for Tank Top",
      "i am not looking for eco friendly print tshirt","i am not looking for Deep V neck dress",
      "i am not looking for full sleeve tees"]
      list2=["i want a short sleeve blouse","i want a full jeans",
      "i want a plain top","i want a full sleeve dress","i am looking for solid jacket",
      "i want a Skinny jacket","i am looking for Full Length Top","i want full sleeve top",
      "i am looking for animal print tshirt","i am looking for rounded neck dress",
      "i am looking for half sleeve tees"]
      if text_caption in list1:
          print("Got a negative text")
          key = list1.index(text_caption)
          positive_text =  list2[key]
          print("positive_text--",positive_text)
          result_req= text_optimize(positive_text)
      else:
          print("Got a positive text")
          result_req= text_optimize(text_caption)
      print("result_req---------",result_req)
      for x in range(0,18):
          image_p = open(result_req[x], 'rb')
          image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
          imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
          result['predicted'+str(x)] = imgstr 
      return result
   except Exception as e:
       print(e)
'''
def search_by_text(quest):
   K.clear_session()
   try:
      result={}
      text_caption = quest
      result_req= text_optimize(text_caption)
    #   print("result_req---------",result_req)
      x1=0
      y1=0#0.25
      x2=0.9
      y2 = 1#0.80
      cv_img= cv2.imread(result_req[0])
      h,w=cv_img.shape[:2]
      sr,sc=int(h*x1),int(w*y1) #sr--y-axis in upper, sc--x-axis in left side
      er,ec=int(h*x2),int(w*y2) #er--y-axis in lower, ec--x-axis in right side
      cropped=cv_img[sr:er,sc:ec]
      cv2.imwrite(result_req[0], cropped)
      for x in range(0,12):
          image_p = open(result_req[x], 'rb')
          image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
          imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
          result['predicted'+str(x)] = imgstr 
      return result
   except Exception as e:
       print(e)
@app.route('/attn_gan', methods=['GET', 'POST'])
def attnGAN_ui():
  #K.clear_session()
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    print("Line number 2905")
    if request.method == 'POST':
        quest = request.form['Ques']
        print("Ques---",quest)
        result = search_by_text(quest)
        return render_template('attn.html', photo_form=photo_form, result=result, querytext=quest)
    else:
        return render_template('attn.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)

def search_gan(quest):
   K.clear_session()
   try:
      result={}
      text_caption = quest
      print("In gansearch method")
      text_path = "custom_projects/resources/AttnGAN_master/code/1.txt"
      text_file=open(text_path,'w')
      text_file.write(text_caption)
      text_file.close()
      result_attn1 = main_test.execute_attngan(text_path)
    #   print("result_Attn 1---",result_attn1)
      attnGAN_result1 = result_attn1[2]
    #   print("result_req---------",attnGAN_result1)
      x1=0
      y1=0#0.25
      x2=0.9
      y2 = 1#0.80
      cv_img= cv2.imread(attnGAN_result1)
      h,w=cv_img.shape[:2]
      sr,sc=int(h*x1),int(w*y1) #sr--y-axis in upper, sc--x-axis in left side
      er,ec=int(h*x2),int(w*y2) #er--y-axis in lower, ec--x-axis in right side
      cropped=cv_img[sr:er,sc:ec]
      cv2.imwrite(attnGAN_result1, cropped)
      image_p = open(attnGAN_result1, 'rb')
      image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
      imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
      result['predicted'] = imgstr 
      return result
   except Exception as e:
       print(e)

@app.route('/query_gan', methods=['GET', 'POST'])
def attnGAN_query():
  #K.clear_session()
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    print("Line number 3025")
    if request.method == 'POST':
        quest = request.form['Ques']
        print("Ques---",quest)
        result = search_gan(quest)
        return render_template('attn_separate.html', photo_form=photo_form, result=result, querytext=quest)
    else:
        return render_template('attn_separate.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)

@app.route('/lex_ui' , methods=['GET', 'POST'])
def signUp():
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    result = "Yes"
    return render_template('bot1.html', photo_form=photo_form, result={})

@app.route('/lext', methods=['GET', 'POST'])
def lext():
  #K.clear_session()
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    print("In lext api")
    #quest = request.form['Ques']
    #print("Ques---",quest)
    #result = "yeah i got this"
    #return render_template('bot1.html', photo_form=photo_form, result={})
    if request.method == 'POST':
        quest = request.form['Ques']
        print("Ques---",quest)
        result = search_by_text(quest)
        #result = "yeah i got this"
        return render_template('attn.html', photo_form=photo_form, result=result)
    else:
        print("In else of lext")
        return render_template('bot1.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)
@app.route('/people_counter',methods=['GET', 'POST'])
def upload_file_people_count():
  photo_form = PhotoForm(request.form)
  return render_template('people_count.html', photo_form=photo_form, result={})

@app.route('/result_people_count',methods=['GET', 'POST'])
def people_count_ui():
    """Video streaming route. Put this in the src attribute of an img tag."""
    #return Response(gen(Camera()), mimetype='multipart/x-mixed-replace; boundary=frame')
    result = {}
    photo_form = PhotoForm(request.form)
    print("Into people count")
    #drowsiness_detection.drowsy_detect()
    result["type"] = "video/mp4"
    result["original"] = "./static/output_02_people_count.mp4"
    # result["original"] = "./static/Frame2.mp4"
    return render_template('people_count.html', photo_form=photo_form, result=result)



def de_detect_from_url(image_path,url):
   try:
      result={}
    #   URL="https://127.0.0.1:6000/result_file"

      headers = {
                "Content-Type": "application/json",
                'Cache-Control': "no-cache"
          }
      data = {'image_path' : image_path}
      print("Image Path: ", image_path)
      response_req = requests.post(url, json=data, headers=headers)
      print("response_req",response_req)
    #   response = json.loads(response_req.text)
      # extracting response text
      #server_url = response.text
    #   print("  The server response is: %s" % response)
      # return response
      abc = 'results.png'
      result_req = os.path.join(TEMPLATE_PATH, abc)
    #   result_req= response
      # result_req = generate_depth_map(image_path)
      if len(result_req) == 0:
          result['original'] ="Not Identified"
      else:
          image_p = open(os.path.join(TEMPLATE_PATH, abc), 'rb')
          image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
          imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
          result['original'] = imgstr
    #   print("from UI", result)
      return result
   except Exception as e:
       print(e)


@app.route('/depth_estimation_upload')
def upload_depth():
  photo_form = PhotoForm(request.form)
  print("now i am in upload")
  return render_template('depth_estimation.html', photo_form=photo_form, result={})


@app.route('/depth_estimation', methods=['GET', 'POST'])
def post_depth():
  try:
    dirname, basename = os.path.split('templates')
    print("in depth estimation api")
    print(dirname, basename)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f = os.path.join(TEMPLATE_PATH, file_p.filename)   #templates mein jakr input img save karo
        file_p.save(f)
        print(f)        #f ka matlab hai uss puri image ki path, for eg. custom/projects/templates/img.jpg
        URL="http://127.0.0.1:6000/result_file"
        result = de_detect_from_url(f,URL)
        print("from post -")
        # print("from post -", result)

        # os.remove(f)
      return render_template('depth_estimation.html',
                             photo_form=photo_form, result=result)
    else:
      # print("GET request to load the demo page...")
      print("i am in else")
      return render_template('depth_estimation.html', photo_form=photo_form, result={})
      # return redirect(url_for('upload'))
  except Exception as e:
      print(e)

def visual_image(image_path):
   try:
      print("image_path",image_path)
      result={}
      output = []
      inp = []
      
      logger.info("in visual_image function")
        
      image_p = open(image_path, 'rb')
      #image_p = Image.open(image)
      image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
      #print("****1111",image_p)
      imgstr = 'data:image/jpg;base64,{:s}'.format(image_64_encoded)
      #logger.info("Reached ui2method")
      logger.info("after imgstr")
      out_path = visualsearch(image_path)
      logger.info("out of testing_manual")
      rec_images = glob.glob(os.path.join("'/home/ubuntu/cv-asset/custom_projects/resources/VisualSearch_MXNet_master/output",out_path, '**.jpg'))
      rec_images1 = sorted(rec_images)
      #logger.info(rec_images1)
      for x in range(len(rec_images1)):
        logger.info(rec_images1[x])
        logger.info(x)
        out = rec_images1[x]
        if(out[-22:] !="RecommendationFull.jpg"):
            image_p1 = open(out, 'rb')
            image_64_encoded1 = base64.b64encode(image_p1.read()).decode("utf-8")
            imgstr1 = 'data:image/jpg;base64,{:s}'.format(image_64_encoded1)
            #result['original'] = imgstr1
            output.append(imgstr1)
            #logger.info('predicted'+str(x))
            #result[str(x)] = imgstr

      return output
      ##K.clear_session()
   except Exception as e:
       print("in exception")
       print(e)



########### biometrics workbench for facial recognition
ALLOWED_EXTENSIONS = set(['mp4','jpg', 'png', 'jpeg'])

def allowed_file(filename):
	return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route('/biometrics_video_upload',methods=['POST','GET'])
def biometrics_video_upload():
  print("hi in biometrics video upload")
  print(request.files)
  if 'video_file' not in request.files:
    resp = jsonify({'message' : 'No file part in the request'})
    resp.status_code = 400
    return resp
	
  # file = request.files('video_file')
  files = request.files.getlist('video_file')
	
  errors = {}
  success = False
	
  for file in files:
    if file and allowed_file(file.filename):
      filename = secure_filename(file.filename)
      #file.save(os.path.join('biometrics_wb/videoUpload', filename))
      file.save(os.path.join('static', filename))
      success = True
    else:
      errors[file.filename] = 'File type is not allowed'

  if success and errors:
    errors['message'] = 'File(s) successfully uploaded'
    resp = jsonify(errors)
    resp.status_code = 206
    return resp
  if success:
    resp = jsonify({'message' : 'Files successfully uploaded'})
    resp.status_code = 201
    imagelist = video_encoding.video_function()
    return jsonify({"imagelist": imagelist})

    # return resp
  else:
    resp = jsonify(errors)
    resp.status_code = 400
    return resp


@app.route('/biometrics_video',methods=['POST','GET'])
def biometrics_video():
  print("hi in biometrics video")
  print(request.files)
  if 'video_file' not in request.files:
    resp = jsonify({'message' : 'No file part in the request'})
    resp.status_code = 400
    return resp
	
  # file = request.files('video_file')
  files = request.files.getlist('video_file')
	
  errors = {}
  success = False
	
  for file in files:
    if file and allowed_file(file.filename):
      filename = secure_filename(file.filename)
      #file.save(os.path.join('biometrics_wb/videoUpload', filename))
      file.save(os.path.join('static', filename))
      success = True
    else:
      errors[file.filename] = 'File type is not allowed'

  if success and errors:
    errors['message'] = 'File(s) successfully uploaded'
    resp = jsonify(errors)
    resp.status_code = 206
    return resp
  if success:
    resp = jsonify({'message' : 'Files successfully uploaded'})
    resp.status_code = 201
    imagelist = video_encoding.video_function()
    return jsonify({"imagelist": imagelist})

    # return resp
  else:
    resp = jsonify(errors)
    resp.status_code = 400
    return resp


@app.route('/biometrics_image',methods=['POST','GET'])
def biometrics_image():
  print("hi in image")

  print(request.files)
  if 'img' not in request.files:
    resp = jsonify({'message' : 'No file part in the request'})
    resp.status_code = 400
    return resp
	
  # file = request.files('video_file')
  files = request.files.getlist('img')

  errors = {}
  success = False
	
  for file in files:
    if file and allowed_file(file.filename):
      filename = secure_filename(file.filename)
      file.save(os.path.join('biometrics_wb/imageUpload', filename))
      success = True
    else:
      errors[file.filename] = 'File type is not allowed'

  if success and errors:
    errors['message'] = 'File(s) successfully uploaded'
    resp = jsonify(errors)
    resp.status_code = 206
    return resp
  if success:
    resp = jsonify({'message' : 'Files successfully uploaded'})
    resp.status_code = 201
    singleimage = image_encoding.image_function()
    return jsonify({"singleimage": singleimage})

    # return resp
  else:
    resp = jsonify(errors)
    resp.status_code = 400
    return resp


@app.route('/biometrics')
def facial_recognition():
  photo_form = PhotoForm(request.form)
  print("in biometrics api ")
  return render_template('BiometricLandingPage.html', photo_form=photo_form, result={})


#####enrollment
def detect_for_biometrics(image,unique_id,url):
    try:
        result={}
        # URL="http://127.0.0.1:5000/FaceRecognition/enroll"

        headers = {
                    "Content-Type": "application/json",
                    'Cache-Control': "no-cache"
            }
        data = {'image' : image, 'unique_id' : unique_id}
        # print("data: ", data)
        response_req = requests.post(url, json=data, headers=headers)
        print("response_req",response_req)
        return response_req
    except Exception as e:
        print(e)


@app.route('/biometrics_enroll', methods=['GET','POST'])
def biometrics_enroll():
    print("In Biometrics enroll api")
    jsonObj = request.get_json()
    # print(jsonObj)
    # logger.info("json object : " + str(jsonObj))
    K.clear_session()
    try:
      dirname, basename = os.path.split('templates')
      print("in enroll api")
      print(dirname, basename)
      form = PhotoForm(CombinedMultiDict((request.files, request.form)))
      photo_form = PhotoForm(request.form)

      if request.method == 'POST' :
        jsonObj = request.get_json()
        print("in biometrics_enroll if condition")
        image = jsonObj['image']
        unique_id = jsonObj['unique_id']
        print("unique_id : ",unique_id)
        URL = "http://127.0.0.1:5000/FaceRecognition/enroll"

        result = detect_for_biometrics(image,unique_id,URL)
        print("result is ", result.text)
        return jsonify(result.text)
      else:
        print("i am in else")

    except Exception as e:
        print(e)

    # return result.text



#####identification
def identify_for_biometrics(image,url):
    try:
        result={}
        # URL = "http://127.0.0.1:5000/FaceRecognition/identify"

        headers = {
                    "Content-Type": "application/json",
                    'Cache-Control': "no-cache"
            }
        data = {'image' : image}
        # print("data: ", data)
        response_req = requests.post(url, json=data, headers=headers)
        print("response_req",response_req)
        return response_req
    except Exception as e:
        print(e)


@app.route('/biometrics_identify', methods=['GET','POST'])
def biometrics_identify():
    print("In Biometrics identify api")
    jsonObj = request.get_json()
    # logger.info("json object : " + str(jsonObj))
    K.clear_session()
    try:
        image = jsonObj['image']

        URL = "http://127.0.0.1:5000/FaceRecognition/identify"

        result = identify_for_biometrics(image,URL)
        print("result is ",result)
        # final_result = {}

        if result.status_code ==200 :
            # output = "Quality check passed and Identity created successfully."
            print(result.text)
            # print(result.json)
            # final_result["enrolment_status"]=result.text

        else :
            print("NO User Found")

    except Exception as e:
        print(e)

    return result.text




@app.route('/Visual_image', methods=['GET', 'POST'])
def visual_search_image():
  #K.clear_session()
  #from flask import session
  #session.clear()
  try:
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST':
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        path = '/home/ubuntu/cv-asset/custom_projects/resources/VisualSearch_MXNet_master/input/'
        f = os.path.join(path, file_p.filename)
        logger.info(f)
        file_p.save(f)
        logger.info("Reached ui1method")
        result = visual_image(f)
        return render_template('vsr_image.html', photo_form=photo_form, result=result)
    else:
        return render_template('vsr_image.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)


@app.route('/cv_workspace/detection', methods=['GET', 'POST'])
@app.route('/detection', methods=['GET', 'POST'])
@cross_origin(origin='*', headers=['Content-Type', 'Authorization', 'Access-Control-Allow-Origin'])
def upload_file_od():
    try:
        K.clear_session()
        if request.method == 'POST' :
            input_image = request.files['input_file']
            print(input_image,"this is input image")
            f=os.path.join(UPLOAD_PATH, input_image.filename)
            print(f,"this is image path")
            input_image.save(f)
    # try:
    #     K.clear_session()
    #     if request.method == 'POST' :
    #         content = request.get_json()

    #         if allowed_file(content['imageInputPath']):
    #             a = content['imageInputPath']
    #             print(a, "this is image")

    except Exception as e:
        print(e)
        status = 'Failure'
        message = 'Object detection failed - Image Upload function'
        final_result = {'Status': status, 'Message': message, 'Extracted File Location': 'Null'}
        return json.dumps(final_result)

    try:
        return_list = object(f)
        my_dict = {}
        for i in return_list:
            print(i['id'])
            my_dict[i['id']] = i
        print("Done/Completed")
        return json.dumps(my_dict)

    except Exception as e:
        print(e)
        errormsg = 'Error in object detection'
        file_path = 'Null'
        return_list = ['Failure', str(errormsg), file_path]
        return return_list

@app.route("/to_s3", methods=['POST'])
def to_s3():
    try:
        jsonObj = request.json
        useCaseId = jsonObj['useCaseId']
        project_name = jsonObj['project_name']
        folder = os.path.join(basepath, useCaseId)
        command = 'aws s3 sync {}/ s3://acn-iasp/iasp_usecases/{}_{}/'.format(folder, project_name, str(useCaseId))
        print(command)
        os.system(command) 
        response = {"message":'success'}
    except Exception as e:
        print(e)
        response = {"message":'error'}
    return jsonify(response)

@app.route("/check_s3", methods=['POST'])
def chk_s3():
    data = {}
    filenames, usecaseids = check_s3()
    data['Filenames'] = filenames
    data['Usecaseids'] = usecaseids
    return jsonify(data)

@app.route("/from_s3", methods=['POST'])
def from_s3():
    try:
        jsonObj = request.json
        useCaseId = jsonObj['useCaseId']
        project_name = jsonObj['project_name']
        folder = os.path.join(basepath, useCaseId)
        command = 'aws s3 sync s3://acn-iasp/iasp_usecases/{}_{}/ {}/'.format(project_name, str(useCaseId), folder)
        print(command)
        os.system(command)
        response = {"message":'success'}
    except Exception as e:
        print(e)
        response = {"message":'error'}
    return jsonify(response)


def activity_demo(image_path):
  #K.clear_session()
  try:
    result1 = {}
    result1['original'] ="/cv_workspace/static/"+path_leaf(image_path)# imgstr

    from custom_projects.resources.activityrecognition.scenarios.action_recognition.demo import recognize_activity
    res=recognize_activity(image_path)
    file2 = "/home/ubuntu/cv-asset/custom_projects/resources/activityrecognition/scenarios/action_recognition/action.json"
    with open(file2, 'r') as openfile:
      json_object = json.load(openfile)
    frst = json_object
    count = 0
    for song in frst:
      index1="key"+str(count)
      result1[index1]=song+":"+str(round(frst[song],2))
      count=count+1
    print("json output is")
    print(frst)
    print("the result is---",result1)
    return result1
  except Exception as e:
    print(e)

@app.route('/startRecognition', methods=['GET', 'POST'])
def startRecognition_UI():
  K.clear_session()
  print("Got the trigger")
  try:
    result={}
    dirname, basename = os.path.split(TEMPLATE_PATH)
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST':
      print("post request")
      VIDEO_UPLOAD_PATH="/home/ubuntu/cv-asset/static"
      print(request.files)
      file = open('videopath.txt', 'r')
      message = file.read()
      file.close()
      #file_p = request.files['video']
      #print("file is---",file_p)
      #f = os.path.join(VIDEO_UPLOAD_PATH, file_p.filename)
      #file_p.save(f)
      print("hitting the caller method")
      result = activity_demo(message)
      print("got the response")
      print(result)
      #quest = request.form['Ques']
      return render_template('upload_video.html', photo_form=photo_form, result=result)
    else:
      return render_template('upload_video.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)


@app.route('/activity_upload', methods=['GET', 'POST'])
def activity_upload():
  try:
    #result={}
    dirname, basename = os.path.split(TEMPLATE_PATH)
    print("in post")
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        VIDEO_UPLOAD_PATH = "/home/ubuntu/cv-asset/static"
        f = os.path.join(VIDEO_UPLOAD_PATH, file_p.filename)
        file_p.save(f)
        print(f)
        file = open("videopath.txt", "w")
        filename = (file_p.filename)
        file.write(f)
        file.close()
        result={}
        result['original'] = "/cv_workspace/static/" + path_leaf(f)
        print("in post :" , result)
      return render_template('upload_video.html',
                             photo_form=photo_form , result=result)
    else:
      return render_template('upload_video.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)


##STEEL DEFECT DETECTION
def steel_detect_from_url(image_path,url):
   try:
      print('===========')
      result={}
    #   URL="https://127.0.0.1:6000/result_steel"

      headers = {
                "Content-Type": "application/json",
                'Cache-Control': "no-cache"
          }
      data = {'image_path' : image_path}
      print("Image Path: ", image_path)
      print('url',url)
      response_req = requests.post(url, json=data, headers=headers)
      print("response_req",response_req)
      return response_req
   except Exception as e:
       print(e)

@app.route('/steel_defect', methods=['GET', 'POST'])
@cross_origin(origin='*', headers=['Content-Type', 'Authorization', 'Access-Control-Allow-Origin'])
def upload_file_steeldefect():
  try:
    print("in steel defect api")
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    
    if request.method == 'POST':
      input_image  = request.files['input_photo']
      input_imgpath = "/home/ubuntu/cv-asset/custom_projects/templates/steel_defect/uploads"
      if not os.path.exists(input_imgpath):
       os.makedirs(input_imgpath)  
      filename = os.path.join(input_imgpath, input_image.filename)
      input_image.save(filename)
      
      result={}
      steel_url="http://127.0.0.1:6001/result_steel"
      result = requests.post(url=steel_url, json={'image_path' : filename}, headers={"Content-Type": "application/json",'Cache-Control': "no-cache"})
      python_result=json.loads(result.text)
      #result = steel_detect_from_url(filename,URL)
      img1=python_result['input'][0]
      image_p1 = open(img1, 'rb')
      image_64_encoded1 = base64.b64encode(image_p1.read()).decode("utf-8")
      imgstr1 = 'data:image/png;base64,{:s}'.format(image_64_encoded1)
      
      img2=python_result['output'][0]
      image_p1 = open(img2, 'rb')
      image_64_encoded1 = base64.b64encode(image_p1.read()).decode("utf-8")
      imgstr2 = 'data:image/png;base64,{:s}'.format(image_64_encoded1)

      img3=python_result['output'][1]
      image_p1 = open(img3, 'rb')
      image_64_encoded1 = base64.b64encode(image_p1.read()).decode("utf-8")
      imgstr3 = 'data:image/png;base64,{:s}'.format(image_64_encoded1)

      img4=python_result['output'][2]
      image_p1 = open(img4, 'rb')
      image_64_encoded1 = base64.b64encode(image_p1.read()).decode("utf-8")
      imgstr4 = 'data:image/png;base64,{:s}'.format(image_64_encoded1)
      result1={}
      result1['input']=imgstr1
      result1['def_type']=python_result['def_type'][0]
      result1['output']=[imgstr2,imgstr3,imgstr4]
      print(python_result['output'][0])
      
      

      #print(python_result['input'][0][12:])
      #print(python_result['output'][0][12:])
      #print(python_result['output'][1][12:])
      #print(python_result['output'][2][12:])
          
      return render_template('demo_steeldefect.html',photo_form=photo_form, result=result1)
    else:
      return render_template('demo_steeldefect.html', photo_form=photo_form, result={})
      
  except Exception as e:
      print(str(e), traceback.format_exc())



# face mask detection
@app.route('/face_mask_detection', methods=['GET', 'POST'])
def face_mask_detection():
  try:
    if request.method == 'POST':
        input_image = request.files['input_file']
        input_imgpath = "custom_projects/resources/face_mask_detection/input_images"
        if not os.path.exists(input_imgpath):
            os.makedirs(input_imgpath)

        filename = os.path.join(input_imgpath, input_image.filename)
        input_image.save(filename)
        print(filename)
  
  except Exception as e:
    print(e)
    status = 'Failure'
    message = 'Image Upload failed'
    final_result = {'Status': status, 'Message': message}
    return json.dumps(final_result)

  try:
    result = detect_mask.mask(filename)
    return json.dumps(result)

  except Exception as e:
    print(e)
    errormsg = 'Error in detect_mask function'
    file_path = 'Null'
    return_list = ['Failure', errormsg, file_path]
    response = {'Status': return_list[0], 'Message': return_list[1], 'Filepath':return_list[2]}
    return json.dumps(response)


# thermal image analytics - temperature detection
@app.route('/thermal_analytics', methods=['GET', 'POST'])
def thermal_analytics():
  try:
    input_imgpath = "custom_projects/resources/temperature_detection/input_images"
    if not os.path.exists(input_imgpath):
        os.makedirs(input_imgpath)

    dirname, basename = os.path.split(input_imgpath)
    print("in post")
    form = PhotoForm(CombinedMultiDict((request.files, request.form)))
    photo_form = PhotoForm(request.form)
    if request.method == 'POST' and form.validate():
      with tempfile.NamedTemporaryFile(prefix=basename, dir=dirname) as temp:
        file_p = request.files['input_photo']
        f = os.path.join(input_imgpath, file_p.filename)
        file_p.save(f)
        print(f)
        file = open("testfile_thermal.txt", "w")
        # filename = (file_p.filename)
        file.write(f)
        file.close()
        result={}
        image_p = open(f, 'rb')
        image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
        imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
        result['original'] = imgstr
        # print("in post :" , result)
      return render_template('thermal_analytics.html', photo_form=photo_form , result=result)
    else:
      return render_template('thermal_analytics.html', photo_form=photo_form, result={})
  except Exception as e:
      print(e)

@app.route('/processing_thermal', methods=['GET', 'POST'])
def processing_thermal():
    photo_form = PhotoForm(request.form)
    try :
        # photo_form = PhotoForm(request.form)
        print("in process thermal")
        file = open('testfile_thermal.txt', 'r')
        message = file.read()
        file.close()
        result={}

        path = measure_temp.allfunctioncalls(message)
        print("Path in UI ",path[2])
        image_p = open(path[2], 'rb')
        image_64_encoded = base64.b64encode(image_p.read()).decode("utf-8")
        imgstr = 'data:image/png;base64,{:s}'.format(image_64_encoded)
        result['original'] = imgstr
        return render_template('thermal_analytics.html', photo_form=photo_form, result=result)

    except Exception as e:
        print(e)
        resp = {}
        resp['message'] = 'Either face is not detected or input image is not Radiometric! Please check!!!' 
        resp['status_code']= 204
        return render_template('thermal_analytics.html', photo_form=photo_form, result=resp)
        # return resp



@app.route("/temperature_measurement", methods=['GET','POST'])
def temperature_measurement():
    try:
        if request.method == 'POST' :
            input_image = request.files['input_file']
            input_imgpath = "custom_projects/resources/temperature_detection/input_images"
            if not os.path.exists(input_imgpath):
                os.makedirs(input_imgpath)

            filename = os.path.join(input_imgpath,input_image.filename)
            input_image.save(filename)
            print(filename)

    except Exception as e:
        print(e)
        status = "Failure"
        message = "Image upload failed"
        final_result = {'Status' : status, "Message" : message}
        return json.dumps(final_result)

    try:
        result = measure_temp.allfunctioncalls(filename)
        status = "SUCCESS"
        output = {'Status' : status, 'Temperature' : result[0], 'State' : result[1]}
        return json.dumps(output)

    except Exception as e:
        print(e)
        error_msg = "Error in measure_temp function"
        file_path = "Null"
        return_list = ['Failure',error_msg,file_path]
        response = {'Status' : return_list[0], 'Message' : return_list[1], 'Filepath' : return_list[2]}
        return json.dumps(response)




@app.route("/mask_temp_detection", methods=['GET','POST'])
def mask_temp_detection():
    try:
        if request.method == 'POST' :
            input_image = request.files['input_file']
            input_imgpath_temp = "custom_projects/resources/temperature_detection/input_images"
            input_imgpath_mask = "custom_projects/resources/face_mask_detection/input_images"

            if not os.path.exists(input_imgpath_temp):
                os.makedirs(input_imgpath_temp)

            if not os.path.exists(input_imgpath_mask):
                os.makedirs(input_imgpath_mask)

            filename_temp = os.path.join(input_imgpath_temp, input_image.filename)
            filename_mask = os.path.join(input_imgpath_mask, input_image.filename)

            input_image.save(filename_temp)
            input_image.save(filename_mask)

            print(filename_temp)
            print(filename_mask)


    except Exception as e:
        print(e)
        status = "Failure"
        message = "Image upload failed"
        final_result = {'Status' : status, "Message" : message}
        return json.dumps(final_result)

    try:
        result_mask = detect_mask.mask(filename_temp)
        print("result_mask",result_mask)

        result_temp = measure_temp.allfunctioncalls(filename_temp)
        print("result_temp", result_temp)

        # result_mask = detect_mask.mask(filename_mask)
        # print("result_mask",result_mask)
        status = "success"
        # output = {'Status' : status, 'detected_image_temp' : result_temp, 'detected_image_mask' : result_mask['detected_image']}
        output = {'Status' : status, 'detected_image_temp' : result_temp, 'detected_image_mask' : result_mask['detected_image']}

        return json.dumps(output)

    except Exception as e:
        print(e)
        error_msg = "Error in measure_temp function"
        file_path = "Null"
        return_list = ['Failure',error_msg,file_path]
        response = {'Status' : return_list[0], 'Message' : return_list[1], 'Filepath' : return_list[2]}
        return json.dumps(response)







if __name__ == '__main__':
    logger.info("Starting AI server..")
    app.run(host='127.0.0.1', debug=True, port=5001, threaded=False)


