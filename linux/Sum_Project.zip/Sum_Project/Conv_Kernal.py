input = [1,2,3,4,5,6,7,8,9,10]
kernal = [1,1]
result=[]
print(len(kernal))
print((kernal[1]))
for i in range(0,len(input)-1):
    count=0
    sum=0
    j = i
    for k in range(0,len(kernal)):
        if(count<=len(kernal)):
            sum+=input[j]*kernal[k]
            j=+1
    result.append(sum)
    if i==8:
        break
    #l1[i] = int((l1[i]*1)+(l1[i+1]*1))
print(result)