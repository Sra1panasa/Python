apt-get install jq -y
echo "{\"password\": \"$VAULT_PASSWORD\"}" > payload.json
RESPONSE=`curl --request POST --data @payload.json ${VAULT_SERVER_URL}/v1/auth/userpass/login/${VAULT_USERNAME}`
rm -f payload.json

VAULT_LEASE_CLIENT_TOKEN=`echo $RESPONSE | jq .auth.client_token | sed 's/"//g'`
GCSA=`curl --header "X-Vault-Token: $VAULT_LEASE_CLIENT_TOKEN" ${VAULT_SERVER_URL}/v1/dataservices/data/gcp/sacreds`

GCP_SA_FILE="gcloud-service-key.json"
echo $GCSA | jq .data.data | tee $GCP_SA_FILE > /dev/null
ls -l $GCP_SA_FILE

gcloud auth activate-service-account --project=$GCP_PROJECTID --key-file=$GCP_SA_FILE
gsutil -m cp -R public/*.whl gs://$DS_DATABRICKS_ARTIFACTS_BUCKET/ds_databricks/classification/wheel_files/

rm -f $GCP_SA_FILE

sed -i "s/DS_DATABRICKS_ARTIFACTS_BUCKET/$DS_DATABRICKS_ARTIFACTS_BUCKET/g" install-libraries.json
sed -i "s/DS_DATABRICKS_CLUSTER_ID/$DS_DATABRICKS_CLUSTER_ID/g" install-libraries.json

sed -i "s/DS_DATABRICKS_ARTIFACTS_BUCKET/$DS_DATABRICKS_ARTIFACTS_BUCKET/g" uninstall-libraries.json
sed -i "s/DS_DATABRICKS_CLUSTER_ID/$DS_DATABRICKS_CLUSTER_ID/g" uninstall-libraries.json

sed -i "s/DS_DATABRICKS_CLUSTER_ID/$DS_DATABRICKS_CLUSTER_ID/g" restart-cluster.json

RESPONSE=`curl --header "X-Vault-Token: $VAULT_LEASE_CLIENT_TOKEN" ${VAULT_SERVER_URL}/v1/dataservices/data/databricks/token`
DATABRICKS_TOKEN=`echo $RESPONSE | jq .data.data.token | sed 's/"//g'`
curl -X POST --header "Authorization: Bearer $DATABRICKS_TOKEN" --data @uninstall-libraries.json $DATABRICKS_URL/libraries/uninstall
curl -X POST --header "Authorization: Bearer $DATABRICKS_TOKEN" --data @restart-cluster.json $DATABRICKS_URL/clusters/restart
curl -X POST --header "Authorization: Bearer $DATABRICKS_TOKEN" --data @install-libraries.json $DATABRICKS_URL/libraries/install
