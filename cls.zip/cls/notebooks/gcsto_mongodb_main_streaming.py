# Databricks notebook source
from datetime import date, timedelta
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.kafka_connector import KafkaConnector
from cls_src.utils.pipeline_context import PipelineContext
from cls_src.utils.read_config import *
from cls_src.utils.deltalake_connector import DeltaLakeConnector
from cls_src.utils.read_config import *
from cls_src.utils.pymongo_db_connector import PyMongoConnector
from delta.tables import *
from cls_src.utils.payload_validator import validator
import json
from cls_src.utils.payload_schema_validator import validation_schema
from datetime import datetime
from cls_src.utils.gcsto_mongodb_main_helper import GcsToMongoDbHelper
from pyspark.sql.functions import to_json,col
from pyspark.sql.types import MapType,StringType
from pyspark.sql.functions import from_json
from cls_src.utils.spark_mongodb_connector import SparkMongoConnector

pipeline_name = "gcs_to_kafka"
log = Framework_Logger()
config_parser = GetConfigAttr()
today = date.today()
failover_startdate=today.strftime("%Y-%m-%d")
enable_ledger = True
spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled=true")
try:
    pipeline_ctx = PipelineContext("stream",pipeline_name)
    spark_ctx = pipeline_ctx.create_pyspark_streaming_session()
    kafka_ctx = KafkaConnector(pipeline_ctx=pipeline_ctx)
    delta_ctx =DeltaLakeConnector(pipeline_ctx, spark_ctx,failover_startdate = failover_startdate) 
    log.log_info("All connectors initialized")
except Exception as e:
    log.log_error("Error in connectors initialization.."+str(e))
    log.log_error("Exception occured.." + str(traceback.format_exc()))


# COMMAND ----------

# this piece of code only for json schema extraction this needs to be replaced with schema.
gcstomongodb_helpr_obj = GcsToMongoDbHelper(spark_ctx,delta_ctx,"30-10-2022")
deserlzd_payloads_df=gcstomongodb_helpr_obj.get_payloads_ingested_date(kafka_ctx,delta_ctx,"30-10-2022")
validated_payloads_df=gcstomongodb_helpr_obj.decrypt_and_validate_payloads(deserlzd_payloads_df)
json_schema = spark.read.json(validated_payloads_df.rdd.map(lambda row: row.decrypted_data)).schema

# COMMAND ----------

"""
schema=StructType([(StructField("applicant_data",StructType([(StructField("address",StructType([(StructField("current_address",StructType([(StructField("address_line1",StringType(),True),StructField("address_line2",StringType(),True),StructField("city",StringType(),True),StructField("county",StringType(),True),StructField("state",StringType(),True),StructField("zip_code",StringType(),True))]),True),StructField("previous_addresses",ArrayType(StringType(),True),True))]),True),StructField("alias_names",ArrayType(StringType(),True),True),StructField("applicant_id",StringType(),True),StructField("county",StringType(),True),StructField("dob",StringType(),True),StructField("driving_license",StringType(),True),StructField("education_details",ArrayType(StringType(),True),True),StructField("first_name",StringType(),True),StructField("last_name",StringType(),True),StructField("middle_name",StringType(),True),StructField("mvr",StringType(),True),StructField("order_service_data_source_id",StringType(),True),StructField("order_service_id",StringType(),True),StructField("photo_path",StringType(),True),StructField("prev_empoyment_details",ArrayType(StringType(),True),True),StructField("reg_id",StringType(),True),StructField("request_id",StringType(),True),StructField("ssn",StringType(),True),StructField("ssn_trace",StringType(),True),StructField("state",StringType(),True))]),True),StructField("court_response",StructType([(StructField("hrg1_results",StructType([(StructField("date_closed",StringType(),True),StructField("date_submitted",StringType(),True),StructField("hrg1_action",StringType(),True),StructField("order_service_id",StringType(),True),StructField("reg_id",StringType(),True),StructField("request_id",StringType(),True))]),True),StructField("order_service_data_source_id",StringType(),True),StructField("order_service_id",StringType(),True),StructField("reg_id",StringType(),True),StructField("request_id",StringType(),True),StructField("source_records",ArrayType(StructType([(StructField("address",StructType([(StructField("address_line1",StringType(),True))]),True),StructField("alias",StringType(),True),StructField("alias_names",ArrayType(StringType(),True),True),StructField("charge_info",ArrayType(StructType([(StructField("arrest_date",StringType(),True),StructField("degree_of_offense",StringType(),True),StructField("disposition_category",StringType(),True),StructField("disposition_date",StringType(),True),StructField("disposition_literal",StringType(),True),StructField("nature_of_offense",StringType(),True),StructField("offense_date",StringType(),True),StructField("offense_literal",StringType(),True),StructField("severity",StringType(),True))]),True),True),StructField("county",StringType(),True),StructField("court_id",StringType(),True),StructField("court_name",StringType(),True),StructField("criminal_case_number",StringType(),True),StructField("dob",StringType(),True),StructField("driving_license",StringType(),True),StructField("eye_color",StringType(),True),StructField("first_name",StringType(),True),StructField("government_id",StringType(),True),StructField("height",StringType(),True),StructField("image",StringType(),True),StructField("jail_time",StringType(),True),StructField("last_name",StringType(),True),StructField("middle_name",StringType(),True),StructField("parole_info",StringType(),True),StructField("sor_id",StringType(),True),StructField("state",StringType(),True),StructField("suppression_status",StringType(),True))]),True),True),StructField("target_records",ArrayType(StringType(),True),True))]),True))])
"""

# COMMAND ----------

stream_landing_df=delta_ctx.stream_read_landing()

# COMMAND ----------

try:
    stream_deserlzd_payloads_df = kafka_ctx.get_kafka_payload(stream_landing_df)
except Exception as e:
    log.error("Error in deserializing orderitem education AVRO Message"+str(e))
    log.error("Exception occured: %s", traceback.format_exc())
    print(e)

# COMMAND ----------

if stream_deserlzd_payloads_df:
    stream_validated_payload_df=gcstomongodb_helpr_obj.decrypt_and_validate_payloads(stream_deserlzd_payloads_df)
    stream_valid_records_df=stream_validated_payload_df.filter(col("validation_flag") == "true")
    stream_invalid_records_df=stream_validated_payload_df.filter(col("validation_flag") != "true")                   
   

# COMMAND ----------

# writing valid records to mongo db
try:
    mongo_ctx = SparkMongoConnector()
    stream_valid_records_df=stream_valid_records_df.withColumn('decrypted_data', from_json(col('decrypted_data'),json_schema))
    collection_name = config_parser.get_io_config_attribute_by_section("mongoDB", "collection_criminal_data_raw_streaming")
    mongo_ctx.stream_upsert(stream_valid_records_df,collection_name)
except Exception as e:
    log.log_error("Error in storing education verification data to mongodb")
    log.log_error("Exception occured: %s", traceback.format_exc())
    print(e)

# COMMAND ----------

# writing invalid payloads to quarantine path
delta_ctx.stream_write_quarantine(stream_invalid_records_df,partition_column = "ingested_date")

