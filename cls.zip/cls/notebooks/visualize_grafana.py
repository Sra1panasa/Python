from cls_src.performance.visualize_grafana import VisualizationGrafanaTransformation
import pandas as pd
from cls_src.utils.pymongo_db_connector import PyMongoConnector
from cls_src.utils.logger import Framework_Logger
import traceback
from cls_src.utils.read_config import GetConfigAttr
import time

start_time=time.time()
try:
    logger=Framework_Logger()
    mongodbconnector=PyMongoConnector()
    viz=VisualizationGrafanaTransformation()
    confg=GetConfigAttr()
    cls_data=mongodbconnector.read_all_dict(confg.get_io_config_attribute_by_section("mongoDB","collection_classification_prediction_results"))
    viz.update_misclassification()
    data_df=pd.json_normalize(cls_data)
    data_df=viz.preprocess_data(data_df)
    test1=viz.transform_data_classification_agg_metrics(data_df)
    test2=viz.transform_data_cm(data_df)
    test3=viz.transform_data_classification_metrics()
    meta=viz.transform_data_meta_dashboard()
    chloro,raw_df=viz.transform_geo_title_viz()
#     noo_df=viz.transform_noo(data_df)
#     viz.compare_lookup_table()
#     viz.doo_juridiction_metrics(data_df)
except Exception as e:
    logger.log_error("Exception occurred: %s"+ str(traceback.format_exc()) )  

end_time=time.time()

elapsed_time=end_time-start_time
elapsed_time=time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
logger.log_info('Classification: Visualize main : Execution time : '+str(elapsed_time))
