import mlflow
from google.cloud import storage
import json
from transformers import TrainingArguments, Trainer, TrainerCallback
from cls_src.training.degree_of_offense_training import DegreeOfOffenseModelTraining
import pickle
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.read_config import *
import random
import string
import traceback
from cls_src.utils.pymongo_db_connector import PyMongoConnector
from cls_src.performance.performance_report import PerformanceEval
import time
import pandas as pd
import numpy as np

logger=Framework_Logger()
# COMMAND ----------

# logs the each epoch information into mlflow as text file
class ModelCallBack(TrainerCallback):
    '''
    This class logs each model epoch information,metrics and parameter in mlflow while training the model

      Parameters :
          TrainerCallback(Object)  : A TrainerCallback that handles the default flow of the training loop for logs, evaluation and checkpoints.

      Returns    : None

    '''

    def on_epoch_end(self, args, state, control, **kwargs):
        if(len(state.log_history)>0):
            mlflow.log_text(json.dumps(state.log_history),"MetricByEpoch")

# COMMAND ----------
def DOOTrainingPipeline(data_path,exp_name):
    '''
        In this function the degree_of_offense_training class is implemented i.e Degree of offense training is done
        The Doo  model(distilbert model) is trained and then used on the Doo training data for classification
        With mlflow all the results, training model, tokenizer, encoder ,predictions , accuracy metrics
           are being stored as artifacts,metrics and parameters in mlflow instance
        Those mlflow artifacts are then being stored into mongodb 

        Parameters :
             data_path(String)  : specifies the GCS path of the training data
             exp_name(String)   : specifies the experiment name for the mlflow instance


        Returns : None

     '''

    try:
        logger=Framework_Logger()
        confg=GetConfigAttr()
        mongodbconnector=PyMongoConnector()
        performance=PerformanceEval()
        mlflow.set_tracking_uri(confg.get_model_config_path_attr_by_section("MLFLOW","tracking_server"))
        experiment_id = mlflow.create_experiment(exp_name)
        mlflow.autolog()
        with mlflow.start_run(nested=True,experiment_id=experiment_id) as run:
            run_id = run.info.run_id
            logger.log_info("Classification: DOO Training main :MLFlow Initialized with run Id "+str(run_id))
            doo=DegreeOfOffenseModelTraining()
            data=doo.load_data(data_path)
            data.rename(columns={"Unnamed: 0":"state"},inplace=True)
            mlflow.log_param("classification_model_name","DOO")
            mlflow.log_param("inital_data",str(data.shape[0])+", "+str(data.shape[1]))
            encoded_data=doo.encode_target(data,col_name="degree_of_offense")
            enc=doo.get_encoder()
            enc_dict=dict(zip(enc.classes_, range(len(enc.classes_))))
            mlflow.log_dict(enc_dict,"encodings")
            processed_data=doo.preprocess_text(encoded_data,col_name="offense_literal")
            doo.load_tokenizer(tokenizer_name="distilbert-base-uncased")
            doo.load_data_collator()
            mlflow.log_text(str(doo.data_collator),"Data_Collator")
            mlflow.log_param("model_name","distilbert-base-uncased")
            doo_model=doo.load_model(num_labels=3,model_name="distilbert-base-uncased")
            processed_dataset=doo.create_dataset_frm_data(processed_data)
            train_dt, test_dt, eval_dt=doo.train_test_eval_split(processed_dataset,0.7,0.2,0.1)
            mlflow.log_param("training_data",str(train_dt.shape[0])+", "+str(train_dt.shape[1]))
            mlflow.log_param("testing_data",str(test_dt.shape[0])+", "+str(test_dt.shape[1]))
            mlflow.log_param("eval_data",str(eval_dt.shape[0])+", "+str(eval_dt.shape[1]))
            training_args = TrainingArguments(
            output_dir=".//model_results//doo//",
            per_device_train_batch_size=32,
            per_device_eval_batch_size=32,
            num_train_epochs=10,
            evaluation_strategy="epoch"
            )
            trainer=doo.load_trainer(doo_model, training_args, train_dt, eval_dt,ModelCallBack)
            trainer.train()
            with open('doo_model', 'wb') as model:
                pickle.dump(doo_model, model) 
            mlflow.log_artifact("doo_model")
            mlflow.pytorch.log_model(doo_model,
                                     artifact_path="pytorch",registered_model_name="DOO Model")
            with open('tokenizer', 'wb') as model:
                pickle.dump(doo.tokenizer, model) 
            mlflow.log_artifact("tokenizer")
            test_preds=doo.make_pred_df(test_dt,'test', trainer)
            eval_preds=doo.make_pred_df(eval_dt,'validation',trainer)
            train_preds=doo.make_pred_df(train_dt,'train',trainer)
            test_preds.to_excel("Test_Predictions.xlsx")
            train_preds.to_excel("Train_Predictions.xlsx")
            eval_preds.to_excel("Validation_Predictions.xlsx")
            mlflow.log_artifact("Test_Predictions.xlsx")
            mlflow.log_artifact("Train_Predictions.xlsx")
            mlflow.log_artifact("Validation_Predictions.xlsx")
            logger.log_info("Classification: DOO Training main :MLFLOW Artifacts saved to GCS")
            logger.log_info("Classification: DOO Training main :Saving MLFLOW metrics, params and model performance into mongodb")
            mlflow_obj=mlflow.tracking.MlflowClient().get_run(run_id).data.to_dictionary()
            metrics=performance.get_performance_metrics(test_preds["actual_doo"],test_preds["Prediction"])
            model_performance=metrics.to_dict('series')
            cm_obj=performance.get_confusion_matrix(test_preds["actual_doo"],test_preds["Prediction"]).T.to_dict('series')
            for key in model_performance:
                model_performance[key]=model_performance[key].to_dict()
            for key in cm_obj:
                cm_obj[key]=cm_obj[key].to_dict()
            store_obj=dict()
            store_obj["_id"]=run_id
            store_obj["experiment_name"]=exp_name
            store_obj["mlflow_params"]=mlflow_obj["params"]
            store_obj["mlflow_metrics"]=mlflow_obj["metrics"]
            store_obj["model_performance"]=model_performance
            store_obj["confusion_matrix"]=cm_obj
            mongodbconnector.write_records_from_json(store_obj,confg.get_io_config_attribute_by_section("mongoDB", "collection_mlops_cls_metrics_logger"))
            logger.log_info("Classification: DOO Training main :Metrics and Params stored into mongodb")
            mlflow.end_run()
    except Exception as e:
        logger.log_error("Exception occurred: %s"+ str(traceback.format_exc()))  

# COMMAND ----------
start_time=time.time()
exp_name="Test_"+"".join(random.choices(string.ascii_lowercase + string.digits, k=7))
data_path="gs://bkt-stg-hrgp-ds-us/experiments/doo_sample_df.xlsx"
DOOTrainingPipeline(data_path,exp_name)
end_time=time.time()

elapsed_time=end_time-start_time
elapsed_time=time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
logger.log_info('Classification: DOO Training main : Execution time : '+str(elapsed_time))