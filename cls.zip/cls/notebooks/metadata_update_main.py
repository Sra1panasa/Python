# Databricks notebook source
# Databricks notebook source
from idr_src.utils.logger import Framework_Logger
from idr_src.utils.read_config import *
from idr_src.utils.pymongo_db_connector import PyMongoConnector
import pandas as pd
import json
import traceback
from pyspark.sql.functions import *
import traceback
from datetime import date, timedelta
from cls_src.utils.kafka_connector import KafkaConnector
from cls_src.utils.pipeline_context import PipelineContext
from cls_src.utils.deltalake_connector import DeltaLakeConnector
from cls_src.utils.pymongo_db_connector import PyMongoConnector
from delta.tables import *
import json
from datetime import datetime
from cls_src.utils.gcsto_mongodb_main_helper import GcsToMongoDbHelper

pipeline_name="metadataupdate"
log=Framework_Logger()
config_parser = GetConfigAttr()
today = date.today()
yesterday = today - timedelta(days = 1)
ingested_date=yesterday.strftime("%d-%m-%Y")
ingested_date="08-11-2022"

try:
    pipeline_ctx = PipelineContext("meta",pipeline_name)
    spark_ctx = pipeline_ctx.create_pyspark_streaming_session()
    kafka_ctx = KafkaConnector(pipeline_ctx=pipeline_ctx)
    delta_ctx =DeltaLakeConnector(pipeline_ctx, spark_ctx) 
    mongodbconnector = PyMongoConnector()
    log.log_info("All connectors initialized")
    
    collection_name = config_parser.get_io_config_attribute_by_section("mongoDB", "collection_criminal_data_raw")
    payloads_list = mongodbconnector.filter_records_dict(collection_name, "ingested_date",ingested_date)
except Exception as e:
    log.log_error("Exception occurred while extracting payloads..."+ str(e))
    log.log_error(traceback.format_exc())


# COMMAND ----------

valid_payload_count=len(payloads_list)

# COMMAND ----------

quarantine_df=delta_ctx.read_quarantine()
quarantine_df=quarantine_df.filter(quarantine_df.ingested_date == ingested_date)
invalid_payload_count=0
if quarantine_df.first():
    invalid_payload_count=quarantine_df.count()

# COMMAND ----------

gcstomongodb_helpr_obj = GcsToMongoDbHelper(spark_ctx,delta_ctx,ingested_date)
gcstomongodb_helpr_obj.write_metadata_mongodb(valid_payload_count,invalid_payload_count,ingested_date)

# COMMAND ----------


