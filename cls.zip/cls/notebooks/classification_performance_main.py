# Databricks notebook source
from cls_src.performance.performance_report import *
from cls_src.utils.pymongo_db_connector import PyMongoConnector
import pandas as pd
from cls_src.utils.logger import *
from cls_src.utils.read_config import GetConfigAttr
import traceback
from datetime import datetime
import time
# COMMAND ----------
'''
    The performance metrics ,confusion matrix for each model i.e DOO, NOO and Disposition prediction data . These performance metrics are stored 
    into Mongo db in the collection_classification_prediction_results collection.
    
'''
start_time=time.time()
try:
    mongodbconnector=PyMongoConnector()
    eval=PerformanceEval()
    logger=Framework_Logger()
    config=GetConfigAttr()
except Exception as e:
    logger.log_error("Classification:  Performance main :Error Occured while initializing performance pipeline"+str(e))

# COMMAND ----------
data=eval.get_data_for_performance_computation()
if(len(data)>0):
    data_df=pd.json_normalize(data)
    ids=data_df["_id"].unique()
    storeObj=dict()
    logger.log_info("Classification:  Performance main :Computing Performance of Disposition Model")
    storeObj["disposition"]=eval.get_model_metrics(data_df["disposition_category"],data_df["disposition_prediction"])
    logger.log_info("Classification:  Performance main :Computing Performance of DOO Model")
    storeObj["doo"]=eval.get_model_metrics(data_df["severity"],data_df["doo_prediction"])
    logger.log_info("Classification:  Performance main :Computing Performance of Nature of Offense Model")
    storeObj["noo"]=eval.get_model_metrics(data_df["nature_of_offense"],data_df["noo_prediction"])
    storeObj["created_date"]=datetime.now()
    logger.log_info("Classification:  Performance main :Storing the Performance metrics of classification model into Collection")
    mongodbconnector.write_records_from_json(storeObj,config.get_io_config_attribute_by_section("mongoDB","collection_classification_performance_metrics"))
    logger.log_info("Classification:  Performance main :Stored the values into mongoDB")
    recs=[{"match_compute_status":1} for index in range(0,len(list(set(ids))))]
    logger.log_info("Classification:  Performance main :Updating compute status flag")
    mongodbconnector.upsert_records(config.get_io_config_attribute_by_section("mongoDB","collection_classification_prediction_results"),list(set(ids)),recs)
    logger.log_info("match status updated")
    logger.log_info("Classification:  Performance main :Storing matches and mismatches status for Disposition")
    eval.store_mismatch_status(data_df,"disposition")
    logger.log_info("Classification:  Performance main :Storing matches and mismatches status for DOO")
    eval.store_mismatch_status(data_df,"doo")
    logger.log_info("Classification:  Performance main :Storing matches and mismatches status for NOO")
    eval.store_mismatch_status(data_df,"noo")
    logger.log_info("Classification:  Performance main :Performance pipeline completed sucessfully")

end_time=time.time()
elapsed_time=end_time-start_time
elapsed_time=time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
logger.log_info('Classification:  Performance main: Execution time : '+str(elapsed_time))
    