# Databricks notebook source
from pyspark.sql.functions import *
import traceback
from datetime import date, timedelta
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.kafka_connector import KafkaConnector
from cls_src.utils.pipeline_context import PipelineContext
from cls_src.utils.read_config import *
from cls_src.utils.deltalake_connector import DeltaLakeConnector
from cls_src.utils.read_config import *
from cls_src.utils.pymongo_db_connector import PyMongoConnector
from delta.tables import *
from cls_src.utils.payload_validator import validator
import json
from cls_src.utils.payload_schema_validator import validation_schema
from datetime import datetime
from cls_src.utils.gcsto_mongodb_main_helper import GcsToMongoDbHelper

# COMMAND ----------

# Initializing connectors
pipeline_name = "kafka_to_gcs"
log = Framework_Logger()
today = date.today()
yesterday = today - timedelta(days = 1)
ingested_date=yesterday.strftime("%d-%m-%Y")
ingested_date="30-10-2022"
failover_startdate=today.strftime("%Y-%m-%d")
enable_ledger = True
spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled=true")
try:
    pipeline_ctx = PipelineContext("stream",pipeline_name)
    spark_ctx = pipeline_ctx.create_pyspark_streaming_session()
    kafka_ctx = KafkaConnector(pipeline_ctx=pipeline_ctx)
    delta_ctx =DeltaLakeConnector(pipeline_ctx, spark_ctx,failover_startdate = failover_startdate) 
    log.log_info("All connectors initialized")
except Exception as e:
    log.log_error("Error in connectors initialization.."+str(e))
    log.log_error("Exception occured.." + str(traceback.format_exc()))

# COMMAND ----------

gcstomongodb_helpr_obj = GcsToMongoDbHelper(spark_ctx,delta_ctx,ingested_date)
deserlzd_payloads_df=gcstomongodb_helpr_obj.get_payloads_ingested_date(kafka_ctx,delta_ctx,ingested_date)

# COMMAND ----------

if deserlzd_payloads_df:
    validated_payloads_df=gcstomongodb_helpr_obj.decrypt_and_validate_payloads(deserlzd_payloads_df)
    valid_records_df=validated_payloads_df.filter(col("validation_flag") == "true")
    invalid_records_df=validated_payloads_df.filter(col("validation_flag") != "true")                   
   

# COMMAND ----------

gcstomongodb_helpr_obj.delete_ingested_date_payloads(ingested_date)
gcstomongodb_helpr_obj.write_validrecords_mongodb(valid_records_df,ingested_date)


# COMMAND ----------

# if this takes time we can enable this only in rerun case.
gcstomongodb_helpr_obj.delete_ingested_date_payloads_qp()

# COMMAND ----------

gcstomongodb_helpr_obj.write_invalidrecords_quarantinepath(invalid_records_df,ingested_date) 
