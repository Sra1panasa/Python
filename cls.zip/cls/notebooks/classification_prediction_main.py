# Databricks notebook source
from cls_src.prediction.dispo_prediction import *
from cls_src.prediction.doo_prediction import *
from cls_src.prediction.extract_payload import *
from cls_src.prediction.offense_nature_prediction import OffenseNaturePrediction
from datetime import datetime
from cls_src.utils.read_config import *
from cls_src.utils.pymongo_db_connector import PyMongoConnector
import time
import re
#Backfilling state information for empty state kafka payloads
def updated_state(state_county,data):
    '''
    In this function , records having empty/Null state will be backfilled with state information by validating the court name of the records to the
    state court name mapped dataset extracted from NATCRIM.
        
        Parameters :
            State_county: The dataframe containg the state courtname mapped dataset.
            data: Dataframe that will be backfilled through state information

        Returns   :
            updated_state_df: Dataframe containing backfilled data .
            state_null_data: Dataframe containing records where not able to backfill state data.


    '''
    logger.log_info("Classification:  Prediction main : Backfilling State info using the state court data of length :"+str(len(state_county)))
    state_null_data=data.copy()
    updated_state_list=[]
    county_list=list(state_county['sourcename'].unique())
    state_list=list(state_county['stateabbrev'].unique())
    #Preprocessing the court name 
    state_null_data['court_name']=state_null_data['court_name'].astype('str')
    state_null_data['court_name']=state_null_data['court_name'].map(lambda x: x.lower())
    state_county['sourcename']=state_county['sourcename'].astype('str')
    state_county['sourcename']=state_county['sourcename'].map(lambda x: x.lower())
    state_county["sourcename"]=state_county["sourcename"].apply(lambda x : re.sub('[^a-zA-Z0-9 \n\.]', '', x))
    state_null_data["court_name"]=state_null_data["court_name"].apply(lambda x : re.sub('[^a-zA-Z0-9 \n\.]', ' ', x))
    state_null_data['court_name']=state_null_data['court_name'].apply(lambda x: re.sub("^\d+\s|\s\d+\s|\s\d+$", " ", x))
    state_county['sourcename']=state_county['sourcename'].apply(lambda x: re.sub("^\d+\s|\s\d+\s|\s\d+$", "", x))
    state_county['sourcename']=state_county['sourcename'].apply(lambda x: re.sub(' +', ' ',x))
    

    for ind,row in state_null_data.iterrows():
        if row['state']=='' or pd.isna(row['state']):

            court_name=row['court_name']
            county=re.search(r'(.*?)county',court_name)
            court_data=re.search(r'(.*?)municipal court',court_name)
            #Checking the court name match with county name pattern
            if court_data :
                court_data_name=court_data.group()
                if court_data_name in county_list:
                    court_data_name=re.sub(' +', ' ',court_data_name)
                    state_df=state_county[state_county['sourcename']==court_data_name]
                    if len(state_df)==1:
                        state_df.reset_index(drop=True,inplace=True)
                        state_name=state_df['stateabbrev'][0]
                        row['state']=state_name
                        row['derived_state_info']=True
                        updated_state_list.append(row)
            #Checking the court name match with municipal court name pattern
            elif county :
                court_name_with_county=county.group()
                if court_name_with_county in county_list :
                    court_name_with_county=re.sub(' +', ' ',court_name_with_county)
                    state_df=state_county[state_county['sourcename']==court_name_with_county]
                    if len(state_df)==1:
                        state_df.reset_index(drop=True,inplace=True)
                        state_name=state_df['stateabbrev'][0]
                        row['state']=state_name
                        row['derived_state_info']=True
                        updated_state_list.append(row)
            

            #Checking the court name match with county directly 
            elif court_name in county_list :
                state_df=state_county[state_county['sourcename']==court_name]
                if len(state_df)==1:
                    state_df.reset_index(drop=True,inplace=True)
                    state_name=state_df['stateabbrev'][0]
                    row['state']=state_name
                    row['derived_state_info']=True
                    updated_state_list.append(row)
    #     elif court_name_with_county in county_list :
    #         state_df=state_county[state_county['sourcename']==court_name_with_county]
    #         state_df.reset_index(drop=True,inplace=True)
    #         state_name=state_df['stateabbrev'][0]
    #         row['state']=state_name
    #         updated_state_list.append(row)
    updated_state_df=pd.DataFrame.from_dict(updated_state_list)
    updated_state_df.drop_duplicates(inplace=True)
    return updated_state_df,state_null_data


# COMMAND ----------
'''
   Prediction of Degree of Offense, Nature of Offense and Disposition data main , all the prediction results are stored in the Mongodb
'''
start_time=time.time()
try:
    logger=Framework_Logger()
    confg=GetConfigAttr()
    mongodbconnector=PyMongoConnector()
    #Payload Extraction
    logger.log_info("Classification:  Prediction main :Extracting Data from the payload")
    payload=Extract_Payload()
    payload_df,ids=payload.process_ingested_data_classification()
    if payload_df.shape[0] < 1:
        logger.log_info("Classification:  Prediction main :No records to process")
    else:
        logger.log_info("Classification:  Prediction main : Backfilling State information through Court name data")
        state_county=pd.read_excel(confg.get_model_config_path_attr_by_section("MODELPATH","state_courtname_data_path"))
        state_county.drop_duplicates(inplace=True)
        state_county['sourcename']=state_county['sourcename'].map(lambda x: x.lower())
        payload_df['state']=payload_df['state'].replace('',np.nan,regex=True)
        logger.log_info("Length of state empty payload dataframe :"+str(payload_df['state'].isna().sum()))
        updated_state_df,state_null_data=updated_state(state_county,payload_df)
        logger.log_info("Classification: Backfilling of state through Courtname :"+str(len(updated_state_df)))
        if updated_state_df.shape[0]>0:
            index_updated_state_values=updated_state_df.index.values
            payload_df.at[index_updated_state_values,"state"]=updated_state_df['state']
            payload_df.at[index_updated_state_values,"derived_state_info"]=updated_state_df['derived_state_info']
            logger.log_info("Number of records with state Null after backifilling :"+str(payload_df["state"].isna().sum()))
        logger.log_info("Classification:  Prediction main :Starting Diposition prediction pipeline")
        # Dispostion Predictions
        dispo=DispositionPrediction()
        dispo_resp=dispo.get_disposition_category_series(payload_df["disposition_literal"])
        if(~dispo_resp["status"]):
            payload_df["disposition_prediction"]=dispo_resp["predictions"]
            payload_df["disposition_score"]=dispo_resp["pred_scores"]
        logger.log_info("Classification:  Prediction main :Diposition prediction pipeline completed")
        logger.log_info("Classification:  Prediction main :Starting DOO prediction pipeline")
        # DOO Predictions
        doo=OffenseDegreePrediction()
        state_miss_df=payload_df[(payload_df["state"]=="") | (payload_df["state"].isna())]

        if(state_miss_df.shape[0]==0):
            doo_response=doo.get_offenseDegreee_category_series(payload_df[["offense_literal","state"]])
            if(doo_response["status"]):
                payload_df["doo_prediction"]=doo_response["predictions"]
                payload_df["doo_score"]=doo_response["pred_scores"]
                payload_df['missing_state_info']=False

        else:
            logger.log_info("Classification:  Prediction main :Some rows doesn't have state values")
            index_values=payload_df[(payload_df["state"]!="") & (payload_df["state"].notna())].index.values
            doo_response=doo.get_offenseDegreee_category_series(payload_df.loc[index_values,["offense_literal","state"]])
            if(doo_response["status"]):
                payload_df.loc[index_values,"doo_prediction"]=doo_response["predictions"]
                payload_df.loc[index_values,"doo_score"]=doo_response["pred_scores"].to_list()
            no_state_index=state_miss_df.index.values
            payload_df.loc[no_state_index,"doo_score"]=np.nan
            payload_df.loc[no_state_index,"doo_prediction"]=np.nan
            payload_df.loc[no_state_index,"missing_state_info"]=True
        logger.log_info("Classification:  Prediction main :DOO prediction pipeline completed")
        logger.log_info("Classification:  Prediction main :Starting NOO prediction pipeline")
        # NOO Predictions
        noo=OffenseNaturePrediction()
        noo_response=noo.get_sub_category_series(payload_df["offense_literal"])
        if(noo_response["status"]):
            payload_df["noo_prediction"]=noo_response["predictions"]
            payload_df["noo_score"]=noo_response["pred_scores"]
        logger.log_info("Classification:  Prediction main :NOO prediction pipeline completed")
        payload_df["created_date"]=datetime.now()
        payload_df["match_compute_status"]=0
        payload_df["disposition_match"]="NA"
        payload_df["doo_match"]="NA"
        payload_df["noo_match"]="NA"
        # Storing Results into mongoDB
        logger.log_info("Classification:  Prediction main :Storing prediction results into mongoDB")
        mongodbconnector.write_records_from_df(payload_df,confg.get_io_config_attribute_by_section("mongoDB","collection_classification_prediction_results"))
        logger.log_info("Classification:  Prediction main :Prediction results stored into mongoDB")
        logger.log_info("Classification:  Prediction main :Updating cls_processing status")
        recs=[{"cls_processing_status":1} for index in range(0,len(list(set(ids))))]
        mongodbconnector.upsert_records(confg.get_io_config_attribute_by_section("mongoDB","collection_criminal_data_raw"),list(set(ids)),recs)
        logger.log_info("Classification:  Prediction main :cls_processing_status updated")
        logger.log_info("Classification:  Prediction main :Classification Models Prediction Pipeline Sucessfully Completed")
except Exception as e:
    logger.log_error("Classification:  Prediction main :Exception occurred in classification prediction pipeline: %s"+ str(traceback.format_exc()))  

end_time=time.time()

elapsed_time=end_time-start_time
elapsed_time=time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
logger.log_info('Classification:  Prediction main : Execution time : '+str(elapsed_time))