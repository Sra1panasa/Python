
from itertools import count
import pandas as pd
import traceback
import os
import datetime
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.read_config import *
from cls_src.utils.pymongo_db_connector import PyMongoConnector
from google.cloud import storage
from io import BytesIO
import json



config_parser = GetConfigAttr()
bucket_name = config_parser.get_io_config_attribute_by_section("kafka", "bucket_name")
payload_path = config_parser.get_io_config_attribute_by_section("kafka", "payload_gcs_path")
errofile_path = config_parser.get_io_config_attribute_by_section("kafka", "kafka_errorfile_path")


log = Framework_Logger()


try:
    mongodbconnector = PyMongoConnector()
    log.log_info("Mongo connector initialized")
except Exception as e:
    log.log_error("Exception occured in mongo connector initialization.."+str(e))
    log.log_error("Exception occured: %s" + str(traceback.format_exc()))



# This date should be passed from schedular
ingestion_date="17-08-2022" # format should be dd-mm-yyyy 
payalod_path_with_date=payload_path+ingestion_date+"/"
count_invalid=0
count_valid=0
client = storage.Client()
try:
    for blob in client.list_blobs(bucket_name,prefix=payalod_path_with_date):
        if "spark_metadata" not in str(blob):
            blobBytes = blob.download_as_bytes()
            df = pd.read_parquet(BytesIO(blobBytes))
            dfdeserlzd = pd.DataFrame(df['deserialized_value'])
            deserlzddict = dict((df['deserialized_value']))
            raw_data=deserlzddict[0]
            try:
                rawdata_dict = json.loads(raw_data)
                data_dict = json.loads(rawdata_dict["data"])
            except Exception as e:
                log.log_error("Exception occured in raw/string data to json conversion"+ str(e))
                log.log_error("Erron in file.."+ str(blob.name).split('/')[-1])
                error_file_name=str(blob.name).split('/')[-1]
                df.to_parquet(errofile_path+error_file_name, engine='pyarrow')
                log.log_info("Error File Successfully moved to error path.."+ str(blob.name).split('/')[-1])
                count_invalid+=1
                continue

            data_dict["validation_status"] = ""
            data_dict["cls_processing_status"] = 0
            data_dict["idr_processing_status"] = 0
            data_dict["id"]=rawdata_dict['id']
            data_dict["orderid"]=rawdata_dict['orderid']
            data_dict["orderitemid"]=rawdata_dict['orderitemid']
            data_dict["created_timestamp"] = datetime.now()
            mongodbconnector.write_records_from_json(data_dict, config_parser.get_io_config_attribute_by_section("mongoDB", "collection_criminal_data_raw"))
            count_valid+=1
except Exception as e:
    log.log_error("Exception occured while reading kafka payload from GCS... "+str(e))
    log.log_error("Exception occured: %s" + str(traceback.format_exc()))


metadata_dict={}
metadata_dict["ingestion_date"]=ingestion_date
metadata_dict["num_valid_records"]=count_valid
metadata_dict["num_invalid_records"]=count_invalid


try:
    mongodbconnector.write_records_from_json(metadata_dict, config_parser.get_io_config_attribute_by_section("mongoDB", "collection_crim_payload_metadata"))
    log.log_info("Successfully written Meta Data to  Mongo DB... ")
except Exception as e:
    log.log_error("Exception occured while writing Meta data to  Mongo DB... ")
    log.log_error("Exception occured: %s" + str(e))

