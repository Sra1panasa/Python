from pyspark.sql.functions import *
import traceback
from datetime import date
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.kafka_connector import KafkaConnector
from cls_src.utils.pipeline_context import PipelineContext
from cls_src.utils.read_config import *
from cls_src.utils.deltalake_connector import DeltaLakeConnector

'''
Creating a pipeline to  read incomming messages from Kafka as payload and 
extract the data from the payload and store the payload data into GCS 

'''

pipeline_name = "kafka_to_gcs"
log = Framework_Logger()
today = date.today()
#failover_startdate = datetime.datetime.now().strftime("%Y-%m-%d")
failover_startdate=today.strftime("%d-%m-%Y")
enable_ledger = True
spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled=true")
try:
    pipeline_ctx = PipelineContext("stream",pipeline_name)
    spark_ctx = pipeline_ctx.create_pyspark_streaming_session()
    kafka_ctx = KafkaConnector(pipeline_ctx=pipeline_ctx)
    delta_ctx =DeltaLakeConnector(pipeline_ctx, spark_ctx,failover_startdate = failover_startdate) 
    log.log_info("Data Ingestion :All connectors initialized")
except Exception as e:
    log.log_error("Data Ingestion :Error in connectors initialization.."+str(e))
    log.log_error("Data Ingestion :Exception occured: %s" + str(traceback.format_exc()))



streaming_df = kafka_ctx.read(spark_ctx)
#display(streaming_df)
# ingested date - date when msg ingested to kafka
# created_date - current timestamp

streaming_df = streaming_df.withColumn("gcs_created_date",date_format(current_timestamp(),"dd-MM-yyyy"))
streaming_df = streaming_df.withColumn("ingested_date",date_format(col("timestamp"),"dd-MM-yyyy"))

#display(streaming_df)

delta_ctx.stream_write_landing(streaming_df,partition_column = "ingested_date")

