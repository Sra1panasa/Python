# Databricks notebook source
from cls_src.training.offense_nature_training import *


# COMMAND ----------

from cls_src.training.offense_nature_training import *
import mlflow
from google.cloud import storage
import pickle
import pickle
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.read_config import *
import random
import string
import traceback
from cls_src.utils.pymongo_db_connector import PyMongoConnector
from cls_src.performance.performance_report import PerformanceEval
import time

logger=Framework_Logger()

# COMMAND ----------
def NatureOffenseTrainingMain(data_path,exp_name):
    '''
        In this function the OffenseNaturetraining class is implemented i.e Nature of offense training is done
        The Noo  model(distilbert model) is trained and then used on the Noo training data for classification
        With mlflow all the results, training model, tokenizer, encoder ,predictions , accuracy metrics
         are being stored as artifacts in mlflow instance
        Those mlflow artifacts are then being stored into mongodb 

        Parameters :
             data_path(String)  : specifies the GCS path of the training data
             exp_name(String)   : specifies the experiment name for the mlflow instance


        Returns : None

     '''
    try:
        logger=Framework_Logger()
        confg=GetConfigAttr()
        mongodbconnector=PyMongoConnector()
        performance=PerformanceEval()
        mlflow.set_tracking_uri(confg.get_model_config_path_attr_by_section("MLFLOW","tracking_server"))
        experiment_id = mlflow.create_experiment(exp_name)
        mlflow.autolog()
        with mlflow.start_run(nested=True,experiment_id=experiment_id) as run:
            run_id = run.info.run_id
            logger.log_info("Classification: NOO Training main :MLFlow Initialized with run Id "+str(run_id))
            noo=NatureOffenseTraining()
            input_data=noo.load_data(data_path)
            mlflow.log_param("No of records in the  dataset",input_data.shape[0])
            mlflow.log_param("NatureOffense Training Model Name","DisitilBert-Base_Uncased")
            cluster_freq=noo.get_cluster_frquency(input_data,"Sub-Category")
            cluster_freq=cluster_freq.to_html("Cluster_Frequency.html")
            mlflow.log_artifact("Cluster_Frequency.html","Cluster_Frequency")
            noo.load_encoder()
            data=noo.get_encodings_data(input_data,"Sub-Category")
            data=data.drop(["cluster-cd"],axis=1)
            noo_model=noo.load_model(num_labels=23,model_name="distilbert-base-uncased")
            noo.load_tokenizer("distilbert-base-uncased")
            noo.setup_collator()
            data['offense_processed']=data['offense_processed'].astype("str")
            data['offense_literal']=data['offense_literal'].astype("str")
            token_data=noo.get_tokenized_dataset(data)
            split_data,val_data=noo.train_test_split(token_data,0.2,0.2)
            training_args=TrainingArguments(output_dir=".//model_results//noo_subcategory//",
                                          per_device_train_batch_size=64,
                                          per_device_eval_batch_size=64,
                                          num_train_epochs=5,
                                          evaluation_strategy="epoch")
            trainer=noo.model_training(noo_model,val_data,training_args)
            trainer.train()
            test_pred_data=noo.make_predictions(trainer,split_data['test'],'test')
            val_pred_data=noo.make_predictions(trainer,val_data['test'],'validation')
            train_pred_data=noo.make_predictions(trainer,val_data['train'],'train')
            noo_pred=train_pred_data.append(val_pred_data, ignore_index=True)
            noo_prediction_data=noo_pred.append(test_pred_data,ignore_index=True)
            
            with open('noo_model', 'wb') as model:
                pickle.dump(noo_model, model)
            mlflow.log_artifact("noo_model")
            mlflow.pytorch.log_model(noo_model,
                                     artifact_path="pytorch",registered_model_name="NOO Model")
            with open('noo_tokenizer', 'wb') as model:
                pickle.dump(noo.tokenizer, model) 
            mlflow.log_artifact("noo_tokenizer")
            
            with open('noo_encoder', 'wb') as model:
                pickle.dump(noo.od_encoder, model) 
            mlflow.log_artifact("noo_encoder")
            
            test_pred_data.to_excel("Test_Pred_Data.xlsx")
            train_pred_data.to_excel("Train_Pred_Data.xlsx")
            val_pred_data.to_excel("Validation_Pred_Data.xlsx")
            noo_prediction_data.to_excel("NOO_Pred_data.xlsx")
            mlflow.log_artifact("NOO_Pred_data.xlsx")
            mlflow.log_artifact("Test_Pred_Data.xlsx")
            mlflow.log_artifact("Validation_Pred_Data.xlsx")
            mlflow.log_artifact("Train_Pred_Data.xlsx")
            
            mlflow.log_param("No of records in training data",train_pred_data.shape[0])
            mlflow.log_param("No of records in test data",test_pred_data.shape[0])
            mlflow.log_param("No of records in validation data ",val_pred_data.shape[0])
            mlflow.log_metrics(trainer.evaluate())
            
            logger.log_info("Classification: NOO Training main :MLFLOW Artifacts saved to GCS")
            logger.log_info("Classification: NOO Training main :Saving MLFLOW metrics, params and model performance into mongodb")
            mlflow_obj=mlflow.tracking.MlflowClient().get_run(run_id).data.to_dictionary()
            
            accuracy_metrics=pd.DataFrame(performance.get_performance_metrics(test_pred_data["Sub-Category"], test_pred_data["Prediction"]))
            cm_obj=performance.get_confusion_matrix(test_pred_data["Sub-Category"], test_pred_data["Prediction"]).T.to_dict('series')
            model_performance=accuracy_metrics.to_dict('series')
            
            store_obj=dict()
            store_obj["_id"]=run_id
            store_obj["experiment_name"]=exp_name
            store_obj["mlflow_params"]=mlflow_obj["params"]
            store_obj["mlflow_metrics"]=mlflow_obj["metrics"]
            
            for key in model_performance:
                model_performance[key]=model_performance[key].to_dict()
            for key in cm_obj:
                cm_obj[key]=cm_obj[key].to_dict()
            store_obj["model_performance"]=model_performance
            store_obj["confusion_matrix"]=cm_obj
            mongodbconnector.write_records_from_json(store_obj,confg.get_io_config_attribute_by_section("mongoDB", "collection_mlops_cls_metrics_logger"))
            logger.log_info("Classification: NOO Training main :Metrics and Params stored into mongodb")
            mlflow.end_run()
    except Exception as e:
        logger.log_error("Classification: NOO Training main :Exception occurred: %s"+ str(traceback.format_exc()) )  
        
# COMMAND ----------     
start_time=time.time()
exp_name="Test_"+"".join(random.choices(string.ascii_lowercase + string.digits, k=7))
data_path="gs://bkt-d-hrgp-data-us/ds_zaha_hrg2/classification/noo/data/training_data/noo_dataset.xlsx"
NatureOffenseTrainingMain(data_path,exp_name)    

end_time=time.time()

elapsed_time=end_time-start_time
elapsed_time=time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
logger.log_info('Classification: NOO Training main : Execution time : '+str(elapsed_time))
    
            