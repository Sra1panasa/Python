#!/bin/bash
# Dev
if lsof -Pi :24224 -sTCP:LISTEN -t >/dev/null ; then
    echo "running"
else
    echo "not running"
    apt-get install jq -y
    # pip install hvac xmltodict pymongo delta-spark==1.1.0 google-cloud google-cloud-storage jsonpath_ng xmlschema confluent-kafka[avro,json]>=1.4.2 fluent-logger google-cloud-logging crcmod
    echo "{\"password\": \"89M3>UKMNWC*^oG-aL7b=BG\"}" > payload.json 
    VAULT_SERVER_URL='https://tools-dev.hireright.com'
    RESPONSE=`curl --request POST --data @payload.json ${VAULT_SERVER_URL}/v1/auth/userpass/login/ddataservices`
    VAULT_LEASE_CLIENT_TOKEN=`echo $RESPONSE | jq .auth.client_token | sed 's/"//g'`
    SPLUNK=`curl --header "X-Vault-Token: $VAULT_LEASE_CLIENT_TOKEN" ${VAULT_SERVER_URL}/v1/dataservices/data/splunk/config`
    SPLUNK_TOKEN=`echo $SPLUNK | jq .data.data.token | sed 's/"//g'`
    echo $SPLUNK_TOKEN
    echo "export SPLUNK_TOKEN=$SPLUNK_TOKEN" >>~/.bashrc    
    echo "init Install"
    echo """net.core.somaxconn = 1024 \nnet.core.netdev_max_backlog = 5000 \nnet.core.rmem_max = 16777216 \nnet.core.wmem_max = 16777216 \nnet.ipv4.tcp_wmem = 4096 12582912 16777216 \nnet.ipv4.tcp_rmem = 4096 12582912 16777216 \nnet.ipv4.tcp_max_syn_backlog = 8096 \nnet.ipv4.tcp_slow_start_after_idle = 0 \nnet.ipv4.tcp_tw_reuse = 1 \nnet.ipv4.ip_local_port_range = 10240 65535""" >> /etc/sysctl.conf
    apt-get update --fix-missing
    apt-get install make gcc screen libz-dev libiconv-hook1 libiconv-hook-dev jq -y
    apt install ruby-full build-essential -y
    gem install fluentd fluent-plugin-splunk-hec
    echo "Installed Nessesary Software "
    tee python.conf <<EOF
<source>
  type forward
  port 24224
  tag fluentd.python
</source>
EOF
    echo "Created python.conf file "
    echo "Created stderr.conf file "
    tee stderr.conf <<EOF
<source>
  type tail
  add_tag_prefix spark_stderr
  output_type json
  read_from_head true
  tag fluentd.stderr
  path /databricks/driver/logs/stderr
  pos_file /var/log/td-agent/stderr1.pos
  <parse>
    @type none
  </parse>
</source>
EOF
    echo "Created log4j-active.conf file "
    tee log4j-active.conf <<EOF
<source>
  type tail
  add_tag_prefix spark_log4j
  output_type json
  read_from_head true
  tag fluentd.log4j-active
  path /databricks/driver/logs/log4j-active.log
  pos_file /var/log/td-agent/log4j-active1.pos
  <parse>
    @type none
  </parse>
</source>
EOF
    echo "Created stdout.conf file "
    tee stdout.conf <<EOF
<source>
  type tail
  add_tag_prefix spark_stdout
  output_type json
  read_from_head true
  tag fluentd.stdout
  path /databricks/driver/classification_logs/classification_pipeline.log
  pos_file /databricks/driver/logs/classification_logs.pos
  <parse>
    @type none
  </parse>
</source>
EOF
    echo "Created stdout_id.conf file "
    tee stdout_id.conf <<EOF
<source>
  type tail
  add_tag_prefix spark_stdout
  output_type json
  read_from_head true
  tag fluentd.stdout
  path /databricks/driver/id_resolution_logs/id_resolution_pipeline.log
  pos_file /databricks/driver/logs/id_resolution_logs.pos
  <parse>
    @type none
  </parse>
</source>
EOF
    echo "Created splunk.conf file "
    tee output_plug.conf <<EOF
<match **>
  <buffer>
      @type file
      path /var/log/fluent/foo
      flush_thread_count 2
      flush_interval 120s
      request_timeout 15
      chunk_limit_size 128Mb    
      overflow_action block
      flush_mode interval
      retry_max_interval 120
      retry_forever true
      chunk_full_threshold 0.95
  </buffer>
    @type splunk_hec
    protocol https
    hec_host splunk-dev.hireright.com
    hec_port 8087
    hec_token beed1fe3-70c5-4cf0-a35e-69a3b03adc1b
    index hrg2-ds-pipeline-dev
</match>
EOF
    echo "Created final.conf file "
    tee final.conf  <<EOF
# ###### Python Framework Logs ######
#@include python.conf
# ###### Databricks Std Error Logs ######
#@include @stderr.conf
# # # ###### Python Log4j Logs ######
# @include log4j-active.conf
# ###### Python stdout Logs ######
@include stdout.conf
@include stdout_id.conf
###### Splunk Forworder ######
@include output_plug.conf
EOF
    echo "Installation Completed FulenD is running on 24224 "
    screen -d -m fluentd -c final.conf
fi