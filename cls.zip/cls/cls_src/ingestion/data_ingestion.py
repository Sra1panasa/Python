
# Write Kafka pull request to pull the data from Kafka topic name to our GCS

