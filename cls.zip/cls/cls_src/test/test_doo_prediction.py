from cls_src.prediction.doo_prediction import *
from cls_src.prediction.dispo_prediction import *
from cls_src.prediction.extract_payload import *


logger=Framework_Logger()
payload=Extract_Payload()
payload_df=payload.process_ingested_data_classification()
payload_df.head()
doo=OffenseDegree()


def test_load_model():
    try:
        model=doo.load_model()
        assert model!=None
        logger.log_info(" Test case Passed for function load_model..")
    except Exception as e:
        logger.log_error(" Test case failed for function load_model.."+str(e))

def test_load_tokenizer():
    try:
        tokenizer=doo.load_tokenizer()
        assert tokenizer!=None
        logger.log_info(" Test case Passed for function load_tokenizer..")
    except Exception as e:
        logger.log_error(" Test case failed for function load_tokenizer.."+str(e))


def test_get_offenseDegreee_category_series():
    try:
        stat_predlb_dict=doo.get_offenseDegreee_category_series(payload_df[["offense_literal","criminal_record_info.state"]])
        assert stat_predlb_dict['status']==True,"Test Failed with status False"
        assert (len(stat_predlb_dict['predictions'])!=0)
        logger.log_info(" Test case Passed for function get_offenseDegreee_category_series..")
    except Exception as e:
        logger.log_error(" Test case failed for get_offenseDegreee_category_series.."+str(e))      

# This funtion not being used need to check
def test_get_offenseDegreee_value():
    try:
        offensedegree_value=doo.get_offenseDegreee_value()
        assert offensedegree_value!=None
        logger.log_info(" Test case Passed for function get_offenseDegreee_value..")
    except Exception as e:
        logger.log_error(" Test case failed for function get_offenseDegreee_value.."+str(e))


if __name__ == "__main__":
    test_load_model()
    test_load_tokenizer()
    test_get_offenseDegreee_category_series()
    #test_get_offenseDegreee_value()