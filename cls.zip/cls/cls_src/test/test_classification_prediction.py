from cls_src.prediction.dispo_prediction import *
from cls_src.prediction.doo_prediction import *
from cls_src.prediction.extract_payload import *
from cls_src.prediction.offense_nature_prediction import OffenseNaturePrediction
from unittest import mock
# from cls_src.utils.pymongo_db_connector import PyMongoConnector
import numpy as np
import pandas as pd
# mongoconnector=PyMongoConnector()

noo_data = np.array([['MAXIMUM SPEED LIMIT 38/25 MILES PER HOUR', 'maximum speeding speeding','Speeding','Speeding',0], [' DRIVING UNDER THE INFLUENCE LICENSE SUSPENDED OR REVOKED/THIRD', 'driving influence license suspended third','Driving License Suspended','Driving License Suspended',1],['Burglary (Occupied/Criminal Offense)','burglary occupied criminal offense','Burglary','Burglary','2']])
  
noo_data = pd.DataFrame(noo_data, columns = ['offense_literal', 'offense_processed','Sub-Category','Prediction','labels'])

dispo_data = np.array([['Dismiss Supervision','Deferral',0,'Deferral'],['GUILTY PLEA / CONVICTION','Conviction',1,'Conviction'],['Guilty Plea','Pending','2','Pending'],['Disposed at Lower Court','Non-Conviction',3,'Non-Conviction'],['Dismiss Supervision','Deferral',0,'Deferral']])
dispo_data = pd.DataFrame(dispo_data, columns = ['Disposition','Dispo_Category','labels','Prediction'])

doo_data = np.array([['TX', 'DRIVING WHILE INTOXICATED','PLEASE NOTE NO MIDDLE INITIAL AS SHOWN ON RECORD / 20 DAYS JAIL CREDIT FOR TIME SERVED / DRIVERS LICENSE SUSPENDED //','Misdemeanor','3 YEARS','20 DAYS','Misdemeanor',1], ['FL', 'BURGLARY','UNSPECIFIED SENTENCING','Felony','4 YEARS','48 HOURS','Felony',0],['CA','PAROLE REVOCATION','NO FURTHER PENALTY / PAROLE SUPERVISION IS RESTORED TIME UNSPECIFIED / NOTE MIDDLE NAME','Felony','2 YEARS','360 DAYS','Felony',0]])

doo_data = pd.DataFrame(doo_data, columns = ['state','offense_literal','sentencing_notes','degree_of_offense','prisontime','jailtime','Prediction','labels'])

log=Framework_Logger()
# payload=Extract_Payload()
dispo=DispositionPrediction()
doo=OffenseDegreePrediction()
noo=OffenseNaturePrediction()
#Test if we are able to extratct ingested processed data 
# def test_process_ingested_data_classification():
#     try:
#         ids=[1,2,3,4,5]
#         mock_process_ingested_data=mock.Mock(name="mock_process_ingested_data_classification",return_value=(noo_data,ids))
#         payload.process_ingested_data_classification=mock_process_ingested_data
#         df,test_ids=payload.process_ingested_data_classification()
#         assert len(df)!=0
#         log.log_info("Test process ingested data classification is successful")
#     except Exception as e:
#         log.log_error("Error in extract payload process ingested data .."+str(e))
        
#Check if we are able to prdict the the disposotion category for the sample data        
def test_get_disposition_category_series():
    try:
        mock_get_disposition_category_series=mock.Mock(name="mock_get_disposition_category_series",return_value=dispo_data)
        dispo.get_disposition_category_series=mock_get_disposition_category_series
        dispo_pred=dispo.get_disposition_category_series(dispo_data)
        assert len(dispo_pred)==len(dispo_data)
        log.log_info("Test get disposition category series passed")
    except Exception as e:
        log.log_error("Test get disposition category series not passed")

#Check if we are able to prdict the the offense degree category for the sample data        
def test_get_offenseDegreee_category_series():
    try:
        mock_get_offenseDegreee_category_series=mock.Mock(name="mock_get_offenseDegreee_category_series",return_value=doo_data)
        doo.get_offenseDegreee_category_series=mock_get_offenseDegreee_category_series
        doo_pred=doo.get_offenseDegreee_category_series(doo_data)
        assert len(doo_pred)==len(doo_data)
        log.log_info("Test get offenseDegreee category series passed ")
    except Exception as e:
        log.log_error("Error in get offenseDegreee category series ..."+str(e))

#Check if we are able to prdict the the nature of offense sub category for the sample data
def test_get_sub_category_series():
    try:
        mock_get_sub_category_series=mock.Mock(name="mock_get_sub_category_series",return_value=noo_data)
        noo.get_sub_category_series=mock_get_sub_category_series
        noo_pred=noo.get_sub_category_series(noo_data)
        assert len(noo_pred)==len(noo_data)
        log.log_info("Test get sub category series passed")
    except Exception as e:
        log.log_error("Error in get sub category series.."+str(e))
        

        
