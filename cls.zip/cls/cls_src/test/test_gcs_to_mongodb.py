#GCS To MONGO DB Main
from pyspark.sql.functions import *
import traceback
from datetime import date
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.kafka_connector import KafkaConnector
from cls_src.utils.pipeline_context import PipelineContext
from cls_src.utils.read_config import *
from cls_src.utils.deltalake_connector import DeltaLakeConnector
from cls_src.utils.read_config import *
# from cls_src.utils.pymongo_db_connector import PyMongoConnector
from delta.tables import *
from cls_src.utils.payload_validator import validator



pipeline_name = "kafka_to_gcs"
log = Framework_Logger()
today = date.today()
failover_startdate=today.strftime("%d-%m-%Y")
enable_ledger = True
spark.sql("SET spark.databricks.delta.schema.autoMerge.enabled=true")
try:
    pipeline_ctx = PipelineContext("stream",pipeline_name)
    spark_ctx = pipeline_ctx.create_pyspark_streaming_session()
    kafka_ctx = KafkaConnector(pipeline_ctx=pipeline_ctx)
    delta_ctx =DeltaLakeConnector(pipeline_ctx, spark_ctx,failover_startdate = failover_startdate) 
    log.log_info("All connectors initialized")
except Exception as e:
    log.log_error("Error in connectors initialization.."+str(e))
    log.log_error("Exception occured: %s" + str(traceback.format_exc()))

#testing the mongodb connection   
# def test_mongodb_connection():
#     print("Inside Mongodb connection test")
#     try:
#         mongoconnector=PyMongoConnector()
#         crim_db=mongoconnector.crimdb
#         assert crim_db!=None
#         log.log_info("MongoDb connection is successfull")
#     except Exception as e:
#         log.log_error("MongoDb connection is not successfull")
        
    
#test if stream Writes dataframe to the delta table path in landing zone    
def test_read_landing():
    try:
        df_landing_zone=delta_ctx.read_landing()
        assert df_landing_zone!=None
        log.log_info("Reading the data from landing zone is successful")
    except Exception as e:
        log.log_error("Error while reading data from landing path.."+str(e))
#test if Creating a UDF for the validating function       
def test_validation_upstream():
    try:
        df_landing_zone=delta_ctx.read_landing()
        deserlzd_df=kafka_ctx.get_kafka_payload(df_landing_zone)
        validate_ctx=validator()
        val_df=validate_ctx.validation_upstream(deserlzd_df,"data")
        assert val_df!=None
        log.log_info("Validation upstream is Successful")
    except Exception as e:
        log.log_error("Error in validation upstream .."+str(e))

#test if the the function takes the payload from kafka and extracts data from the payload.      
def test_get_kafka_payload():
    
    try:
        df_landing_zone=delta_ctx.read_landing()
        deserlzd_df=kafka_ctx.get_kafka_payload(df_landing_zone)
        assert deserlzd_df!=None
        log.log_info("Data extraction from Kafka Payload is successfull")
    except Exception as e:
        log.log_error("Error in Kafka payload data extraction.."+str(e))
