from cls_src.utils.logger import Framework_Logger
from cls_src.utils.kafka_connector import KafkaConnector
from cls_src.utils.pipeline_context import PipelineContext
from cls_src.utils.read_config import *
from cls_src.utils.deltalake_connector import DeltaLakeConnector
from datetime import date
import os

logger=Framework_Logger()

def test_pipelinecontext():
    print("Inside test pipelinecontext ")
    try:
        pipelineconnector=PipelineContext("stream","kafka_to_gcs")
        assert pipelineconnector!=None
        logger.log_info("PipilineContext connection is established")
    except Exception as e:
        logger.log_error("PipelineContext connection not successfull.."+str(e))
def test_kafka_connector():
    print("Inside test Kafka Connection")
    try:
        pipelineconnector=PipelineContext("stream","kafka_to_gcs")
        kafka_obj = KafkaConnector(pipeline_ctx=pipelineconnector)
        assert kafka_obj!=None
        logger.log_info("Kafka Connection is established")
    except Exception as e:
        logger.log_error("Kafka connection not successfull.."+str(e))
        
        
def test_spark_streaming_session():
    print("Inside test spark streaming session")
    try:
        pipelineconnector=PipelineContext("stream","kafka_to_gcs")
        spark_ctx =pipelineconnector.create_pyspark_streaming_session()
        assert spark_ctx!=None
        logger.log_info("Spark Streaming session is successfull")
    except Exception as e:
        logger.log_error("Error in establishing Spark streaming session "+str(e))
        


def test_kafka_read():
    print("inside test kafka read")
    try :
        initialize_ctx = PipelineContext("stream","kafka_to_gcs")
        spark_streaming_ctx = initialize_ctx.create_pyspark_streaming_session()
        kafka_obj = KafkaConnector(pipeline_ctx=initialize_ctx)
        streaming_df=kafka_obj.read(spark_streaming_ctx)
        assert streaming_df!=None
        logger.log_info("Test for Kafka read passed")
        
    except Exception as e:
        logger.log_error("Error in Kafka read function .."+str(e))
        assert False