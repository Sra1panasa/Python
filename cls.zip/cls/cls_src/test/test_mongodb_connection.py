from cls_src.utils.pymongo_db_connector import PyMongoConnector
from pymongo.errors import ConnectionFailure
from cls_src.utils.logger import Framework_Logger
import numpy as np
import pandas as pd


#Test the mongodb connection
def test_mongodb_connection():
    log = Framework_Logger()
    mongoconnector=PyMongoConnector()
    print("test the inits of mongodb")
    log.log_info("test the inits of mongodb")
    print(mongoconnector.environment)
    print(mongoconnector.mongo_checkpoint)
    print("test the inits of mongodb completetd")
    try:
        client=mongoconnector.client

        assert client.admin.command('ismaster')['ismaster']==True
        log.log_info("Testing mongodb connection is successful")
    except Exception as e:
        log.log_error("Error in mongodb connection.."+str(e))



        
 #Test if 'hrg2_datascience' database exists in the mongodb   
def test_mongodb_database():
    log = Framework_Logger()
    mongoconnector=PyMongoConnector()
    print(mongoconnector.environment)
    print(mongoconnector.mongo_checkpoint)
    try:
        
        database_list=mongoconnector.client.list_database_names()
        if "hrg2_datascience" in database_list:
            log.log_info("Hrg2-Datascience data base exists.")
    except Exception as e:
        log.log_error("hrg2-datascience database doesn't exist in Mongodb.."+str(e))

#Check if we are able to write json records into mongodb collection       
def test_write_records_from_json():
    log = Framework_Logger()
    mongoconnector=PyMongoConnector()
    print(mongoconnector.environment)
    print(mongoconnector.mongo_checkpoint)
    try:
        db=mongoconnector.crimdb
        data=dict()
        data['run_id']='run_id'
        data['experiment_name']='exp_name'
        data['mlflow_params']='params'
        data['model_performance']='model_performance'
        data['confusion matrix']='confusion_matrix'
        mongoconnector.write_records_from_json(data,'test_mongodb')
        assert db.test_mongodb.count_documents({})!=0
        mongoconnector.delete_all('test_mongodb')
#         db.test_mongodb.delete_one(data)
        logger.log_info("Test write data to mongo_db in json  is successfull" )
    except Exception as e:
        log.log_error("Error in writing data to mongo_db.."+str(e))

#Check if we are able to write dataframe into mongodb collection        
def test_write_records_from_df():
    log = Framework_Logger()
    mongoconnector=PyMongoConnector()
    print(mongoconnector.environment)
    print(mongoconnector.mongo_checkpoint)
    try:
        db=mongoconnector.crimdb
        data= np.array([['MAXIMUM SPEED LIMIT 38/25 MILES PER HOUR', 'maximum speeding speeding','Speeding','Speeding'],['Burglary (Occupied/Criminal Offense)','burglary occupied criminal offense','Burglary','Burglary']])
        sample_data = pd.DataFrame(data, columns = ['offense_literal', 'offense_processed','Sub-Category','Prediction'])
        mongoconnector.write_records_from_df(sample_data,'test_mongodb')
        assert db.test_mongodb.count_documents({})!=0
        mongoconnector.delete_all('test_mongodb')
#         db.test_mongodb.delete_many(sample_data.to_dict('split'))
        log.log_info("Test write data to mongo_db in dataframe  is successfull" )
    except Exception as e:
        log.log_error("Error in writing data to mongo_db.."+str(e))

#Check if we are able to update records in mongodb         
def test_upsert_records():
    log = Framework_Logger()
    mongoconnector=PyMongoConnector()
    print(mongoconnector.environment)
    print(mongoconnector.mongo_checkpoint)
    try:
        db=mongoconnector.crimdb
        mongoconnector.upsert_records("test_mongodb",['run_id'],[{"cls_processing_status":1}])
        mongoconnector.delete_all('test_mongodb')
        assert True
        log.log_info("Test upsert records is successful")
    except Exception as e:
        log.log_error("Error in updating records into collections")
        assert False
        