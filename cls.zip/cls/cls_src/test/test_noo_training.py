import pytest
import unittest
from cls_src.training.offense_nature_training import *
from unittest import mock
from cls_src.utils.logger import Framework_Logger
# from cls_src.performance.performance_report import PerformanceEval  - TEMP COMMENTING TO TEST UNIT CASES INTEGRATON 
# from cls_src.utils.pymongo_db_connector import PyMongoConnector  - TEMP COMMENTING TO TEST UNIT CASES INTEGRATON 

noo=NatureOffenseTraining()
logger=Framework_Logger()
# mongoconnector=PyMongoConnector()  - TEMP COMMENTING TO TEST UNIT CASES INTEGRATON 

data = np.array([['MAXIMUM SPEED LIMIT 38/25 MILES PER HOUR', 'maximum speeding speeding','Speeding','Speeding',0], [' DRIVING UNDER THE INFLUENCE LICENSE SUSPENDED OR REVOKED/THIRD', 'driving influence license suspended third','Driving License Suspended','Driving License Suspended',1],['Burglary (Occupied/Criminal Offense)','burglary occupied criminal offense','Burglary','Burglary','2']])
  
sample_data = pd.DataFrame(data, columns = ['offense_literal', 'offense_processed','Sub-Category','Prediction','labels'])
sample_data['offense_processed']=sample_data['offense_processed'].astype("str")
sample_data['offense_literal']=sample_data['offense_literal'].astype("str")
tokenizer=AutoTokenizer.from_pretrained("distilbert-base-uncased")
noo_model = AutoModelForSequenceClassification.from_pretrained("distilbert-base-uncased",num_labels=23)

#checking if the path contains the NOO training data
def test_load_data():
    
    try:
        mock_load_data=mock.Mock(name="mock_load_data",return_value=sample_data)
        noo.load_data=mock_load_data
        assert len(noo.load_data("path"))==len(sample_data)
        logger.log_info("Load data from GCS test passed")
        
    except Exception as e:
        logger.log_error("Error in loading the data from GCS.."+str(e))
#Test the function that returns each sub-category of NOO frequency        
def test_get_cluster_frequency():
    try:
        cluster_freq=noo.get_cluster_frquency(sample_data,"Sub-Category")
        assert len(cluster_freq)!=0
        logger.log_info("Get Cluster frequency test passed")
    except Exception as e:
        logger.log_error("Error in get cluster frequency.."+str(e))
#check if we are able to load encoder 
def test_load_encoder():
    try:
        od_encoder = preprocessing.LabelEncoder()
        mock_load_encoder=mock.Mock(name="mock_load_encoder",return_value=od_encoder)
        noo.load_encoder=mock_load_encoder
        
        assert noo.load_encoder()==od_encoder
        logger.log_info("Test load encoder has passed")
    except Exception as e:
        logger.log_info("Error in load encoder test.."+str(e))
#Check if we are able to encode the target variable i.e Sub-Category
def test_get_encodings_data():
    
    try:
        mock_get_encodings_data=mock.Mock(name="mock_get_encodings_data",return_value=sample_data)
        noo.get_encodings_data=mock_get_encodings_data
        assert len(noo.get_encodings_data("sample_data","Sub-Category"))==2
        logger.log_info("Test get encodings data passed")
    except Exception as e:
        logger.log_error("Error in test get encodings data.."+str(e))
 #Checking if we are able to load NOO model       
def test_load_model():
    
    try:
       
        mock_load_model=mock.Mock(name="mock_load_model",return_value=noo_model)
        noo.load_model=mock_load_model
        assert noo.load_model('model_name',23)==noo_model
        logger.log_info("Test Load Model has passed")
    except Exception as e:
        logger.log_error("Error in loading model .."+str(e))
#Checking if we are able to load NOO tokenizer        
def test_load_tokenizer():
    try:
        
        mock_load_tokenizer=mock.Mock(name="mock_load_tokenizer",return_value=tokenizer)
        noo.load_tokenizer=mock_load_tokenizer
        assert noo.load_tokenizer('model_name')==tokenizer
        logger.log_info("Test Load tokenizer has passed")
    except Exception as e:
        logger.log_error("Error in Test load tokenizer.. "+str(e))
#Check if we are able to load data collator
def test_load_data_collator():
    try:
        data_collator = DataCollatorWithPadding(tokenizer=tokenizer)
        mock_setup_collator=mock.Mock(name="mock_load_datacollator",return_value=data_collator)
        noo.setup_collator=mock_setup_collator
        assert noo.setup_collator()==data_collator
        logger.log_info("Test for loading data collator has passed")
    except Exception as e:
        logger.log_error("Error in loading data collator.."+str(e))
        
#tokenization function         
def preprocess_function(data):
    return tokenizer(data["offense_processed"], truncation=True)
    
#Check if we are able to tokenize the NOO data 
def test_get_tokenized_data():
    try:
        
        data=Dataset.from_pandas(sample_data)
        tokenized_dataset= data.map(preprocess_function, batched=True)
#         tokenized_dataset= data.map(tokenizer(sample_data["offense_processed"], truncation=True), batched=True)
        mock_get_tokenized_data=mock.Mock(name="mock_get_tokeized_data",return_value=tokenized_dataset)
        noo.get_tokenized_dataset=mock_get_tokenized_data
        
        assert noo.get_tokenized_dataset(sample_data)==tokenized_dataset
        logger.log_info("Test Get tokenized data has Passed")
    except Exception as e:
        print("Error in get tokenized data test.."+str(e))
        
#Check if we are able to split the data into training,test and validation data 
def test_train_test_split():
    try:
        data=Dataset.from_pandas(sample_data)
        tokenized_dataset= data.map(preprocess_function, batched=True)
        split_data=tokenized_dataset.train_test_split(0.2,0.8)
        val_data=split_data["train"].train_test_split(0.2,0.8)
        mock_train_test_split=mock.Mock(name="mock_train_test_split",return_value=val_data)
        noo.train_test_split=mock_train_test_split
        split_data_test,val_data_test=noo.train_test_split(tokenized_dataset,0.2,0.2)
        assert val_data_test!=None
        logger.log_info("Test the training and validation data passed")
    except Exception as e:
        logger.log_error("Error in test the training and validation split ..."+str(e))
        
    
#Check if we are able to create a confusion matrix with predicted NOO classification data 
# def test_confusion_matrix():  - TEMP COMMENTING TO TEST UNIT CASES INTEGRATON 
#     try:
#         performance=PerformanceEval()
#         cm=performance.get_confusion_matrix(sample_data["Sub-Category"], sample_data["Prediction"])
#         assert len(cm)!=0
#         logger.log_info("test confusion matrix passed")
#     except Exception as e:
#         logger.log_error("error in confusion matrix test "+str(e))

# #Check if we are able to get performance metrics with predicted NOO classification data        
# def test_get_performance_metrics():  - TEMP COMMENTING TO TEST UNIT CASES INTEGRATON 
#     try:
#         performance=PerformanceEval()
#         accuracy_metrics=performance.get_performance_metrics(sample_data["Sub-Category"], sample_data["Prediction"])
#         assert len(accuracy_metrics)!=0
#         logger.log_info("Test accuracy metrics passed")
#     except Exception as e:
#         logger.log_error("Error in the test accuracy metrics.."+str(e))
