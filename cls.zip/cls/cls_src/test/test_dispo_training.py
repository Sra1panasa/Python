from cls_src.training.disposition_model_training import *
from unittest import mock
from cls_src.utils.logger import Framework_Logger
# from cls_src.performance.performance_report import PerformanceEval


dispo=DispositionModelTraining()
log=Framework_Logger()

data = np.array([['Dismiss Supervision','Deferral',0,'Deferral'],['GUILTY PLEA / CONVICTION','Conviction',1,'Conviction'],['Guilty Plea','Pending','2','Pending'],['Disposed at Lower Court','Non-Conviction',3,'Non-Conviction'],['Dismiss Supervision','Deferral',0,'Deferral']])
sample_data = pd.DataFrame(data, columns = ['Disposition','Dispo_Category','labels','Prediction'])
sample_data
tokenizer=AutoTokenizer.from_pretrained("distilbert-base-uncased")
dispo_model = AutoModelForSequenceClassification.from_pretrained("distilbert-base-uncased",num_labels=4)

#checking if the path contains the Disposition training data
def test_load_data():
    
    try:
        mock_load_data=mock.Mock(name="mock_load_data",return_value=sample_data)
        dispo.load_data=mock_load_data
        assert len(dispo.load_data("path"))==len(sample_data)
        log.log_info("Load Disposition data from GCS test passed")
        
    except Exception as e:
        log.log_error("Error in loading the DOO data from GCS.."+str(e))
#Check if we are able to encode the target variable i.e Dispo_Category  
def test_encode_target():
    
    try:
        encoded_data=dispo.encode_target(sample_data,col_name="Dispo_Category")
        assert len(encoded_data)==len(sample_data)
        log.log_info("Test encode target has passed")
    except Exception as e:
        log.log_error("Error in test encode target data.."+str(e))

#check if we are able to load encoder       
def test_get_encoder():
    try:
        od_encoder = preprocessing.LabelEncoder()
        mock_load_encoder=mock.Mock(name="mock_load_encoder",return_value=od_encoder)
        dispo.get_encoder=mock_load_encoder
        
        assert dispo.get_encoder()==od_encoder
        log.log_info("Test load encoder has passed")
    except Exception as e:
        log.log_info("Error in load encoder test.."+str(e))

#Check if we are able to preprocess the test of Disposition data         
def test_preprocess_text():
    try:
        preprocessed_text=dispo.preprocess_text(sample_data,col_name="Disposition")
        assert len(preprocessed_text)==len(sample_data)
        log.log_info("Test preprocess text has passed")
    except Exception as e:
        log.log_info("Error in preprocess text test.."+str(e))

#Checking if we are able to load Disposition tokenizer            
def test_load_tokenizer():
    try:
        
        mock_load_tokenizer=mock.Mock(name="mock_load_tokenizer",return_value=tokenizer)
        dispo.load_tokenizer=mock_load_tokenizer
        assert dispo.load_tokenizer('model_name')==tokenizer
        log.log_info("Test Load tokenizer has passed")
    except Exception as e:
        log.log_error("Error in Test load tokenizer.. "+str(e))

#Check if we are able to load data collator        
def test_load_data_collator():
    try:
        data_collator = DataCollatorWithPadding(tokenizer=tokenizer)
        mock_setup_collator=mock.Mock(name="mock_load_datacollator",return_value=data_collator)
        dispo.load_data_collator=mock_setup_collator
        assert dispo.load_data_collator()==data_collator
        log.log_info("Test for loading data collator has passed")
    except Exception as e:
        log.log_error("Error in loading data collator.."+str(e))
#Checking if we are able to load DOO model     
def test_load_model():
    
    try:
       
        mock_load_model=mock.Mock(name="mock_load_model",return_value=dispo_model)
        dispo.load_model=mock_load_model
        assert dispo.load_model('model_name',3)==dispo_model
        log.log_info("Test Load Model has passed")
    except Exception as e:
        log.log_error("Error in loading model .."+str(e))
        
        
def preprocess_function(data, col_name1="Disposition"):
        '''Converts text into embeddings'''
        return tokenizer(data[col_name1], truncation=True)

#Check if we are able to tokenize the Disposition data      
def test_create_dataset_frm_data():
    try:
        data=Dataset.from_pandas(sample_data)
        tokenized_dataset= data.map(preprocess_function, batched=True)
        mock_get_tokenized_data=mock.Mock(name="mock_get_tokeized_data",return_value=tokenized_dataset)
        dispo.create_dataset_frm_data=mock_get_tokenized_data
        
        assert dispo.create_dataset_frm_data(sample_data)==tokenized_dataset
        log.log_info("Test Get tokenized data has Passed")
    except Exception as e:
        log.log_error("Error in get tokenized data test.."+str(e))
 #Check if we are able to split the data into training,test and validation data       
def test_train_test_eval_split():
    
    try:
        data=Dataset.from_pandas(sample_data)
        tokenized_dataset= data.map(preprocess_function, batched=True)
        split_data=tokenized_dataset.train_test_split(0.2,0.8)
        val_data=split_data["train"].train_test_split(0.2,0.8)
        mock_train_test_split=mock.Mock(name="mock_train_test_split",return_value=val_data)
        dispo.train_test_eval_split=mock_train_test_split
        train_dt,test_dt=dispo.train_test_eval_split(tokenized_dataset,0.7,0.2,0.1)
        assert test_dt!=None
        log.log_info("Test the training and validation data passed")
    except Exception as e:
        log.log_error("Error in test the training and validation split ..."+str(e))
        
#Check if we are able to load the trainer        
def test_load_trainer():
    try:
        trainer = Trainer(
            model=dispo_model,
            tokenizer=tokenizer)
        mock_load_trainer=mock.Mock("mock_load_trainer",return_value=trainer)
        dispo.load_trainer=mock_load_trainer
        assert dispo.load_trainer()==trainer
        log.log_info("Test load trainer has passed")
    except Exception as e:
        log.log_error("Error in loading trainer.."+str(e))
#Check if we are able to create a confusion matrix with predicted Disposition classification data         
# def test_confusion_matrix():  - TEMP COMMENTING TO TEST UNIT CASES INTEGRATON 
#     try:
#         performance=PerformanceEval()
#         cm=performance.get_confusion_matrix(sample_data["Dispo_Category"],sample_data["Prediction"])
#         assert len(cm)!=0
#         log.log_info("test confusion matrix passed")
#     except Exception as e:
#         log.log_error("error in confusion matrix test "+str(e))

# #Check if we are able to get performance metrics with predicted Disposition classification data
# def test_get_performance_metrics():  - TEMP COMMENTING TO TEST UNIT CASES INTEGRATON 
#     try:
#         performance=PerformanceEval()
#         accuracy_metrics=performance.get_performance_metrics(sample_data["Dispo_Category"],sample_data["Prediction"])
#         assert len(accuracy_metrics)!=0
#         log.log_info("Test accuracy metrics passed")
#     except Exception as e:
#         log.log_error("Error in the test accuracy metrics.."+str(e))
        
