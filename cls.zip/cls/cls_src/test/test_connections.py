import pandas as pd
from cls_src.utils.logger import Framework_Logger

logger=Framework_Logger()


def test_gcs_connection():
    try:
        filename = "payload.xlsx"
        file_path = "gs://bkt-d-hrgp-data-us/ds_zaha_hrg2/test_gcs_connection/"
        df = pd.read_excel(file_path+filename)
        assert df.empty==False
        logger.log_info(" Test case Passed for function test_gcs_connection..")
    except Exception as e:
        logger.log_error(" Test case failed for function test_gcs_connection.."+str(e))


if __name__ == "__main__":
    test_gcs_connection()