from cls_src.utils.pymongo_db_connector import PyMongoConnector
import pandas as pd
from cls_src.performance.performance_report import *
from cls_src.utils.read_config import GetConfigAttr
from cls_src.utils.logger import *
import math

class VisualizationTransformation:

    def __init__(self):
        self.eval=PerformanceEval()
        self.mongodbconnector=PyMongoConnector()
        self.confg=GetConfigAttr()
        self.logger=Framework_Logger()



    def preprocess_data(self,data_df):
        # Standardization of values according to the model targets
        data_df["severity"].replace({"Misdemeanor (or equivalent)":"Misdemeanor",
                                     "Felony (or equivalent)":"Felony",
                                     "Felony Class Go":"Felony",
                                     "Criminal offense":"Felony",
                                     "Non-criminal offense":"Non-Criminal Offense",
                                     "Class B Misdemeanor":"Misdemeanor",
                                     'Misdemeanor - Class: A - Category: Drug':"Misdemeanor",
                                     'MINOR MISDEMEANOR':"Misdemeanor",
                                     'UNCLASSIFIED MISDEMEANOR':"Misdemeanor",
                                     'Class A Misdemeanor':"Misdemeanor",
                                     "First Degree Felony":"Felony",
                                     'Third Degree Felony':"Felony",
                                     'INFRACTION':"Non-Criminal Offense",
                                     'Class C Misdemeanor':"Misdemeanor",
                                     'Misdemeanor Traffic':"Misdemeanor",
                                     "State Jail Felony":"Felony",
                                     "MISDEMEANOR":"Misdemeanor",
                                     "MISDEMEANOR SECOND DEGREE":"Misdemeanor",
                                     "Traffic":"Misdemeanor",
                                     "MISDEMEANOR FIRST DEGREE":"Misdemeanor",
                                     "FELONY SECOND DEGREE":"Felony",
                                     "FELONY THIRD DEGREE":"Felony",
                                      "FELONY FIRST DEGREE":"Felony",
                                     "Minor Misdemeanor":"Misdemeanor",
                                     "(2) Misdemeanor 2Nd Degree":"Misdemeanor",
                                     "(1) Misdemeanor 1St Degree":"Misdemeanor",
                                    "Second Degree Felony":"Felony",
                                    "MISDEMEANOR FOURTH DEGREE":"Misdemeanor",
                         "FELONY":"Felony",
                         "Misdemeanor First Degree":"Misdemeanor",
                         "SIMPLE MISDEMEANOR":"Misdemeanor",
                         "FELONY FOURTH DEGREE":"Felony",
                         "Second Degree Misdemeanor":"Misdemeanor",
                         "Felony 2nd Degree":"Felony",
                         "CLASS A MISDEMEANOR":"Misdemeanor",
                          "FELONY FIFTH DEGREE":"Felony",
                          "Misdemeanor - Degree - 1":"Misdemeanor",
                          'Misdemeanor Degree 3':"Misdemeanor",
                          "1st Degree Felony":"Felony",
                          "M":"Misdemeanor",
                          'Felony - Class: C - Category: Property':"Felony",
                          "Infraction":"Non-Criminal Offense",
                          "Misdemeanor Class B":"Misdemeanor",
                          "Felony Punishable By Life":"Felony"
                         },inplace=True)
        data_df["disposition_category"].replace({"Active Deferral":"Deferral","Completed Deferral":"Deferral"},inplace=True)
        return data_df

    def transform_data_classification_agg_metrics(self,data_df):
        '''Takes Dataframe as input and computes aggregated metrics, returns the results as dataframe'''
        self.logger.log_info("Visualization Transformation: Computation of CLS Aggregated Data Metrics Initialized")
        performance_list=[]
        # Disposition
        dispo_obj=dict()
        dispo_obj["Model Name"]="Disposition"
        dispo_obj["Total Records"]=data_df.shape[0]
        data_df["disposition_category"]=data_df["disposition_category"].replace(r'^\s*$',np.nan,regex=True)
        data_df[~(data_df["disposition_category"].isna())|(data_df["disposition_category"]!="")]
        dispo_obj["Missing Researcher Result Count"]=data_df["disposition_category"].isna().sum()
        data_df=data_df[~(data_df["disposition_category"].isna())]
        data_df.reset_index(inplace=True,drop=True)
        # Getting Aggregated Metrics For Disposition
        dispo_obj_peformance=self.eval.get_model_metrics(data_df["disposition_category"],data_df["disposition_prediction"])
        dispo_obj.update(self.flatten_json(dispo_obj_peformance))
        performance_list.append(dispo_obj)
        # DOO
        doo_obj=dict()
        doo_obj["Model Name"]="DOO"
        data_df["severity"]=data_df["severity"].replace(r'^\s*$',np.nan,regex=True)
        doo_obj["Missing Researcher Result Count"]=data_df["severity"].isna().sum()
        valid_doo_df=data_df[~(data_df["missing_state_info"]==True)]
        valid_doo_df=valid_doo_df[~(valid_doo_df["severity"].isna())]
        doo_obj["Total Records"]=valid_doo_df.shape[0]
        # Getting Aggregated Metrics For DOO
        doo_obj_peformance=self.eval.get_model_metrics(valid_doo_df["severity"],valid_doo_df["doo_prediction"])
        doo_obj.update(self.flatten_json(doo_obj_peformance))
        performance_list.append(doo_obj)
        cls_perf_data=pd.DataFrame(performance_list)
        # Formatting Column Names
        cls_perf_data.columns=cls_perf_data.columns.to_series().apply(lambda x:x.replace("_micro-average","")).tolist()
        cls_perf_data=cls_perf_data[["Model Name","accuracy","f1","precision","recall","false_positive_rate","true_negative_rate","Total Records","Missing Researcher Result Count"]]
        cols=cls_perf_data.columns.str.replace("_"," ")
        cols=cols.str.title()
        cls_perf_data.columns=cols
        cls_perf_data["% of Correct Classification"]=cls_perf_data.apply(lambda x:round(((x["Accuracy"]*x["Total Records"])/x["Total Records"])*100,2),axis=1)
        cls_perf_data["% of Incorrect Classification"]=cls_perf_data.apply(lambda x:round(100-x["% of Correct Classification"],2),axis=1)
        cls_perf_data["# of Correct Classification"]=cls_perf_data.apply(lambda x:str(int(x["Accuracy"]*x["Total Records"]))+"/"+str(x["Total Records"])+" "+str(x["% of Correct Classification"])+"%",axis=1)
        cls_perf_data["# of Incorrect Classification"]=cls_perf_data.apply(lambda x:str(x["Total Records"]-(int(x["Accuracy"]*x["Total Records"])))+"/"+str(x["Total Records"])+" "+str(x["% of Incorrect Classification"])+"%",axis=1)
        raw_data=self.mongodbconnector.read_all_dict("criminal_data_raw")
        cls_perf_data["# of Records Received"]=len(raw_data)
        cls_perf_data.rename(columns={"Total Records":"# of Valid Targets Records"}, inplace=True)
        cls_perf_data["Accuracy"]= cls_perf_data["Accuracy"].apply(lambda x:self.truncate(x,3))
        # Writing into the dashboard files
        cls_perf_data.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","cls_agg_metrics"),index=False)
        return cls_perf_data
    

    def transform_data_classification_predictions(self,data):
        '''Takes DataFrame as input with the DOO and Dispo Predictions and Formats the values needed for Visualization'''
        data["disposition_literal"]=data["disposition_literal"].str.strip()
        data["offense_literal"]=data["offense_literal"].str.strip()
        # DOO
        doo_df=data[["request_id","reg_id","orderitemid","criminal_case_number","ingested_date","state",'offense_literal',
                         "severity","doo_prediction","doo_score","missing_state_info"]]
        doo_df["severity"]=doo_df["severity"].replace(r'^\s*$',np.nan,regex=True)
        doo_df=doo_df[~(doo_df["severity"].isna())]
        doo_df=doo_df[(doo_df["severity"]=="Misdemeanor") | (doo_df["severity"]=="Felony") | (doo_df["severity"]=="Non-Criminal Offense")]
        doo_df=doo_df[(doo_df["missing_state_info"]!=True)]
        doo_df["Model Name"]="DOO"
        doo_df["Match"]=doo_df.apply(lambda x:True if(x["severity"]==x["doo_prediction"]) else False, axis=1)
        doo_df.rename(columns={"severity":"Researcher Values","doo_prediction":"Model Prediction","doo_score":"Prediction Score"},inplace=True)
        # Disposition
        dispo_df=data[["request_id","reg_id","orderitemid","criminal_case_number","ingested_date",'disposition_literal',"state", 'disposition_category','disposition_prediction',
        'disposition_score']]
        dispo_df["disposition_category"]=dispo_df["disposition_category"].replace(r'^\s*$',np.nan,regex=True)
        dispo_df=dispo_df[~(dispo_df["disposition_category"].isna())]
        dispo_df.reset_index(inplace=True,drop=True)
        dispo_df["Model Name"]="Disposition"
        dispo_df["Match"]=dispo_df.apply(lambda x:True if(x["disposition_category"]==x["disposition_prediction"]) else False, axis=1)
        dispo_df.rename(columns={"disposition_category":"Researcher Values","disposition_prediction":"Model Prediction","disposition_score":"Prediction Score"},inplace=True)
        doo_df.reset_index(inplace=True,drop=True)
        dispo_df.reset_index(inplace=True,drop=True)
        # Adding Serial No to keep the rows unique in the dashboard table
        doo_df["Serial No"]=doo_df.index.values
        dispo_df["Serial No"]=dispo_df.index.values
        # Merging and Standardization of DataFrame
        predictions=pd.concat([doo_df,dispo_df],ignore_index=True)
        predictions.rename(columns={"ingested_date":"Date"},inplace=True)
        predictions["Date"]=predictions["Date"].apply(lambda x:datetime.strptime(x, '%d-%m-%Y'))
        cols=predictions.columns.str.replace("_"," ")
        cols=cols.str.title()
        predictions.columns=cols
        # Rounding-Off Prediction Score
        predictions["Prediction Score"]=predictions["Prediction Score"].round(2)
        # Writing into dashboard files
        predictions.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","cls_predictions"),index=False)
        return predictions

    def transform_data_classification_metrics(self,data_df):
        '''Takes DataFrame as input and returns a dataframe with the datewise metrics of Disposition and DOO Model'''
        self.logger.log_info("Visualization Transformation: Computation of CLS Metrics Initialized")
        performance_df=pd.DataFrame()
        dates=data_df["ingested_date"].unique()
        # Datawise Metrics Calculation
        for date in dates:
            df=data_df[data_df["ingested_date"]==date]
            df=df[~(df["disposition_category"].isna())]
            df.reset_index(inplace=True,drop=True)
            dispo_obj_peformance=self.eval.get_performance_metrics(df["disposition_category"],df["disposition_prediction"])
            dispo_obj_peformance["Date"]=date
            dispo_obj_peformance["Model Name"]="Disposition"
            dispo_obj_peformance["Model Version"]="1.0"
            dispo_obj_peformance["Total Records"]=df.shape[0]
            dispo_obj_peformance.reset_index(inplace=True)
            performance_df=pd.concat([performance_df,dispo_obj_peformance],ignore_index=True)
            # Taking rows which has state information for DOO Model
            valid_doo_df=df[~(df["missing_state_info"]==True)]
            if(valid_doo_df.shape[0]>0):
                doo_obj_peformance=self.eval.get_performance_metrics(valid_doo_df["severity"],valid_doo_df["doo_prediction"])
                doo_obj_peformance["Date"]=date
                doo_obj_peformance["Model Name"]="DOO"
                doo_obj_peformance["Model Version"]="1.0"
                doo_obj_peformance["Total Records"]=valid_doo_df.shape[0]
                doo_obj_peformance.reset_index(inplace=True)
                performance_df=pd.concat([performance_df,doo_obj_peformance],ignore_index=True)
        # Standardizing Column Names
        performance_df.rename(columns={"index":"Metric Name","micro-average":"Score"},inplace=True)
        performance_df=performance_df[['Date', 'Model Name', 'Model Version', 'Total Records',"Metric Name",'Conviction', 'Deferral', 'Non-Conviction', 'Pending', 'Felony','Misdemeanor', 'Non-Criminal Offense','Score']]
        # Date Format
        performance_df["Date"]=performance_df["Date"].apply(lambda x:datetime.strptime(x, '%d-%m-%Y'))
        # Rounding-off to 2 decimal places
        performance_df=performance_df.round(2)
        # Standardizing Column Names
        cols=performance_df.columns.str.replace("_"," ")
        cols=cols.str.title()
        performance_df.columns=cols
        # Standardizing Names of Metrics
        performance_df["Metric Name"]=performance_df["Metric Name"].apply(lambda x:x.replace("_"," "))
        performance_df["Metric Name"]=performance_df["Metric Name"].apply(lambda x:x.title())
        # Writing into dashboard files
        performance_df.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","cls_metrics"),index=False)
        return performance_df


    def flatten_json(self,y):
        '''Flattens the nested json'''
        out = {}

        def flatten(x, name=''):
            if type(x) is dict:
                for a in x:
                    flatten(x[a], name + a + '_')
            elif type(x) is list:
                i = 0
                for a in x:
                    flatten(a, name + str(i) + '_')
                    i += 1
            else:
                out[name[:-1]] = x

        flatten(y)
        return out
    
    def truncate(self,f, n):
        '''Trancate the decimal places after n numbers'''
        return math.floor(f * 10 ** n) / 10 ** n

    def get_datewise_data_availability(self,data,typ):
        '''Takes dataframe and type="crim/app" as input and computes datawise attribute availability and returns results as dataframe '''
        dates=data["ingested_date"].unique()
        rec_list=[]
        da_df=pd.DataFrame()
        for date in dates:
            df=data[data["ingested_date"]==date]
            if(df.shape[0]>0):
                temp=dict()
                na_count=df.isna().sum().to_dict()
                crim_obj={typ+"_"+k: v for k, v in na_count.items()}
                temp.update(crim_obj)
                temp["ingested_date"]=date
                temp["total_record_count"]=df.shape[0]
            else:
                temp["ingested_date"]=date
                temp["total_record_count"]=df.shape[0]
            rec_list.append(temp)
        if(len(rec_list)>0):
            da_df=pd.DataFrame(rec_list)
        return da_df
    
    def transform_record_counts_map(self):
        '''Reads Data from MongoDB and compute the Meta Informations & data for Maps'''
        cls_data=self.mongodbconnector.read_all(self.confg.get_io_config_attribute_by_section("mongoDB","collection_classification_prediction_results"))
#         raw_data=mongodbconnector.read_all_dict(confg.get_io_config_attribute_by_section("mongoDB","collection_criminal_data_raw"))
        raw = self.mongodbconnector.crimdb[self.confg.get_io_config_attribute_by_section("mongoDB","collection_criminal_data_raw")]
        temp=dict()
        raw_cursor=raw.aggregate( [
       { '$count': "total_records" }
    ])
        total_rec=list(raw_cursor)
        temp["# of Request Processed"]=total_rec[0]["total_records"]
        raw_cursor=raw.find({ "decrypted_data.court_response.target_records": { "$exists": "true", "$ne": [] } })
        sub_req_df=list(raw_cursor)
        temp["# of Sub-Request Imported"]=len(sub_req_df)
#         temp["# of Request Processed"]-sum(map(lambda x : 
#                                                                                  len(x["decrypted_data"]["court_response"]["target_records"])==0, raw_data))
        temp["# of Court Records"]=cls_data.shape[0]
        temp["Missing State Info"]=cls_data[cls_data["missing_state_info"]==True].shape[0]
        cls_data["nature_of_offense"]=cls_data["nature_of_offense"].str.strip()
        cls_data["nature_of_offense"]=cls_data["nature_of_offense"].replace('', np.nan, regex=True)
        temp["Missing NOO Attribute"]=cls_data[cls_data["nature_of_offense"].isna()].shape[0]
        temp["Court Records with NOO"]=temp["# of Court Records"]-temp["Missing NOO Attribute"]
#         raw_data_df=pd.json_normalize(raw_data)
        
        raw_cursor=raw.aggregate([
            {"$group" : {'_id':"$cls_processing_status", 'count':{'$sum':1}}}
        ])
        rec_counts=list(raw_cursor)
        temp["Classification Processed"]=[rec['count'] for rec in rec_counts if rec["_id"]==1][0]
        raw_cursor=raw.aggregate([
            {"$group" : {'_id':"$idr_processing_status", 'count':{'$sum':1}}}
        ])
        rec_counts=list(raw_cursor)
        temp["ID Resolution Processed"]=[rec['count'] for rec in rec_counts if rec["_id"]==1][0]
        res=pd.DataFrame([temp])
        # For Chloropeth Maps
        geo_cursor=raw.aggregate([
                             { '$group': { '_id': {'zip' : '$decrypted_data.applicant_data.address.current_address.zip_code','state':'$decrypted_data.applicant_data.address.current_address.state'}, 'count':{'$sum':1} } },
            {'$project' : {'zip' : '$_id.zip', 'state' : '$_id.state', 'count' : '$count', '_id' : 0}}
                           ])
        geo_list=list(geo_cursor)
        geo_df=pd.DataFrame(geo_list)
        geo_df.rename(columns={"zip":"ZIP","state":"State","count":"Frequency"}, inplace=True)
        # Wirting into dashboard files
        geo_df.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","chloropeth"),index=False)
        res.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","payload_info"),index=False)
        return geo_df,res

    # def transform_data_chloropeth(self):
    #     '''Reads Data from MongoDB and filter '''
    #     raw_data=self.mongodbconnector.read_all_dict("criminal_data_raw")
    #     data=pd.json_normalize(raw_data)
    #     data=data[['ingested_date', 'gcs_created_date','decrypted_data.applicant_data.address.current_address.state',
    #            'decrypted_data.applicant_data.address.current_address.zip_code','decrypted_data.court_response.request_id']]
    #     data.rename(columns={'ingested_date':"Date", 'gcs_created_date':"GCS Date",'decrypted_data.applicant_data.address.current_address.state':"State",
    #            'decrypted_data.applicant_data.address.current_address.zip_code':"ZIP",'decrypted_data.court_response.request_id':"Request ID"},inplace=True)
    #     data.to_csv("gs://bkt-stg-hrgp-ds-us/dashboard_files/meta_info/chloropeth.csv",index=False)
    #     return data

    def transform_data_meta_dashboard(self):
        '''Fetches the valid and invalid json counts
        Computes datawise attribute availability of the data'''
        #count of valid & Invalid json
        data=self.mongodbconnector.read_all(self.confg.get_io_config_attribute_by_section("mongoDB","collection_crim_payload_metadata"))
        data["ingestion_date"]=data["ingestion_date"].apply(lambda x:datetime.strptime(x, '%d-%m-%Y'))
        data.columns=['id', 'Date', 'Total Request Count', '# of Valid Requests','# of Invalid Requests', 'MongoDB Created Date']
        data.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","valid_records"),index=False)


         #percentage of missing data
        raw = self.mongodbconnector.crimdb[self.confg.get_io_config_attribute_by_section("mongoDB","collection_criminal_data_raw")]
        raw_cursor=raw.distinct("ingested_date")
        raw_dates=list(raw_cursor)
        processed = self.mongodbconnector.crimdb["viz_percentage_missing_values"]
        processed_cursor=processed.distinct("ingested_date")
        processed_dates=list(processed_cursor)
        processed_dates=pd.Series(processed_dates)
        processed_dates=processed_dates.apply(lambda x:datetime.strptime(x, '%Y-%m-%d'))
        processed_dates=processed_dates.apply(lambda x:x.strftime("%d-%m-%Y"))
        processed_dates=processed_dates.tolist()
        dates=set(raw_dates) ^ set(processed_dates)
        crim_df=pd.DataFrame()
        applicant_df=pd.DataFrame()
        da=pd.DataFrame()
        for date in dates:
            try:
                raw_data=self.mongodbconnector.filter_records_dict(self.confg.get_io_config_attribute_by_section("mongoDB","collection_criminal_data_raw"),"ingested_date",date)
                df=pd.json_normalize(raw_data,record_path=["decrypted_data","court_response","source_records"],meta=["_id","id","ingested_date",["decrypted_data","applicant_data","request_id"],["decrypted_data","applicant_data","reg_id"],["decrypted_data","applicant_data","order_service_id"],
                                                                                                    ["decrypted_data","applicant_data","order_service_data_source_id"]])
                df.replace("",np.nan, inplace=True)
                df.rename(columns={"address.address_line1":"address","address.zip_code":"zip"}, inplace=True)
                crim_df=pd.concat([crim_df,df],ignore_index=True)

                app_df=pd.json_normalize(raw_data)
                app_df=app_df[['decrypted_data.applicant_data.first_name',
                'decrypted_data.applicant_data.middle_name', 'decrypted_data.applicant_data.last_name',
                'decrypted_data.applicant_data.dob', 'decrypted_data.applicant_data.address.current_address.address_line1',
                               'decrypted_data.applicant_data.address.current_address.address_line2',
                       'decrypted_data.applicant_data.address.current_address.city',
                       'decrypted_data.applicant_data.address.current_address.county',
                       'decrypted_data.applicant_data.address.current_address.state',
                       'decrypted_data.applicant_data.address.current_address.zip_code','decrypted_data.applicant_data.request_id', 'decrypted_data.applicant_data.reg_id',"ingested_date"]]
                app_df.drop_duplicates(inplace=True)
                # Renaming Columns
                app_df.rename(columns={"decrypted_data.applicant_data.first_name":"first_name","decrypted_data.applicant_data.middle_name":"middle_name","decrypted_data.applicant_data.last_name":"last_name",
                                "decrypted_data.applicant_data.dob":"dob","decrypted_data.applicant_data.address.current_address.address_line1":"address",
                                       "decrypted_data.applicant_data.address.current_address.zip_code":"zip", 'decrypted_data.applicant_data.address.current_address.city':"city",
                                       'decrypted_data.applicant_data.address.current_address.county':"county",'decrypted_data.applicant_data.address.current_address.state':"state",
                                "decrypted_data.applicant_data.request_id":"request_id","decrypted_data.applicant_data.reg_id":"reg_id"},inplace=True)
                applicant_df=pd.concat([applicant_df,app_df],ignore_index=True)
            except:
                print("exception",date)
        if((crim_df.shape[0]>0) & (applicant_df.shape[0]>0)):
            # Getting Datewise data availability for each attribute from the subset columns
            crim=self.get_datewise_data_availability(crim_df,"crim")

            # Getting Datewise data availability for each attribute from the subset columns
            app=self.get_datewise_data_availability(applicant_df,"app")
             # subsetting dataframe with the columns needed
            if("crim_address.city" not in crim):
                crim["crim_address.city"]=crim["total_record_count"]
            if("crim_address.county" not in crim):
                crim["crim_address.county"]=crim["total_record_count"]
            if("crim_address.state" not in crim):
                crim["crim_address.state"]=crim["total_record_count"]
            if("crim_zip" not in crim):
                crim["crim_zip"]=crim["total_record_count"]
            if("crim_address.address_line2" not in crim):
                crim["crim_address.address_line2"]=crim["total_record_count"]
            crim=crim[['crim_first_name', 'crim_middle_name', 'crim_last_name', 'crim_dob', 'crim_county', 'crim_state',"crim_address","crim_suppression_status",
                       'crim_address.address_line2',
                   'crim_address.city', 'crim_address.county', 'crim_address.state',
                   'crim_zip','ingested_date','total_record_count']]
            crim.rename(columns={"crim_address.city":"crim_city","crim_address.county":"crim_address_county","crim_address.state":"crim_address_state"},inplace=True)
            # print(crim.columns)
            # Converting into percentage format - Criminal Attributes
            crim["crim_first_name"]=(crim["crim_first_name"]/crim["total_record_count"])*100
            crim["crim_middle_name"]=(crim["crim_middle_name"]/crim["total_record_count"])*100
            crim["crim_last_name"]=(crim["crim_last_name"]/crim["total_record_count"])*100
            crim["crim_dob"]=(crim["crim_dob"]/crim["total_record_count"])*100
            crim["crim_county"]=(crim["crim_county"]/crim["total_record_count"])*100
            crim["crim_state"]=(crim["crim_state"]/crim["total_record_count"])*100
            crim["crim_zip"]=(crim["crim_zip"]/crim["total_record_count"])*100
            crim["crim_address"]=(crim["crim_address"]/crim["total_record_count"])*100
            crim["crim_city"]=(crim["crim_city"]/crim["total_record_count"])*100

            crim["crim_suppression_status"]=(crim["crim_suppression_status"]/crim["total_record_count"])*100
            # Converting into percentage format - Applicant Attributes
            app["app_first_name"]=(app["app_first_name"]/app["total_record_count"])*100
            app["app_middle_name"]=(app["app_middle_name"]/app["total_record_count"])*100
            app["app_last_name"]=(app["app_last_name"]/app["total_record_count"])*100
            app["app_dob"]=(app["app_dob"]/app["total_record_count"])*100
            app["app_address"]=(app["app_address"]/app["total_record_count"])*100
            app["app_county"]=(app["app_county"]/app["total_record_count"])*100
            app["app_city"]=(app["app_city"]/app["total_record_count"])*100
            app["app_state"]=(app["app_state"]/app["total_record_count"])*100
            app["app_zip"]=(app["app_zip"]/app["total_record_count"])*100
            # Merging DF's on dates
            da=pd.merge(app, crim, on='ingested_date', how='outer')
            # Renaming Columns
            da["ingested_date"]=da["ingested_date"].apply(lambda x:datetime.strptime(x, '%d-%m-%Y'))
            da.rename(columns={"crim_suppression_status":"Suppression Status","app_first_name":"First Name","app_middle_name":"Middle Name","app_last_name":"Last Name","app_dob":"DOB",
            "app_address":"Street","app_zip":"ZIP","app_city":"City","app_county":"County","app_state":"State",
                               "crim_first_name":"First Name-R","crim_middle_name":"Middle Name-R",
                              "crim_last_name":"Last Name-R","crim_dob":"DOB-R","crim_county":"County-R","crim_state":"State-R","crim_address":"Street-R",
                              "crim_zip":"ZIP-R",},inplace=True)
            da["ingested_date"]=da["ingested_date"].astype("str")
            self.mongodbconnector.write_records_from_df(da,"viz_percentage_missing_values")
            missing_data=self.mongodbconnector.read_all("viz_percentage_missing_values")
            missing_data.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","percentage_missing_values"),index=False)
        return data,da
    
    def transform_noo(self,data_df):
        '''Take Preprocessed DF to transform data needed for NOO dashbord'''
        noo_df=data_df[["request_id","reg_id","orderitemid","criminal_case_number",'ingested_date', 'offense_literal','nature_of_offense','noo_prediction', 'noo_score']]
        noo_df["nature_of_offense"]=noo_df["nature_of_offense"].str.strip()
        noo_df.columns=["Request ID","Reg ID","Order Item ID","Criminal CaseNumber","Date","Offense Literal","Researcher Values","Model Prediction","Prediction Score"]
        noo_df["Date"]=noo_df["Date"].apply(lambda x:datetime.strptime(x, '%d-%m-%Y'))
        noo_df["Prediction Score"]=noo_df["Prediction Score"].round(2)
        # Writing into Dashboard files
        noo_df.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","noo_df"),index=False)
        return noo_df

    def doo_juridiction_metrics(self,data_df):
        data_df["severity"]=data_df["severity"].replace(r'^\s*$',np.nan,regex=True)
        data_df=data_df[~(data_df["severity"].isna())]
        data_df=data_df[data_df["missing_state_info"]!=True]
        state_list=data_df["state"].unique()
        performance_list=[]
        for state in state_list:
            df=data_df[data_df["state"]==state]
            doo_obj=dict()
            doo_obj["State"]=state
            doo_obj["Count of Records"]=df.shape[0]
            doo_obj["Count of Correct Prediction"]=df[df["severity"]==df["doo_prediction"]].shape[0]
            doo_obj["Count of Incorrect Prediction"]=df[df["severity"]!=df["doo_prediction"]].shape[0]
            doo_obj_peformance=self.eval.get_model_metrics(df["severity"],df["doo_prediction"])
            doo_obj.update(self.flatten_json(doo_obj_peformance))
            performance_list.append(doo_obj)
        performance_df=pd.DataFrame(performance_list)
        performance_df.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","doo_jurisdiction"),index=False)
        return performance_df

    def compare_lookup_table(self):
        collection = self.mongodbconnector.crimdb[self.confg.get_io_config_attribute_by_section("mongoDB","collection_classification_prediction_results")]
        cursor = collection.find({"suppression_engine_results.se_degree_of_offense": {"$nin": [np.nan]},"suppression_engine_results.se_disposition_category": {"$nin": [np.nan]},})
        doo=list(cursor)
        data_df=pd.json_normalize(doo)
        data_df=self.preprocess_data(data_df)
        data_df.rename(columns={"suppression_engine_results.se_degree_of_offense":"se_degree_of_offense",
                       "suppression_engine_results.se_disposition_category":"se_disposition_category",
                       "suppression_engine_results.se_nature_of_offense":"se_nature_of_offense"}, inplace=True)
        data_df["se_degree_of_offense"].replace({"Misdemeanor (or equivalent)":"Misdemeanor",
                                     "Felony (or equivalent)":"Felony"}, inplace=True)
        data_df["se_disposition_category"].replace({"Active Deferral":"Deferral","Completed Deferral":"Deferral"},inplace=True)
        data_df=data_df[(data_df["severity"]=="Misdemeanor") | (data_df["severity"]=="Felony") |(data_df["severity"]=="Non-Criminal Offense")]
        data_df=data_df[["_id",'orderitemid', 'ingested_date', 'offense_literal','degree_of_offense', 'severity', 'disposition_literal', 'disposition_category',
       'criminal_case_number', 'state', 'se_degree_of_offense','se_disposition_category','disposition_prediction', 'doo_prediction']]
        data_df.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","compare_lookup"),index=False)
        return data_df