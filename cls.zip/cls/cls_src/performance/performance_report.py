# Code Files to compute the metrics, identify misclassified cases. (Report and analysis)  
# Code Files to compute the metrics, identify misclassified cases. (Report and analysis)
import pandas as pd
import numpy as np
from sklearn.metrics import confusion_matrix
import disarray
from cls_src.utils.pymongo_db_connector import PyMongoConnector
import pandas as pd
from cls_src.utils.logger import *
from cls_src.utils.read_config import GetConfigAttr
import traceback
import disarray

from datetime import datetime

class PerformanceEval:
    '''
        In the PerformanceEval class  , we compute the metrics , identify mismatch or misclassified cases in the prediction of NOO , DOO and Disposition data.


    '''

    def __init__(self):
        '''
        Constructors of  PerformanceEval class

        '''
        self.logger=Framework_Logger()
        self.config=GetConfigAttr()
        self.mongodbconnector=PyMongoConnector()

    # Get confusion matric for predicted data
    def get_confusion_matrix(self,actual,pred):
        '''
           Takes Actual and Predicted Values and returns Confusion Matrix as DataFrame

           Parameters  :
              actual(String) : actual target variable
              pred(String)   : Predicted target variable

           Returns   :
              cm_df(DataFrame)   : confusion matrix returned as a Dataframe

        '''
        unique_label = np.unique([actual, pred])
        cm_df = pd.DataFrame(
            confusion_matrix(actual, pred, labels=unique_label), 
            index=['Actual:{:}'.format(x) for x in unique_label], 
            columns=['Predictions:{:}'.format(x) for x in unique_label]
        )
        self.logger.log_info("Classification: Performance Eval :Confusion matrix for pred data  :"+str(cm_df.shape))
        return cm_df

    # Get performance metrics for the prediction data
    def get_performance_metrics(self,actual,pred):
        '''
            Takes Actual and Predicted Values and returns classification metrics as DataFrame

            Parameters  :
              actual(String) : actual target variable
              pred(String)   : Predicted target variable

           Returns   :
              cm_df(DataFrame)   :  classification metrics returned as a Dataframe

            
        '''
        unique_label = np.unique([actual, pred])
        cm_df = pd.DataFrame(
            confusion_matrix(actual, pred, labels=unique_label), 
            index=[x for x in unique_label], 
            columns=[x for x in unique_label]
        )
        self.logger.log_info("Classification: Performance Eval :performance_metrics for pred data  :"+str(cm_df.shape))
        return cm_df.da.export_metrics()
    
    #   Get Disposition false or mis matched prediction 
    def get_dispo_mismatch(self,data):
        '''
            Returns Disposition Mis-classifications

            Parameters  :
               data(Dataframe)  : Dataframe containing dispositon predicted data 

            Returns     :
               data(DataFrame)  : Dataframe containing the false disposition category predictions 
            
        '''
        self.logger.log_info("Classification: Performance Eval : Mismatch records for Disposition prediction")
        return data[data["disposition_category"]!=data["disposition_prediction"]]

    #   Get DOO false or mis matched prediction  
    def get_doo_mismatch(self,data):
        '''
            Returns DOO Mis-classifications

            Parameters  :
               data(Dataframe)  : Dataframe containing DOO predicted data 

            Returns     :
               data(DataFrame)  : Dataframe containing the false DOO severity predictions 
            
        '''
        self.logger.log_info("Classification: Performance Eval : Mismatch records for DOO prediction")
        return data[data["severity"]!=data["doo_prediction"]]

    #   Get NOO false or mis matched prediction    
    def get_noo_mismatch(self,data):
        '''
            Returns NOO Mis-classifications

            Parameters  :
               data(Dataframe)  : Dataframe containing NOO predicted data 

            Returns     :
               data(DataFrame)  : Dataframe containing the false NOO category predictions 
            
        '''
        self.logger.log_info("Classification: Performance Eval : Mismatch records for NOO prediction")
        return data[data["nature_of_offense"]!=data["noo_prediction"]]

    #   Fetch records from the classification prediction results 
    def get_data_for_performance_computation(self):
        '''
           Fetch records from the classification prediction results from Mongodb collection

           Parameters : None

           Returns    :
                 data(Dataframe)  : Dataframe containing the classification prediction results

        '''
        self.logger.log_info("Classification: Performance Eval :Fetching records from the classification prediction results")
        data=[]
        try:
            data=self.mongodbconnector.filter_records_dict(self.config.get_io_config_attribute_by_section("mongoDB","collection_classification_prediction_results"),"match_compute_status",0)
        except Exception as e:
            self.logger.log_error("Classification: Performance Eval :Error Occured in getting data for performance pipeline"+str(e))
        return data

    #  Store the model metrics in a dataframe
    def get_model_metrics(self,actual,pred):
        '''
            Store the model metrics in a dataframe i.e confusion matrix and performance metrics

             Parameters  :
              actual(String) : actual target variable
              pred(String)   : Predicted target variable

           Returns   :
              performance_metrics(DataFrame)   :  classification metrics and confusion matrix returned as a Dataframe

        '''
        cm=self.get_confusion_matrix(actual,pred).T.to_dict('series')
        for key in cm:
            cm[key]=cm[key].to_dict()
        performance_metrics=self.get_performance_metrics(actual,pred).T.to_dict('series')
        for key in performance_metrics:
            performance_metrics[key]=performance_metrics[key].to_dict()
        performance_metrics["confusion_matrix"]=cm
        # self.logger.log_info("Classification: Performance Eval :Performance metrics : "+str(performance_metrics.shape))
        return performance_metrics

    #  Store the mismatch status of NOO , DOO and Disposition predictions
    def store_mismatch_status(self,data,model_name):
        '''
            Store the mismatch status of NOO , DOO and Disposition predictions and the the mismatch status is written into Mongodb

            Parameters :
               Data(Dataframe)  :  Classification prediction results data

               model_name(String) : Specifies the model(DOO/NOO/Disposition)

            Returns   : None
               Mismatch status is written into Mongo db  collection - 'collection_classification_prediction_results'

        '''
        self.logger.log_info("Classification: Performance Eval :Writing mismatch records of "+ model_name +" into Mong db collection")
        all_ids=data["_id"].unique()
        mismatch_data=pd.DataFrame()
        if(model_name=="dispostion"):
            mismatch_data=self.get_dispo_mismatch(data)
        elif(model_name=="doo"):
            mismatch_data=self.get_doo_mismatch(data)
        elif(model_name=="noo"):
            mismatch_data=self.get_noo_mismatch(data)
        mismatch_ids=[]
        if(mismatch_data.shape[0]>0):
            mismatch_ids=mismatch_data["_id"].unique()
            mismatch_recs=[{model_name+"_match":"N"} for index in range(0,len(list(set(mismatch_ids))))]
            self.mongodbconnector.upsert_records(self.config.get_io_config_attribute_by_section("mongoDB","collection_classification_prediction_results"),list(set(mismatch_ids)),mismatch_recs)
        match_ids=[x for x in all_ids if x not in mismatch_ids]
        match_recs=[{model_name+"_match":"Y"} for index in range(0,len(list(set(match_ids))))]
        self.mongodbconnector.upsert_records(self.config.get_io_config_attribute_by_section("mongoDB","collection_classification_prediction_results"),list(set(match_ids)),match_recs)