# Degree of Offense Prediction Pipeline
from asyncio.log import logger
import pandas as pd
import numpy as np
from datasets import Dataset
from transformers import DataCollatorWithPadding
from transformers import  Trainer
import torch
from google.cloud import storage
import io
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.read_config import *
from scipy.special import softmax
import traceback
import pickle
from cls_src.training.degree_of_offense_training import DegreeOfOffenseModelTraining
import gcsfs

class OffenseDegreePrediction:

    ''' 
       In this class , prediction of degree of offense i.e target variable of the Degree of Offense .
       we predict the degree_of_offense through the trained Doo model ,Doo tokenizer and encoder.

    '''
    
    def __init__(self):
        '''
        The constructors of the Degreeoffense Prediction class

        '''
        client = storage.Client()
        self.confg=GetConfigAttr()
        self.logger=Framework_Logger()
        self.doo_training=DegreeOfOffenseModelTraining()
        proj=self.confg.get_project_name()
        self.fs = gcsfs.GCSFileSystem(project=proj)
        self.logger.log_info("Classification: DOO Prediction : Inside Degree of Offense Prediction")


    # Loading Encoding from the training
    def get_offenseDeg_encodings(self,path):
        '''
          Load the encoder from GCS and get the encodings from the encoder
           
          Parameters :
              path(String)  : GCS filepath where encoder is stored

          Returns    :
              mappings(Dict): contains all the labels mapping to degree of offense values.
            
        '''
        
        with self.fs.open(path, 'rb') as output:
            self.encoder=pickle.load(output)
        mappings=dict(zip(self.encoder.classes_, range(len(self.encoder.classes_))))
        self.logger.log_info("Classification: DOO Prediction :Loading the encoder and mappings:"+str(mappings))
        return mappings
    
    #Loading model for prediction from GCS
    def load_model(self,path):
        '''
           Loading the model from the file path in GCS

           Parameters :
                 path(String)  : the GCS file path where the DOO model is stored 

           Returns    :
                 model(Object) : returns the DOO trained model object from GCS.

        '''
        with self.fs.open(path, 'rb') as output:
            doo_model=pickle.load(output)
        self.logger.log_info("Classification: DOO Prediction :Loading the DOO model from GCS")

        return doo_model

    #Loading tokenizer for prediction from GCS
    def load_tokenizer(self,path):
        '''
            Loading the tokenizer from the file path in GCS

            Parameters  :
                  path(String)      : the GCS file path where the DOO tokenizer is stored.

            Returns     :
                  tokenizer(Object) : returns the DOO tokenizer object from GCS.
        '''
        with self.fs.open(path, 'rb') as output:
            tokenizer=pickle.load(output)
        self.logger.log_info("Classification: DOO Prediction :Loading the DOO tokenizer from GCS")
        return tokenizer

    #Loading data collator
    def setup_collator(self):
        '''
            Loading Data collator from DataCollatorWithPadding

            Parameters : None

            Returns  :
                data_collator(Object) : returns the data collator in which objects that will form a batch by using 
                                        a list of dataset elements as input
        
        '''
        data_collator = DataCollatorWithPadding(tokenizer=self.tokenizer)
        self.logger.log_info("Classification: DOO Prediction :setup the data collator")
        return data_collator

    #Configuring Trainer for prediction
    def config_trainer(self,doo_model,data_collator):
        '''
           Defining the Trainer function and configuring it with the doo_model,data collator.
            
           Parameters : 
             
              doo_model(Object)     : Doo trained model
              tokenizer(Object)     : Doo tokenizer object 
              data_collator(Object) : data collator in which objects that will form a batch by using 
                                        a list of dataset elements as input

           Returns    :
               trainer(Object)      : trainer which will be used for prediction in the Doo prediction main

        '''
        trainer=Trainer(model=doo_model, tokenizer=self.tokenizer,data_collator=data_collator)
        self.logger.log_info("Classification: DOO Prediction :Loading the trainer")
        return trainer


    # def get_label(self,value):
    #     return list(self.encodings.keys())[list(self.encodings.values()).index(value)]

    # tokenizing the data
    def preprocess_function(self,data):
        ''' Tokenizination of the data and Converts text into embeddings 

        Parameters:

             data(DataFrame) : Dataframe of Doo training data
        Returns :

             tokenized(dataset): Embeddings of the offense processed record of Doo data

        '''    
        return self.tokenizer(data["processed_text"],data["state"], truncation=True)
         
    #Predicting the Degreeofoffense labels
    def get_offenseDegreee_category_series(self,offense_literal):
        '''
            Requires Dataframe consist of offense literal in first column and state id(proper format) in the second column
            Output will be series with the predicted DOO category such as Felony, Misdemeanor and Non-Criminal Offense
            
            Parameters :
                 offense_literal(DataFrame) : Dataframe containing offense literal records
                 

            Returns :
                  status(Boolean)       : Flag showing if the prediction is successful
                  pred_labels(Series)   : returns the prediction values of the records of the offense literal
            
        '''
        status=False
        pred_labels=pd.Series()
        try:
            self.logger.log_info("Preprocessing for DOO")
            offense_literal.rename(columns={list(offense_literal)[0]:"offense_literal",list(offense_literal)[1]:"state"},inplace=True)
            processed_df=self.doo_training.preprocess_text(offense_literal,col_name="offense_literal")
            offense_literal_dataset=Dataset.from_pandas(processed_df)
            self.logger.log_info("Loading Model")
            doo_model = self.load_model(self.confg.get_model_config_path_attr_by_section("MODELPATH","doo_path")+"model_file")
            self.tokenizer = self.load_tokenizer(self.confg.get_model_config_path_attr_by_section("MODELPATH","doo_path")+"tokenizer")
            self.get_offenseDeg_encodings(self.confg.get_model_config_path_attr_by_section("MODELPATH","doo_path")+"encoder")
            data_collator = self.setup_collator()
            trainer=self.config_trainer(doo_model,data_collator)
            tokenized_dataset= offense_literal_dataset.map(self.preprocess_function, batched=True)
            pred=trainer.predict(tokenized_dataset)
            probs=softmax(pred.predictions, axis=1)
            probs=np.around(probs, decimals=3)
            pred_scores=np.amax(probs, axis=1)
            status=True
            pred_labels=self.encoder.inverse_transform(np.argmax(pred.predictions, axis=-1))
            self.logger.log_info("Classification: DOO Prediction :Length of predicted labels: "+str(len(pred_labels)))
        except Exception as e:
            self.logger.log_error("Classification: DOO Prediction :Exception occurred at doo prediction pipeline: %s"+ str(traceback.format_exc()))  
            status=False
        return {"status":status,"predictions":pred_labels,"pred_scores":pd.Series(pred_scores)}

    def get_offenseDegreee_value(self,offense,state):
        doo_model = self.load_model()
        self.tokenizer = self.load_tokenizer()
        data_collator = self.setup_collator()
        trainer=self.config_trainer(doo_model,data_collator)
        tokens=self.tokenizer([offense],[state], padding=True, truncation=True, return_tensors="pt")
        out=doo_model(**tokens)
        index=torch.argmax(torch.nn.functional.softmax(out.logits, dim = -1))
        pred_label=self.get_label(index)
        return pred_label






