from asyncio.log import logger
import pandas as pd
import numpy as np
import json
from google.cloud import storage
from datetime import datetime
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.read_config import *
from cls_src.utils.pymongo_db_connector import PyMongoConnector
import traceback

class Extract_Payload:
    '''
        In this class, we read the data from Mongodb database and do the required preprocessing to get the data in required format

    '''
    
    def __init__(self):
        '''
           The constructors of Extract payload class

        '''
        self.confg=GetConfigAttr()
        self.logger=Framework_Logger()
        self.mongodbconnector=PyMongoConnector()


    #Fetching unprocessed criminal raw data
    def get_collection_unprocessed_data(self, collection_name,ingested_date):
        '''
           Fetching unprocessed criminal raw data from the specified collection in database

           Parameters :
                 collection_name(String): specifies the collection in which the unprocessed criminal data is available

           Returns     :
                  data(DataFrame)       : dataframe containing raw criminal data from mongodb

        '''
        data=[]
        try:
            if(ingested_date):
                data=self.mongodbconnector.filter_records_dict(collection_name,"cls_processing_status",0,"ingested_date",ingested_date)
            else:
                data=self.mongodbconnector.filter_records_dict(collection_name,"cls_processing_status",0)
        except Exception as e:
            self.logger.log_error("Classification : Extract Payload :Exception occured while fetching unprocessed criminal raw data"+str(e))
        return data

    #Fetching state information from source records  
    def state_info(self,j,obj):
        '''
            Fetching state information from source records which is copied to target records

            Parameters:
                j(String)      : Criminal case number from target record from the court response in payload
                Obj(Dataframe) : Dataframe containing the payload data 

            Returns :
                state_value(String) : returns the state which is mapped to given criminal case number in source record

        '''
        state_info=pd.json_normalize(obj["decrypted_data"]["court_response"],record_path=["source_records","charge_info"],meta=[['source_records','criminal_case_number'],['source_records','state']])
        state_value=state_info[state_info['source_records.criminal_case_number']==j]['source_records.state']
        return state_value

    #Fetch the data from mongodb and process the data that is required for classification models
    def process_ingested_data_classification(self,ingested_date=None):
        '''
            Takes the data from the Database
            Process the data for input format required for classfication models and returns dataframe

            Parameters : None
            
            Returns    :
                payload_df(DataFrame)  : Dataframe in a format required for classification models
                ids(list)              : contains list of the object id's of the data in Mongodb


        '''
        bag_df = []
        ids=[]
        payload_df=pd.DataFrame()
        try:
            data_dict=self.get_collection_unprocessed_data(self.confg.get_io_config_attribute_by_section("mongoDB","collection_criminal_data_raw"),ingested_date)
            for obj in data_dict:
                if "data" in obj.keys():
                    obj["applicant_data"]=obj["decrypted_data"]["applicant_data"]
                    obj["court_response"]=obj["decrypted_data"]["court_response"]
                ids.append(obj["_id"])
                data_df=pd.json_normalize(obj["court_response"],record_path=["target_records","charge_info"],meta=["request_id","reg_id","order_service_id","order_service_data_source_id",["target_records","criminal_case_number"],["target_records","state"],["target_records","court_name"]])
                if len(data_df)!=0:
                    for i in data_df['target_records.criminal_case_number']:
                        data_df['target_records.state']=self.state_info(i,obj)
                data_df["orderid"]=obj["orderid"]
                data_df["orderitemid"]=obj["orderitemid"]
                data_df["ingested_date"]=obj["ingested_date"]
                data_df["derived_state_info"]=False
                data_df.drop_duplicates(inplace=True)
                data_df.reset_index(inplace=True,drop=True)
                temp=data_df.columns.to_series().apply(lambda x:x.replace("target_records.","") if "target_records." in x else x)
                data_df.columns=temp.values
                bag_df.append(data_df)
        except Exception as e:
            self.logger.log_error("Classification : Extract Payload :Exception occured at process classification data"+str(traceback.format_exc()))
        if(len(bag_df)>0):
            payload_df = pd.concat(bag_df, ignore_index=True)
            self.logger.log_info("Classification : Extract Payload :Payload shape:"+str(payload_df.shape))
        return payload_df,ids
