import pandas as pd
import numpy as np
from datasets import Dataset
from transformers import DataCollatorWithPadding
from transformers import TrainingArguments, Trainer
import gcsfs
import pickle
from google.cloud import storage
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.read_config import *
from cls_src.training.offense_nature_training import *
from scipy.special import softmax
import traceback


class OffenseNaturePrediction:
    ''' 
       In this class , prediction of sub-category i.e target variable of the Nature of Offense .
       we predict the Sub-Category through the trained Noo model ,Noo tokenizer and encoder.

    '''

  
    def __init__(self):
        '''
        The constructors of the Natureoffense Prediction class

        '''
        # self.encodings=self.get_natureoffense_encodings()
        client = storage.Client()
        self.confg=GetConfigAttr()
        self.logger=Framework_Logger()
        proj=self.confg.get_project_name()
        self.fs = gcsfs.GCSFileSystem(project=proj)
        self.logger.log_info("Classification : NOO Prediction :Inside the Nature of Offense Prediction")
            
    
    #Returning Subcategory respective to label
    # def get_label(self,value):
    #     labels= list(self.encodings.keys())[list(self.encodings.values()).index(value)]
    #     self.logger.log_info("Number of labels:"+str(len(labels)))
    #     return labels
    
    
    #Loading encoder from the path 
    def load_encoder(self,path):
        '''
          Loading the encoder from the file path .

          Parameters :
               path(String) : the GCS file path where the encoder is stored.

          Returns :
               encoder(Object) : returns the encoder object from GCS.

        '''
        with self.fs.open(path, 'rb') as output:
            encoder = pickle.load(output)
        self.logger.log_info("Classification : NOO Prediction :Load the encoder from GCS")
        return encoder

    #Loading model for prediction from GCS
    def load_model(self,path):
        '''
           Loading the model from the file path in GCS

           Parameters :
                 path(String)  : the GCS file path where the NOO model is stored 

           Returns    :
                 model(Object) : returns the NOO trained model object from GCS.

        '''
        with self.fs.open(path, 'rb') as output:
            model = pickle.load(output)
        self.logger.log_info("Classification : NOO Prediction :Load the trained NOO model from GCS")

        return model


    #Loading tokenizer for prediction from GCS
    def load_tokenizer(self,path):
        '''
            Loading the tokenizer from the file path in GCS

            Parameters  :
                  path(String)      : the GCS file path where the NOO tokenizer is stored.

            Returns     :
                  tokenizer(Object) : returns the NOO tokenizer object from GCS.
        '''
        with self.fs.open(path, 'rb') as output:
            self.tokenizer = pickle.load(output)
        self.logger.log_info("Classification : NOO Prediction :Load the tokenizer from GCS")
        return self.tokenizer
    
    #Loading data collator
    def setup_collator(self,tokenizer):
        '''
            Loading Data collator from DataCollatorWithPadding

            Parameters : 

                tokenizer(Object)     : the loaded tokenizer model is used for defining data collator

            Returns  :
                data_collator(Object) : returns the data collator in which objects that will form a batch by using 
                                        a list of dataset elements as input
        
        '''
        data_collator = DataCollatorWithPadding(tokenizer=tokenizer)
        self.logger.log_info("Classification : NOO Prediction :Load the data collator")
        return data_collator
    
    #Setting up the training args
    def training_args(self):
        '''
          TrainingArguments is the subset of the arguments we use in our example scripts **which relate to the training loop
          itself
            batch_size=64
            number_of_epochs=5

          Parameters  : None

          Returns     :
              TrainingArguments(Object): retuns the TrainingArguments object with the specific configuration

        '''
        self.logger.log_info("Classification : NOO Prediction :Loading the training arguments for the trainer")
        return TrainingArguments(output_dir=".//model_results//noo_subcategory//",per_device_train_batch_size=64,per_device_eval_batch_size=64,num_train_epochs=5,
    evaluation_strategy="epoch")
       
    #Tokenization of the data
    def preprocess_function(self,data):
        ''' Tokenizination of the data and Converts text into embeddings 

        Parameters:

             noo_data(DataFrame) : Dataframe of Noo training data
        Returns :

             tokenized(dataset): Embeddings of the offense processed record of Noo data

        '''    
        tokenizer=self.tokenizer
        return tokenizer(data["offense_processed"], truncation=True)
    
    #Configuring Trainer for prediction
    def config_trainer(self,noo_model,tokenizer,data_collator,training_args):
        '''
           Defining the Trainer function and configuring it with the noo_model, noo_tokenizer,data collator, training arguments
            
           Parameters : 
             
              noo_model(Object)     : Noo trained model
              tokenizer(Object)     : Noo tokenizer object 
              data_collator(Object) : data collator in which objects that will form a batch by using 
                                        a list of dataset elements as input
              training_args(Object) : TrainingArguments object with the specific configuration

           Returns    :
               trainer(Object)      : trainer which will be used for prediction in the Noo prediction main

        '''
        trainer=Trainer(model=noo_model, tokenizer=tokenizer,data_collator=data_collator,args=training_args)
        self.logger.log_info("Classification : NOO Prediction :Loading and configuring the trainer")
        return trainer
    
    #Preprocessing function that were in NatureOffense training class used to clean the data 
    def preprocess_data(self,data,column_name):
        '''
           Preprocessing the data and cleaning the data by removing the stopwords,non english words, unnecessary characters
           These preprocessing functions are in NatureOffense training class 

           Parameters :
                data(DataFrame)  : raw data for prediction

           Returns    :
                preprocessed_data(Dataframe)  : Dataframe returning the cleaned and preprocessed records of column 'offense processed'

        '''
        noo=NatureOffenseTraining()
        data=noo.data_cleaning(data,column_name)
        preprocessed_data=noo.preprocess_data(data,'data')
        self.logger.log_info("Classification : NOO Prediction :Preprocessing and cleaning the data , shape of the preprocessed data :"+str(preprocessed_data.shape))
        return preprocessed_data['offense_processed']
        
    
    #Predicting the subcategory labels
    def get_sub_category_series(self,offense_literal,column_name="offense_literal"):
        ''' 
            Predicting the sub-category labels for the offense literal data
            Requires pandas series consist of Offense literal as text for prediction
            Output provides Nature of Offense category

            Parameters :
                 offense_literal(DataFrame) : Dataframe containing offense literal records
                 column_name(String)        : Column_name specifying the target variable of the nature of offense

            Returns :
                  pred_labels(Series)   : returns the prediction values of the records of the offense literal

            
        '''
        status=False
        pred_labels=pd.Series()
        pred_scores=[]
        try:
            self.logger.log_info("Preproccessing for NOO Model")
            offense_literal=offense_literal.to_frame()
            offense_literal.rename(columns={list(offense_literal)[0]:"offense_literal"},inplace=True)
            offense_literal=self.preprocess_data(offense_literal,column_name)
            offense_literal_dataset=Dataset.from_pandas(offense_literal.to_frame())
            self.logger.log_info("Loading Model")
            model=self.load_model(self.confg.get_model_config_path_attr_by_section("MODELPATH","noo_path")+"model_file")
            tokenizer=self.load_tokenizer(self.confg.get_model_config_path_attr_by_section("MODELPATH","noo_path")+'tokenizer')
            od_encoder=self.load_encoder(self.confg.get_model_config_path_attr_by_section("MODELPATH","noo_path")+'encoder')
            data_collator = self.setup_collator(tokenizer)
            tokenized_dataset= offense_literal_dataset.map(self.preprocess_function, batched=True)
            trainer=self.config_trainer(model,tokenizer,data_collator,self.training_args())
            pred=trainer.predict(tokenized_dataset)
            pred_labels=pd.Series(od_encoder.inverse_transform(np.argmax(pred.predictions, axis=-1)))
            pred=trainer.predict(tokenized_dataset)
            probs=softmax(pred.predictions, axis=1)
            probs=np.around(probs, decimals=3)
            pred_scores=np.amax(probs, axis=1)
            status=True
            self.logger.log_info("Classification : NOO Prediction :Length of predicted labels: "+str(len(pred_labels)))
        except Exception as e:
            self.logger.log_error("Classification : NOO Prediction :Exception occurred at noo prediction pipeline: %s"+ str(traceback.format_exc()))  
            status=False
        return {"status":status,"predictions":pred_labels,"pred_scores":pd.Series(pred_scores)}
    
    #Predicting subcategory for each offense value
    # def get_NOO_predicted_value(self,offense_value):
    #     '''Predicting the Sub-Category with an offense value'''
    #     offense_model = self.load_model()
    #     tokenizer = self.load_tokenizer()
    #     data_collator = self.setup_collator(tokenizer)
    #     trainer=self.config_trainer(offense_model,tokenizer,data_collator,self.training_args())
    #     tokens=tokenizer([offense_value], padding=True, truncation=True, return_tensors="pt")
    #     out=offense_model(**tokens)
    #     index=torch.argmax(torch.nn.functional.softmax(out.logits, dim = -1))
    #     pred_label=self.get_label(index)
    #     return pred_label
        


    