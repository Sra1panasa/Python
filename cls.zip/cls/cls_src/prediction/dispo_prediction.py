# Disposition Prediction Pipeline


from ast import Import
from asyncio.log import logger
from copyreg import pickle
import pandas as pd
import numpy as np
from datasets import Dataset
from transformers import DataCollatorWithPadding
from transformers import  Trainer
import torch
from google.cloud import storage
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.read_config import *
from scipy.special import softmax
import traceback
import pickle
import gcsfs
from cls_src.training.disposition_model_training import DispositionModelTraining

class DispositionPrediction:
    ''' 
       In this class , prediction of Disposition category i.e target variable of the Disposition.
       we predict the Disposition category through the trained Disposition model ,Disposition tokenizer and encoder.

    '''
    
    def __init__(self):
        '''
        The constructors of the Disposition Prediction class

        '''
        client = storage.Client()
        self.confg=GetConfigAttr()
        self.logger=Framework_Logger()
        proj=self.confg.get_project_name()
        self.fs = gcsfs.GCSFileSystem(project=proj)
        self.dispo_training=DispositionModelTraining()
  
    # Loading Encoding from the training
    def get_disposition_encodings(self,path):
        '''
          Load the encoder from GCS and get the encodings from the encoder
           
          Parameters :
              path(String)  : GCS filepath where encoder is stored

          Returns    :
              mappings(Dict): contains all the labels mapping to disposition category values.
            
        '''
        with self.fs.open(path, 'rb') as output:
            self.encoder=pickle.load(output)
        mappings=dict(zip(self.encoder.classes_, range(len(self.encoder.classes_))))
        self.logger.log_info("Classification: Disposition Prediction :Loading the encoder and mappings:"+str(mappings))
        return mappings

    #Loading model for prediction from GCS
    def load_model(self,path):
        '''
           Loading the model from the file path in GCS

           Parameters :
                 path(String)  : the GCS file path where the Disposition model is stored 

           Returns    :
                 model(Object) : returns the Disposition trained model object from GCS.

        '''
        with self.fs.open(path, 'rb') as output:
            offense_model=pickle.load(output)
        self.logger.log_info("Classification: Disposition Prediction :Load the dispositon model from GCS")
        return offense_model

    #Loading tokenizer for prediction from GCS
    def load_tokenizer(self,path):
        '''
            Loading the tokenizer from the file path in GCS

            Parameters  :
                  path(String)      : the GCS file path where the Disposition tokenizer is stored.

            Returns     :
                  tokenizer(Object) : returns the Disposition tokenizer object from GCS.
        '''
        with self.fs.open(path, 'rb') as output:
            tokenizer=pickle.load(output)

        self.logger.log_info("Classification: Disposition Prediction :Load the disposition tokenizer from GCS ")
        return tokenizer

    #Loading data collator
    def setup_collator(self,tokenizer):
        '''
            Loading Data collator from DataCollatorWithPadding

            Parameters : None

            Returns  :
                data_collator(Object) : returns the data collator in which objects that will form a batch by using 
                                        a list of dataset elements as input
        
        '''
        data_collator = DataCollatorWithPadding(tokenizer=tokenizer)
        self.logger.log_info("Classification: Disposition Prediction :Setting up the data collator ")
        return data_collator

    #Configuring Trainer for prediction
    def config_trainer(self,offense_model,tokenizer,data_collator):
        '''
           Defining the Trainer function and configuring it with the offense_model,data collator.
            
           Parameters : 
             
              offense_model(Object)     : Disposition trained model
              tokenizer(Object)     : Disposition tokenizer object 
              data_collator(Object) : data collator in which objects that will form a batch by using 
                                        a list of dataset elements as input

           Returns    :
               trainer(Object)      : trainer which will be used for prediction in the Disposition prediction main

        '''
        self.logger.log_info("Classification: Disposition Prediction :Configuring the trainer")
        trainer=Trainer(model=offense_model, tokenizer=tokenizer,data_collator=data_collator)
        return trainer


    # def get_label(self,value):
    #     return list(self.encodings.keys())[list(self.encodings.values()).index(value)]

    # tokenizing the data
    def preprocess_function(self,data):
        ''' Tokenizination of the data and Converts text into embeddings 

        Parameters:

             data(DataFrame) : Dataframe of Disposition training data
        Returns :

             tokenized(dataset): Embeddings of the offense processed record of Disposition data

        '''    
        return self.tokenizer(data["processed_text"], truncation=True)


    #Predicting the disposition category labels
    def get_disposition_category_series(self,disposition):
        '''
           Requires pandas series consist of Disposition literal as text for prediction
           Output provides dispostion category such as Convition, Non-Conviction, Pending and Deferral

           Parameters :
                 disposition(DataFrame) : Dataframe containing Disposition records
                 

            Returns :
                  status(Boolean)       : Flag showing if the prediction is successful
                  pred_labels(Series)   : returns the prediction values of the records of the Disposition 
           
        '''
        status=False
        pred_labels=pd.Series()
        try:
            self.logger.log_info("Preprocessing for Disposition Model")
            disposition_df=disposition.to_frame()
            disposition_df.rename(columns={list(disposition_df)[0]:"disposition"},inplace=True)
            processed_df=self.dispo_training.preprocess_text(disposition_df,col_name="disposition")
            disposition_dataset=Dataset.from_pandas(processed_df)
            self.logger.log_info("Loading Disposition Model")
            offense_model = self.load_model(self.confg.get_model_config_path_attr_by_section("MODELPATH","dispo_path")+"model_file")
            tokenizer = self.load_tokenizer(self.confg.get_model_config_path_attr_by_section("MODELPATH","dispo_path")+"tokenizer")
            self.get_disposition_encodings(self.confg.get_model_config_path_attr_by_section("MODELPATH","dispo_path")+"encoder")
            self.tokenizer=tokenizer
            data_collator = self.setup_collator(tokenizer)
            trainer=self.config_trainer(offense_model, tokenizer,data_collator)
            tokenized_dataset= disposition_dataset.map(self.preprocess_function, batched=True)
            pred=trainer.predict(tokenized_dataset)
            probs=softmax(pred.predictions, axis=1)
            probs=np.around(probs, decimals=3)
            pred_scores=np.amax(probs, axis=1)
            pred_labels=self.encoder.inverse_transform(np.argmax(pred.predictions, axis=-1))
            self.logger.log_info("Classification: Disposition Prediction :Length of predicted labels: "+str(len(pred_labels)))
            status=True
        except Exception as e:
            self.logger.log_error(e)
            self.logger.log_error("Classification: Disposition Prediction :Exception occurred at disposition prediction pipeline: %s"+ str(traceback.format_exc()))  
            status=False
        return {"status":status,"predictions":pred_labels,"pred_scores":pd.Series(pred_scores)}

    def get_disposition_value(self,dispo_value):
        offense_model = self.load_model()
        self.tokenizer = self.load_tokenizer()
        data_collator = self.setup_collator()
        trainer=self.config_trainer(offense_model,data_collator)
        tokens=self.tokenizer([dispo_value], padding=True, truncation=True, return_tensors="pt")
        out=offense_model(**tokens)
        index=torch.argmax(torch.nn.functional.softmax(out.logits, dim = -1))
        pred_label=self.get_label(index)
        return pred_label
 