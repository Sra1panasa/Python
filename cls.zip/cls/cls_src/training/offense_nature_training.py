import pandas as pd
import numpy as np
import json
import gc
import re
import nltk
from sklearn import preprocessing
from transformers import AutoTokenizer
from datasets import Dataset
from transformers import DataCollatorWithPadding
from transformers import AutoModelForSequenceClassification
from transformers import TrainingArguments, Trainer
from datasets import load_metric
from nltk.corpus import words
from nltk.corpus import wordnet
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer 
from sklearn.metrics import confusion_matrix
import disarray
import torch
import nltk
import gcsfs
import io
import mlflow
import pickle
from google.cloud import storage
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.read_config import *

mlflow.sklearn.autolog()


class NatureOffenseTraining:

    '''
    This class is for classfication of the Nature of offense data with target variable as Sub-Catgeory
    Here we train the distilbert model,distilbert tokenizer  with Nature of offense data
    Load these models and use the trained models for Nature of offense prediction

    '''
    

    def __init__(self):
        '''
        The constructors of the Natureoffense training class

        '''
        
        client = storage.Client()
        self.confg=GetConfigAttr()
        self.logger=Framework_Logger()
        self.logger.log_info('Classification: NOO Training :Nature Of Offense Training Initialized !!!')
        proj=self.confg.get_project_name()
        self.fs = gcsfs.GCSFileSystem(project=proj)
        
        nltk.download('stopwords')
        nltk.download('wordnet')
        nltk.download('omw-1.4')
        nltk.download('words')
        self.stop_words = stopwords.words('english')
        self.stop_words.extend(['from', 'use', 'also', 'much', 'get', 'nt', 'say', 'id', 'etc', 'must','st', 'nd', 'hi', 'okay', 'bye', 'get', 'go', 
                   'always', 'cannot', 'please', 'put', 'let', 'actually', 'actual', 'anything', 'may', 'would', 'could', 'couldnt', 'dont', 
                   'didnt', 'couldnt', 'wont', 'ct.', 'of','to','or','on',"misd","misdemeanor","infraction","infra","infr","count","less","gram","grm","grms","grams",
                   "class","rd", "nd","st","a","b","c","plant","zone","","count","limit","penalty" ,"group"])
        self.stop_words.remove("no")
    
    #    Load the Noo training  data
    def load_data(self,file_path):
        '''
        Reading the training data from the file path 

        Parameters :
            file_path(String): Specifies the file path for the NOO raw data.
        Returns: 
            data(dataframe)  : Dataframe storing the raw NOO data from the file path.

        '''
        data=pd.DataFrame()
        try:
            data=pd.read_excel(file_path)
        except Exception as e:
            self.logger.log_error("Classification: NOO Training :Exception occured while loading data for NOO Model Training "+ str(e))
        self.logger.log_info("Classification: NOO Training :Shape of the input data"+str(data.shape))
        return data

    #   Use this function to remove stopwords from the offence literal
    def remove_stopwords_lemmatize(self,sentence):
        '''
        Removing the stop words in offense literal

        Parameters : 
            Sentence(String) : sentence is the offense literal containing stopwords

        Returns :
                             : offense literal filtered from stopwords 
            
         '''
        lemmatizer = WordNetLemmatizer()
        return  (" ").join([lemmatizer.lemmatize(word) for word in sentence.split() if not word in self.stop_words])

    #   Use this function to remove non english words(or)characters from offence literal
    def remove_non_eng(self,sent):
        '''
        Removing the non english in offense literal 
        
        Parameters:

            Sent(String) : sentence is the offense literal containing non english words

        Returns :
                         : return offense literal filtered from non english words 

        '''
        wordnet_list=list(wordnet.words())
        word_list = words.words() + wordnet_list
        return " ".join(w for w in nltk.wordpunct_tokenize(sent) if w in word_list)

    #Cleaning the data by removing " :" and converting the sentence to lower sentence 
    def data_cleaning(self,data, col_name):
        '''
        Cleaning the raw data removing the unneccessary characters and converting into lower sentence

        Parameters:

                data(Dataframe)  : the dataframe containing raw data

                col_name(String) : a string specifying the column name of raw_data that needs to be cleaned

            Returns:

                data (dataframe) : dataframe containing cleaned raw data 
        '''
        data=data[~data[col_name].isna()]
        data.reset_index(inplace=True)
        data["data"]=data[col_name].apply(lambda x:x.split(":")[1] if x.find(":")!=-1 else x)
        data["data"]=data[col_name].apply(lambda x:x.lower())
        data["data"]=data["data"].apply(lambda x : re.sub('[^a-zA-Z0-9 \n\.]', ' ', x))
        self.logger.log_info("Classification: NOO Training :Shape of the data"+str(data.shape))
        return data
    
   
       
    #expanding the abbrevitions present in each record . 
    def expand_str(self,sentence):
        '''
        Expanding the abbreviations in each offense literal where there are shortforms of words .
           
        The abbreviations of the words are stored as json in GCS from which we expand the abbrevations  in offense literal.

        Parameters:
                sentence(String) : sentence is the offense literal with abbreviations

        Returns :
                sentence(String)  : offense literal with expanded shortforms 
        
        '''
        with self.fs.open(self.confg.get_model_config_path_attr_by_section("MODELPATH","noo_metadata_path")+"abbreviations.json") as f:
            abbr = json.load(f)
        abbr=json.loads(abbr)
        for key in abbr.keys():
            if key in sentence:
                sentence=re.sub(r'(?<![a-zA-Z])'+key+'(?![a-z-Z])',abbr[key], sentence)
        return sentence

    #preprocessing the data by removing stopwords,converting into lower case and removal of special characters
    def preprocess_data(self,data,column_name):
        '''
        Preprocess the text - lower case, removal of digits & special character and removal of stopwords

        Parameters:

                data(Dataframe)     : Noo training dataframe after data cleaning 

                column_name(String) : column name specifying the column in dataframe that needs to be preprocessed

        Returns:
                data(DataFrame)     : dataframe containing preprocessed NOO training data 

        '''
        data[column_name]=data[column_name].apply(lambda x: re.sub("^\d+\s|\s\d+\s|\s\d+$", " ", x))
        data["offense_processed"]=data[column_name].apply(lambda x:x.translate(str.maketrans('','','1234567890')).strip())
        data["offense_processed"]=data["offense_processed"].apply(lambda x:self.expand_str(x))
        data["offense_processed"]=data["offense_processed"].apply(lambda x:self.remove_stopwords_lemmatize(x))
        data["offense_processed"]=data["offense_processed"].apply(lambda x:self.remove_non_eng(x))
        self.logger.log_info("Classification: NOO Training :Preprocessing the training data and no of records :"+str(data.shape[0]))
        return data
    # Defining label encoder for the encoding the labels to the target variables    
    def load_encoder(self):
        ''' 
        Loading the label encoder from preprocessing library for encoding the target variable i.e sub-category for the Noo training data

        Parameters   : None
        Returns      : None

        '''
        self.logger.log_info("Classification: NOO Training :Loading the label encoder")
        self.od_encoder = preprocessing.LabelEncoder()

        
        
     #adding labels for the feature SubCategory through LabelEncoder   
    def get_encodings_data(self,noo_data,column_name):
        '''
        Adding labels to the target variable (Sub-Category) through the label encoder

        Parameters:

           noo_data(DataFrame) :  NOO Training data
           column_name(String) :  column_name specifying the column_name of target variable i.e Sub-Category

        Returns: 

           noo_data(DataFrame) : feature labeled training dataframe with an added column of labels 

        '''
        noo_data['labels']=self.od_encoder.fit_transform(noo_data[column_name])
        noo_encodings=dict(zip(self.od_encoder.classes_, range(len(self.od_encoder.classes_))))
        self.logger.log_info("Classification: NOO Training :Ecoding the labels :"+str(noo_encodings))
        return noo_data
    
   
    # return the frequency of each cluster 
    def get_cluster_frquency(self,noo_data,column_name):
        ''' 
        Getting the frequency of each target variable value (Sub_Category)

        Parameters:

            noo_data(DataFrame) : NOO training dataframe 
            column_name(String) : target variable column name

        Returns : 

            noo_data(DataFrame)  : containing each target variable and thier frequency as two columns 

        '''
        noo_data=pd.DataFrame(noo_data[column_name].value_counts())
        noo_data=noo_data.reset_index(drop=False)
        noo_data.columns=["Sub-Category","Count of records in each Cluster"]
        self.logger.log_info("Classification: NOO Training :Number of clusters :"+str(noo_data.shape[0]))
        return noo_data

    #loading the distilbert model 
    def load_model(self,model_name,num_labels):
        '''
        Loading the NOO training model 

        Parameters:

           model_name(String) : model_name specifying the type of model 
           num_labels(int)    : number of labels

        Returns :

            noo_model(Object)  : noo model defined from AutoModelForSequenceClassification

        '''
        self.logger.log_info("Classification: NOO Training :Loading the Noo training model")
        noo_model = AutoModelForSequenceClassification.from_pretrained(model_name,num_labels=num_labels)
        return noo_model

    #loading the distilbert tokenizer 
    def load_tokenizer(self,model_name):
        '''
        Loading the NOO tokenizer from AutoToenizer

        Parameters:

           model_name(String) : model_name for the tokenizer in Autotokenizer library
        Returns : None

        '''
        self.logger.log_info("Classification: NOO Training :Loading the Noo tokenizer")
        self.tokenizer=AutoTokenizer.from_pretrained(model_name)
        

    #loading the datacollator
    def setup_collator(self):
        '''
        Loading the Data Collator from DataCollatorWithPadding for the trainer 

        Parameters: None

        Returns : None

        '''
        self.logger.log_info("Classification: NOO Training :Loading the Data collator")
        self.data_collator = DataCollatorWithPadding(tokenizer=self.tokenizer)
         

    # defining the compute metrics for trainer which returns accuracy metrics for the predicted data
    def compute_metrics(self,eval_preds):
        '''
        Compute accuracy and f1 metrics of the prdictions , this function is an argument for trainer.

        Parameters :

           eval_preds(Dataframe) : eval_preds is the each record of the data after prediction 

        Returns:

           metrics(Dataframe)    : Dataframe containing the accuracy metrics for the prediction of the classification data 

        '''
        logits, labels = eval_preds
        predictions = np.argmax(logits, axis=-1)
        metric = load_metric("accuracy","f1")
        return metric.compute(predictions=predictions, references=labels)


    # configuring the trainer
#     def config_trainer(self,noo_model,training_args,train_data,val_data,tokenizer,data_collator,compute_metrics):
#         self.logger.log_info("Configuring the trainer ")
#         trainer=Trainer(model=noo_model,args=training_args,train_dataset=train_data,eval_dataset=val_data,tokenizer=tokenizer,data_collator=data_collator,compute_metrics=compute_metrics)
#         return trainer
    
    # returning  the label encodings 
    def get_label(self,value):
        '''
        Getting target variable i.e sub-category  of the each label 

        Parameters:

            value(int)     : value is the label value of the sub-category .


        Returns :

            labels(String) : the associate sub-category according to the label

        '''
        labels= list(self.encodings.keys())[list(self.encodings.values()).index(value)]
        self.logger.log_info("Classification: NOO Training :Number of labels:"+len(labels))
        return labels
    

    # tokenizing the data 
    def tokenization_data(self,noo_data):
        ''' Tokenizination of the data and Converts text into embeddings 

        Parameters:

             noo_data(DataFrame) : Dataframe of Noo training data
        Returns :

             tokenized(dataset): Embeddings of the offense processed record of Noo data

        '''
#         tokenizer=self.tokenizer
        # self.logger.log_info("Tokenizination of the data")
        return self.tokenizer(noo_data["offense_processed"], truncation=True)

    # mapping the tokenized records in the dataset
    def get_tokenized_dataset(self,noo_data):
        ''' 
        Mapping the tokenized records in the Noo dataset

        Parameters :

            noo_data : Dataframe of Noo data

        Returns : 

            tokenized_dataset(dataset) : the tokenized dataset with offense processed column containing the tokenization

        '''
        offense_dataset=Dataset.from_pandas(noo_data)
        tokenized_dataset= offense_dataset.map(self.tokenization_data, batched=True)
        self.logger.log_info("Classification: NOO Training : tokenized dataset:"+str(tokenized_dataset))
        return tokenized_dataset


    # splitting the data into train,test,validation data 
    #test percent should be in decimal
    def train_test_split(self,noo_data,test_percent,val_test_percent):
        '''
        Splitting the tokenized dataset into train,test and validation data 

        Parameters:

            noo_data(Dataframe)     : Noo data dataframe
            test_percent(float)     : test percentage for training tokenised data split. 
            val_test_percent(float) : validation test percentage for test tokenised data split into validation data

        Returns:

            split_data(dataset)     : the train and test data split
            val_data (dataset)      : validation data split
        '''
        split_data=noo_data.train_test_split(test_percent,1-test_percent)
        val_data=split_data["train"].train_test_split(val_test_percent,1-val_test_percent)
        self.logger.log_info("Classification: NOO Training :Train test validation split and test with test percent:"+str(test_percent)+" validation test percent:"+str(val_test_percent))
        return split_data,val_data
    
    
    # loading the trainer with the configuration 
    def model_training(self,noo_model,tokenised_val_data,training_args):
        '''
        Loading the trainer with configuring the variables for the trainer

        Parameters:

            noo_model(Object)           : Noo model from the load_model() , 
            tokenized_val_data(dataset) : validation data  
            training_args(object)       : training arguments

        Returns :

            trainer(Object)             : trainer which will be used for training in the Noo training main

        '''
        
        
        trainer=Trainer(model=noo_model,
                        args=training_args,
                        tokenizer=self.tokenizer,
                        train_dataset=tokenised_val_data["train"],
                        eval_dataset=tokenised_val_data["test"],
                        compute_metrics=self.compute_metrics,
                        data_collator=self.data_collator
                        
        )
            
        
        self.logger.log_info("Classification: NOO Training :Loading the trainer with configurations")
        
        
        return trainer
    
 

    # predicting the target variable i.e sub-category  for classification data 
    def make_predictions(self,trainer,noo_data,bucket):
        '''
        Creates predictions dataframe with the inputs, processed input, actual output, predicted labels

        Parameters:

           Trainer(Object)     : Trainer from the load_trainer(), 
           noo_data(DataFrame) : data specifying the train,test and validation tokenized dataset
           bucket(String)      : bucket which specifies train,test and validation data


        Returns:

           data(Dataframe)      : dataframe with predictions for the specific test or train or validation data.

        '''
        pred=trainer.predict(noo_data)
        pred_labels=self.od_encoder.inverse_transform(np.argmax(pred.predictions, axis=-1))
        temp={"offense_literal":noo_data["offense_literal"],"offense_processed":noo_data["offense_processed"],"Sub-Category":noo_data["Sub-Category"],"Bucket":bucket,"Prediction":pred_labels,"labels":noo_data["labels"]}
        self.logger.log_info("Classification: NOO Training :Predicted labels for "+bucket+" data.")
        return pd.DataFrame(temp)


        
        
    
 
    

