import pandas as pd
import numpy as np
from sklearn import preprocessing
from transformers import AutoTokenizer
from datasets import Dataset
from transformers import DataCollatorWithPadding
from transformers import AutoModelForSequenceClassification
from transformers import  Trainer
from datasets import load_metric
import nltk
from nltk.corpus import stopwords
import re
from nltk.stem import WordNetLemmatizer 
import disarray
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.read_config import *

class DegreeOfOffenseModelTraining:
    '''
    This a class for classfication of the Degree of offense data with target variable as degree_of_offense
    Here we train the distilbert model,distilbert tokenizer  with Degree of offense data
    Load these models and use the trained models for Degree of offense prediction

    '''


    def __init__(self):
        '''
        The constructors of the Degreeoffense training class

        '''
        self.od_encoder = preprocessing.LabelEncoder()
        nltk.download('stopwords')
        nltk.download('wordnet')
        nltk.download('omw-1.4')
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = stopwords.words('english')
        # self.file_sys = gcsfs.GCSFileSystem(project='prj-d-hrgp')
        self.logger=Framework_Logger()
        self.logger.log_info("Classification : DOO Training :Degree of offense model training intialized")
        self.confg=GetConfigAttr()

    #    Load the training  data   
    def load_data(self,path):
        '''
        Reading the training data from the file path 

        Parameters :
            path(String)         : Specifies the file path for the DOO raw data.

        Returns: 
            doo_data(dataframe)  : Dataframe storing the raw DOO data from the file path.

        '''
        doo_data=pd.DataFrame()
        try:
            doo_data=pd.read_excel(path)
            self.logger.log_info("Classification: DOO Training :Shape of the input data"+str(doo_data.shape))
        except Exception as e:
            self.logger.log_error("Classification : DOO Training :Exception in Loading Data DOO Training"+str(e))
        return doo_data

     #adding labels for the feature degree_of_offense through LabelEncoder
    def encode_target(self, data,col_name="degree_of_offense"):
        '''
        Adding labels to the target variable (degree_of_offense) through the label encoder

        Parameters:

           data(DataFrame)     :  DOO Training data
           column_name(String) :  column_name specifying the column_name of target variable i.e degree_of_offense

        Returns: 

           data(DataFrame) : feature labeled training dataframe with an added column of labels 

        '''     
        data["labels"]=self.od_encoder.fit_transform(data[col_name])
        #print(dict(zip(self.od_encoder.classes_, range(len(self.od_encoder.classes_))))) 
#         self.logger.log_info("Classification : DOO Training :"+dict(zip(self.od_encoder.classes_, range(len(self.od_encoder.classes_)))))
        return data

     # Defining label encoder for the encoding the labels to the target variables
    def get_encoder(self):
        ''' 
        Loading the label encoder from preprocessing library for encoding the target variable i.e degree_of_offense for the Doo training data

        Parameters   : None

        Returns      : 

            od_encoder(Object): return Label Encoder from preprocessing

        '''
        self.logger.log_info("Classification : DOO Training :Loading the label encoder for encoding the target variables")
        return self.od_encoder

    #   Use this function to remove stopwords from the offence literal
    def remove_stopwords_lemmatize(self,sentence):
        '''
        Removing the stop words in offense literal

        Parameters : 
            Sentence(String) : sentence is the offense literal containing stopwords

        Returns :
                            : offense literal filtered from stopwords 
            
         '''
        return  (" ").join([self.lemmatizer.lemmatize(word) for word in sentence.split() if not word in self.stop_words])

    def lemmatize(self,sentence):
        return  (" ").join([self.lemmatizer.lemmatize(word) for word in sentence.split()])

    #   Cleaning the data by removing " :" and converting the sentence to lower sentence 
    def preprocess_text(self,data, col_name="offense_literal"):
        '''
        Preprocess the text - lower case, removal of digits & special character and removal of stopwords

        Parameters:

                data(Dataframe)     : Doo training dataframe after data cleaning 

                column_name(String) : column name specifying the column in dataframe that needs to be preprocessed

        Returns:
                data(DataFrame)     : dataframe containing preprocessed DOO training data 

        '''
        data['processed_text']=data[col_name].astype("str")
        data["processed_text"]=data["processed_text"].apply(lambda x:x.lower())
        data["processed_text"]=data["processed_text"].str.replace("<"," less than ")
        data["processed_text"]=data["processed_text"].str.replace(">"," greater than ")
        data["processed_text"]=data["processed_text"].apply(lambda x: re.sub('[^A-Za-z0-9 .]+', " ", x))

        # data['processed_text']=data[col_name].astype("str")
        # data["processed_text"]=data["processed_text"].apply(lambda x:x.lower())
        # data["processed_text"]=data["processed_text"].apply(lambda x : re.sub('[^a-zA-Z0-9 \n\.]', ' ', x))
        # data["processed_text"]=data["processed_text"].apply(lambda x: re.sub("^\d+\s|\s\d+\s|\s\d+$", " ", x))
        # data["processed_text"]=data["processed_text"].apply(lambda x:self.remove_stopwords_lemmatize(x))
        self.logger.log_info("Classification : DOO Training :Preprocess the text - removing the unneccessary characters and convert into lower case")
        return data

     #  loading the distilbert tokenizer
    def load_tokenizer(self,tokenizer_name="distilbert-base-uncased"):
        '''
        Loading the DOO tokenizer from AutoToenizer

        Parameters:

           model_name(String) : model_name for the tokenizer in Autotokenizer library

        Returns : None

        '''
        self.logger.log_info("Classification : DOO Training :Loading Distilbert-base-uncased tokenizer")
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)

    #  tokenizing the data 
    def preprocess_function(self,data, col_name1="processed_text", col_name2="state"):
        ''' Tokenizination of the data and Converts text into embeddings 

        Parameters:

             data(DataFrame) : Dataframe of Doo training data

        Returns :

             tokenized(dataset): Embeddings of the offense processed record of Doo data

        '''
        self.logger.log_info("Classification : DOO Training :Preprocessing "+col_name1+" "+col_name2)
        return self.tokenizer(data[col_name1],data[col_name2], truncation=True)
    
     # mapping the tokenized records in the dataset
    def create_dataset_frm_data(self,data):
        ''' 
        Mapping the tokenized records in the Doo dataset

        Parameters :

            data : Dataframe of Doo data

        Returns : 

            tokenized_dataset(dataset) : the tokenized dataset with offense processed column containing the tokenization

        '''
        doo_dataset=Dataset.from_pandas(data)
        tokenized_dataset= doo_dataset.map(self.preprocess_function, batched=True)
        self.logger.log_info("Classification : DOO Training :Mapping the tokenized records in data")
        return tokenized_dataset

     #loading the datacollator
    def load_data_collator(self):
        '''
        Loading the Data Collator from DataCollatorWithPadding for the trainer 

        Parameters: None

        Returns : None

        '''
        self.logger.log_info("Classification : DOO Training :Loading Data Collator")
        self.data_collator = DataCollatorWithPadding(tokenizer=self.tokenizer)

    #   loading the distilbert model 
    def load_model(self, num_labels, model_name="distilbert-base-uncased"):
        '''
        Loading the DOO training model 

        Parameters:

           model_name(String) : model_name specifying the type of model i.e distilbert-base-uncased
           num_labels(int)    : number of labels

        Returns :

            Doo_model(Object)  : Doo model defined from AutoModelForSequenceClassification

        '''
        self.logger.log_info("Classification : DOO Training :Loading Distilbert-Base-Uncased Model")
        return AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=num_labels)

    # splitting the data into train,test,validation data 
    #test percent should be in decimal
    def train_test_eval_split(self, dataset,train_size, test_size, eval_size):
        '''
        Splitting the tokenized dataset into train,test and validation data 

        Parameters:

            Doo_data(Dataframe)     : Doo data dataframe
            train_size(float)       : train percentage for training tokenised data split.
            test_size(float)        : test percentage for training tokenised data split
            eval_size(float)        : validation test percentage for test tokenised data split into validation data

        Returns:

            train_eval["train"](dataset)     : the training tokenized dataset
            train_test["test"](dataset)      : the test tokenized dataset
            train_eval["test"](dataset       : validation dataset
        '''
        self.logger.log_info("Classification : DOO Training :Splitting Dataset in the ratio "+str(train_size)+" "+str(test_size)+" "+str(eval_size))
        train_test=dataset.train_test_split(test_size,train_size+eval_size)
        train_eval=train_test["train"].train_test_split(eval_size/(train_size+eval_size),train_size/(train_size+eval_size))
        return train_eval["train"],train_test["test"],train_eval["test"]
    
    # defining the compute metrics for trainer which returns accuracy metrics for the predicted data
    def compute_metrics(self,eval_preds):
        '''
        Compute accuracy and f1 metrics of the prdictions , this function is an argument for trainer.

        Parameters :

           eval_preds(Dataframe) : eval_preds is the each record of the data after prediction 

        Returns:

           metrics(Dataframe)    : Dataframe containing the accuracy metrics for the prediction of the classification data 

        '''
        logits, labels = eval_preds
        predictions = np.argmax(logits, axis=-1)
        metric = load_metric("accuracy","f1")
        return metric.compute(predictions=predictions, references=labels)

    # loading the trainer with the configuration 
    def load_trainer(self, doo_model,training_args,train, eval,ModelCallBack):
        '''
        Loading the trainer with configuring the variables for the trainer

        Parameters:

            doo_model(Object)           : Doo model from the load_model()  
            train(dataset)              : training validation data 
            eval(dataset)               : validation data
            ModelCallBack()             : function that logs the each epoch information into mlflow as text file
            training_args(object)       : training arguments

        Returns :

            trainer(Object)             : trainer which will be used for training in the Doo training main

        '''
        self.logger.log_info("Loading Trainer")
        trainer = Trainer(
            model=doo_model,
            args=training_args,
            train_dataset=train, 
            eval_dataset=eval,
            tokenizer=self.tokenizer,
            data_collator=self.data_collator,
            compute_metrics=self.compute_metrics,
            callbacks=[ModelCallBack],
        )
        self.logger.log_info("Classification : DOO Training :Loading the model trainer ")
        return trainer

    #  predicting the target variable i.e degree_of_offense  for classification data    
    def make_pred_df(self,data,bucket,trainer):
        '''
        Creates predictions dataframe with the inputs, processed input, actual output, predicted labels

        Parameters:

           Trainer(Object)     : Trainer from the load_trainer(), 
           data(DataFrame)     : data specifying the train,test and validation tokenized dataset
           bucket(String)      : bucket which specifies train,test and validation data


        Returns:

           data(Dataframe)      : dataframe with predictions for the specific test or train or validation data.

        '''
        pred = trainer.predict(data)
        pred_labels=self.od_encoder.inverse_transform(np.argmax(pred.predictions, axis=-1))
        temp={"offense_literal":data["offense_literal"],"processed_text":data["processed_text"],"state":data["state"],"actual_doo":data["degree_of_offense"],
            "Prediction":pred_labels,"Bucket":bucket}
        self.logger.log_info("Classification : DOO Training :Predicting the target variable(degree_of_offense) ")
        return pd.DataFrame(temp)


    # def save_obj(self,path, obj):
    #     with self.file_sys.open(path, 'wb') as output:
    #         pickle.dump(obj, output)