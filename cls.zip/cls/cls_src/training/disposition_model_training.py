from asyncio.log import logger
import pandas as pd
import numpy as np
import json
from sklearn import preprocessing
from transformers import AutoTokenizer
from datasets import Dataset
from transformers import DataCollatorWithPadding
from transformers import AutoModelForSequenceClassification
from transformers import TrainingArguments, Trainer, TrainerCallback
from datasets import load_metric
import nltk
from nltk.corpus import stopwords
import re
from nltk.stem import WordNetLemmatizer 
from sklearn.metrics import confusion_matrix
import gcsfs
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.read_config import *

class DispositionModelTraining:
    '''
    This a class for classfication of the Disposition data with target variable as Charge Code Description
    Here we train the distilbert model,distilbert tokenizer  with Disposition data
    Load these models and use the trained models for Disposition prediction

    '''
    def __init__(self):
        '''
        The constructors of the Disposition training class

        '''
        self.od_encoder = preprocessing.LabelEncoder()
        nltk.download('stopwords')
        nltk.download('wordnet')
        nltk.download('omw-1.4')
        self.lemmatizer = WordNetLemmatizer()
        self.stop_words = stopwords.words('english')
        # self.file_sys = gcsfs.GCSFileSystem(project='prj-d-hrgp')
        self.logger=Framework_Logger()
        self.confg=GetConfigAttr()
        self.logger.log_info("Classification :Disposition Training :Disposition model training intialized")

    #   Load the disposition training data    
    def load_data(self,path):
        '''
        Reading the training data from the file path 

        Parameters :
            path(String)         : Specifies the file path for the Disposition raw data.

        Returns: 
            dispo_data(dataframe)  : Dataframe storing the raw Disposition data from the file path.

        '''
        
        dispo_data=pd.DataFrame()
        try:
            dispo_data=pd.read_excel(path)
        except Exception as e:
            self.logger.log_error("Classification :Disposition Training :Exception occured at loading data for Disposition training "+str(e))
#         doo_data.dropna(axis=0,inplace=True)
        return dispo_data

    #   Adding labels for the feature Charge Code Description through LabelEncoder   
    def encode_target(self, data,col_name="Charge Code Description"):
        '''
        Adding labels to the target variable (degree_of_offense) through the label encoder

        Parameters:

           data(DataFrame)     :  Disposition Training data
           column_name(String) :  column_name specifying the column_name of target variable i.e Charge Code Description

        Returns: 

           data(DataFrame) : feature labeled training dataframe with an added column of labels 

        '''           
        data["labels"]=self.od_encoder.fit_transform(data[col_name])
        self.logger.log_info("Classification :Disposition Training :Encodings "+ json.dumps(dict(zip(self.od_encoder.classes_, range(len(self.od_encoder.classes_))))))
        #print(dict(zip(self.od_encoder.classes_, range(len(self.od_encoder.classes_))))) 
        return data
    #   Defining label encoder for the encoding the labels to the target variables


    def get_encoder(self):
        ''' 
        Loading the label encoder from preprocessing library for encoding the target variable i.e Charge Code Description for the Disposition training data

        Parameters   : None

        Returns      : 

            od_encoder(Object): return Label Encoder from preprocessing

        '''
        self.logger.log_info("Classification :Disposition Training :Loading the label encoder for encoding the target variables")
        return self.od_encoder


    #   Removing stop words in offense literal in disposition
    def remove_stopwords_lemmatize(self,sentence):
        '''
        Removing the stop words in offense literal

        Parameters : 
            Sentence(String) : sentence is the offense literal containing stopwords

        Returns :
                            : offense literal filtered from stopwords 
            
         '''
        return  (" ").join([self.lemmatizer.lemmatize(word) for word in sentence.split() if not word in self.stop_words])

    def lemmatize(self,sentence):
        return  (" ").join([self.lemmatizer.lemmatize(word) for word in sentence.split()])


     #  Cleaning the raw data removing the unneccessary characters and converting into lower sentence
    def preprocess_text(self,data, col_name="Disposition"):
        '''
        Preprocess the text - lower case, removal of digits & special character and removal of stopwords

        Parameters:

                data(Dataframe)     : Disposition training dataframe after data cleaning 

                column_name(String) : column name specifying the column in dataframe that needs to be preprocessed

        Returns:
                data(DataFrame)     : dataframe containing preprocessed Disposition training data 

        '''
        data['processed_text']=data[col_name].astype("str")
        data["processed_text"]=data["processed_text"].apply(lambda x:x.lower())
        data["processed_text"]=data["processed_text"].apply(lambda x : re.sub('[^a-zA-Z0-9 \n\.]', ' ', x))
        data["processed_text"]=data["processed_text"].apply(lambda x: re.sub("^\d+\s|\s\d+\s|\s\d+$", " ", x))
        data["processed_text"]=data["processed_text"].apply(lambda x:self.lemmatize(x))
        # data['processed_text']=data[col_name].astype("str")
        # data["processed_text"]=data["processed_text"].apply(lambda x:x.lower())
        # data["processed_text"]=data["processed_text"].apply(lambda x : re.sub('[^a-zA-Z0-9 \n\.]', ' ', x))
        # data["processed_text"]=data["processed_text"].apply(lambda x: re.sub("^\d+\s|\s\d+\s|\s\d+$", " ", x))
        # data["processed_text"]=data["processed_text"].apply(lambda x:self.remove_stopwords_lemmatize(x))
        self.logger.log_info("Classification :Disposition Training :Preprocess the text - removing the unneccessary characters and convert into lower case")
        return data


    #   Loading the distilbert-base-uncased tokenizer 
    def load_tokenizer(self,tokenizer_name="distilbert-base-uncased"):
        '''
        Loading the Disposition tokenizer from AutoToenizer

        Parameters:

           model_name(String) : model_name for the tokenizer in Autotokenizer library

        Returns : None

        '''
        self.logger.log_info("Classification :Disposition Training :Loading Distilbert Tokenizer")
        self.tokenizer = AutoTokenizer.from_pretrained(tokenizer_name)


    # Tokenizination of the data and Converts text into embeddings 
    def preprocess_function(self,data, col_name1="processed_text"):
        ''' Tokenizination of the data and Converts text into embeddings 

        Parameters:

             data(DataFrame) : Dataframe of Disposition training data

        Returns :

             tokenized(dataset): Embeddings of the offense processed record of Disposition data

        '''
        return self.tokenizer(data[col_name1], truncation=True)


    #   mapping the tokenized records in the dataset
    def create_dataset_frm_data(self,data):
        ''' 
        Mapping the tokenized records in the Disposition dataset

        Parameters :

            data : Dataframe of Disposition data

        Returns : 

            tokenized_dataset(dataset) : the tokenized dataset with offense processed column containing the tokenization

        '''
        dispo_dataset=Dataset.from_pandas(data)
        tokenized_dataset= dispo_dataset.map(self.preprocess_function, batched=True)
        self.logger.log_info("Classification :Disposition Training :Mapping the tokenized records in data")
        return tokenized_dataset

    #   Loading the Data Collator for the trainer 
    def load_data_collator(self):
        '''
        Loading the Data Collator from DataCollatorWithPadding for the trainer 

        Parameters: None

        Returns : None

        '''
        self.logger.log_info("Classification :Disposition Training :Loading the data collator for the trainer")
        self.data_collator = DataCollatorWithPadding(tokenizer=self.tokenizer)


    #   Loading the distilbert model 
    def load_model(self, num_labels, model_name="distilbert-base-uncased"):
        '''
        Loading the Disposition training model 

        Parameters:

           model_name(String) : model_name specifying the type of model i.e distilbert-base-uncased
           num_labels(int)    : number of labels

        Returns :

            model(Object)     : Disposition model defined from AutoModelForSequenceClassification

        '''
        self.logger.log_info("Classification :Disposition Training :Loading Distilbert-Base-Uncased Model")
        return AutoModelForSequenceClassification.from_pretrained(model_name, num_labels=num_labels)


    #  splitting the data into train,test,validation data 
    #  test percent should be in decimal
    def train_test_eval_split(self, dataset,train_size, test_size, eval_size):
        '''
        Splitting the tokenized dataset into train,test and validation data 

        Parameters:

            dataset(Dataframe)      : Disposition data dataframe
            train_size(float)       : train percentage for training tokenised data split.
            test_size(float)        : test percentage for training tokenised data split
            eval_size(float)        : validation test percentage for test tokenised data split into validation data

        Returns:

            train_eval["train"](dataset)     : the training tokenized dataset
            train_test["test"](dataset)      : the test tokenized dataset
            train_eval["test"](dataset       : validation dataset
        '''
        self.logger.log_info("Classification :Disposition Training :Datasplit ratios "+str(train_size)+" "+str(test_size)+" "+str(eval_size))
        train_test=dataset.train_test_split(test_size,train_size+eval_size)
        train_eval=train_test["train"].train_test_split(eval_size/(train_size+eval_size),train_size/(train_size+eval_size))
        return train_eval["train"],train_test["test"],train_eval["test"]

    #   Defining the compute metrics for trainer which returns accuracy metrics for the predicted data
    def compute_metrics(self,eval_preds):
        '''
        Compute accuracy and f1 metrics of the prdictions , this function is an argument for trainer.

        Parameters :

           eval_preds(Dataframe) : eval_preds is the each record of the data after prediction 

        Returns:

           metrics(Dataframe)    : Dataframe containing the accuracy metrics for the prediction of the classification data 

        '''
        logits, labels = eval_preds
        predictions = np.argmax(logits, axis=-1)
        metric = load_metric("accuracy","f1")
        return metric.compute(predictions=predictions, references=labels)

    #   Loading the trainer with the configuration 
    def load_trainer(self, dispo_model,training_args,train, eval,ModelCallBack):
        '''
        Loading the trainer with configuring the variables for the trainer

        Parameters:

            dispo_model(Object)         : Disposition model from the load_model()  
            train(dataset)              : training validation data 
            eval(dataset)               : validation data
            ModelCallBack()             : function that logs the each epoch information into mlflow as text file( in main file)
            training_args(object)       : training arguments

        Returns :

            trainer(Object)             : trainer which will be used for training in the Disposition training main

        '''
        trainer = Trainer(
            model=dispo_model,
            args=training_args,
            train_dataset=train, 
            eval_dataset=eval,
            tokenizer=self.tokenizer,
            data_collator=self.data_collator,
            compute_metrics=self.compute_metrics,
            callbacks=[ModelCallBack],
        )
        self.logger.log_info("Classification :Disposition Training :Loading the model trainer ")
        return trainer


    #   Predicting the target variable i.e sub-category  for classification data   
    def make_pred_df(self,data,bucket,trainer):
        '''
        Creates predictions dataframe with the inputs, processed input, actual output, predicted labels

        Parameters:

           Trainer(Object)     : Trainer from the load_trainer(), 
           data(DataFrame)     : data specifying the train,test and validation tokenized dataset
           bucket(String)      : bucket which specifies train,test and validation data


        Returns:

           data(Dataframe)      : dataframe with predictions for the specific test or train or validation data.

        '''
        pred = trainer.predict(data)
        pred_labels=self.od_encoder.inverse_transform(np.argmax(pred.predictions, axis=-1))
        temp={"dispo_literal":data["Disposition"],"dispo_processed":data["processed_text"],"Dispo_Category":data["Charge Code Description"],
              "Prediction":pred_labels,"Bucket":bucket}

        self.logger.log_info("Classification :Disposition Training :Predicting the target variable(Charge Code Description) ")
        return pd.DataFrame(temp) 


    # def save_obj(self,path, obj):
    #     with self.file_sys.open(path, 'wb') as output:
    #         pickle.dump(obj, output)