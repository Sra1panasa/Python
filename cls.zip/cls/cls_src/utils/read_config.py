import configparser
import os



class GetConfigAttr:
    def __init__(self):
        try:
            # print(os.path.join(os.path.dirname(__file__)))
            # print(os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config', 'io_config.ini')))
            self.ioconfig = configparser.RawConfigParser()
            ioConfigFilePath=os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config', 'io_config.ini'))
            modelConfigFilePath=os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config', 'model_config.ini'))
            self.ioconfig.read_file(open(ioConfigFilePath))
            self.modelConfig = configparser.RawConfigParser()   
            self.modelConfig.read_file(open(modelConfigFilePath))
            self.environment=os.environ.get('environment')
            self.bucket_name = self.get_io_config_attribute_by_section("gcsBucket",f"{self.environment}_bucket")

        except Exception as e:
            print(e)
            print(self.ioconfig, self.modelConfig)

    def get_io_config_attribute(self,key):
        '''Get value of the attribute from the input/ouput config'''
        return self.ioconfig.get("PATH",key)

    def get_model_config_attribute(self, key):
        '''Get value of the attribute from the model config'''
        return self.modelConfig.get("MODELPATH",key)
    
    def get_io_config_attribute_by_section(self, section, key):
        '''Get value of the attribute from the input/ouput config by section'''
        return self.ioconfig.get(section,key)

    def get_model_config_attribute_by_section(self, section, key):
        '''Get value of the attribute from the input/ouput config by section'''
        return self.modelConfig.get(section,key)

    def get_io_config_path_attr_by_section(self, section, key):
        '''Get value of the attribute from the input/ouput config by section'''
        local_path=self.ioconfig.get(section,key)
        gcs_path="gs://"+self.bucket_name+"/"+local_path
        return gcs_path

    def get_model_config_path_attr_by_section(self, section, key):
        '''Get value of the attribute from the input/ouput config by section'''
        local_path=self.modelConfig.get(section,key)
        gcs_path="gs://"+self.bucket_name+"/"+local_path
        return gcs_path

    def get_project_name(self):
        return self.get_io_config_attribute_by_section("project",f"{self.environment}")


# attr=GetConfigAttr()
# print(attr.get_model_config_attribute("bucket_name"))

# print(os.path.join(os.path.dirname(__file__), '..', 'config', 'io_config.config'))