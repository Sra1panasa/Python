from delta.tables import DeltaTable
from pyspark.sql import DataFrame
from pyspark.sql.functions import col
import os, traceback
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.read_config import *
from pyspark.sql.functions import current_timestamp,current_date,to_timestamp, lit
import uuid
class DeltaLakeConnector:
    '''
        In deltalake connector the data is stored in table structure i.e is Deltatable 
        Delta Live Table (DLT) is a framework that can be used for building reliable, maintainable, 
        and testable data processing pipelines on Delta Lake.
    '''

    def __init__(self, pipeline_ctx, spark_ctx, failover_startdate = None,failover_starting_version = "latest", maxFilesPerTrigger = 10) -> None:
        '''
           The constuctors of the Deltalake connector class

           Parameters :
               pipeline_ctx(Object)  :  Pipeline context object
               spark_ctx(Object)     :  pyspark streaming session object
               failover_startdate(Date) : breakpoint date , the previous pipeline failed
               maxFilesPerTrigger(int) : maximum files that can be read per session
 
        '''
        self._pipeline_ctx = pipeline_ctx
        self._spark_ctx =  spark_ctx
        self.fw_logger = Framework_Logger()
        self.failover_startdate = failover_startdate
        self.failover_starting_version = failover_starting_version
        self.maxFilesPerTrigger = maxFilesPerTrigger
        self.triggerInterval = "15 seconds"
        self.environment=os.environ.get('environment')
        self.config = GetConfigAttr()
        self.bucket_name = self.config.get_io_config_attribute_by_section("gcsBucket",f"{self.environment}_bucket")
        self.landing_zone_path="gs://"+self.bucket_name+"/"+self.config.get_io_config_attribute_by_section("kafka", "kafka_payloads_landingpath")
        self.invalid_payloads_quarantinepath="gs://"+self.bucket_name+"/"+self.config.get_io_config_attribute_by_section("kafka", "invalid_payloads_quarantinepath")



        if self._pipeline_ctx.pipeline_type != "batch":
            landing_latest_history_date = self.get_latest_timestamp_from_history("landing")
            if landing_latest_history_date is None:
                #if there is no data 
                self.landing_failover_startdate = None
            else:
                if landing_latest_history_date < str(failover_startdate):
                    self.landing_failover_startdate = landing_latest_history_date
                else:
                    self.landing_failover_startdate = failover_startdate

    #Create a delta table 
    def create_delta_table(self, spark_ctx, delta_table_path):
        '''
          Creating the delta table in the given delta table path

          Parameters:
              spark_ctx(Object) : pyspark streaming session object
              delta_table_path(String) : specifies the  path where delta table created .

          Returns :
               Deltatable(Deltatable)  : Created delta table at the path  

        '''
        self.fw_logger.log_info("Data Ingestion: Deltalake Connector:Delta table is created")
        return DeltaTable.forPath(spark_ctx, delta_table_path)    

    #Check if a delta table exists in the path.
    def check_if_table_exists(self,delta_table_path):
        """
        Checks if a delta table exists.

        Parameters :
            delta_table_path : The path of the delta table
        Returns:
            returns if exists : delta table
                    otherwise : None
        """
        self.fw_logger.log_info('Data Ingestion: Deltalake Connector:Function Call DeltaLake check_if_table_exists')
        try:
            delta_table = self.create_delta_table(self._spark_ctx, delta_table_path)
            return delta_table
        except Exception as e:
            self.fw_logger.log_error("Data Ingestion: Deltalake Connector:Exception occurred in check_if_table_exists.." +str(e))


    #Read the delta table at the path and return it as a dataframe
    def read(self,delta_table_path) -> DataFrame:
        """
        Batch Reads the delta table as dataframe

        Parameters :
            delta_table_path : Path of the delta Table
        Returns:
            returns dataframe
        """
        self.fw_logger.log_info('Data Ingestion: Deltalake Connector:Function Call DeltaLake read')
        try:
            return self._spark_ctx.read.format("delta").load(delta_table_path)
        except Exception as e:
            self.fw_logger.log_error("Data Ingestion: Deltalake Connector:Exception occurred in read function with delta table path.." +str(e))
            self.fw_logger.log_error(traceback.format_exc())

    #  Reads the delta table in the landing zone and returns it as a dataframe
    def read_landing(self) -> DataFrame:
        """
        Batch Reads the delta table as dataframe from landing zone

        Returns:
            returns dataframe
        """
        #df = spark.read.format("delta").option("timestampAsOf", last_week).load("/tmp/delta/events")
        self.fw_logger.log_info('Data Ingestion: Deltalake Connector:Function Call DeltaLake read_landing')
        try:    
            delta_table_path = self.landing_zone_path
            return self._spark_ctx.read.format("delta").load(delta_table_path)
        except Exception as e:
            self.fw_logger.log_error("Data Ingestion: Deltalake Connector:Exception occurred in read_landing function ..." +str(e))
            self.fw_logger.log_error(traceback.format_exc())
    

    #  spark Stream session reads the delta table as dataframe from landing zone
    def stream_read_landing(self):
        """
        Stream Reads the delta table as dataframe from landing zone

        Returns:
            returns dataframe
        """
        self.fw_logger.log_info('Data Ingestion: Deltalake Connector:Function Call DeltaLake stream_read_landing')
        try:
            # delta_table_path = "gs://"+self.pipeline_ctx.landing_zone +path
            delta_table_path = self.landing_zone_path
            if self.landing_failover_startdate:
                return self._spark_ctx.readStream.format("delta") \
                .option("startingTimestamp",self.landing_failover_startdate) \
                .option("maxFilesPerTrigger",self.maxFilesPerTrigger).load(delta_table_path)
            else:
                return self._spark_ctx.readStream.format("delta") \
                    .option("startingVersion",self.failover_starting_version) \
                    .option("maxFilesPerTrigger",self.maxFilesPerTrigger).load(delta_table_path)
        except Exception as e:
            self.fw_logger.log_error("Data Ingestion: Deltalake Connector:Exception occurred in stream_read_landing function ..." +str(e))
            self.fw_logger.log_error(traceback.format_exc())


    #  Spark streaming session writes the dataframe into the delta table at the landing zone path
    def stream_write_landing(self,stream_df,checkpoint = None, partition_column = None):
        """
        Stream Writes dataframe to the delta table path in landing zone

        Parameters:
            stream_df : dataframe which has to be written
            delta_table_path : The path of the delta table
            checkpoint : checkpoint location
        Returns:
            returns None
        """
        self.fw_logger.log_info('Data Ingestion: Deltalake Connector:Function Call DeltaLake stream_write_landing')
        try:
            # delta_table_path = "gs://"+self.pipeline_ctx.landing_zone + path
            delta_table_path = self.landing_zone_path
            if checkpoint is None:
                checkpoint = os.path.join(delta_table_path, "_checkpoints")

            if partition_column:
                DeltaTable.createIfNotExists(self._spark_ctx)\
                    .location(delta_table_path)\
                    .addColumns(stream_df.schema)\
                    .partitionedBy(partition_column)\
                    .execute()
                stream_df.writeStream \
                    .format("delta") \
                    .queryName("delta_write_landing_p_"+ self._pipeline_ctx.pipeline_name + "_"+str(uuid.uuid4())) \
                    .outputMode("append") \
                    .partitionBy(partition_column)\
                    .option("mergeSchema", "true") \
                    .option("checkpointLocation", checkpoint) \
                    .trigger(processingTime=self.triggerInterval)\
                    .start(delta_table_path)

            else:
                DeltaTable.createIfNotExists(self._spark_ctx)\
                    .location(delta_table_path)\
                    .addColumns(stream_df.schema)\
                    .execute()

                stream_df.writeStream \
                    .format("delta") \
                    .queryName("delta_write_landing_"+ self._pipeline_ctx.pipeline_name + "_"+str(uuid.uuid4())) \
                    .outputMode("append") \
                    .option("mergeSchema", "true") \
                    .option("checkpointLocation", checkpoint) \
                    .trigger(processingTime=self.triggerInterval)\
                    .start(delta_table_path)
        except Exception as e:
            self.fw_logger.log_error("Data Ingestion: Deltalake Connector:Exception occurred in stream_write_landing.."+str(e))
            self.fw_logger.log_error(traceback.format_exc())

    #
    def write_transaction_log(self, df, uid, id, stage, message, checkpoint = None, type="stream"):
        try:
            delta_path = self.get_delta_path("transaction_log")

            if checkpoint is None:
                checkpoint = os.path.join(delta_path, "_checkpoints/"+message)

            if uid and id:
                df = df.select(col(uid).alias("uid"), col(id).alias("id"))
            elif uid:
                df = df.select(col(uid).alias("uid"))
                df = df.withColumn("id", lit(None).cast("string"))
            elif id:
                df = df.select(col(id).alias("id"))
                df = df.withColumn("uid", lit(None).cast("string"))
            
            df = df.withColumn("date", current_date().cast("string")) \
                .withColumn("timestamp", to_timestamp(current_timestamp(),"HH mm ss").cast("string")) \
                .withColumn("stage", lit(stage)) \
                .withColumn("process", lit(message))

            if type == "stream":
                self.stream_write(stage, df, delta_path, checkpoint, partition_columns=['date','stage'])
            if type == "batch":
                self.write(df, delta_path, partition_column=['date','stage'])

        except Exception as e:
            self.fw_logger.log_error("Data Ingestion: Deltalake Connector:Exception occurred: %s",traceback.format_exc())

    #Read latest timestamp
    def get_latest_timestamp_from_history(self,zone):
        try:
            deltaTable = DeltaTable.forPath(self._spark_ctx, self.landing_zone_path)
            latestTimestamp = deltaTable.history().first()['timestamp'].strftime("%Y-%m-%dT%H:%M:%S")+".000Z"
            return latestTimestamp
        except Exception as e:
            self.fw_logger.log_error("Data Ingestion: Deltalake Connector:Exception occurred while reading latest timestamp.."+str(e))
            self.fw_logger.log_error(traceback.format_exc())
            return None

    # Invalid dataframe are written into delta table at quarantine path
    def write_quarantine(self, df, partition_column = None) -> None:
        """
        Writes dataframe to the delta table path

        Parameters :
            df : dataframe which has to be written
            delta_table_path : The path of the delta table
        Returns:
            returns None
        """
        self.fw_logger.log_info('Data Ingestion: Deltalake Connector:Function Call DeltaLake write_raw')
        try:            
            delta_table_path = self.invalid_payloads_quarantinepath
            if partition_column:
                df.write.format("delta").mode("append").partitionBy(partition_column).save(delta_table_path)
                self.fw_logger.log_info('Data Ingestion: Deltalake Connector:Invalid payloads written to quarantine path..')
            else:
                df.write.format("delta").mode("append").save(delta_table_path)
        except Exception as E:
            self.fw_logger.log_error("Data Ingestion: Deltalake Connector:Exception occurred: %s",traceback.format_exc())


    
    def stream_write_quarantine(self,stream_df,checkpoint = None, partition_column = None):
        """
        Stream Writes dataframe to the delta table path in landing zone

        Parameters:
            stream_df : dataframe which has to be written
            delta_table_path : The path of the delta table
            checkpoint : checkpoint location
        Returns:
            returns None
        """
        self.fw_logger.log_info('Data Ingestion: Deltalake Connector:Function Call DeltaLake stream_write_landing')
        try:
            # delta_table_path = "gs://"+self.pipeline_ctx.landing_zone + path
            delta_table_path = self.invalid_payloads_quarantinepath
            if checkpoint is None:
                checkpoint = os.path.join(delta_table_path, "_checkpoints")

            if partition_column:
                DeltaTable.createIfNotExists(self._spark_ctx)\
                    .location(delta_table_path)\
                    .addColumns(stream_df.schema)\
                    .partitionedBy(partition_column)\
                    .execute()
                stream_df.writeStream \
                    .format("delta") \
                    .queryName("delta_write_landing_p_"+ self._pipeline_ctx.pipeline_name + "_"+str(uuid.uuid4())) \
                    .outputMode("append") \
                    .partitionBy(partition_column)\
                    .option("mergeSchema", "true") \
                    .option("checkpointLocation", checkpoint) \
                    .trigger(processingTime=self.triggerInterval)\
                    .start(delta_table_path)

            else:
                DeltaTable.createIfNotExists(self._spark_ctx)\
                    .location(delta_table_path)\
                    .addColumns(stream_df.schema)\
                    .execute()

                stream_df.writeStream \
                    .format("delta") \
                    .queryName("delta_write_landing_"+ self._pipeline_ctx.pipeline_name + "_"+str(uuid.uuid4())) \
                    .outputMode("append") \
                    .option("mergeSchema", "true") \
                    .option("checkpointLocation", checkpoint) \
                    .trigger(processingTime=self.triggerInterval)\
                    .start(delta_table_path)
        except Exception as e:
            self.fw_logger.log_error("Data Ingestion: Deltalake Connector:Exception occurred in stream_write_landing.."+str(e))
            self.fw_logger.log_error(traceback.format_exc())

    def read_quarantine(self) -> DataFrame:
        """
        Batch Reads the delta table as dataframe from landing zone

        Returns:
            returns dataframe
        """
        #df = spark.read.format("delta").option("timestampAsOf", last_week).load("/tmp/delta/events")
        self.fw_logger.log_info('Data Ingestion: Deltalake Connector:Function Call DeltaLake read_landing')
        try:    
            delta_table_path = self.invalid_payloads_quarantinepath
            return self._spark_ctx.read.format("delta").load(delta_table_path)
        except Exception as e:
            self.fw_logger.log_error("Data Ingestion: Deltalake Connector:Exception occurred in read_landing function ..." +str(e))
            self.fw_logger.log_error(traceback.format_exc())

    
    def delete_from_quarantine(self, spark_ctx):
        self.fw_logger.info('Function Call DeltaLake delete_from_quarantine')
        delta_table_path = self.get_delta_path("quarantine")
        delta_table = self.create_delta_table(spark_ctx, delta_table_path)
        
        try:
            if delta_table:
                delta_table.delete(col("processed") == 1)
        except Exception as E:
            self.fw_logger.error("Exception occurred: %s",traceback.format_exc())