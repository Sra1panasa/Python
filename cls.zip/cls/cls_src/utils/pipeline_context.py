from pyspark.sql import SparkSession
from pyspark.sql import DataFrame
from delta import *
import traceback
from cls_src.utils.read_config import *
from cls_src.utils.hvac_connector import Vault
from cls_src.utils.logger import Framework_Logger

class PipelineContext:
  '''
     In Pipeline Context class the spark streaming/batch sessions  are established 
  '''
  
  def __init__(self, pipeline_type, pipeline_name = None,
    config_file = None):
    '''
       Constructors of PipelineContext class

         Parameters :
           pipeline_type(String)  : Specifying the type of pipeline(stream  or batch)
           pipeline_name(String)  : Specifying the pipeline's name

    '''

    self.kafka_env = "kafka"
    self.pipeline_type = pipeline_type
    self.pipeline_name = pipeline_name
    self.config_parser = GetConfigAttr()
    self.fw_logger = Framework_Logger()

    self.environment = os.environ.get('environment') # dev
    
    if self.environment=="dsstg":
        self.confluentApiKey = "L7MKICZIKBXIPDIB"
        self.confluentSecret = "IeWa1s0Yp3SZPOfug0pa3Eyq0Phkg96z3R7P0J80T3QuvLSKZ6gsPu8egKUTSQ4Q"
        self.confluentRegistryApiKey = "SVMSWHX4WDORM2JW"
        self.confluentRegistrySecret = "5I+7A2CSh5eTG5DnZKZh9A6EdCMDgu/wk5NduOFy24mLi+Iy9oodBc6hHEoYJAaz"
        self.confluentBootstrapServers="" 
        self.schema_registry_url = "https://psrc-xqq6z.us-central1.gcp.confluent.cloud"
        self.confluent_host = "pkc-wzdn9.us-central1.gcp.confluent.cloud:9092"
    
    else:
    #self.region = region
      vault_obj = Vault(self.environment)
      print(self.environment)

      kafkacreds = vault_obj.get_kakfa_creds()
      if kafkacreds:
          self.confluentApiKey = kafkacreds["confluentApiKey"]
          self.confluentSecret = kafkacreds["confluentSecret"]
          self.confluentRegistryApiKey = kafkacreds["confluentRegistryApiKey"]
          self.confluentRegistrySecret = kafkacreds["confluentRegistrySecret"]
          self.confluentBootstrapServers="" 
          self.schema_registry_url =  kafkacreds["schemaRegistryUrl"]
          self.confluent_host = kafkacreds["host"]
    
    self.confluent_sasl_mechanism = self.config_parser.get_io_config_attribute_by_section("kafka","sasl_mechanism")
    self.confluent_protocol = self.config_parser.get_io_config_attribute_by_section("kafka","protocol")
    self.confluent_offset_status = self.config_parser.get_io_config_attribute_by_section("kafka","offset_status")
    self.kafka_topic = self.config_parser.get_io_config_attribute_by_section("topicnames",f"{self.environment}")
    

  # Creates spark streaming session
  def create_pyspark_streaming_session(self):
    '''
        Creating a pyspark streaming session 
         Parameters : None
         Returns    :
             s(Sparksession object) : return a spark streaming session object configured with pipeline name and environment
    '''
    try:
      s = (SparkSession.builder \
          .appName(self.pipeline_name+ "_"+ self.environment) \
          .getOrCreate()) 
      s.sparkContext.setLogLevel('WARN')
      self.fw_logger.log_info("Data Ingestion : Created pyspark stream session")
      return s
      
    except Exception as e:
      self.fw_logger.log_error("Data Ingestion : Exception occurred while creating pyspark streaming session .."+str(e))
      self.fw_logger.log_error(str(traceback.format_exc()))   
            
  # Creates spark batch session
  def create_pyspark_batch_session(self):

    '''
       Creating pyspark batch session 
       Paramters : None
       Returns   :
           s(SparkSession Object) : return a spark batch session object configured with pipeline name and environment

    '''
    try:
      s = (SparkSession.builder
          .appName(self.pipeline+ "_"+ self.environment)
          .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
          .config("spark.submit.deployMode","cluster") \
          .getOrCreate())
      s.sparkContext.setLogLevel('WARN')
      self.fw_logger.log_info("Data Ingestion : Created pyspark batch session")
      return s
    except Exception as e:
      self.fw_logger.log_error("Data Ingestion :Exception occurred: %s"+ str(traceback.format_exc()))  