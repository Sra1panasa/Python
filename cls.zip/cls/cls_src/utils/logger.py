from ctypes import util
import re
import os
import sys
import logging

class Framework_Logger:
    logger_temp_path = "/databricks/driver/classification_logs/"
    if( not os.path.exists(logger_temp_path)):
        os.mkdir(logger_temp_path)
    log_file=logger_temp_path+"classification_pipeline.log"
    logging.basicConfig(filename =log_file )
    logger = logging.getLogger("classification_logs")
    logger.setLevel(logging.DEBUG)
    fn=logging.FileHandler(log_file,mode="a")
    ch=logging.StreamHandler()
    ch.setLevel(logging.DEBUG)
    formatter=logging.Formatter('%(asctime)s %(levelname)-15s %(name)-8s %(message)s')
    fn.setFormatter(formatter)
    ch.setFormatter(formatter)
    if(logger.hasHandlers()):
        logger.handlers.clear()
    logger.addHandler(fn)
    logger.addHandler(ch)
    # if(~os.path.exists(logger_temp_path)):
    #     os.mkdir(logger_temp_path)
    # logging.basicConfig(filename = logger_temp_path+"classification.log", format='%(asctime)s %(levelname)-15s %(name)-8s %(message)s')
    # logger = logging.getLogger()
    # handler = logging.StreamHandler(stream=sys.stdout)
    pattern = re.compile(r'<[^>]*>')
    # logger.addHandler(handler)
    
    @staticmethod  
    def log_debug(text):
        Framework_Logger.logger.debug(text)
        
    @staticmethod  
    def log_info(text):
        Framework_Logger.logger.info( text)
        
    @staticmethod  
    def log_warning(text):
        Framework_Logger.logger.warning( text)
        
    @staticmethod  
    def log_error(text):
        Framework_Logger.logger.error(text)
        
    @staticmethod  
    def log_critical(text):
        Framework_Logger.logger.log( text)

    
    @staticmethod  
    def strip_html(text):
        try: 
            return Framework_Logger.pattern.sub('', text)
        except:
            return text

    @staticmethod  
    def strip_prefix(text):
        try:
            if text is not None and text != "":
                return text.split("/")[-1].lower()
            else:
                return text
        except:
            return text

    

    # @staticmethod  
    # def log_file(text, fname='./files/stardog_logs.txt', level = logging.DEBUG):
    #     formatter = logging.Formatter('%(asctime)s | %(levelname)s | %(message)s')
    #     framework_logger.handler = logging.FileHandler(fname)
    #     framework_logger.handler.setLevel(logging.DEBUG)
    #     framework_logger.handler.setFormatter(formatter)
    #     if (framework_logger.logger.hasHandlers()):
    #         framework_logger.logger.handlers.clear()
    #     framework_logger.logger.addHandler(framework_logger.handler)
    #     framework_logger.logger.log(level, text)