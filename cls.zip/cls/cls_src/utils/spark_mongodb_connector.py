import pandas as pd
import traceback
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.read_config import *
from cls_src.utils.hvac_connector import Vault
import uuid
import pymongo
import json


class SparkMongoConnector:

    def __init__(self, region = "us") -> None:

        '''
         Constructors of the Pymongoconnector class

        '''
        self.confg=GetConfigAttr()
        self.logger=Framework_Logger()
        self.logger.log_info('Mongodb :inside mongodb connector init !!!')

        self.environment = os.environ.get('environment')
        print(self.environment)
        self.region = region
        self.pipeline="gcstomongostreaming"

        if self.environment == "dsstg":
            self.mongo_username = "datascience-apps"
            self.mongo_password = "OhIZjsOllNrX0N4S"
        else:
            vault_obj = Vault(self.environment)
            mongoDbcreds = vault_obj.get_mongoDb_creds()
            if mongoDbcreds:
                self.mongo_username = mongoDbcreds['mongoUser']
                self.mongo_password = mongoDbcreds['mongoPass']
            
        self.mongo_checkpoint = self.confg.get_io_config_attribute_by_section("mongoDB","checkpoint")
        print(self.mongo_checkpoint)
        mongo_server_end_point = self.confg.get_io_config_attribute_by_section("mongoDB",f"{self.environment}_url")
        if self.environment == "local":
            self._uri = "mongodb://%s:%s@%s"% (self.mongo_username,self.mongo_password, mongo_server_end_point)
        else:
            self._uri ="mongodb+srv://%s:%s@%s/myFirstDatabase?retryWrites=true&w=majority"% (self.mongo_username,self.mongo_password, mongo_server_end_point)
 
        self._database = self.confg.get_io_config_attribute_by_section("mongoDB","mongodb_database")
        self.triggerInterval = "15 seconds"

        self._collection = "criminal_data_raw_stream_valid"

        self.write_conflict_retry_attempts = 3
        self.write_conflict_retry_delay = 5 # in seconds

    def get_mongo_connection_config(self, query,collection):
        return query.option("uri",self._uri).option("database",self._database).option("collection",collection)


    def upsert(self,df,collection,batch_id="001",shardkey=None, retry_attempts = None,raise_error = False):

        df = df.persist()
        try:
            # if shardkey is None:
            #     shardkey = "_id"

            key_string = ""
            if retry_attempts is None:
                retry_attemps = self.write_conflict_retry_attempts
                
            if isinstance(shardkey, list):
                key_dict ={}
                for key in shardkey:
                    key_dict[key] = "hashed"
                key_string = json.dumps(key_dict)
            elif isinstance(shardkey, str):
                key_string = json.dumps({shardkey:"hashed"})

            query = self.get_mongo_connection_config(df.write.format("mongo").mode("append"),collection)
            query = query.option("replaceDocument",False)
            if key_string != "":
                query = query.option("shardkey",key_string)

            query.save()

        except Exception as e:
            self.logger.log_error("Exception occurred: %s", traceback.format_exc())
                    # if self.write_conflict_retry:
            if retry_attempts > 0:
                        #Exponentially increase the sleep time - formula = retry_delay * 2^retry_count
                sleep_time = self.write_conflict_retry_delay * pow(2 , (self.write_conflict_retry_attempts - retry_attempts))
                time.sleep(sleep_time)
                self.logger.log_info("Retrying mongodb merge for ", traceback.format_exc())
                self.upsert(self,df,batch_id=batch_id,shardkey=shardkey, retry_attempts = retry_attempts-1)
            else:
                self.logger.log_error(error_codes.get_error_message(error_codes.FW_MONGO_UPSERT_RETRY_ERROR))
                if raise_error:
                    raise e
        df.unpersist()


    def stream_upsert(self, stream_df, collection,shardkey=None, checkpoint=None):
        """
        Stream upserts dataframe to mongo db based on the shardkey

        Args:
            df : dataframe which has to be upserted
            shardkey : key to uniquely identify  a record.  
        Returns:
            returns dataframe
        """
        self.logger.log_info("Function Call - Mongo DB stream upsert")
        if checkpoint is None:
            checkpoint = self.mongo_checkpoint

        try:
            stream_df.writeStream\
                    .option("checkpointLocation", checkpoint)\
                    .queryName("mongodb_write_upsert_"+ self.pipeline + "_"+str(uuid.uuid4()))\
                    .foreachBatch(lambda df, batch_id : self.upsert(df,collection, batch_id,shardkey=shardkey))\
                    .trigger(processingTime=self.triggerInterval).start()
        except Exception as E:
            self.logger.log_error("Exception occurred: %s",traceback.format_exc())

    
    def read(self, spark_ctx,collection):
        """
        Reads data from mongo db as dataframe

        Args:
            aprk_ctx : spark context
        Returns:
            returns dataframe
        """
        self.logger.log_info('Function Call MongoDb Read')

        try: 
            return self.get_mongo_connection_config(spark_ctx.read.format("mongo"),collection).load()
        except Exception as E:
            self.logger.log_error("Exception occurred: %s",traceback.format_exc())

    def write(self, df,collection, epochId = "epochId",shardkey = None) -> None:
        """
        Writes dataframe to the mongo db

        Args:
            df : dataframe which has to be written
            shardkey : it is a dummy keyword argument added in regional connector to make it compatible with global connector
        Returns:
            returns None
        """
        self.logger.log_info('Function Call MongoDb Write')
        
        try:
            self.get_mongo_connection_config(df.write.format("mongo").mode("append"),collection)\
                .option("writeConcern.w", 2).option("writeConcern.wTimeoutMS",900000) \
                .save()
        except Exception as E:
            self.logger.log_error("Exception occurred: %s",traceback.format_exc())


    def mongo_filter(self, spark_ctx, field_name, field_value):
        value={}
        if isinstance(field_name, str):
            value[field_name] = field_value
        elif isinstance(field_name, list) and isinstance(field_value,list):
            if len(field_name) != len(field_value):
                self.logger.log_error("field name list length and field value list length should match")
                return None

            for name, f_value in zip(field_name, field_value):
                value[name] = f_value

        pipeline = {'$match':value}

        try:            
            filtered_df =self.get_mongo_connection_config(spark_ctx.read.format("mongo")).option("pipeline",str(pipeline)).load()
            return filtered_df
        except Exception as E:
            self.logger.log_error("Exception occurred: %s",traceback.format_exc())