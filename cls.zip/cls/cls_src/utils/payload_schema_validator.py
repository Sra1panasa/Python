validation_schema={
  "$schema": "http://json-schema.org/draft-04/schema#",
  "type": "object",
  "properties": {
    "applicant_data": {
      "type": "object",
      "properties": {
        "request_id": {
          "type": [ "string", "null" ]
        },
        "reg_id": {
          "type": [ "string", "null" ]
        },
        "order_service_id": {
          "type": [ "string", "null" ]
        },
        "order_service_data_source_id": {
          "type": [ "string", "null" ]
        },
        "applicant_id": {
          "type": [ "string", "null" ]
        },
        "first_name": {
          "type": "string"
        },
        "middle_name": {
          "type": [ "string", "null"]
        },
        "last_name": {
         "type": [ "string", "null" ]
        },
        "dob": {
          "type": [ "string", "null"]
        },
        "ssn": {
          "type": [ "string", "null" ]
        },
        "driving_license": {
          "type": [ "string", "null" ]
        },
        "address": {
          "type": "object",
          "properties": {
            "current_address": {
              "type": "object",
              "properties": {
                "address_line1": {
                  "type": [ "string", "null" ]
                },
                "address_line2": {
                  "type": [ "string", "null" ]
                },
                "city": {
                  "type": [ "string", "null" ]
                },
                "county": {
                  "type": [ "string", "null" ]
                },
                "state": {
                  "type": [ "string", "null" ]
                },
                "zip_code": {
                  "type": [ "string", "null" ]
                }
              },
              "required": [
                "address_line1",
                "address_line2",
                "city",
                "county",
                "state",
                "zip_code"
              ]
            },
            "previous_addresses": {
              "type": "array",
              "items": {}
            }
          },
          "required": [
            "current_address",
            "previous_addresses"
          ]
        },
        "county": {
          "type": [ "string", "null"]
        },
        "state": {
          "type": [ "string", "null"]
        },
        "alias_names": {
          "type": "array",
          "items": {}
        },
        "photo_path": {
          "type": [ "string", "null"]
        },
        "education_details": {
          "type": "array",
          "items": {}
        },
        "prev_empoyment_details": {
          "type": "array",
          "items": {}
        },
        "ssn_trace": {
          "type": [ "string", "null"]
        },
        "mvr": {
          "type": [ "string", "null"]
        }
      },
      "required": [
        "request_id",
        "reg_id",
        "order_service_id",
        "order_service_data_source_id",
        "applicant_id",
        "first_name",
        "middle_name",
        "last_name",
        "dob",
        "ssn",
        "driving_license",
        "address",
        "county",
        "state",
        "alias_names",
        #"photo_path",
        "education_details",
        "prev_empoyment_details",
        "ssn_trace",
        "mvr"
      ]
    },
    "court_response": {
      "type": "object",
      "properties": {
        "request_id": {
          "type": [ "string", "null"]
        },
        "reg_id": {
          "type": [ "string", "null"]
        },
        "order_service_id": {
          "type": [ "string", "null"]
        },
        "order_service_data_source_id": {
          "type": [ "string", "null"]
        },
        "source_records": {
          "type": "array",
          "items": [
            {
              "type": "object",
              "properties": {
                "first_name": {
                  "type": [ "string", "null"]
                },
                "middle_name": {
                  "type": [ "string", "null"]
                },
                "last_name": {
                  "type": [ "string", "null"]
                },
                "alias_names": {
                  "type": "array",
                  "items": [
                    {
                      "type": [ "string", "null"]
                    },
                    {
                      "type": [ "string", "null"]
                    }
                  ]
                },
                "dob": {
                  "type": [ "string", "null"]
                },
                "address": {
                  "type": "object",
                  "properties": {
                    "address_line1": {
                      "type": [ "string", "null"]
                    }
                  },
                  "required": [
                    "address_line1"
                  ]
                },
                "county": {
                  "type": [ "string", "null"]
                },
                "state": {
                  "type": [ "string", "null"]
                },
                "court_name": {
                  "type": [ "string", "null"]
                },
                "court_id": {
                  "type": [ "string", "null"]
                },
                "sor_id": {
                  "type": [ "string", "null"]
                },
                "height": {
                  "type": [ "string", "null"]
                },
                "eye_color": {
                  "type": [ "string", "null"]
                },
                "alias": {
                  "type": [ "string", "null"]
                },
                "image": {
                  "type": [ "string", "null"]
                },
                "government_id": {
                  "type": [ "string", "null"]
                },
                "driving_license": {
                  "type": [ "string", "null"]
                },
                "criminal_case_number": {
                  "type": [ "string", "null"]
                },
                "charge_info": {
                  "type": "array",
                  "items": [
                    {
                      "type": "object",
                      "properties": {
                        "offense_literal": {
                          "type": [ "string", "null"]
                        },
                        "degree_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "severity": {
                          "type": [ "string", "null"]
                        },
                        "nature_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "disposition_literal": {
                          "type": [ "string", "null"]
                        },
                        "disposition_category": {
                          "type": [ "string", "null"]
                        },
                        "disposition_date": {
                          "type": [ "string", "null"]
                        },
                        "offense_date": {
                          "type": [ "string", "null"]
                        },
                        "arrest_date": {
                          "type": [ "string", "null"]
                        }
                      },
                      "required": [
                        "offense_literal",
                        "degree_of_offense",
                        #"severity",
                        "nature_of_offense",
                        "disposition_literal",
                        "disposition_category",
                        #"disposition_date",
                        #"offense_date",
                        #"arrest_date"
                      ]
                    },
                    {
                      "type": "object",
                      "properties": {
                        "offense_literal": {
                          "type": [ "string", "null"]
                        },
                        "degree_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "severity": {
                          "type": [ "string", "null"]
                        },
                        "nature_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "disposition_literal": {
                          "type": [ "string", "null"]
                        },
                        "disposition_category": {
                          "type": [ "string", "null"]
                        },
                        "disposition_date": {
                          "type": [ "string", "null"]
                        },
                        "offense_date": {
                          "type": [ "string", "null"]
                        },
                        "arrest_date": {
                          "type": [ "string", "null"]
                        }
                      },
                      "required": [
                        "offense_literal",
                        "degree_of_offense",
                        #"severity",
                        "nature_of_offense",
                        "disposition_literal",
                        "disposition_category",
                        #"disposition_date",
                        #"offense_date",
                        #"arrest_date"
                      ]
                    }
                  ]
                },
                "parole_info": {
                  "type": [ "string", "null"]
                },
                "jail_time": {
                  "type": [ "string", "null"]
                },
                "suppression_status": {
                  "type": [ "string", "null"]
                }
              },
              "required": [
                "first_name",
                "middle_name",
                "last_name",
                "alias_names",
                "dob",
                "address",
                "county",
                "state",
                #"court_name",
                #"court_id",
                #"sor_id",
                "height",
                "eye_color",
                "alias",
                #"image",
                "government_id",
                "driving_license",
                "criminal_case_number",
                "charge_info",
                "parole_info",
                "jail_time",
                "suppression_status"
              ]
            },
            {
              "type": "object",
              "properties": {
                "first_name": {
                  "type": [ "string", "null"]
                },
                "middle_name": {
                  "type": [ "string", "null"]
                },
                "last_name": {
                  "type": [ "string", "null"]
                },
                "alias_names": {
                  "type": "array",
                  "items": [
                    {
                      "type": [ "string", "null"]
                    },
                    {
                      "type": [ "string", "null"]
                    }
                  ]
                },
                "dob": {
                  "type": [ "string", "null"]
                },
                "address": {
                  "type": "object",
                  "properties": {
                    "address_line1": {
                      "type": [ "string", "null"]
                    }
                  },
                  "required": [
                    "address_line1"
                  ]
                },
                "county": {
                  "type": [ "string", "null"]
                },
                "state": {
                  "type": [ "string", "null"]
                },
                "court_name": {
                  "type": [ "string", "null"]
                },
                "court_id": {
                  "type": [ "string", "null"]
                },
                "sor_id": {
                  "type": [ "string", "null"]
                },
                "height": {
                  "type": [ "string", "null"]
                },
                "eye_color": {
                  "type": [ "string", "null"]
                },
                "alias": {
                  "type": [ "string", "null"]
                },
                "image": {
                  "type": [ "string", "null"]
                },
                "government_id": {
                  "type": [ "string", "null"]
                },
                "driving_license": {
                  "type": [ "string", "null"]
                },
                "criminal_case_number": {
                  "type": [ "string", "null"]
                },
                "charge_info": {
                  "type": "array",
                  "items": [
                    {
                      "type": "object",
                      "properties": {
                        "offense_literal": {
                          "type": [ "string", "null"]
                        },
                        "degree_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "severity": {
                          "type": [ "string", "null"]
                        },
                        "nature_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "disposition_literal": {
                          "type": [ "string", "null"]
                        },
                        "disposition_category": {
                          "type": [ "string", "null"]
                        },
                        "disposition_date": {
                          "type": [ "string", "null"]
                        },
                        "offense_date": {
                          "type": [ "string", "null"]
                        },
                        "arrest_date": {
                          "type": [ "string", "null"]
                        }
                      },
                      "required": [
                        "offense_literal",
                        "degree_of_offense",
                        #"severity",
                        "nature_of_offense",
                        "disposition_literal",
                        "disposition_category",
                        #"disposition_date",
                        #"offense_date",
                        #"arrest_date"
                      ]
                    },
                    {
                      "type": "object",
                      "properties": {
                        "offense_literal": {
                          "type": [ "string", "null"]
                        },
                        "degree_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "severity": {
                          "type": [ "string", "null"]
                        },
                        "nature_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "disposition_literal": {
                          "type": [ "string", "null"]
                        },
                        "disposition_category": {
                          "type": [ "string", "null"]
                        },
                        "disposition_date": {
                          "type": [ "string", "null"]
                        },
                        "offense_date": {
                          "type": [ "string", "null"]
                        },
                        "arrest_date": {
                          "type": [ "string", "null"]
                        }
                      },
                      "required": [
                        "offense_literal",
                        "degree_of_offense",
                        #"severity",
                        "nature_of_offense",
                        "disposition_literal",
                        "disposition_category",
                        #"disposition_date",
                        #"offense_date",
                        #"arrest_date"
                      ]
                    }
                  ]
                },
                "parole_info": {
                  "type": [ "string", "null"]
                },
                "jail_time": {
                  "type": [ "string", "null"]
                },
                "suppression_status": {
                  "type": [ "string", "null"]
                }
              },
              "required": [
                "first_name",
                "middle_name",
                "last_name",
                "alias_names",
                "dob",
                "address",
                "county",
                "state",
                #"court_name",
                #"court_id",
                #"sor_id",
                "height",
                "eye_color",
                "alias",
                #"image",
                "government_id",
                "driving_license",
                "criminal_case_number",
                "charge_info",
                "parole_info",
                "jail_time",
                "suppression_status"
              ]
            }
          ]
        },
        "target_records": {
          "type": "array",
          "items": [
            {
              "type": "object",
              "properties": {
                "first_name": {
                  "type": [ "string", "null"]
                },
                "middle_name": {
                  "type": [ "string", "null"]
                },
                "last_name": {
                  "type": [ "string", "null"]
                },
                "alias_names": {
                  "type": "array",
                  "items": [
                    {
                      "type": [ "string", "null"]
                    },
                    {
                      "type": [ "string", "null"]
                    }
                  ]
                },
                "dob": {
                  "type": [ "string", "null"]
                },
                "address": {
                  "type": "object",
                  "properties": {
                    "address_line1": {
                      "type": [ "string", "null"]
                    },
                    "address_line2": {
                      "type": [ "string", "null"]
                    },
                    "city": {
                      "type": [ "string", "null"]
                    },
                    "county": {
                      "type": [ "string", "null"]
                    },
                    "state": {
                      "type": [ "string", "null"]
                    },
                    "zip_code": {
                      "type": [ "string", "null"]
                    }
                  },
                  "required": [
                    "address_line1",
                    "address_line2",
                    "city",
                    "county",
                    "state",
                    "zip_code"
                  ]
                },
                "county": {
                  "type": [ "string", "null"]
                },
                "state": {
                  "type": [ "string", "null"]
                },
                "court_name": {
                  "type": [ "string", "null"]
                },
                "court_id": {
                  "type": [ "string", "null"]
                },
                "sor_id": {
                  "type": [ "string", "null"]
                },
                "height": {
                  "type": [ "string", "null"]
                },
                "eye_color": {
                  "type": [ "string", "null"]
                },
                "alias": {
                  "type": [ "string", "null"]
                },
                "image": {
                  "type": [ "string", "null"]
                },
                "government_id": {
                  "type": [ "string", "null"]
                },
                "driving_license": {
                  "type": [ "string", "null"]
                },
                "criminal_case_number": {
                  "type": [ "string", "null"]
                },
                "charge_info": {
                  "type": "array",
                  "items": [
                    {
                      "type": "object",
                      "properties": {
                        "offense_literal": {
                          "type": [ "string", "null"]
                        },
                        "degree_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "severity": {
                          "type": [ "string", "null"]
                        },
                        "nature_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "disposition_literal": {
                          "type": [ "string", "null"]
                        },
                        "disposition_category": {
                          "type": [ "string", "null"]
                        },
                        "disposition_date": {
                          "type": [ "string", "null"]
                        },
                        "offense_date": {
                          "type": [ "string", "null"]
                        },
                        "arrest_date": {
                          "type": [ "string", "null"]
                        }
                      },
                      "required": [
                        "offense_literal",
                        "degree_of_offense",
                        #"severity",
                        "nature_of_offense",
                        "disposition_literal",
                        "disposition_category",
                        #"disposition_date",
                        #"offense_date",
                        #"arrest_date"
                      ]
                    }
                  ]
                },
                "parole_info": {
                  "type": [ "string", "null"]
                },
                "jail_time": {
                  "type": [ "string", "null"]
                },
                "suppression_status": {
                  "type": [ "string", "null"]
                }
              },
              "required": [
                "first_name",
                "middle_name",
                "last_name",
                "alias_names",
                "dob",
                "address",
                "county",
                "state",
                #"court_name",
                #"court_id",
                #"sor_id",
                "height",
                "eye_color",
                "alias",
                #"image",
                "government_id",
                "driving_license",
                "criminal_case_number",
                "charge_info",
                "parole_info",
                "jail_time",
                "suppression_status"
              ]
            },
            {
              "type": "object",
              "properties": {
                "first_name": {
                  "type": [ "string", "null"]
                },
                "middle_name": {
                  "type": [ "string", "null"]
                },
                "last_name": {
                  "type": [ "string", "null"]
                },
                "alias_names": {
                  "type": "array",
                  "items": [
                    {
                      "type": [ "string", "null"]
                    },
                    {
                      "type": [ "string", "null"]
                    }
                  ]
                },
                "dob": {
                  "type": [ "string", "null"]
                },
                "address": {
                  "type": "object",
                  "properties": {
                    "address_line1": {
                      "type": [ "string", "null"]
                    },
                    "address_line2": {
                      "type": [ "string", "null"]
                    },
                    "city": {
                      "type": [ "string", "null"]
                    },
                    "county": {
                      "type": [ "string", "null"]
                    },
                    "state": {
                      "type": [ "string", "null"]
                    },
                    "zip_code": {
                      "type": [ "string", "null"]
                    }
                  },
                  "required": [
                    "address_line1",
                    "address_line2",
                    "city",
                    "county",
                    "state",
                    "zip_code"
                  ]
                },
                "county": {
                  "type": [ "string", "null"]
                },
                "state": {
                  "type": [ "string", "null"]
                },
                "court_name": {
                  "type": [ "string", "null"]
                },
                "court_id": {
                  "type": [ "string", "null"]
                },
                "sor_id": {
                  "type": [ "string", "null"]
                },
                "height": {
                  "type": [ "string", "null"]
                },
                "eye_color": {
                  "type": [ "string", "null"]
                },
                "alias": {
                  "type": [ "string", "null"]
                },
                "image": {
                  "type": [ "string", "null"]
                },
                "government_id": {
                  "type": [ "string", "null"]
                },
                "driving_license": {
                  "type": [ "string", "null"]
                },
                "criminal_case_number": {
                  "type": [ "string", "null"]
                },
                "charge_info": {
                  "type": "array",
                  "items": [
                    {
                      "type": "object",
                      "properties": {
                        "offense_literal": {
                          "type": [ "string", "null"]
                        },
                        "degree_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "severity": {
                          "type": [ "string", "null"]
                        },
                        "nature_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "disposition_literal": {
                          "type": [ "string", "null"]
                        },
                        "disposition_category": {
                          "type": [ "string", "null"]
                        },
                        "disposition_date": {
                          "type": [ "string", "null"]
                        },
                        "offense_date": {
                          "type": [ "string", "null"]
                        },
                        "arrest_date": {
                          "type": [ "string", "null"]
                        }
                      },
                      "required": [
                        "offense_literal",
                        "degree_of_offense",
                        #"severity",
                        "nature_of_offense",
                        "disposition_literal",
                        "disposition_category",
                        #"disposition_date",
                        #"offense_date",
                        #"arrest_date"
                      ]
                    },
                    {
                      "type": "object",
                      "properties": {
                        "offense_literal": {
                          "type": [ "string", "null"]
                        },
                        "degree_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "severity": {
                          "type": [ "string", "null"]
                        },
                        "nature_of_offense": {
                          "type": [ "string", "null"]
                        },
                        "disposition_literal": {
                          "type": [ "string", "null"]
                        },
                        "disposition_category": {
                          "type": [ "string", "null"]
                        },
                        "disposition_date": {
                          "type": [ "string", "null"]
                        },
                        "offense_date": {
                          "type": [ "string", "null"]
                        },
                        "arrest_date": {
                          "type": [ "string", "null"]
                        }
                      },
                      "required": [
                        "offense_literal",
                        "degree_of_offense",
                        #"severity",
                        "nature_of_offense",
                        "disposition_literal",
                        "disposition_category",
                        #"disposition_date",
                        #"offense_date",
                        #"arrest_date"
                      ]
                    }
                  ]
                },
                "parole_info": {
                  "type": [ "string", "null"]
                },
                "jail_time": {
                  "type": [ "string", "null"]
                },
                "suppression_status": {
                  "type": [ "string", "null"]
                }
              },
              "required": [
                "first_name",
                "middle_name",
                "last_name",
                "alias_names",
                "dob",
                "address",
                "county",
                "state",
                #"court_name",
                #"court_id",
                #"sor_id",
                "height",
                "eye_color",
                "alias",
                #"image",
                "government_id",
                "driving_license",
                "criminal_case_number",
                "charge_info",
                "parole_info",
                "jail_time",
                "suppression_status"
              ]
            }
          ]
        },
        "hrg1_results": {
          "type": "object",
          "properties": {
            "request_id": {
              "type": [ "string", "null"]
            },
            "reg_id": {
              "type": [ "string", "null"]
            },
            "order_service_id": {
              "type": [ "string", "null"]
            },
            "hrg1_action": {
              "type": [ "string", "null"]
            },
            "date_submitted": {
              "type": [ "string", "null"]
            },
            "date_closed": {
              "type": [ "string", "null"]
            }
          },
          "required": [
            "request_id",
            "reg_id",
            "order_service_id",
            "hrg1_action",
            "date_submitted",
            "date_closed"
          ]
        }
      },
      "required": [
        "request_id",
        "reg_id",
        "order_service_id",
        "order_service_data_source_id",
        "source_records",
        "target_records",
        "hrg1_results"
      ]
    }
  },
  "required": [
    "applicant_data",
    "court_response"
  ]
}