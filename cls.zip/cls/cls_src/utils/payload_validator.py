import json
from unicodedata import name
import jsonschema
from jsonschema import validate
from pyspark.sql.functions import to_json, col, udf
from pyspark.sql import DataFrame
import pyspark.sql.functions as fn
import traceback
from cls_src.utils.logger import Framework_Logger
from pyspark.sql.types import StructType, StructField, StringType
import pgpy
from google.cloud import storage
import base64 as b64


class validator:
    '''
       In this validator class, the streaming dataframe is validated with the given schema  and converting the subrequest 
       'subrequest' to string and passing it validating function which returns a DF with flag column

    '''
    def __init__(self, template_schema=None, pipeline_name=None):
        self.template_schema=template_schema
        self.fw_logger = Framework_Logger()
        client = storage.Client()
        private_key=None

        for blob in client.list_blobs('bkt-stg-hrgp-ds-us', prefix='ds_zaha_hrg2/kafka_pgp_decryption_keys'):
            if "HireRight_0xBD49B938_SECRET" in str(blob.name).split('/')[-1]:
                private_key = blob.download_as_text(encoding="utf-8")
            
        self.private_key=private_key
        
    # The validating function takes in the streamingDF and validates with the given schema and returns a flag
    # validate is a jsonschema function, where we passing input streamingDF and input json schema
    def validating(self,json_string): 
        '''
            Validates the streaming dataframe with the give json schema

            Parameters : 
                json_string(DataFrame) : Streaming dataframe

            Returns :
                Flag(Boolean)   : If the streaming df is valid True ,else False 

        '''
        self.fw_logger.log_info('Data Ingestion : Payload Validator :calling function validating')
    
        try:
            decrypted_payload=None
            payload_data=b64.b64decode(json_string)
            key, _ = pgpy.PGPKey.from_blob(self.private_key)
            encrypted_msg = pgpy.PGPMessage.from_blob(payload_data)

            with key.unlock('XiYsAXfku3NjnIoOeFxFRphcdZj1nO'):
                decrypted_payload = key.decrypt(encrypted_msg).message

            decrypted_payload = str(decrypted_payload, 'UTF-8')
            validate(json.loads(decrypted_payload),schema=self.template_schema) 
            return str(decrypted_payload),True
        except jsonschema.exceptions.ValidationError as err:
            self.fw_logger.log_error("Data Ingestion : Payload Validator :Exception occurred in json schema validation..." +str(err))
            return str(decrypted_payload),str(err)
        except Exception as e:
            self.fw_logger.log_error("Data Ingestion : Payload Validator :Exception occurred while validating payload.." +str(e))
            self.fw_logger.log_error(traceback.format_exc())
            return str(decrypted_payload),str(e)

    #Creating a UDF for the validating function defined above
    def validation_upstream(self, streaming_df,data_column): 
        '''
           converting the 'subrequest' to string and passing it validating function which returns a DF with flag column indicating True or Flase, if the surequest is valid or invalid.

           Parameters : 
                Streaming_df(DataFrame) : Streaming dataframe

           Returns    : 
                streaming_df.withColumn("subrequest", to_json("subrequest")).withColumn("flag",validating_udf("subrequest"))
               
        '''
        self.fw_logger.log_info('Data Ingestion : Payload Validator :calling function validation_upstream')
        try:
            schema = StructType([StructField("decrypted_data", StringType(), True), StructField("validation_flag", StringType(), True)])
            validating_udf = udf(self.validating,schema)
            decrypted_df=streaming_df.withColumn('decryndflag', validating_udf(col('data'))).select(col('partition'),\
            col('offset'),col('ingested_date'),col('gcs_created_date'),col('id'),col('orderid'),col('orderitemid'),col('data')\
                                                                                                       ,col("decryndflag.*"))
            return decrypted_df
            #return streaming_df.withColumn("validation_flag",validating_udf(data_column)) 
        except Exception as e:
            self.fw_logger.log_error("Data Ingestion : Payload Validator :Exception occurred in validation_upstream.." +str(e))
            self.fw_logger.log_error(traceback.format_exc())
            return str(e)

    def recursive_items(self,dictionary):
        try:
            for key, value in dictionary.items():
                if type(value) is dict:
                    yield (key, value)
                    yield from self.recursive_items(value)
                elif type(value) is list and value:
                    for index in range(len(value)):
                        if type(value[index]) is dict:
                            for ldkey, ldvalue in value[index].items():
                                if type(ldvalue) is dict:
                                    pass
                                elif type(ldvalue) is list:
                                    for ldlindex in range(len(ldvalue)):
                                        if type(ldvalue[ldlindex]) is dict:
                                            for ldldkey, ldldvalue in ldvalue[ldlindex].items():
                                                yield (ldldkey, ldldvalue)

                                else:
                                    yield (ldkey, ldvalue)
                else:
                    yield (key, value)
        except Exception as e:
            self.fw_logger.log_error("Exception Occured in recursive_items func..." +str(e))
            self.fw_logger.log_error(traceback.format_exc())
        
    
    def validate_json_content(self,string_json):
        req_keys={'applicant_data', 'request_id', 'reg_id', 'order_service_id', 'order_service_data_source_id',\
        'applicant_id', 'first_name', 'middle_name', 'last_name', 'dob','address','county',\
        'state','court_id', 'date_submitted', 'criminal_case_number', 'offense_literal', \
        'disposition_literal', 'degree_of_offense', 'disposition_category','hrg1_results','suppression_status'}
        
        json_file_keys=set()
        value_empty_keys=[]
        
        try:
            if string_json != "None":
                json_content_dict = json.loads(str(string_json))
                for key, value in self.recursive_items(json_content_dict):
                    json_file_keys.add(key)
                    if not value and key in req_keys :
                        value_empty_keys.append(key)

                req_keys_not_present=req_keys-json_file_keys
                return json_content_dict['applicant_data']['request_id'],' '.join([str(elem) for elem in req_keys_not_present]),' '.join([str(elem) for elem in value_empty_keys])
            else:
                return "Payload received with empty content","Payload received with empty content","Payload received with empty content"
        except Exception as e:
            self.fw_logger.log_error("Exception Occured in validate_json_content func..." +str(e))
            return str(e),str(e),str(e)