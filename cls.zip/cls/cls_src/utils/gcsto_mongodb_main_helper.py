# Databricks notebook source
from pyspark.sql.functions import *
import traceback
from datetime import date, timedelta
from cls_src.utils.logger import Framework_Logger
from cls_src.utils.read_config import *
from cls_src.utils.read_config import *
from cls_src.utils.pymongo_db_connector import PyMongoConnector
from delta.tables import *
from cls_src.utils.payload_validator import validator
from cls_src.utils.payload_schema_validator import validation_schema
import json
from datetime import datetime
from pyspark.sql.functions import col


class GcsToMongoDbHelper:
    
    def __init__(self,spark_ctx,delta_ctx,ingested_date=None):
        self.log = Framework_Logger()
        self.config_parser = GetConfigAttr()
        self.mongodbconnector = PyMongoConnector()
        self.spark_ctx=spark_ctx
        self.delta_ctx=delta_ctx
        self.ingested_date=ingested_date

    def write_metadata_mongodb(self,count_valid_records,count_invalid_records,ingested_date):
        now = datetime.now()
        # dd/mm/YY H:M:S
        dt_string = now.strftime("%d-%m-%Y %H:%M:%S")
        metadata_dict={}
        metadata_dict["ingestion_date"]=ingested_date
        metadata_dict["total_payloads"]=count_valid_records+count_invalid_records
        metadata_dict["count_valid_payloads"]=count_valid_records
        metadata_dict["count_invalid_payloads"]=count_invalid_records
        metadata_dict["mongodb_created_date"]=dt_string
        
        try:
            self.mongodbconnector.write_records_from_json(metadata_dict, \
                self.config_parser.get_io_config_attribute_by_section("mongoDB", "collection_crim_payload_metadata"))
            self.log.log_info("Successfully written Meta Data to  Mongo DB... ")
        except Exception as e:
            self.log.log_error("Exception occured while writing Meta data to  Mongo DB... "+str(e))


    def write_invalidrecords_quarantinepath(self,invalid_records_df,ingested_date,count_invalid_records=None):
        invalid_payloads_quarantinepath=self.delta_ctx.invalid_payloads_quarantinepath
        
        # Verifies if the specified path exist or not if exists returns deltatable if doesn't exist return none..
        # check_if_table_exists - only checks whether delta table exists or not it will not create the table
        
        # for time being skipping check_if_table_exists since it is taking time 
        """
        path_exist=self.delta_ctx.check_if_table_exists(invalid_payloads_quarantinepath)
        
        # if path exist is none then below script creates deltatable with specified path
        if not path_exist:
            self.log.log_info("Creating Payloads Quarantinepath..."+str(invalid_payloads_quarantinepath))
            DeltaTable.createOrReplace(self.spark_ctx) \
        .addColumn("partition", "STRING") \
        .addColumn("offset", "STRING") \
        .addColumn("ingested_date", "STRING") \
        .addColumn("gcs_created_date", "STRING") \
        .addColumn("id", "STRING") \
        .addColumn("orderid", "STRING")\
        .addColumn("orderitemid", "STRING") \
        .addColumn("data", "STRING") \
        .addColumn("decrypted_data", "STRING") \
        .addColumn("validation_flag", "STRING") \
        .location(invalid_payloads_quarantinepath)\
        .partitionedBy("ingested_date") \
        .execute() 

        """
        try:
            if invalid_records_df.first():
                self.delta_ctx.write_quarantine(invalid_records_df,partition_column = "ingested_date")
            else:
                self.log.log_info("There are no Invalid payloads for ingested date .."+ str(ingested_date))
        except Exception as e:
            self.log.log_error("Exception occured while writing invalid payload to quarantine path.."+str(e))
            self.log.log_error("Exception occured: %s" + str(traceback.format_exc()))


    def write_validrecords_mongodb(self,valid_records_df,ingested_date,count_valid_records=None):

        valid_records_df = valid_records_df.withColumn("mongodb_created_date",date_format(current_timestamp(),"dd-MM-yyyy"))
        valid_records_df = valid_records_df.withColumn("cls_processing_status",lit(0))
        valid_records_df = valid_records_df.withColumn("idr_processing_status",lit(0))
        try:
            if valid_records_df.first():
                pandas_df=valid_records_df.toPandas()
                #print(pandas_df['decrypted_data'])
                pandas_df['decrypted_data'] = pandas_df['decrypted_data'].apply(json.loads)
                collection_name=self.config_parser.get_io_config_attribute_by_section("mongoDB", "collection_criminal_data_raw")
                self.mongodbconnector.write_records_from_df(pandas_df,collection_name)
            else:
                self.log.log_info("There are no Valid payloads for ingested date .."+ str(ingested_date))
        except Exception as e:
            self.log.log_error("Exception occured while writing valid records to mongodb.."+str(e))
            self.log.log_error("Exception occured: %s" + str(traceback.format_exc()))
            

    def delete_ingested_date_payloads(self,ingested_date):
        
        try:
            
            collection_criminal_data_raw = self.config_parser.get_io_config_attribute_by_section("mongoDB", "collection_criminal_data_raw")
            payloads_list = self.mongodbconnector.filter_records_dict(collection_criminal_data_raw,"ingested_date",ingested_date)
            self.log.log_info("Count of payloads from criminal_data_raw for ingested date = "+ingested_date+"is : "+ str(len(payloads_list)))
            
            collection_criminal_payload_metadata = self.config_parser.get_io_config_attribute_by_section("mongoDB", \
                                                                                                         "collection_crim_payload_metadata")
            metadata_payloads_list = self.mongodbconnector.filter_records_dict(collection_criminal_payload_metadata,"ingestion_date",ingested_date)
            self.log.log_info("Count of payloads from  collection_crim_payload_metadata for ingested date = "+ingested_date+" is : "+ \
                        str(len(metadata_payloads_list)))
            
            if len(payloads_list)>0:
                self.mongodbconnector.delete_records_with_keyvalue(collection_criminal_data_raw,"ingested_date",ingested_date) 
            else:
                self.log.log_info("No payloads exist for ingested date = "+ingested_date)
                
            if len(metadata_payloads_list)>0:
                self.mongodbconnector.delete_records_with_keyvalue(collection_criminal_payload_metadata,"ingestion_date",ingested_date) 
            else:
                self.log.log_info("No meta data exist for ingested date = "+ingested_date)
        except Exception as e:
            self.log.log_error("Exception occurred while deleting mongo db records for  ingested date..."+ingested_date+ str(e))

    def decrypt_and_validate_payloads(self,deserlzd_payloads_df):
        try:
            validate_ctx=validator(validation_schema)
            validated_df=validate_ctx.validation_upstream(deserlzd_payloads_df,"data")
            return validated_df
        except Exception as e:
            self.log.log_error("Exception occured while validating payload.."+str(e))
            self.log.log_error("Exception occured: %s" + str(traceback.format_exc()))

    def get_payloads_ingested_date(self,kafka_ctx,delta_ctx,ingested_date):
        df_landing_zone=delta_ctx.read_landing()
        deserlzd_df=None
        ingested_date_df=df_landing_zone.filter(df_landing_zone.ingested_date == ingested_date)

        #first() - 
        if ingested_date_df.first():
            deserlzd_df=kafka_ctx.get_kafka_payload(ingested_date_df)
            return deserlzd_df
        else:
            self.log.log_info("There are no payloads for the ingested date ..."+ ingested_date)
            return deserlzd_df
    
    def delete_ingested_date_payloads_qp(self):
        try:
            invalid_payloads_quarantinepath=self.delta_ctx.invalid_payloads_quarantinepath
            quarantine_df=self.delta_ctx.read_quarantine()
            ingested_date_df=quarantine_df.filter(quarantine_df.ingested_date == self.ingested_date)
            if ingested_date_df.first():
                delta_table = self.delta_ctx.create_delta_table(self._spark_ctx, invalid_payloads_quarantinepath)

                if delta_table:
                    delta_table.delete(col("ingested_date") == self.ingested_date)
                    self.log.log_info("Payloads successfully deleted for ingested date ..."+ self.ingested_date)
        except Exception as e:
            self.log.log_error("Exception occured while deleting payloads from quarantinepath ..."+str(e))
            self.log.log_error("Exception occured: %s" + str(traceback.format_exc()))    