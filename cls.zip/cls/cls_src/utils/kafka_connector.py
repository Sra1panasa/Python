import pyspark.sql.functions as fn
from pyspark.sql.types import StringType
from pyspark.sql.functions import col,get_json_object, udf,lit
from confluent_kafka import KafkaError, KafkaException
from confluent_kafka.schema_registry.avro import AvroDeserializer, AvroSerializer, _schema_loads
from confluent_kafka.schema_registry import SchemaRegistryClient
from confluent_kafka.serialization import SerializationContext
import json
import traceback
from fastavro import parse_schema
from cls_src.utils.logger import Framework_Logger
from datetime import datetime, timedelta
from pyspark.sql.functions import from_json, col, to_json,get_json_object, to_json, udf,lit, map_from_arrays, collect_list



class KafkaConnector:
    '''
        In Kafka Connector class , we read the payload data from Kafka  and extract the data from payload 

    '''
    
    def __init__(self, pipeline_ctx, maxFilesPerTrigger = 100) -> None:

        '''
         Constructorr of Kafka Connector class
            Parameters :
               pipeline_ctx(Object) : Pipeline context object 
               maFilesPerTrigger(int) : Maximum files that can be read for each session 

        '''
        self.pipeline_name = pipeline_ctx.pipeline_name
        self.confluentApiKey = pipeline_ctx.confluentApiKey
        self.confluentSecret = pipeline_ctx.confluentSecret
        self.host = pipeline_ctx.confluent_host
        self.topic = pipeline_ctx.kafka_topic
        self.confluent_protocol = pipeline_ctx.confluent_protocol
        self.confluent_offset_status = pipeline_ctx.confluent_offset_status
        self.confluentRegistryApiKey = pipeline_ctx.confluentRegistryApiKey
        self.confluentRegistrySecret = pipeline_ctx.confluentRegistrySecret
        self.schema_registry_url = pipeline_ctx.schema_registry_url
        self.maxFilesPerTrigger = maxFilesPerTrigger
        self.triggerInterval = "15 seconds"
        self.fw_logger = Framework_Logger()

    #Spark streaming session reads the raw Kafka message     
    def read(self, spark_streaming_ctx):
        self.fw_logger.log_info('Data Ingestion :calling read function....')
        """
        Stream reads the incoming kafka message in raw format. 

        Parameters :
            spark_ctx : spark streaming context created from PipelineContext().create_pyspark_streaming_session()

        Returns:
            Streaming dataframe (column "value" has the incoming message)
        """
        try:
            binary_to_string = fn.udf(lambda x: str(int.from_bytes(x, byteorder='big')), StringType())
            return spark_streaming_ctx \
                .readStream \
                .format("kafka") \
                .option("maxFilesPerTrigger",self.maxFilesPerTrigger)\
                .option("kafka.bootstrap.servers", self.host)  \
                .option("kafka.security.protocol", self.confluent_protocol) \
                .option("kafka.sasl.jaas.config", "kafkashaded.org.apache.kafka.common.security.plain.PlainLoginModule required username='{}' password='{}';".format(self.confluentApiKey,
self.confluentSecret)) \
                .option("kafka.ssl.endpoint.identification.algorithm", "https") \
                .option("kafka.sasl.mechanism", "PLAIN") \
                .option("startingOffsets", self.confluent_offset_status) \
                .option("failOnDataLoss", "false") \
                .option("subscribe", self.topic) \
                .load() \
                .withColumn('key', fn.col("key").cast(StringType())) \
                .withColumn('valueSchemaId', binary_to_string(fn.expr("substring(value, 2, 4)"))) \
                .select(
                    col("topic").cast("string"),
                    col("key").cast("string"),
                    col("value"),
                    col("partition").cast("string"),
                    col("offset").cast("string"),
                    col("timestamp").cast("string"),
                    col("timestampType").cast("string"),
                    col("valueSchemaId").cast("string"))
        except Exception as e: 
            self.fw_logger.log_error("Data Ingestion :Exception occurred in read function.."+str(e))
            self.fw_logger.log_error("Data Ingestion :Exception occurred: %s" + str(traceback.format_exc()))
            
    #  Extract the data from payload 
    def get_kafka_payload(self,df,type = "AVRO"):
        self.fw_logger.log_info('Data Ingestion :calling function get_kafka_payload')
        """
            The function takes the payload from kafka and extracts data from the payload. 

            Parameters :
                spark_ctx(SparkSession Object) : spark streaming context created from PipelineContext().create_pyspark_streaming_session()
                type(String) : Type of the  incoming kafka message.  Currently implemented for TEXT/AVRO

            Returns:
                Streaming dataframe with the below structure
                | topic | key | value | deserialized_value (available only if the type is AVRO) | orderitemid | data | partition | offset | timestampType | valueSchemaId | timestamp |
        """
        try:
            if type == "TEXT":
                # df = self.read_as_string(spark_ctx)
                return df.select(col('topic'),
                                get_json_object(col("value"), "$.orderitemid").alias('orderitemid'),
                                get_json_object(col("value"), "$.data").alias('data'),
                                col('partition'),col('offset'),col('timestampType'),col('valueSchemaId'),col('key'))
            elif type == "AVRO":
                # if payload_schema is None:
                #     print("Error : Payload schema should not be NONE for type AVRO")
                # else:
                # df = self.read(spark_ctx)
                # *****value - passing value column since it has msg data *****
                df = self.avro_deserializer(df, self.topic, "value","deserialized_value")
                
                return df.select(col("partition"),col("offset"),col("ingested_date"),col("gcs_created_date"),
                            get_json_object(col("deserialized_value"), "$.id").alias('id'),
                            get_json_object(col("deserialized_value"), "$.orderid").alias('orderid'),
                            get_json_object(col("deserialized_value"), "$.orderitemid").alias('orderitemid'),
                            get_json_object(col("deserialized_value"), "$.data").alias('data'))
                #return df
        except Exception as e:
            self.fw_logger.log_error("Data Ingestion :Exception occurred in get_kafka_payload function.."+str(e))
            self.fw_logger.log_error("Data Ingestion :Exception occurred: %s" + str(traceback.format_exc()))

    #  Applying avro_decoder to the data        
    def avro_deserializer(self,streaming_df,topic, input_col, output_col):
        """
        Applies the avro_decoder function to a column from a pyspark dataframe. 

        Args:
            streaming_df : Streaming pyspark dataframe
            topic : kafka topic
            input_col : Name of the column which has its value in AVRO format
            output_col : Name of the column in which the deserilized value should be stored

        Returns:
            Streaming dataframe with deserialized value in its output column  
        """
        schema_str,schema_id,schema_registry_client = self.get_schema_from_registry(topic)

        avro_deserialize_udf = udf(lambda msg_value, topic, schema_str, schema_id : self.avro_decoder(msg_value,topic,schema_str, schema_id))
        # schema_str,schema_id = self.get_schema_from_registry(topic)
        streaming_df = streaming_df.withColumn(output_col, avro_deserialize_udf(col(input_col), lit(topic), lit(schema_str), lit(schema_id)))
        return streaming_df 
    
    # Deserialize avro messages 
    def avro_decoder(self,msg_value,topic,schema_str, schema_id):
        self.fw_logger.log_info('Data Ingestion :calling function avro_decoder')
        """
        Deserialize avro messages

        Args:
            msg_value : incoming kafka message in avro format
            topic : kafka topic

        Returns:
            Deserialized value in a json string format
            
        """
        try:
            schema_registry_client = self.get_schema_registry_client()
            avro_deserializer = AvroDeserializer(schema_registry_client,schema_str)

            prepared_schema = _schema_loads(schema_str)
            writer_schema = parse_schema(json.loads(prepared_schema.schema_str))
            avro_deserializer._writer_schemas[schema_id] = writer_schema

            ctx = SerializationContext(topic,"value")
            return json.dumps(avro_deserializer(msg_value,ctx))
        except Exception as e:
            self.fw_logger.log_error("Data Ingestion :Exception occurred: %s" + str(traceback.format_exc())) 
            return str(e)

    #  Extract schema from Kafka topic      
    def get_schema_from_registry(self, topic,context="value"):
        self.fw_logger.log_info('calling function get_schema_from_registry')
        """
        Extracts schema from schema registry

        Args:
            topic : kafka topic --> from which the schema has to be extracted

        Returns:
            schema and schema id
        """
        schema_registry_client = self.get_schema_registry_client()
        schema = schema_registry_client.get_latest_version(subject_name=topic+"-"+context)
        schema_id = schema.schema_id
        schema = schema_registry_client.get_schema(schema_id)
        schema_str = schema.schema_str
        return schema_str, schema_id, schema_registry_client
                                     
    def get_schema_registry_client(self):
        schema_registry_conf = {'url': self.schema_registry_url, 'basic.auth.user.info': '{}:{}'.format(self.confluentRegistryApiKey, self.confluentRegistrySecret)}
        schema_registry_client = SchemaRegistryClient(schema_registry_conf)
        return schema_registry_client

    #   Get offset for the unread message at each partition
    def get_starting_offset(self, delta_ctx, partition_count = 10):
        """
            Finds the offset for the unread message at every partition

            Args:
                delta_ctx(deltlake_connector object) : deltalake context object
                partition_count(int) : count of partitions 
              
            Returns:
                startingOffsets for kafka consuming
                {"com.hireright.order.item.education.request-dev": {"7": 128, "3": 143, "8": 125, "0": 115, "6": 121, "9": 126, "1": 119, "4": 132, "2": 142, "5": 136}}
        """
        try:
            filter_date = datetime.now() - timedelta(7)
            filter_date_str = datetime.strftime(filter_date, '%Y-%m-%d')
            df = delta_ctx.read_landing().filter(col("processed_date") >= lit(filter_date_str))
            df = df.select("partition",col("offset").cast("int")).groupBy("partition").max("offset") 
            offset_json = df.groupBy(lit(1)).agg(to_json(map_from_arrays(collect_list(col("partition")),collect_list(col("max(offset)")+1))).alias("dict")).select("dict").collect()[0][0]
            offset_json = json.loads(offset_json)
            for i in range(partition_count):
                if str(i) not in offset_json:
                    offset_json[str(i)] = -2
            
            result = {}
            result[self.topic] = offset_json
            return json.dumps(result)
        except Exception as e:
            # self.fw_logger.error("?Exception occurred: %s",traceback.format_exc())  
            return "earliest"


