from datetime import datetime, timedelta
from airflow import DAG
from airflow.providers.databricks.operators.databricks import DatabricksSubmitRunOperator
#from airflow.utils.email import send_email
from airflow.models import Variable
import re
#from airflow_utils.custom_email import notify_email

#cluster_id = Variable.get("stream_cluster_id")

default_args = {
    'owner': 'airflow.admin',
    'retries': 5,
    'start_date': datetime(2022, 8, 3),
    'retry_delay': False,
    
    'schedule_interval': '@daily'
}
with DAG(
        dag_id='ds_gcsto_mongodb',
        default_args=default_args,
        schedule_interval=None,
        max_active_runs = 1
) as dag:


    notebook_task = {
      'notebook_path': '/ds_classification/gcs_to_mongodb_pipeline',
    }
    notebook_run = DatabricksSubmitRunOperator(
        task_id='gcs_to_mongodb_pipeline',
        databricks_conn_id='databricks_default',
        # existing_cluster_id='0621-084306-s3ooxf96', # dev cluster id
        # existing_cluster_id='0321-073910-ldvq95cb', #test cluster id
        existing_cluster_id='0724-152858-evu4iq',
        timeout_seconds=None,
        notebook_task=notebook_task)