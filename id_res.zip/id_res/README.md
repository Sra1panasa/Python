# Identity Resolution Methods

Using various approaches we tried to match information of applicant with the criminal records retrieved from court and other public sources

## Profile String with None

![Profile String Method Flow](/images/Profile_String.png)

### Input Features:
First name, Middle name, Last name, date of birth, month of birth, year of birth, street, city, state, zip
### Preprocessing:
- Profile String - Features are combined using ‘_’ as delimiter
- If any of the feature is missing it will be taken as empty string
- Profile string is created for both applicant profile and criminal profile
### Model:
- Profile string is embedded/encoded using open-source library(HuggingFace) Model 
- Model Name: all-mpnet-base model
- Cosine similarity is computed between applicant profile against each of the criminal profile
### Output:
- By following method, based on similarity score profiles are classified into Match, No Match and Inconclusive category.
    - Similarity score >= 0.7  -> Match
    - Similarity score < 0.4 -> No Match
    - Similarity score >= 0.4 and similarity score < 0.7 -> Inconclusive


## Profile String without None

### Input Features:
First name, Middle name, Last name, date of birth, month of birth, year of birth, street, city, state, zip
### Preprocessing:
- Profile String - Features are combined using ‘_’ as delimiter
- If any of the feature is missing it will not be considered while creating profile string
- Profile string is created for both applicant profile and criminal profile
### Model:
- Profile string is embedded/encoded using open-source library(HuggingFace) Model 
- Model Name: all-mpnet-base model
- Cosine similarity is computed between applicant profile against each of the criminal profile
### Output:
- By following method, based on similarity score profiles are classified into Match, No Match and Inconclusive category.
    - Similarity score >= 0.7 -> Match
    - Similarity score < 0.4 -> No Match
    - Similarity score >= 0.4 and similarity score < 0.7 -> Inconclusive
 
## Feature-wise aggregated score

![Feature-wise Method Flow](/images/featurewise.png)
 
### Input Features:
First name, Middle name, Last name, date of birth, month of birth, year of birth, street, city, state, zip
### Preprocessing:
- Each feature is encoded using huggingface all-mpnet-base model
### Model:
- Cosine similarity score is computed between each feature from applicant profile to the corresponding feature in the criminal profile
- The similarity score from each feature is aggregated using average
### Output:
- By following method, based on aggregated score profiles are classified into Match, No Match and Inconclusive category.
    - Aggregated score >= 0.7  -> Match
    - Aggregated score < 0.4 -> No Match
    - Aggregated score >= 0.4 and similariy score < 0.7 -> Inconclusive

###### Note: This feature-wise computation is primarily used to create model summary

 
## Classification Model

![Feature-wise Method Flow](/images/id_res_cls.png)
 
### Input Features:
First name similarity score, Middle name similarity score, Last name similarity score,
 day of birth similarity score, month of birth similarity score, year of birth similarity score, 
street similarity score, city similarity score, state similarity score, zip similarity score, 
height similarity score, eye similarity 
### Preprocessing:
- Each Feature such as First name, Middle name, Last name, dob, street, city, state, zip, in both applicant profile and criminal profile are encoded using huggingface all-mpnet-base model
- Cosine similarity score is computed between each feature from applicant profile to the corresponding feature in the criminal profile
- Handling Missing Attribute: Missing attribute value score is filled as 0
### Model:
- Pretrained classification model: XGBoostClassifier
- The preprocessed input feature passed through pretrained model
- Training dataset size ~20K
### Output:
- Match/NoMatch
