apt-get install jq -y
echo "{\"password\": \"$VAULT_PASSWORD\"}" > payload.json
RESPONSE=`curl --request POST --data @payload.json ${VAULT_SERVER_URL}/v1/auth/userpass/login/${VAULT_USERNAME}`
rm -f payload.json

VAULT_LEASE_CLIENT_TOKEN=`echo $RESPONSE | jq .auth.client_token | sed 's/"//g'`
GCSA=`curl --header "X-Vault-Token: $VAULT_LEASE_CLIENT_TOKEN" ${VAULT_SERVER_URL}/v1/dataservices/data/gcp/sacreds`

GCP_SA_FILE="gcloud-service-key.json"
echo $GCSA | jq .data.data | tee $GCP_SA_FILE > /dev/null
ls -l $GCP_SA_FILE

gcloud auth activate-service-account --project=$GCP_PROJECTID --key-file=$GCP_SA_FILE
gsutil -m cp -R airflow/dags/dev/* gs://$COMPOSER_BUCKET_NAME/dags/datascience_dags_files

