# Databricks notebook source
from idr_src.performance.performance_report import *
from idr_src.utils.read_config import *
from idr_src.performance.visualize import *
config_parser = GetConfigAttr()
import pandas as pd
import numpy as np
from sklearn.metrics import confusion_matrix
from idr_src.utils.pymongo_db_connector import PyMongoConnector
from idr_src.utils.logger import Framework_Logger
import time
import traceback
import datetime
# COMMAND ----------
'''
    The performance metrics ,confusion matrix  for indentity resolution model.
    
'''
start_time=time.time()
import datetime
try:
    mongodbconnector=PyMongoConnector()
    eval=PerformanceEval()
    logger=Framework_Logger()
    config=GetConfigAttr()
    idrv=IDResolutionVisualizationTransformation()
    #Reading the JSON from mongodb -sliding window
    start_dt = '26-10-2022';format = '%d-%m-%Y'
    date_start = datetime.datetime.strptime(start_dt, format)
    date_today = datetime.datetime.now();diff = date_today - date_start;diff.days
    #starting from nov 26th 2022 to till yesterday dates
    entire_days=[(datetime.date.today() - datetime.timedelta(days=x+1)).strftime('%d-%m-%Y') for x in range(diff.days)]
    toggle_days=[(datetime.date.today() - datetime.timedelta(days=x+1)).strftime('%d-%m-%Y') for x in range(30)]
    #sliding window - from yesterday previous three days
    sliding_days=[(datetime.date.today() - datetime.timedelta(days=x+1)).strftime('%d-%m-%Y') for x in range(3)]
    mongodb_value=mongodbconnector.read_all_dict(config.get_io_config_attribute_by_section("mongoDB","collection_idr_prediction_recall_Eng"))
    #mongodb already written dates
    mongodb_days=[[v for k,v in d.items() if k=="ingested_date"] for d in mongodb_value]
    mongodb_days=[v[0] for v in mongodb_days]
    #Missing dates in the mongodb dates
    missing_transformation_data = list(set(entire_days).difference(mongodb_days))
    #sliding days and missiing days
    sliding_days.extend(missing_transformation_data)
    sliding_days=list(set(sliding_days))
    #converting JSON's into dataframe
    prediction_result=idrv.mangodb_datarange_json_read(config.get_io_config_attribute_by_section("mongoDB","collection_idr_prediction_results_v3"),sliding_days)
    logger.log_info("length of the total json is..."+ str(len(prediction_result)))
    logger.log_info("Dataframe creation...")
    df=idrv.dataset_creation_from_json(prediction_result)
    #Preprocessing the data (renaming the flag for applicant and court data)
    logger.log_info("Preprocessing the dataframe...")
    preprocessed_data=idrv.preprocessing_data(df)
    #create the dataframe for ID Resolution output for result table recent data(3days) and toggle button calculation(10days) - 100MB limitation
    logger.log_info("Dashboard master data creation...")
    master_data=idrv.master_data_creation(preprocessed_data,sliding_days)
    raw_df=master_data.copy()
    #All five models output, create the confusion matrix and transform data for - Bar chart datewise  
    logger.log_info("Bar chart transformation data creation for Dashboard...")
    bar_chart_data_datewise=idrv.confusion_bar_chart(raw_df)
    #Confusion matrix datewise score write into mongodb
    logger.log_info("Writting Bar chart data to Mongodb...")
    idrv.update_mongodb_confusion_matrix(bar_chart_data_datewise,config.get_io_config_attribute_by_section("mongoDB","collection_idr_confusion_matrix_Eng"))
    #Read Confusion matrix datewise score and combine all the date into single Bar chart 
    logger.log_info("Read data from MongoDB and transform the data for Bar chart...")
    bar_chart_data_entire_days=idrv.transform_confusion_matrix_score(config.get_io_config_attribute_by_section("mongoDB","collection_idr_confusion_matrix_Eng"))
    #All five models output, create the data for precision and recall for entire date  
    logger.log_info("Precision table creation for the dashboard...")
    final_df=idrv.precision_recall_overall_data(raw_df)
    #All five models output, create the dataframe for recall values with all the date - Line chart
    logger.log_info("Recall table running for the dashboard...")
    recall_chart_df=idrv.recall_line_chart(raw_df)
    #All five models output, create the dataframe for recall values with all the date - Line chart without insufficient data
    logger.log_info("Recall Line chart data creation - Without insufficient data...")
    recall_chart_df_without_insufficient=idrv.recall_line_chart_without_insufficient(raw_df)
    #recall line chart data write to mongodb with insufficient data - datewise - recall line chart
    logger.log_info("Writting recall chart - with insufficient data into Mongodb...")
    idrv.update_mongodb_recall_precision_multimodel(recall_chart_df,config.get_io_config_attribute_by_section("mongoDB","collection_idr_prediction_recall_Eng"),'recall')
    #recall line chart data write to mongodb without insufficient data - datewise - recall line chart
    logger.log_info("Writting recall chart - without insufficient data into Mongodb...")
    idrv.update_mongodb_recall_precision_multimodel(recall_chart_df_without_insufficient,config.get_io_config_attribute_by_section("mongoDB","collection_idr_recall_without_insufficient_Eng"),'recall')
    #Read the recall score and convert into dataframe for recall line chart  with insufficient data
    logger.log_info("Read data from MongoDB and transform the data for recall chart...")
    recall_dashbord_data=idrv.recall_transformation_data(config.get_io_config_attribute_by_section("mongoDB","collection_idr_prediction_recall_Eng"))
    #Read the recall score and convert into dataframe for recall line chart  without insufficient data
    logger.log_info("Read data from MongoDB and transform the data for recall chart without insufficient...")
    recall_dashbord_data_without_insufficient=idrv.recall_transformation_data(config.get_io_config_attribute_by_section("mongoDB","collection_idr_recall_without_insufficient_Eng"))
    #combining recall with and without insufficient data together for dashboard
    recall_chart_df_final=pd.concat([recall_dashbord_data,recall_dashbord_data_without_insufficient],axis=0)
    #write the recall chart data into GCS
    logger.log_info("Writting line chart data to GCS...")
    recall_chart_df_final.to_csv(config.get_io_config_path_attr_by_section("dashboard","idr_recall_line_chart_Eng"),index=False)
    #All five models output, create the dataframe for precision values with all the date - Line chart
    logger.log_info("precision line chart data creation for the dashboard...")
    precision_chart_df=idrv.precision_line_chart(raw_df)
    #Removal of noise from the off-diagnal rows (False positive and False Negative)
    raw_df_noise_removed=idrv.precision_noise_removal(raw_df)
    precision_chart_df_without_noise=idrv.precision_line_chart_without_noise(raw_df_noise_removed)
    #All five model precision output write it to mongodb
    logger.log_info("write precision line chart data to MongoDB...")
    idrv.update_mongodb_recall_precision_multimodel(precision_chart_df,config.get_io_config_attribute_by_section("mongoDB","collection_idr_prediction_precision_Eng"),'precision')
    idrv.update_mongodb_recall_precision_multimodel(precision_chart_df_without_noise,config.get_io_config_attribute_by_section("mongoDB",'collection_idr_precision_without_noise_Eng'),'precision')
    #Read the precision score and convert into dataframe for recall line chart
    logger.log_info("Read data from MongoDB and transform the data for precision chart...")
    precision_dashbord_data_with_noise=idrv.precision_transformation_data(config.get_io_config_attribute_by_section("mongoDB","collection_idr_prediction_precision_Eng"))
    precision_dashbord_data_without_noise=idrv.precision_transformation_data(config.get_io_config_attribute_by_section("mongoDB",'collection_idr_precision_without_noise_Eng'))
    logger.log_info("precision line chart data creation with and without noise for the dashboard...")
    precision_chart_df_final=pd.concat([precision_dashbord_data_with_noise,precision_dashbord_data_without_noise],axis=0)
    logger.log_info("precision line chart write it into GCS...")
    precision_chart_df_final.to_csv(config.get_io_config_path_attr_by_section("dashboard","idr_precision_line_chart_Eng"),index=False)
    logger.log_info("write all the models output to MongoDB - Toggle Button...")
    idrv.update_mongodb_multi_model(raw_df,config.get_io_config_attribute_by_section("mongoDB","collection_idr_multi_model_output_Eng"))
    logger.log_info("Read data from MongoDB and transform the data - Toggle Button...")
    toggle_dashbord_data=idrv.transform_multi_model_score(config.get_io_config_attribute_by_section("mongoDB","collection_idr_multi_model_output_Eng"),toggle_days)
    #Store the date values in gcs to see how many days we are showing in the graph for overview and toggle functionalities page
    idr_gds_dates=pd.DataFrame()
    idr_gds_dates['result_table_date']=list(df.ingested_date.unique())
    idr_toggle_dates=pd.DataFrame()
    idr_toggle_dates['toggle_date']=list(toggle_dashbord_data.ingested_date.unique())
    dates_file=pd.concat([idr_gds_dates,idr_toggle_dates],axis=1)
    dates_file.to_csv(config.get_io_config_attribute_by_section("dashboard","idr_date_values_Eng"))

except Exception as e:
    logger.log_error("Exception occurred..."+ str(e))
    logger.log_error(traceback.format_exc())

end_time=time.time()
elapsed_time=end_time-start_time
elapsed_time=time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
logger.log_info('Identity Resolution:  Transfromation Script: Execution time : '+str(elapsed_time))
