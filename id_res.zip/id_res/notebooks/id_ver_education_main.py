from pydoc import visiblename
from idr_src.utils.logger import Framework_Logger
from idr_src.utils.read_config import *
from idr_src.utils.pymongo_db_connector import PyMongoConnector
from idr_src.utils.verification_modules import VerificationModules
from idr_src.education.education_verification import EducationVerification
import mlflow
import pandas as pd
import numpy as np
import json
import traceback
import time

start_time=time.time()

vm=VerificationModules()
edu=EducationVerification()
logger=Framework_Logger()
config_parser = GetConfigAttr()

try:
    mongodbconnector = PyMongoConnector()
    logger.log_info("Mongo connector initialized")
    order_item_education_payload=config_parser.get_io_config_attribute_by_section("id_ver_education", "order_item_education_raw_table")
    education_payload=config_parser.get_io_config_attribute_by_section("id_ver_education", "education_verification_raw_table")
    education_verification_output=config_parser.get_io_config_attribute_by_section("id_ver_education", "education_verification_output")
    payload_orderitem_verification=mongodbconnector.read_all_dict(order_item_education_payload) 
    payload_education_verification=mongodbconnector.read_all_dict(education_payload)

    app_featute_list=['given','middle','family']
    edu_feature_list=['start','end','institution_name','institution_communication.address_city','educationDegrees_name','educationDegrees_degreeGrantedStatus','educationDegrees_specializations_name']
    

    for payload in payload_orderitem_verification: 
        order_id_list=payload['screeningRequest']['referenceObjects']
        for id in order_id_list:
            if id['type']=='order':
                order_id=id['id']
        nsch_json_list=mongodbconnector.filter_records_dict(education_payload, "orderid", order_id)
        logger.log_info("count of the matched dataframe with the order id"+str(order_id)+"from nsch"+str(len(nsch_json_list)))
        #Add logging length of the list
        if len(nsch_json_list)>0:
            for verification in nsch_json_list:
                #order item name section details datafrme creation
                edu_name_data=vm.name_data(payload,'screeningRequest')
                #education verification name section details datafrme creation
                nsch_edu_name_data=vm.nsch_talx_name_data(verification,'verifiedInfo')
                
                #order item education details datafrme creation
                edu_data=edu.app_education_data_creation(payload)
                logger.log_info("order_item education payload name details converted as dataframe")
                #education verification details datafrme creation
                nsch_edu_data=edu.nsch_education_data_creation(verification)
                logger.log_info("order_item education payload education details converted as dataframe")
                
                #profile string creation of order item education name section
                ps_app=vm.get_profile_string_added(edu_name_data,app_featute_list)
                #profile string creation of education name section
                ps_nsch=vm.get_profile_string_added(nsch_edu_name_data,app_featute_list)
                
                #creation of embedding both the side of name section 
                ps_embed_app,ps_embed_nsch=vm.create_embeddings(ps_app,ps_nsch,app_featute_list+['profle_string_with_none','profle_string_without_none'])
                #creation of cosine similarity both the side of name section
                final_name_result=vm.create_cosine_name_similarty(ps_embed_app,ps_embed_nsch)
                final_name_result.columns=final_name_result.columns.str.strip().str.lower()
                #adding disposition details 
                final_name_result[['orderid','orderitemid','dispo_reason','dispo_recommendation']]=vm.get_order_details(payload)
                #rename the order item education dataframe
                final_dict_edu_rename=config_parser.verification_edu_emp_name_feature()
                final_name_result=final_name_result.rename(columns=final_dict_edu_rename)
                final_name_result['aggregated_score'] = final_name_result[['first_name_score','middle_name_score','last_name_score']].mean(axis=1,skipna=True)
                final_name_result['ivr_match_score']=['Match' if x>0.7 else 'NoMatch' if 0.4>=x<0.7 else 'Inconclusive' 
                                                                         for x in final_name_result['profle_string_with_none_score']]
                
                #profile string creation of education section - order item education
                ps_app_edu=vm.get_profile_string_added(edu_data,edu_feature_list)
                #profile string creation education section - education verification
                ps_nsch_edu=vm.get_profile_string_added(nsch_edu_data,edu_feature_list)
                
                #creation of embedding both the side of education section 
                ps_embed_app_edu,ps_embed_nsch_edu=vm.create_embeddings(ps_app_edu,ps_nsch_edu,['start_date_summary','end_date_summary']+edu_feature_list+['profle_string_with_none','profle_string_without_none'])
                final_edu_result=vm.create_cosine_similarty(ps_embed_app_edu,ps_embed_nsch_edu)
                final_edu_result.columns=final_edu_result.columns.str.strip().str.lower()
                #Get the disposition details
                final_edu_result[['orderid','orderitemid','dispo_reason','dispo_recommendation']]=vm.get_order_details(payload)
                #get the aggragated score for name section
                
                
                #rename the education verification dataframe
                final_dict_edu_section_rename=config_parser.verification_education_feature()
                final_edu_result=final_edu_result.rename(columns=final_dict_edu_section_rename)
                #create the summary/match between start, end date 
                final_edu_result['start_summary']=np.where(final_edu_result['app_start'] == final_edu_result['nsch_start'], 'Matching Date', 'No Match Date')
                final_edu_result['end_summary']=np.where(final_edu_result['app_end']==final_edu_result['nsch_end'],"Matching Date","No Match Date")
                #get the aggragated score for education section
                final_edu_result['aggregated_score'] = final_edu_result[['institution_score', \
            'inst_city_score','degree_score','degree_status_score','specializations_score']].mean(axis=1,skipna=True)
                


                final_edu_result['ivr_match_score']=['Match' if x>0.7 else 'NoMatch' if 0.4>=x<0.7 else 'Inconclusive' \
                                                                         for x in final_edu_result['profle_string_with_none_score']]
            else:
                logger.log_info("order id not matching with NSCH "+str(order_id))


except Exception as e:
            logger.log_error("Exception occurred in predicting and saving results to mongodb..."+ str(e))
            logger.log_error(traceback.format_exc())

end_time=time.time()

elapsed_time=end_time-start_time
elapsed_time=time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
logger.log_info('ID Resolution : Education Verification main : Execution time : '+str(elapsed_time))