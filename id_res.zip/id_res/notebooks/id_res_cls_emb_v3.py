import datetime
from datetime import date, timedelta
import pandas as pd
from idr_src.utils.pymongo_db_connector import PyMongoConnector
from idr_src.utils.read_config import *
config=GetConfigAttr()
import pickle
import gcsfs
import numpy as np
fs = gcsfs.GCSFileSystem(project=config.get_io_config_attribute_by_section("project","dsstg"))
# with fs.open("gs://bkt-stg-hrgp-ds-us/ds_zaha_hrg2/id_resolution/ID_Resolution_Model/cls_emb_v5.pkl", 'rb') as output:
#     lgb_cls=pickle.load(output)
with fs.open(config.get_io_config_attribute_by_section("PATH","cls_emb_v3_model_path")+"cls_emb_v5.pkl", 'rb') as output:
    lgb_cls=pickle.load(output)

mongodbconnector=PyMongoConnector()

today = date.today()
yesterday = today - timedelta(days = 1)
ingested_date=yesterday.strftime("%d-%m-%Y")

# one_day_prior=[(datetime.date.today() - datetime.timedelta(days=x+1)).strftime('%d-%m-%Y') for x in range(1)]
# print(one_day_prior)
# date="".join(one_day_prior)
print(ingested_date)
df=mongodbconnector.filter_records("idr_predictions","ingested_date", ingested_date)
tmp_exp=df.explode("pred_res")
tmp_exp.reset_index(inplace=True,drop=True)
temp_df=pd.concat([tmp_exp, pd.DataFrame(tmp_exp['pred_res'].tolist())], axis=1)

temp_df["d-dob_exact_score"]=temp_df.apply(lambda x:1 if x['appl_day_of_birth']== x['crim_day_of_birth'] else 0,axis=1)
temp_df["m-dob_exact_score"]=temp_df.apply(lambda x:1 if x['appl_month_of_birth']== x['crim_month_of_birth'] else 0,axis=1)
temp_df["y-dob_exact_score"]=temp_df.apply(lambda x:1 if x['appl_year_of_birth']== x['crim_year_of_birth'] else 0,axis=1)
temp_df["cls_emb"]=lgb_cls.predict(temp_df[['first_name_score', 'middle_name_score', 'last_name_score',
    "d-dob_exact_score","m-dob_exact_score","y-dob_exact_score",
   'address_line_score', 'county_score', 'state_score', 'city_score',
   'zip_code_score', 'height_score', 'eye_color_score']])
temp_df["cls_emb_prob"]=np.max(lgb_cls.predict_proba(temp_df[['first_name_score', 'middle_name_score', 'last_name_score',
    "d-dob_exact_score","m-dob_exact_score","y-dob_exact_score",
   'address_line_score', 'county_score', 'state_score', 'city_score',
   'zip_code_score', 'height_score', 'eye_color_score']]),axis=1)
temp_df["cls_emb"]=temp_df["cls_emb"].replace({1:"Match",0:"NoMatch"})
unq_ids=temp_df["_id"].unique().tolist()
for idx in unq_ids:
    exception_jsons=[]
    try:
        temp=dict()
        temp["id_res_prediction_results_id"]=idx
        temp["criminal_raw_data_id"]=temp_df[temp_df["_id"]==idx]["id"].unique()[0]
        temp["request_id"]=temp_df[temp_df["_id"]==idx]["request_id"].iloc[:,1].unique()[0]
        temp["order_service_data_source_id"]=temp_df[temp_df["_id"]==idx]["order_service_data_source_id"].unique()[0]
        temp["reg_id"]=temp_df[temp_df["_id"]==idx]["reg_id"].unique()[0]
        temp["orderid"]=temp_df[temp_df["_id"]==idx]["orderid"].unique()[0]
        temp["orderitemid"]=temp_df[temp_df["_id"]==idx]["orderitemid"].unique()[0]
        temp["ingested_date"]=ingested_date
        temp["pred_res"]=temp_df[temp_df["_id"]==idx].iloc[:,9:].to_dict('records')
        mongodbconnector.write_records_from_json(temp,config.get_io_config_attribute_by_section("mongoDB","collection_idr_prediction_results_v3"))
    except:
        exception_jsons.append(idx)
        
print("The Exception jsons length is ",len(exception_jsons))
print("The Exception jsons Id's are ",exception_jsons)

        
print("-----completed-----",ingested_date)