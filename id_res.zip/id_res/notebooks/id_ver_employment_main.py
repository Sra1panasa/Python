from idr_src.utils.logger import Framework_Logger
from idr_src.utils.read_config import *
from idr_src.utils.pymongo_db_connector import PyMongoConnector
from idr_src.utils.verification_modules import VerificationModules
from idr_src.employment.employment_verification import EmploymentVerification
import mlflow
import pandas as pd
import numpy as np
import json
import traceback
import time

start_time=time.time()

vm=VerificationModules()
emp=EmploymentVerification()
logger=Framework_Logger()
config_parser = GetConfigAttr()


try:
    mongodbconnector = PyMongoConnector()
    order_item_employment_payload=config_parser.get_io_config_attribute_by_section("id_ver_employment", "order_item_employment_raw_table")
    employment_payload=config_parser.get_io_config_attribute_by_section("id_ver_employment", "employment_verification_raw_table")
    employment_verification_output=config_parser.get_io_config_attribute_by_section("id_ver_employment", "employment_verification_output")

    
    emp_json_list=mongodbconnector.read_all_dict(order_item_employment_payload)
    app_featute_list=['given','middle','family']
    
    for payload in emp_json_list:
        order_id_list=payload['screeningRequest']['referenceObjects']
        for id in order_id_list:
            if id['type']=='order':
                order_id=id['id']
        talx_json_list=mongodbconnector.filter_records_dict(employment_payload, "orderid", order_id)
        logger.log_info("count of the matched dataframe with the order id"+str(order_id)+"from talx"+str(len(talx_json_list)))
        emp_data=emp.orderitem_emp_dataframe(payload)
        for verification in [talx_json_list[1]]:
            talx_data=emp.talx_emp_dataframe(verification)
            if vm.check_valid_dates(emp_data,talx_data,''):
                #create the dataframe for name section - order item employment
                emp_name_data=vm.name_data(payload,'screeningRequest')
                #create the dataframe for name section - employment verification
                talx_emp_name_data=vm.nsch_talx_name_data(verification,'verifiedInfo')
                #create the profile string for both the order item and employment verification
                ps_app=vm.get_profile_string_added(emp_name_data,app_featute_list)
                ps_talx=vm.get_profile_string_added(talx_emp_name_data,app_featute_list)
                #create the embedding for both the order item and employment verification
                ps_embed_app,ps_embed_talx=vm.create_embeddings(ps_app,ps_talx,app_featute_list+['profle_string_with_none','profle_string_without_none'])
                final_name_result=vm.create_cosine_name_similarty(ps_embed_app,ps_embed_talx)
                final_name_result.columns=final_name_result.columns.str.strip().str.lower()
                final_dict_name_rename=config_parser.verification_edu_emp_name_feature()
                #rename the name section dataframe
                final_name_result=final_name_result.rename(columns=final_dict_name_rename)
                final_name_result['Avg_Score'] = final_name_result[['first_name_score','middle_name_score','last_name_score']].mean(axis=1,skipna=True)


                final_name_result['ivr_match_score']=['Match' if x>0.7 else 'NoMatch' if 0.4>=x<0.7 else  'Inconclusive'
                                                                                         for x in final_name_result['profle_string_with_none_score']]
                final_name_result[['orderid','orderitemid','dispo_reason','dispo_recommendation']]=vm.get_order_details(payload)

                if ((emp_data['start'][0]==talx_data['start'][0] and emp_data['end'][0]==talx_data['end'][0])) or ((emp_data['start'][0]==talx_data['start'][0] and emp_data['current'][0].lower()=='true')) :
                    print('Start validation')
                    emp_data,talx_data=vm.explode_features(emp_data,talx_data,'organization_aliases')
                    emp_data_embed,talx_data_embed=vm.create_embeddings(emp_data,talx_data,['organization_aliases'])


                    emp_cosine_similarity=vm.create_emp_cosine_similarty(emp_data_embed,talx_data_embed,list(emp_data.columns),['organization_aliases'],'')
                    emp_cosine_similarity=emp_cosine_similarity.explode('order_item_positionHistories_titleAliases')
                    emp_cosine_similarity=emp_cosine_similarity.explode('verification_positionHistories_titleAliases')
                    emp_cosine_similarity=emp_cosine_similarity.drop(['order_item_organization_aliases_embeded','verification_organization_aliases_embeded'],axis=1)
                    emp_cosine_similarity.drop_duplicates(inplace=True)
                    emp_cosine_similarity['order_item_positionHistories_titleAliases_embeded']=emp_cosine_similarity['order_item_positionHistories_titleAliases'].apply(lambda x: vm.model.encode(str(x),convert_to_tensor=True) if x else None)
                    emp_cosine_similarity['verification_positionHistories_titleAliases_embeded']=emp_cosine_similarity['verification_positionHistories_titleAliases'].apply(lambda x: vm.model.encode(str(x),convert_to_tensor=True) if x else None)


                    pos_cosine_similarity=vm.pos_cosine(emp_cosine_similarity,list(emp_cosine_similarity.columns))
                    final_dataframe=pos_cosine_similarity.copy()
                    final_dataframe=final_dataframe.drop(['verification_order_id','order_item_positionHistories_title','verification_positionHistories_title','order_item_organization_name','verification_organization_name','order_item_positionHistories_titleAliases_embeded','verification_positionHistories_titleAliases_embeded'],axis=1)
                    final_dataframe.columns=final_dataframe.columns.str.strip().str.lower()
                    final_dict_emp_rename=config_parser.verification_employment_feature()
                    final_dataframe=final_dataframe.rename(columns=final_dict_emp_rename)

                    ps_data=vm.profile_string(final_dataframe,list(final_dataframe.columns))
                else:
                    logger.log_error("orderitem orderitemId Not matching dates :"+str(emp_data['orderitemid'][0]))
                    logger.log_error("talx orderitemId Not matching dates :"+str(talx_data['orderitemid'][0]))
except Exception as e:
            logger.log_error("Exception occurred in predicting and saving results to mongodb..."+ str(e))
            logger.log_error(traceback.format_exc())

end_time=time.time()


elapsed_time=end_time-start_time
elapsed_time=time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
logger.log_info('ID Resolution : Employment Verification main : Execution time : '+str(elapsed_time))