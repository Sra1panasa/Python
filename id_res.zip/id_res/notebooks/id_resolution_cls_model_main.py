import mlflow
from google.cloud import storage
import json
from transformers import TrainingArguments, Trainer, TrainerCallback
import pickle
from idr_src.utils.logger import Framework_Logger
from idr_src.utils.read_config import *
import random
import string
import traceback
import pandas as pd
import numpy as np
from idr_src.utils.pymongo_db_connector import PyMongoConnector
from idr_src.performance.performance_report import PerformanceEval
import lightgbm as lgb
eval=PerformanceEval()

class ModelCallBack(TrainerCallback):

    def on_epoch_end(self, args, state, control, **kwargs):
        if(len(state.log_history)>0):
            mlflow.log_text(json.dumps(state.log_history),"MetricByEpoch")
            

def IDRTrainingPipeline(data_path,exp_name):

    try:
        logger=Framework_Logger()
        confg=GetConfigAttr()
        mongodbconnector=PyMongoConnector()
        performance=PerformanceEval()
        mlflow.set_tracking_uri(confg.get_model_config_path_attr_by_section("MLFLOW","tracking_server"))
        experiment_id = mlflow.create_experiment(exp_name)
#         artifact_location="gs://bkt-stg-hrgp-ds-us/ds_zaha_hrg2/id_resolution/ID_Resolution_Model/mlflow_artifacts/"
        mlflow.autolog()
        training_data=pd.read_csv(data_path)
        with mlflow.start_run(nested=True,experiment_id=experiment_id) as run:
            run_id = run.info.run_id
            logger.log_info("MLFlow Initialized with run Id "+str(run_id))
 
            mlflow.log_param("Model Name","ID Resolution CLS Model")
            mlflow.log_param("training data",str(training_data.shape[0])+", "+str(training_data.shape[1]))
            
            lgb_cls = lgb.LGBMClassifier(boosting_type='gbdt',objective='binary',num_leaves= 40,learning_rate=0.1,feature_fraction= 0.9,num_boost_round=1500)
            lgb_cls.fit(training_data[['first_name_score', 'middle_name_score', 'last_name_score',
                   'd-dob_exact_score', 'm-dob_exact_score', 'y-dob_exact_score',
                   'address_line_score', 'county_score', 'state_score', 'city_score',
                   'zip_code_score', 'height_score', 'eye_color_score']],training_data["researcher_resp"])
            
            testing_data=pd.read_csv(confg.get_io_config_path_attr_by_section("PATH","id_res_cls_model_testing_data"))
            
            y_pred=lgb_cls.predict(testing_data[['first_name_score', 'middle_name_score', 'last_name_score',
                   'd-dob_exact_score', 'm-dob_exact_score', 'y-dob_exact_score',
                   'address_line_score', 'county_score', 'state_score', 'city_score',
                   'zip_code_score', 'height_score', 'eye_color_score']])
            pred_df=pd.DataFrame(y_pred)
            pred_df.index=testing_data.index.values
            

            with open('cls_emb', 'wb') as model:
                pickle.dump(lgb_cls, model) 
            mlflow.log_artifact("cls_emb")
            mlflow.lightgbm.log_model(lgb_cls,
                                     artifact_path="lightgbm_model",registered_model_name="ID Resolution")

            logger.log_info("MLFLOW Artifacts saved to GCS")
            logger.log_info("Saving MLFLOW metrics, params and model performance into mongodb")
            metrics=performance.get_performance_metrics(testing_data["researcher_resp"],pred_df[0])
            metrics.rename(columns={0:"NoMatch",1:"Match"},inplace=True)
            metrics=metrics.round(4)
            metrics.reset_index(inplace=True)
            metrics.rename(columns={"index":"Metric Name"},inplace=True)
            model_performance= metrics.to_dict("records")
            for obj in model_performance:
                temp=dict()
                temp[obj["Metric Name"]+"_Match"]=obj["Match"]
                temp[obj["Metric Name"]+"_NoMatch"]=obj["NoMatch"]
                temp[obj["Metric Name"]]=obj["micro-average"]
                mlflow.log_metrics(temp)
            mlflow_obj=mlflow.tracking.MlflowClient().get_run(run_id).data.to_dictionary()
            store_obj=dict()
            store_obj["_id"]=run_id
            store_obj["experiment_name"]=exp_name
            store_obj["mlflow_params"]=mlflow_obj["params"]
            store_obj["mlflow_metrics"]=mlflow_obj["metrics"]
            store_obj["model_performance"]=model_performance
            mongodbconnector.write_records_from_json(store_obj,"mlops_metrics_logger")
            logger.log_info("Metrics and Params stored into mongodb")
            mlflow.end_run()
    except Exception as e:
        logger.log_error("Exception occurred: %s"+ str(traceback.format_exc()))  

exp_name="IDR pipeline_12"
# "Test_"+"".join(random.choices(string.ascii_lowercase + string.digits, k=7))
data_path="gs://bkt-stg-hrgp-ds-us/ds_zaha_hrg2/id_resolution/ID_Resolution_Model/data/training_data.csv"
metrics=IDRTrainingPipeline(data_path,exp_name)