# Databricks notebook source
from idr_src.performance.performance_report import *
from idr_src.utils.read_config import *
from idr_src.performance.visualize_gf import *
config_parser = GetConfigAttr()
import pandas as pd
import numpy as np
from sklearn.metrics import confusion_matrix
from idr_src.utils.pymongo_db_connector import PyMongoConnector
from idr_src.utils.logger import Framework_Logger
import time
import traceback
import datetime
# COMMAND ----------
'''
    The performance metrics ,confusion matrix  for indentity resolution model.
    
'''
start_time=time.time()
import datetime
try:
    mongodbconnector=PyMongoConnector()
    eval=PerformanceEval()
    logger=Framework_Logger()
    config=GetConfigAttr()
    idrv=IDResolutionVisualizationTransformation_gf()
    #Reading the JSON from mongodb -sliding window
    start_dt = '26-10-2022';format = '%d-%m-%Y'
    date_start = datetime.datetime.strptime(start_dt, format)
    date_today = datetime.datetime.now();diff = date_today - date_start;diff.days
    #starting from nov 26th 2022 to till yesterday dates
    entire_days=[(datetime.date.today() - datetime.timedelta(days=x+1)).strftime('%d-%m-%Y') for x in range(diff.days)]
    toggle_days=[(datetime.date.today() - datetime.timedelta(days=x+1)).strftime('%d-%m-%Y') for x in range(30)]
    #sliding window - from yesterday previous three days
    sliding_days=[(datetime.date.today() - datetime.timedelta(days=x+1)).strftime('%d-%m-%Y') for x in range(3)]
    mongodb_value=mongodbconnector.read_all_dict(config.get_io_config_attribute_by_section("mongoDB","collection_idr_prediction_recall_gf"))
    #mongodb already written dates
    mongodb_days=[[v for k,v in d.items() if k=="ingested_date"] for d in mongodb_value]
    mongodb_days=[v[0] for v in mongodb_days]
    #Missing dates in the mongodb dates
    missing_transformation_data = list(set(entire_days).difference(mongodb_days))
    #sliding days and missiing days
    sliding_days.extend(missing_transformation_data)
    sliding_days=list(set(sliding_days))
    #converting JSON's into dataframe
    prediction_result=idrv.mangodb_datarange_json_read(config.get_io_config_attribute_by_section("mongoDB","collection_idr_prediction_results_v3"),sliding_days)
    logger.log_info("length of the total json is..."+ str(len(prediction_result)))
    logger.log_info("Dataframe creation...")
    df=idrv.dataset_creation_from_json(prediction_result)
    #Preprocessing the data (renaming the flag for applicant and court data)
    logger.log_info("Preprocessing the dataframe...")
    preprocessed_data=idrv.preprocessing_data(df)
    logger.log_info("Dashboard master data creation...")
    master_data=idrv.master_data_creation(preprocessed_data,sliding_days)
    #Writting master data into Mongodb collection
    mongodbconnector.write_records_from_df(master_data,config.get_io_config_attribute_by_section("mongoDB","collection_idr_result_table_gf"))
    #Filtering only models output columns and researcher response
    precision_recall_columns=master_data[['PS_Nan','PS','FW_Nan','Cls_Emb','Synthetic','Cls_Emb_70','Cls_Emb_80','Cls_V3','ingested_date','Researcher Value']]
    #Writting all models output into mongodb
    mongodbconnector.write_records_from_df(precision_recall_columns,config.get_io_config_attribute_by_section("mongoDB","collection_idr_all_model_output_gf"))
    #Reading all the models output and transforming data
    all_models_output=mongodbconnector.read_all(config.get_io_config_attribute_by_section("mongoDB","collection_idr_all_model_output_gf"))
    raw_df=master_data.copy()
    #All five models output, create the confusion matrix and transform data for - Bar chart datewise  
    logger.log_info("Bar chart transformation data creation for Dashboard...")
    bar_chart_data_datewise=idrv.confusion_bar_chart(raw_df)
    #Confusion matrix datewise score write into mongodb
    logger.log_info("Writting Bar chart data to Mongodb...")
    mongodbconnector.write_records_from_df(bar_chart_data_datewise,config.get_io_config_attribute_by_section("mongoDB","collection_idr_confusion_matrix_gf"))
    #Read all the dates confusion matrix and transforming
    all_dates_confusion_matrix_values=mongodbconnector.read_all(config.get_io_config_attribute_by_section("mongoDB","collection_idr_confusion_matrix_gf"))
    #Aggregate all the dates values and show in the Grafana
    confusion_aggregated_chart_data=all_dates_confusion_matrix_values.groupby(['model','category'])['Count'].sum()
    confusion_aggregated_chart_data=confusion_aggregated_chart_data.reset_index()
    mongodbconnector.delete_all(config.get_io_config_attribute_by_section("mongoDB","collection_idr_aggregated_confusion_matrix_gf"))
    mongodbconnector.write_records_from_df(confusion_aggregated_chart_data,config.get_io_config_attribute_by_section("mongoDB","collection_idr_aggregated_confusion_matrix_gf"))
    
    #ModelPerformance panel for Different models and show in the Grafana
    mongodbconnector.delete_all(config.get_io_config_attribute_by_section("mongoDB","collection_idr_model_performance_gf"))
    idrv.modelperformance(confusion_aggregated_chart_data)

    #Read Confusion matrix datewise score and combine all the date into single Bar chart 
    logger.log_info("Read data from MongoDB and transform the data for Bar chart...")
    #All five models output, create the data for precision and recall for entire date  
    logger.log_info("Precision table creation for the dashboard...")
    final_df=idrv.precision_recall_overall_data(all_models_output)
    mongodbconnector.delete_all(config.get_io_config_attribute_by_section("mongoDB","collection_idr_precision_recall_table_gf"))
    mongodbconnector.write_records_from_df(final_df,config.get_io_config_attribute_by_section("mongoDB","collection_idr_precision_recall_table_gf"))
    #All five models output, create the dataframe for recall values with all the date - Line chart
    logger.log_info("Recall table running for the dashboard...")
    recall_chart_df=idrv.recall_line_chart(raw_df)
    #All five models output, create the dataframe for recall values with all the date - Line chart without insufficient data
    logger.log_info("Recall Line chart data creation - Without insufficient data...")
    recall_chart_df_without_insufficient=idrv.recall_line_chart_without_insufficient(raw_df)
    #recall line chart data write to mongodb with insufficient data - datewise - recall line chart
    logger.log_info("Writting recall chart - with insufficient data into Mongodb...")
    #combining recall with and without insufficient data together for dashboard
    recall_chart_df_final=pd.concat([recall_chart_df,recall_chart_df_without_insufficient],axis=0)
    mongodbconnector.write_records_from_df(recall_chart_df_final,config.get_io_config_attribute_by_section("mongoDB","collection_idr_prediction_recall_gf"))
#     logger.log_info("precision line chart data creation for the dashboard...")
    precision_chart_df=idrv.precision_line_chart(raw_df)
    logger.log_info("Noise removal for precision chart...")
    raw_df_noise_removed=idrv.precision_noise_removal(raw_df)
    precision_chart_df_without_noise=idrv.precision_line_chart_without_noise(raw_df_noise_removed)
    precision_chart_df_final=pd.concat([precision_chart_df,precision_chart_df_without_noise],axis=0)
    logger.log_info("Writting precision chart - with insufficient data into Mongodb...")
    mongodbconnector.write_records_from_df(precision_chart_df_final,config.get_io_config_attribute_by_section("mongoDB","collection_idr_prediction_precision_gf"))
    #All five model precision output write it to mongodb
    logger.log_info("write precision line chart data to MongoDB...")
except Exception as e:
    logger.log_error("Exception occurred..."+ str(e))
    logger.log_error(traceback.format_exc())

end_time=time.time()
elapsed_time=end_time-start_time
elapsed_time=time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
logger.log_info('Identity Resolution:  Transfromation Script: Execution time : '+str(elapsed_time))
