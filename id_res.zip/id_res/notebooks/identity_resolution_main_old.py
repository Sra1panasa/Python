# Databricks notebook source
from idr_src.prediction.extract_payload import *
from idr_src.prediction.save_data_gcs import *
from idr_src.prediction.identity_resolution import *
from idr_src.prediction.name_variation import *
import random,string
from idr_src.performance.performance_report import PerformanceEval

# COMMAND ----------
    
def save_data_applicant(payload_df):
    # push these static fields to config files  
    extracted_payload_filename = "payload_id_res_applicant" + str(datetime.now().date()) + ".xlsx"
    processed_ingested_file_path = "gs://bkt-d-hrgp-data-us/ds_zaha_hrg2/id_resolution/predicted_results/"
    payload_df.to_excel(processed_ingested_file_path + extracted_payload_filename , index= False)
    
def save_data_court(payload_df):
    # push these static fields to config files  
    extracted_payload_filename = "payload_id_res_court" + str(datetime.now().date()) + ".xlsx"
    processed_ingested_file_path = "gs://bkt-d-hrgp-data-us/ds_zaha_hrg2/id_resolution/predicted_results/"
    payload_df.to_excel(processed_ingested_file_path + extracted_payload_filename , index= False)
    
def save_data_prediction(payload_df):
    # push these static fields to config files  
    extracted_payload_filename = "payload_id_res_prediction" + str(datetime.now().date()) + ".xlsx"
    processed_ingested_file_path = "gs://bkt-d-hrgp-data-us/ds_zaha_hrg2/id_resolution/predicted_results/"
    payload_df.to_excel(processed_ingested_file_path + extracted_payload_filename , index= False)
    
    


# COMMAND ----------

def ID_resolution_prediction_pipeline(exp_name):
    try:
        logger=Framework_Logger()
        confg=GetConfigAttr()
        mongodbconnector=PyMongoConnector()
        performance=PerformanceEval()
        experiment_id = mlflow.create_experiment("/mlops_folder/"+exp_name,artifact_location=confg.get_model_config_attribute_by_section("MLFLOW","idr_artifacts"))
        mlflow.autolog()
        with mlflow.start_run(nested=True ,experiment_id=experiment_id) as run:
            run_id = run.info.run_id
            logger.log_info("MLFlow Initialized with run Id "+str(run_id))
            pay=ExtractPayload()
            applicant_path,criminal_rec_path=pay.process_ingested_data_id_resolution()
            save_data_applicant(applicant_path)
            save_data_court(criminal_rec_path) 
            logger.log_info("payload extraction completed")
            id_res=IdentityResolution()
            id_res_prediction=id_res.prediction(applicant_path,criminal_rec_path)
            mlflow_obj=mlflow.tracking.MlflowClient().get_run(run_id).data.to_dictionary()
            metrics=performance.get_performance_metrics(id_res_prediction["researcher_response"],id_res_prediction["id_match_prediction"])
            model_performance=metrics.to_dict('series')
            cm_obj=performance.get_confusion_matrix(id_res_prediction["researcher_response"],id_res_prediction["id_match_prediction"]).T.to_dict('series')
            for key in model_performance:
                model_performance[key]=model_performance[key].to_dict()
            for key in cm_obj:
                cm_obj[key]=cm_obj[key].to_dict()
            store_obj=dict()
            store_obj["_id"]=run_id
            store_obj["experiment_name"]=exp_name
            store_obj["mlflow_params"]=mlflow_obj["params"]
            store_obj["mlflow_metrics"]=mlflow_obj["metrics"]
            store_obj["model_performance"]=model_performance
            store_obj["confusion_matrix"]=cm_obj
            save_data_prediction(id_res_prediction)
            mlflow.log_text(str(IdentityResolution.model), "id_res_model_property.txt")
            applicant_path.to_excel("applicant_data.xlsx")
            criminal_rec_path.to_excel("criminal_data.xlsx")
            id_res_prediction.to_excel("id_res_prediction.xlsx")
            mlflow.log_artifact("applicant_data.xlsx")
            mlflow.log_artifact("criminal_data.xlsx")
            mlflow.log_artifact("id_res_prediction.xlsx")
            logger.log_info("MLFLOW Artifacts saved to GCS")
            mlflow.end_run()
    except Exception as e:
        logger.log_error("Exception occurred" )  


exp_name="ID_resolution_prediction_pipeline_"+"".join(random.choices(string.ascii_lowercase + string.digits, k=10))
ID_resolution_prediction_pipeline(exp_name)



# COMMAND ----------


