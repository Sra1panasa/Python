# Databricks notebook source
from idr_src.utils.logger import Framework_Logger
from idr_src.utils.read_config import *
from idr_src.utils.read_config import *
from idr_src.utils.pymongo_db_connector import PyMongoConnector
import pandas as pd
from idr_src.prediction.name_variation import *
from sentence_transformers import SentenceTransformer
import mlflow
import pandas as pd
import numpy as np
from transformers import AutoTokenizer
from transformers import DataCollatorWithPadding
from transformers import AutoModelForSequenceClassification
from transformers import TrainingArguments, Trainer
from sentence_transformers import SentenceTransformer,util
from idr_src.prediction.replicate_profiles import Replicate_Profiles
import json
import traceback
import time

# COMMAND ----------
#Load the logger framework
log=Framework_Logger()
#Load the configuration 
config_parser = GetConfigAttr()

start_time=time.time()
try:
    #mongodb connection loading here
    mongodbconnector = PyMongoConnector()
    log.log_info("Mongo connector initialized")
    collection_criminal_data_raw = config_parser.get_io_config_attribute_by_section("mongoDB", "collection_criminal_data_raw")
    #Get all the payload in the form list of dictionary
    # This needs to be changed with yesterday date
    payloads_list = mongodbconnector.filter_records_dict(collection_criminal_data_raw, "ingested_date","30-10-2022","idr_processing_status",0)
    log.log_info("Count of payloads is = "+ str(len(payloads_list)))
except Exception as e:
    log.log_error("Exception occurred while extracting payloads..."+ str(e))
    log.log_error(traceback.format_exc())

# COMMAND ----------


rep_prof_obj=Replicate_Profiles()  
    
if payloads_list:
    for payload in payloads_list:
        try:
            request_id=payload['decrypted_data']['applicant_data']['request_id']
            log.log_info("Process Started for request id and mongodb id..."+ str(request_id)+","+str(payload['_id']))
            reg_id=payload['decrypted_data']['applicant_data']['reg_id']
            orderid=payload['orderid']
            orderitemid=payload['orderitemid']
            applcnt_primary_profile_df= pd.json_normalize(payload['decrypted_data']['applicant_data'], max_level=1)
            applcnt_primary_profile_df.insert(0,'payload_index',payload['_id'])
            applicant_profile_addr_fix_df=rep_prof_obj.extract_applicant_address_fields(applcnt_primary_profile_df)
            bod,bom,boy=rep_prof_obj.get_dob_fixed(payload['decrypted_data']['applicant_data']['dob'])
            applicant_profile_dob_fix_df=applicant_profile_addr_fix_df.assign(day_of_birth=bod,month_of_birth=bom,year_of_birth=boy)
            total_replcted_applicant_profiles_df=rep_prof_obj.create_applicant_profiles(applicant_profile_dob_fix_df)
            
            #total_replcted_applicant_profiles.drop_duplicates()

            court_response_df= pd.json_normalize(payload['decrypted_data']['court_response']['source_records'],max_level=0)
            court_response_df = court_response_df.loc[(court_response_df['suppression_status'].notnull()) & \
                                    (court_response_df['suppression_status']!="ELIMINATED")]
            
            if court_response_df.shape[0]!=0:
                order_service_data_source_id= payload['decrypted_data']['court_response']['order_service_data_source_id']
                court_primry_profile_df=court_response_df.assign(payload_index=payload['_id'],request_id=request_id,court_profile_flag="CP_PP")
                court_profile_middle_lastname_fix_df=rep_prof_obj.get_middle_last_name_fixed(court_primry_profile_df)
                court_profile_addrs_dob_fix_df=rep_prof_obj.extract_crime_address_fields(court_profile_middle_lastname_fix_df)
                #court_alias_names_profile_df=rep_prof_obj.create_court_profiles(court_profile_addrs_dob_fix_df)
                #total_court_profiles=pd.concat([court_primry_profile_df,court_alias_names_profile_df],ignore_index=True)
                total_court_profiles=court_profile_addrs_dob_fix_df.copy()
                #total_court_profiles=total_court_profiles.drop_duplicates()
                appl_ps_added_df=rep_prof_obj.get_profile_string_added(total_replcted_applicant_profiles_df)
                crim_ps_added_df=rep_prof_obj.get_profile_string_added(total_court_profiles)
                                                                
                embeded_applicant_profiles_df,embeded_court_profiles_df=rep_prof_obj.create_embedings(\
                    appl_ps_added_df,crim_ps_added_df)
                #Save results to mongodb
                total_cosine_similarty_scores_df=rep_prof_obj.create_cosine_similarty(embeded_applicant_profiles_df,embeded_court_profiles_df)
                rep_prof_obj.predict_nd_save_predicn_results(total_cosine_similarty_scores_df,mongodbconnector,request_id,\
                    payload['_id'],order_service_data_source_id,payload['ingested_date'],reg_id,orderid,orderitemid)

                mongodbconnector.update_idr_process_status(collection_criminal_data_raw,payload['_id'])

            else:
                log.log_info("Paylaod having all missing/eliminated supression status..."+ str(request_id)+","+str(payload['_id']))
                mongodbconnector.update_idr_process_status(collection_criminal_data_raw,payload['_id'],all_eminated_ss_status=True)    
            log.log_info("Processed payload with request id..."+ str(request_id))
        except Exception as e:
            log.log_error("Exception occurred for req id..."+ str(request_id)+","+str(payload['_id'])+ str(e))
            log.log_error(traceback.format_exc())
else:
    log.log_error("No payloads retrieved from Mongo DB to create profiles...")

end_time=time.time()


elapsed_time=end_time-start_time
elapsed_time=time.strftime("%H:%M:%S", time.gmtime(elapsed_time))
log.log_info('ID Resolution : ID Resolution main : Execution time : '+str(elapsed_time))
    

# COMMAND ----------


