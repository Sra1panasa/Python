echo "Installation Started1"
mkdir libpostal
cd libpostal
git clone https://github.com/openvenues/libpostal
cd libpostal
sh bootstrap.sh
sh configure
sudo make install
pip install nose
pip install postal
sudo ldconfig /usr/local/lib
echo "Installation completed"