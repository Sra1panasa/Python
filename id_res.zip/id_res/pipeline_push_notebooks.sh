apt-get install jq zip -y
echo "{\"password\": \"$VAULT_PASSWORD\"}" > payload.json
RESPONSE=`curl --request POST --data @payload.json ${VAULT_SERVER_URL}/v1/auth/userpass/login/${VAULT_USERNAME}`
rm -f payload.json

VAULT_LEASE_CLIENT_TOKEN=`echo $RESPONSE | jq .auth.client_token | sed 's/"//g'`
RESPONSE=`curl --header "X-Vault-Token: $VAULT_LEASE_CLIENT_TOKEN" ${VAULT_SERVER_URL}/v1/dataservices/data/databricks/token`
DATABRICKS_TOKEN=`echo $RESPONSE | jq .data.data.token | sed 's/"//g'`

zip -r notebooks.py.zip notebooks

curl -X POST --header "Authorization: Bearer $DATABRICKS_TOKEN" $DATABRICKS_URL/workspace/delete --data '{ "path": "/ds_idresolution", "recursive": true }'

curl -X POST --header "Authorization: Bearer $DATABRICKS_TOKEN" $DATABRICKS_URL/workspace/import 'Content-Type: multipart/form-data' -F path="/ds_idresolution" -F format=dbc -F  content=@notebooks.py.zip

rm -rf notebooks.py.zip

