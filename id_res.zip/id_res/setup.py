from setuptools import find_packages, setup

setup(
    name='idr_src',
    packages=find_packages(), package_data={
    '': ['*.ini','*.json','*.xml']
    },
    version='0.1.0',
    description='criminal records',
    author='Hireright-crfm',
    license='',
)
