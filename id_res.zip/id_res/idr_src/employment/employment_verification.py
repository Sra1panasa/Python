from idr_src.utils.logger import Framework_Logger
from idr_src.utils.read_config import *
from idr_src.utils.read_config import *
from idr_src.utils.pymongo_db_connector import PyMongoConnector
import pandas as pd
from idr_src.prediction.name_variation import *
from sentence_transformers import SentenceTransformer
import mlflow
import pandas as pd
import numpy as np
from transformers import AutoTokenizer
from transformers import DataCollatorWithPadding
from transformers import AutoModelForSequenceClassification
from idr_src.utils.verification_modules import VerificationModules
from transformers import TrainingArguments, Trainer
from sentence_transformers import SentenceTransformer,util
from datetime import datetime
import traceback
import string


class EmploymentVerification:
    
    
    def __init__(self):
        self.vm=VerificationModules()
    
    def orderitem_emp_dataframe(self,json):
        """
        The function to create the orderitem_emp_dataframe based on employment json

        Parameters:
            emp_json(json):order_item_employment json

        Returns:
            dataframe: employment dataframe 
        """
        order_id_list=json['screeningRequest']['referenceObjects']
        for id in order_id_list:
            if id['type']=='order':
                order_id=id['id']
        emp_data=json['screeningRequest']['subject']['person']['profile']['employment']
        emp_data=pd.DataFrame(emp_data)
        emp_data['order_id']=order_id
        emp_data['orderitemid']=json['_id']
        emp_data=emp_data.explode('positionHistories')
        emp_data=self.vm.normalize_columns(emp_data,'positionHistories')
        emp_data=self.vm.normalize_columns(emp_data,'organization')
        emp_data=emp_data[['order_id','orderitemid','start','end','current','positionHistories_title','positionHistories_titleAliases','positionHistories_start','positionHistories_end','positionHistories_current','organization_name','organization_aliases']]
        for index,row in emp_data.iterrows():
            row['title_variations']=row['positionHistories_titleAliases'].extend((row['positionHistories_title'].split(" ")))
            row['organization_aliases_variation']=row['organization_aliases'].extend((row['organization_name'].split(";")))

        emp_data=self.vm.date_summary(emp_data,list(emp_data.columns),['start','end','positionHistories_start','positionHistories_end'])
        
        return emp_data
    
    def talx_emp_dataframe(self,json):
        """
        The function to create the profiles based on employment_verification payload json

        Parameters:
            json(json):Employment payload json

        Returns:
            dataframe: Employment dataframe of employment sections from payload
        """
        order_id=json['orderid']       
        talx_data=json['verifiedInfo']['subject']['person']['profile']['employment']
        talx_data=pd.DataFrame(talx_data)
        talx_data['order_id']=order_id
        talx_data['orderitemid']=json['orderitemid']
        talx_data=talx_data.explode('positionHistories')
        talx_data=self.vm.normalize_columns(talx_data,'positionHistories')
        talx_data=self.vm.normalize_columns(talx_data,'organization')
        talx_data=talx_data[['order_id','orderitemid','start','end','current','positionHistories_title','positionHistories_titleAliases','positionHistories_start','positionHistories_end','positionHistories_current','organization_name','organization_aliases']]
        for index,row in talx_data.iterrows():
            row['title_variations']=row['positionHistories_titleAliases'].extend((row['positionHistories_title'].split(" ")))
            row['organization_aliases_variation']=row['organization_aliases'].extend((row['organization_name'].split(";")))
        talx_data=self.vm.date_summary(talx_data,list(talx_data.columns),['start','end','positionHistories_start','positionHistories_end'])
        
        
        return talx_data