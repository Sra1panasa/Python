# Code Files to compute the metrics, identify misclassified cases. (Report and analysis)  
import pandas as pd
import numpy as np
from sklearn.metrics import confusion_matrix
import disarray

class PerformanceEval:

    """
        This is a class to check the perfomance metrices (confusion matrix, mismatch cases) of the model 
        
        """


    def get_confusion_matrix(self,actual,pred):

        """
        The function to create confusion matrix

        Parameters:
            actual(dataframe):actual column from dataframe
            pred(dataframe) : prediction column from dataframe

        Returns:
            dataframe: A dataframe of confusion matrix
        """

        unique_label = np.unique([actual, pred])
        cm_df = pd.DataFrame(
            confusion_matrix(actual, pred, labels=unique_label), 
            index=['Actual:{:}'.format(x) for x in unique_label], 
            columns=['Predictions:{:}'.format(x) for x in unique_label]
        )
        return cm_df

    def get_performance_metrics(self,actual,pred):

        """
        The function to create perfomance metrices

        Parameters:
            actual(dataframe):actual column from dataframe
            pred(dataframe) : prediction column from dataframe

        Returns:
            dataframe: A dataframe of perfomance metrices
        """

        unique_label = np.unique([actual, pred])
        cm_df = pd.DataFrame(
            confusion_matrix(actual, pred, labels=unique_label), 
            index=[x for x in unique_label], 
            columns=[x for x in unique_label]
        )
        return cm_df.da.export_metrics()
    

    def get_id_resolution_mismatch(self,data):

        """
        The function to create mismatch cases of prediction dataframe

        Parameters:
            data(dataframe):actual column from dataframe

        Returns:
            dataframe: A dataframe of mismatched cases
        """

        return data[data["researcher_response"]!=data["id_match_prediction"]]

    def get_request_confusion_matrix(request,data):

        """
        The function to create confusion matrix for request_id

        Parameters:
            request(int):request_id values

        Returns:
            data(dataframe): confusion matrix for the given request_id
        """

        data=data[data['request_id']==request]
        return get_confusion_matrix(data["id_match_prediction"].astype(str), data["researcher_resp"].astype(str))