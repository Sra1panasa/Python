from idr_src.utils.pymongo_db_connector import PyMongoConnector
import pandas as pd
from idr_src.performance.performance_report import *
from idr_src.utils.read_config import GetConfigAttr
from idr_src.utils.logger import *
import pandas as pd
from idr_src.performance.performance_report import *
from idr_src.utils.read_config import GetConfigAttr
from idr_src.utils.logger import *
import math
import traceback
import datetime



class IDResolutionVisualizationTransformation:
    
    '''
        In the IDResolutionVisualizationTransformation class  , we compute the Accuracy metrics for Identity Resolution Model
    '''


    def __init__(self):
        self.eval=PerformanceEval()
        self.mongodbconnector=PyMongoConnector()
        self.confg=GetConfigAttr()
        self.logger=Framework_Logger()
        
    def mangodb_datarange_json_read(self,table_name,date_range):
        '''
           Takes all the payload json's from table 

           Parameters  :
              table_name(str) : actual table from mongodb

           Returns   :
              table_name(str)   : read all the payload from table

        '''
        try:
            all_prediction=[]
            for date in date_range:
                prediction_result=self.mongodbconnector.filter_records_dict(table_name, "ingested_date",date)
                all_prediction.extend(prediction_result)
            return all_prediction
        except Exception as e:
            self.logger.log_error("Exception occurred while reading the json's from Mongodb..."+ str(e))
            self.logger.log_error(traceback.format_exc())
        

    def dataset_creation_from_json(self,prediction_result):
        '''
           Convert all the payload json's into dataframe

           Parameters  :
              prediction_result(list) : All the payloads from table
              
           Returns   :
              final_data(DataFrame)   : All the payloads converted into dataframe

        '''
        try:
            df=pd.json_normalize(prediction_result)
            prediction_result_df=df.explode('pred_res')
            prediction_result_df=prediction_result_df.drop(['request_id'],axis=1)
            prediction_result_df=prediction_result_df.reset_index()
            prediction_result_object=pd.json_normalize(prediction_result_df['pred_res'])
            final_df=pd.concat([prediction_result_df,prediction_result_object],axis=1)
            return final_df
        except Exception as e:
            self.logger.log_error("Exception occurred while converting dataframe..."+ str(e))
            self.logger.log_error(traceback.format_exc())
    
    def preprocessing_data(self,df):
        '''
           Takes the dataframe and converted the flag names

           Parameters  :
              df(Dataframe) : payload json's converted dataframe 
           Returns   :
              perform_data(DataFrame)   : Applicant and court flag names changed dataframe

        '''
        try:
            df=df[df['researcher_resp'].notnull()]
            perform_data=df.copy()
            perform_data['applicant_profile_flag'] = perform_data['applicant_profile_flag'].map({'DER_FNV': 'Derived', 'DER_LNV': 'Derived','PRIMARY':'Submitted',"PROV_AN":"Found"})
            perform_data['court_profile_flag']=perform_data['court_profile_flag'].map({"CP_PP":"Submitted"})
            return perform_data
        except Exception as e:
            self.logger.log_error("Exception occurred while preprocessing the data..."+ str(e))
            self.logger.log_error(traceback.format_exc())
    
    def master_data_creation(self,df,toggle_days):
        '''
           Takes preprocessed dataframe and do the neccessery changes (ramaning columns and create the serian no)

           Parameters  :
              df(DataFrame) : all the JSON's converted dataframe

           Returns   :
              master_data_with_pii(DataFrame)   : All the PII data included Dataframe

        '''
        try:
            master_data=df.copy()
            master_data['serial No']=range(0,len(master_data),1)
            master_data=master_data[master_data['applicant_profile_flag']=='Submitted']
            master_data['orderitemid']=master_data['orderitemid'].str.split(':').str[-1]
            master_data=master_data.replace('Inconclusive','Insufficient Data')
#             master_data=master_data.drop(['index','_id','pred_res','appl_profle_string_with_none','crim_profle_string_with_none', 'appl_profle_string_without_none','crim_profle_string_without_none','criminal_case_number', 'payload_index', 'match_compute_status','idr_outcome','court_profile_flag'],axis=1)
            master_data["avg_score"]=master_data[['first_name_score', 'middle_name_score', 'last_name_score',
       'day_of_birth_score', 'month_of_birth_score', 'year_of_birth_score',
       'address_line_score',  'state_score', 'city_score',
       'zip_code_score']].mean(axis=1)

            master_data_with_pii=master_data.rename(columns={'order_service_data_source_id':'osds','appl_first_name':'AFname','crim_first_name':'CFname','first_name_score':'Fname', 'appl_middle_name':'AMname','crim_middle_name':'CMname','middle_name_score':'Mname','appl_last_name':'ALname','crim_last_name':'CLname', 'last_name_score':'Lname','appl_day_of_birth':'AD-DoB','crim_day_of_birth':'CD-DoB','day_of_birth_score':'D-DoB','appl_month_of_birth':'AM-DoB', 'crim_month_of_birth':'CM-DoB','month_of_birth_score':'M-DoB','appl_year_of_birth':'AY-DoB','crim_year_of_birth':'CY-DoB','year_of_birth_score':'Y-DoB','appl_address_line':'A-Add','crim_address_line':'C-Add','address_line_score':'Add','appl_county':'A-County','crim_county':'C-County','county_score':'County','appl_state':'A-State','crim_state':'C-State','state_score':'State','appl_city':'A-City','crim_city':'C-City','city_score':'City','appl_zip_code':'A-Zip','crim_zip_code':'C-Zip','zip_code_score':'Zip','appl_height':'A-Height','crim_height':'C-Height','height_score':'Height','appl_eye_color':'A-eye','crim_eye_color':'C-eye','eye_color_score':'Eye','cls_emb':'Cls_V3','cls_emb_prob':'Cls_V3_Score'})

            master_data_with_pii=master_data_with_pii.rename(columns={'profle_string_with_none_score':'PS_Nan_score','profle_string_without_none_score':'PS_Score','researcher_resp':'Researcher Value', 'aggr_fw_score_without_none':'F_Score','aggr_fw_score_with_none':'F_Nan_Score','cls_model_prob':'Cls_Score','syn_model_prob':'Syn_Score','match_profle_string_with_none':'PS_Nan', 'match_profle_string_without_none':'PS','match_aggr_fw_score_without_none':'FW','match_aggr_fw_score_with_none':'FW_Nan', 'classification_model_prediction':'Cls_Emb','synthetic_model_prediction':'Synthetic'})
            
            master_data_with_pii['Cls_Emb_70'] = master_data_with_pii.loc[master_data_with_pii['Cls_Score']>=0.7,'Cls_Emb']
            master_data_with_pii['Cls_Emb_70'].loc[master_data_with_pii['Cls_Score']<0.7] = 'Insufficient Data'
            
            master_data_with_pii['Cls_Emb_80'] = master_data_with_pii.loc[master_data_with_pii['Cls_Score']>=0.8,'Cls_Emb']
            master_data_with_pii['Cls_Emb_80'].loc[master_data_with_pii['Cls_Score']<0.8] = 'Insufficient Data'
            
            score_columns=['Fname','Mname','Lname','D-DoB','M-DoB','Y-DoB','Add','County','State','City','Zip','Height','Eye']
            master_data_with_pii['feature_count']=master_data_with_pii[master_data_with_pii[score_columns]!=0.0].count(axis=1)
            master_data_with_pii['feature_count']=master_data_with_pii['feature_count'].astype(int)

            master_data_without_pii=master_data_with_pii.drop(['AFname','CFname','AMname','CMname','ALname','CLname','AD-DoB','CD-DoB','AM-DoB','CM-DoB','AY-DoB','CY-DoB','A-Add','C-Add','A-County','C-County','A-State','C-State','A-City','C-City','A-Zip','C-Zip','A-Height','C-Height','A-eye','C-eye'],axis=1)
            master_data_with_pii=master_data_with_pii.round(2)
            master_data_without_pii=master_data_without_pii.round(2)
            
            #100 MB issues - take the recent two or three days of data for result table which covers lesser than 100MB 
            date_list=master_data_with_pii.ingested_date.unique()
            lesser_100mb_final=master_data_with_pii.copy()
            for date in date_list:
                mb=(lesser_100mb_final.memory_usage(index=True,deep=False).sum()/1024)/1024
                if mb>100:
                    lesser_100mb_final=lesser_100mb_final[lesser_100mb_final['ingested_date']!=date]
                else:
                    break
                    
            date_list=lesser_100mb_final.ingested_date.unique()
            
            master_data_for_charts=master_data_with_pii[['PS_Nan','PS','FW_Nan','Cls_Emb','Synthetic','ingested_date','Researcher Value','PS_Score','PS_Nan_score','F_Nan_Score','Cls_Score','Syn_Score','Cls_Emb_70','Cls_Emb_80','Cls_V3','Cls_V3_Score','avg_score']]
            master_data_for_toggle_button=master_data_with_pii[['PS','Cls_Emb','ingested_date','Researcher Value','PS_Score','Cls_Score']]
            lesser_100mb_final.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","idr_results_Eng"),index=False)
            master_data_for_toggle_button.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","idr_toggle_data_Eng"),index=False)
            return master_data_with_pii
        except Exception as e:
            self.logger.log_error("Exception occurred while creating master data with PII.."+ str(e))
            self.logger.log_error(traceback.format_exc())
    
    
    def confusion_bar_chart(self,df):
        '''
           Takes the master dataframe and column, and create the accuracy metrics for confusion matrix - Bar Chart

           Parameters  :
              df(DataFrame) : Data Frame contains all the models results with Researcher Value
              col_name(str)   : column names of all the models

           Returns   :
              temp_df(DataFrame)   : Dataframe contains confusion matrix values

        '''
        try:
            date_list=list(df.ingested_date.unique())
            dfs=[]
            for col in df[['PS_Nan','PS','FW_Nan','Cls_Emb','Synthetic','Cls_Emb_70','Cls_Emb_80','Cls_V3']]:
                df["temp"] = df[col]+";"+df["Researcher Value"]
                for date in date_list:
                    temp_data=df[df['ingested_date']==date]
                    grouped = temp_data.groupby("temp")["temp"].count()
                    actual = grouped.index.str.split(";").str[1]
                    predictions = grouped.index.str.split(";").str[0]
                    temp_df = pd.DataFrame(
                        {
                            "category": actual + " Vs " + predictions,
                            "Count": grouped.values
                        }
                    )

                    temp_df.insert( 0, "model", col)
                    temp_df.insert( 1, "ingested_date", date)

                    dfs.append(temp_df)
            df_bar_chart = pd.concat(dfs).reset_index(drop=True)
            df_bar_chart=df_bar_chart.replace("Actual:","",regex=True)
            df_bar_chart=df_bar_chart.replace("Predictions:","",regex=True)
            return df_bar_chart
        except Exception as e:
            self.logger.log_error("Exception occurred while creating the confusion matrix for Bar chart..."+ str(e))
            self.logger.log_error(traceback.format_exc())

    
    def recall_calculation(self,raw_df):
        '''
           Takes the all the model results column and Researcher value and compute the recall metrics
           Recall =TP/TP+FN

           Parameters  :
              df(DataFrame) : Data Frame contains all the models results with Researcher Value

           Returns   :
              recall_df(DataFrame)   : results with Recall values Dataframe

        '''
        try:
            raw_df=raw_df[['PS_Nan','PS','FW_Nan','Cls_Emb','Synthetic','Cls_Emb_70','Cls_Emb_80','Cls_V3','ingested_date','Researcher Value']]
            recall_df=pd.DataFrame(columns=['Type_r','category_r', 'model name_r', 'model/researcher_r','count_r'])

            to_find=['Match', 'NoMatch']

            filter_col='Researcher Value'

            count=0

            raw_df1 = raw_df.drop(['ingested_date'], axis=1)

            for index in range(raw_df1.shape[1]-1):
                df=raw_df1[[raw_df1.columns[index], raw_df1.columns[raw_df1.shape[1]-1]]]
                for key in to_find:
                    results=dict()
                    lst=[]
                    temp_df=df[df[filter_col]==key]
                    for col in temp_df.columns:
                        results['Type_r']='Recall'
                        results['category_r']=key
                        results['model name_r']=raw_df.columns[index]
                        results['model/researcher_r']=str(col)+" "+str(key)
                        if key in temp_df[col].tolist():
                            count=temp_df[col][temp_df[col]==key].value_counts()[0]
                        else:
                            count=0
                        results['count_r']=count
                        lst.append(count)
                        recall_df=recall_df.append(results, ignore_index=True)
                        count+=1

                    if lst[1]!=0:
                        percentage = ['Recall', key, raw_df.columns[index], 'Percentage Correctly Predicted',  round((lst[0]/lst[1]),2)]
                    else:
                        percentage = ['Recall', key, 'Percentage Correctly Predicted', raw_df.columns[index], 0]

                    recall_df.loc[len(recall_df)] = percentage
            return recall_df
        except Exception as e:
            self.logger.log_error("Exception occurred while create the recall metrics overall..."+ str(e))
            self.logger.log_error(traceback.format_exc())
                
    def precision_calculation(self,raw_df):
        '''
           Takes Actual and Predicted Values and returns Confusion Matrix as DataFrame

           Parameters  :
              actual(String) : actual target variable
              pred(String)   : Predicted target variable

           Returns   :
              cm_df(DataFrame)   : confusion matrix returned as a Dataframe

        '''
        try:
            raw_df=raw_df[['PS_Nan','PS','FW_Nan','Cls_Emb','Synthetic','Cls_Emb_70','Cls_Emb_80','Cls_V3','ingested_date','Researcher Value']]

            precision_df=pd.DataFrame(columns=['Type_p','category_p', 'model name_p', 'model/researcher_p','count_p'])

            to_find=['Match', 'NoMatch']

            count=0

            raw_df1 = raw_df.drop(['ingested_date'], axis=1)

            for index in range(raw_df1.shape[1]-1):
                df=raw_df1[[raw_df1.columns[index], raw_df1.columns[raw_df1.shape[1]-1]]]
                for key in to_find:
                    results=dict()
                    lst=[]
                    filter_col=df.columns[0]
                    temp_df=df[df[filter_col]==key]
                    for col in temp_df.columns:
                        results['Type_p']='Precision'
                        results['category_p']=key
                        results['model name_p']=raw_df.columns[index]
                        results['model/researcher_p']=str(col)+" "+str(key)
                        if key in temp_df[col].tolist():
                            count=temp_df[col][temp_df[col]==key].value_counts()[0]
                        else:
                            count=0
                        results['count_p']=count
                        lst.append(count)
                        precision_df=precision_df.append(results, ignore_index=True)
                        count+=1

                    if lst[0]!=0:
                        percentage = ['Precision', key, raw_df.columns[index], 'Percentage Correctly Predicted from all Prediction',  round((lst[1]/lst[0]),2)]
                    else:
                        percentage = ['Precision', key, 'Percentage Correctly Predicted from all Prediction', raw_df.columns[index], 0]

                    precision_df.loc[len(precision_df)] = percentage
            return precision_df
        except Exception as e:
            self.logger.log_error("Exception occurred while creating the precision overall..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
    def precision_recall_overall_data(self,raw_df):
        '''
        Takes precision recall output and concatinate both the results for dashboard
        Recall =TP/TP+FN

        Parameters  :
            raw_df(DataFrame) : Data Frame contains all the models results with Researcher Value with datewise

        Returns   :
            final_data_recall(DataFrame)   : results with Precision and Recall values Dataframe with datewise

        '''
        try:
            precision_df=self.precision_calculation(raw_df)
            recall_df=self.recall_calculation(raw_df)
            final_df = pd.concat([recall_df, precision_df], axis=1)
            final_df.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","idr_precision_recall_overall_Eng"),index=False)
            return final_df
        except Exception as e:
            self.logger.log_error("Exception occurred while creating the precision overall..."+ str(e))
            self.logger.log_error(traceback.format_exc())
        
                        
    def recall_line_chart(self,raw_df):
        '''
        Takes the all the model results column and Researcher value and compute the precision metrics
        Recall =TP/TP+FN

        Parameters  :
            raw_df(DataFrame) : Data Frame contains all the models results with Researcher Value with datewise

        Returns   :
            final_data_recall(DataFrame)   : results with Precision values Dataframe with datewise

        '''
        try:
            raw_date=list(raw_df['ingested_date'].unique())
            model_list=['PS','PS_Nan','FW_Nan','Synthetic','Cls_Emb','Cls_Emb_70','Cls_Emb_80','Cls_V3']
            matches=['Match','NoMatch']
            found_list=[]

            for ing_date in raw_date:
                dicti={}
                temp_data=raw_df[raw_df['ingested_date']==ing_date]
                for model in model_list:
                    for m in matches:
                        per=self.eval.get_performance_metrics(temp_data['Researcher Value'],temp_data[model]).T
                        dicti[model+' '+m]=per['recall'][m]
                        dicti['ingested_date']=ing_date
                        dicti['Category']="With Insufficient"
                found_list.append(dicti)
            final_data_recall=pd.DataFrame.from_dict(found_list)
            final_data_recall=final_data_recall.fillna(0)
            return final_data_recall
        except Exception as e:
            self.logger.log_error("Exception occurred while creating the recall charts..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
    def recall_line_chart_without_insufficient(self,raw_df):
        raw_date=list(raw_df['ingested_date'].unique())
        model_list=['PS','PS_Nan','FW_Nan','Synthetic','Cls_Emb','Cls_Emb_70','Cls_Emb_80','Cls_V3']
        matches=['Match','NoMatch']
        found_list=[]
        for ing_date in raw_date:
            dicti={}
            temp_data=raw_df[raw_df['ingested_date']==ing_date]
            for model in model_list:
                for m in matches:
                    new_temp=temp_data[temp_data[model]!="Insufficient Data"]
                    per=self.eval.get_performance_metrics(new_temp['Researcher Value'],new_temp[model]).T
                    dicti[model+' '+m]=per['recall'][m]
                    dicti['ingested_date']=ing_date
                    dicti['Category']="Without Insufficient"
            found_list.append(dicti)
        final_data_recall=pd.DataFrame.from_dict(found_list)
        final_data_recall=final_data_recall.fillna(0)
        return final_data_recall
        

    def precision_line_chart(self,raw_df):
        '''
           Takes the all the model results column and Researcher value and compute the precision metrics
           Precision =TP/TP+FP

           Parameters  :
              df(DataFrame) : Data Frame contains all the models results with Researcher Value with datewise

           Returns   :
              final_data_precision(DataFrame)   : results with Precision values Dataframe with datewise

        '''
        try:
            raw_date=list(raw_df['ingested_date'].unique())
            model_list=['PS','PS_Nan','FW_Nan','Synthetic','Cls_Emb','Cls_Emb_70','Cls_Emb_80','Cls_V3']
            matches=['Match','NoMatch']
            found_list=[]

            for ing_date in raw_date:
                dicti={}
                temp_data=raw_df[raw_df['ingested_date']==ing_date]
                for model in model_list:
                    for m in matches:
                        per=self.eval.get_performance_metrics(temp_data['Researcher Value'],temp_data[model]).T
                        dicti[model+' '+m]=per['precision'][m]
                        dicti['ingested_date']=ing_date
                        dicti['Category']="With Noise"
                found_list.append(dicti)
            final_data_precision=pd.DataFrame.from_dict(found_list)
            return final_data_precision
        except Exception as e:
            self.logger.log_error("Exception occurred while creating the precision chart..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
    def precision_line_chart_without_noise(self,raw_df):
        '''
           Takes the all the model results column and Researcher value and compute the precision metrics
           Precision =TP/TP+FP

           Parameters  :
              df(DataFrame) : Data Frame contains all the models results with Researcher Value with datewise

           Returns   :
              final_data_precision(DataFrame)   : results with Precision values Dataframe with datewise

        '''
        try:
            raw_date=list(raw_df['ingested_date'].unique())
            model_list=['PS','PS_Nan','FW_Nan','Synthetic','Cls_Emb','Cls_Emb_70','Cls_Emb_80','Cls_V3']
            matches=['Match','NoMatch']
            found_list=[]

            for ing_date in raw_date:
                dicti={}
                temp_data=raw_df[raw_df['ingested_date']==ing_date]
                for model in model_list:
                    for m in matches:
                        per=self.eval.get_performance_metrics(temp_data['Researcher Value'],temp_data[model]).T
                        dicti[model+' '+m]=per['precision'][m]
                        dicti['ingested_date']=ing_date
                        dicti['Category']="Without Noise"
                found_list.append(dicti)
            final_data_precision=pd.DataFrame.from_dict(found_list)
            return final_data_precision
        except Exception as e:
            self.logger.log_error("Exception occurred while creating the precision chart without noise..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
            
    def update_mongodb_recall_precision_multimodel(self,df,table_name,metric):
        '''
           Takes precision recall value and write into mongo db with idr_recall and idr_precision

           Parameters  :
              df(DataFrame) : Data Frame contains all the models results  with datewise
              table_name(str): mongodb table name
              metric(str): precision/recall sting to store in mongodb

           Returns   :
              write the results into mongodb

        '''
        try:
            recall_dict=df.set_index('ingested_date').T.to_dict()
            recall_payloads_list=self.mongodbconnector.read_all_dict(table_name)

            date_list=[payload['ingested_date'] for payload in recall_payloads_list]
            for date, recall_values in recall_dict.items():
                final_recall_dict={}
                final_recall_dict['ingested_date']=date
                final_recall_dict[metric+'_score']=recall_values
                if final_recall_dict['ingested_date'] not in date_list:
                    self.mongodbconnector.write_records_from_json(final_recall_dict,table_name)
        except Exception as e:
            self.logger.log_error("Exception occurred while writting the precision recall into mongodb..."+ str(e))
            self.logger.log_error(traceback.format_exc())
                
    def read_mongodb_score(self,table_name):
        '''
           Takes table name and read all the precision or recall value from mongodb

           Parameters  :
              table_name(str) : mongodb table name

           Returns   :
              list   : returns the list of precision/recall value json's

        '''
        try:
            return self.mongodbconnector.read_all_dict(table_name)
        except Exception as e:
            self.logger.log_error("Exception occurred while reading the precision/recall table from mongodb..."+ str(e))
            self.logger.log_error(traceback.format_exc())
    
    def transform_data_creation(self,payload_list):
        '''
           Takes the all Precision/recall table and convert as a dataframe for the dashboard

           Parameters  :
              payload_list(list) : ist of precision/recall value json's

           Returns   :
              df(DataFrame)   : precision/recall score dataframe

        '''
        try:
            df=pd.json_normalize(payload_list)
            df.columns=[dfcol.replace("recall_score.","") for dfcol in df.columns]
            df.columns=[dfcol.replace("precision_score.","") for dfcol in df.columns]
#             df=df.drop(['_id'],axis=1)
            return df
        except Exception as e:
            self.logger.log_error("Exception occurred while transforming precision recall dataframe..."+ str(e))
            self.logger.log_error(traceback.format_exc())
    
    def recall_transformation_data(self,table_name):
        '''
           Takes the table from mongodb and create the dataframe store the recall line chart in GCS

           Parameters  :
              table_name(str) : recall table from mongodb

           Returns   :
              recall_scores_df(DataFrame)   : results with recall values Dataframe with datewise

        '''
        try:
            recall_scores_list=self.read_mongodb_score(table_name)
            recall_scores_df=self.transform_data_creation(recall_scores_list)
            recall_scores_df["ingested_date"]=recall_scores_df["ingested_date"].apply(lambda x:datetime.datetime.strptime(x, '%d-%m-%Y'))
            return recall_scores_df
        except Exception as e:
            self.logger.log_error("Exception occurred while transforming recall dataframe..."+ str(e))
            self.logger.log_error(traceback.format_exc())
        
    def precision_transformation_data(self,table_name):
        '''
           Takes the table from mongodb and create the dataframe store the precision line chart in GCS

           Parameters  :
              table_name(str) : precision table from mongodb

           Returns   :
              precision_scores_df(DataFrame)   : results with Precision values Dataframe with datewise

        '''
        try:
            precision_scores_list=self.read_mongodb_score(table_name)
            precision_scores_df=self.transform_data_creation(precision_scores_list)
            precision_scores_df["ingested_date"]=precision_scores_df["ingested_date"].apply(lambda x:datetime.datetime.strptime(x, '%d-%m-%Y'))
#             precision_scores_df.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","idr_precision_line_chart_Eng"),index=False)
            
            return precision_scores_df
        except Exception as e:
            self.logger.log_error("Exception occurred while creating the precision transformation chart..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
    def update_mongodb_confusion_matrix(self,df,table_name):
        '''
           Takes the table from mongodb and create the dataframe store the precision line chart in GCS

           Parameters  :
              df(dataframe):confusion matrix score dataframe
              table_name(str) : confusion matrix table from mongodb

           Returns   :
              mongodb   : written successfully

        '''
        try:
            unique_date_list=list(df['ingested_date'].unique())
            for date in unique_date_list:
                bar_dict={}
                temp_data=df[df['ingested_date']==date]
                bar_dict['ingested_date']=date
                bar_dict['confusion_matrix']=temp_data.to_dict(orient="records")
                multi_model_payloads_list=self.mongodbconnector.read_all_dict(table_name)

                date_list=[payload['ingested_date'] for payload in multi_model_payloads_list]
                if bar_dict['ingested_date'] not in date_list:
                    self.mongodbconnector.write_records_from_json(bar_dict,table_name)
        except Exception as e:
            self.logger.log_error("Exception occurred while writing confusion matrix score..."+ str(e))
            self.logger.log_error(traceback.format_exc())
                
    def transform_confusion_matrix_score(self,table_name):
        '''
           Takes the table from mongodb and create the dataframe store the precision line chart in GCS

           Parameters  :
              table_name(str) : precision table from mongodb

           Returns   :
              bar_chart_data(DataFrame)   : transofromed bar chart data

        '''
        try:
            prediction_result=self.read_mongodb_score(table_name)
            df=pd.json_normalize(prediction_result)
            prediction_result_df=df.explode('confusion_matrix')
            prediction_result_df=prediction_result_df.reset_index()
            prediction_result_object=pd.json_normalize(prediction_result_df['confusion_matrix'])
            final_df_confusion_matrix=pd.concat([prediction_result_df,prediction_result_object],axis=1)
            final_df_confusion_matrix=final_df_confusion_matrix.drop(['index','_id','confusion_matrix'],axis=1)
            bar_chart_data=final_df_confusion_matrix.groupby(['model','category'])['Count'].sum()
            bar_chart_data=bar_chart_data.reset_index()
            bar_chart_data.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","idr_bar_chart_data_Eng"),index=False)
            return bar_chart_data
        except Exception as e:
            self.logger.log_error("Exception occurred while transforming the confusion matrix..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
    def update_mongodb_multi_model(self,df,table_name):
        '''
           Takes the table from mongodb and create the dataframe store the precision line chart in GCS

           Parameters  :
              df(dataframe):confusion matrix score dataframe
              table_name(str) : confusion matrix table from mongodb

           Returns   :
              mongodb   : written successfully

        '''
        try:
            df=df[['PS','Cls_Emb','ingested_date','Researcher Value','PS_Score','Cls_Score','Cls_V3','Cls_V3_Score']]
            unique_date_list=list(df['ingested_date'].unique())
            
            multi_model_payloads_list=self.mongodbconnector.read_all_dict(table_name)
            date_list=[payload['ingested_date'] for payload in multi_model_payloads_list]
            
            for date in unique_date_list:
                if date not in date_list:
                    temp_data=df[df['ingested_date']==date]
                    temp_data_list=np.array_split(temp_data, 2)
                    for i in range(0,len(temp_data_list)):
                        dicti={}
                        dicti['ingested_date']=date
                        dicti['multi_model_prediction']=temp_data_list[i].to_dict(orient="records")
                        self.mongodbconnector.write_records_from_json(dicti,'idr_v2_multiple_model_output')
        except Exception as e:
            self.logger.log_error("Exception occurred while writting the multi model..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
    def transform_multi_model_score(self,table_name,toggle_days):
        '''
           Takes the table from mongodb and create the dataframe store the toggle button operations in GCS

           Parameters  :
              table_name(str) : precision table from mongodb

           Returns   :
              final_df_multi_model(DataFrame)   : transofromed bar chart data

        '''
        try:
            prediction_result=self.mangodb_datarange_json_read(table_name,toggle_days)
            df=pd.json_normalize(prediction_result)
            df=df.drop(['ingested_date'],axis=1)
            prediction_result_df=df.explode('multi_model_prediction')
            prediction_result_df=prediction_result_df.reset_index()
            prediction_result_object=pd.json_normalize(prediction_result_df['multi_model_prediction'])
            final_df_multi_model=pd.concat([prediction_result_df,prediction_result_object],axis=1)
            final_df_multi_model=final_df_multi_model.drop(['index','_id','multi_model_prediction'],axis=1)
            
            #100 MB issues - take approximtely 1 month of data for toggle button which covers lesser than 100MB 
            date_list=final_df_multi_model['ingested_date'].unique()
            lesser_100mb_toggle=final_df_multi_model.copy()
            for date in date_list:
                mb=(lesser_100mb_toggle.memory_usage(index=True,deep=False).sum()/1024)/1024
                if mb>100:
                    lesser_100mb_toggle=lesser_100mb_toggle[lesser_100mb_toggle['ingested_date']!=date]
                else:
                    break
                    
            date_list=lesser_100mb_toggle.ingested_date.unique()
            
            lesser_100mb_toggle.to_csv(self.confg.get_io_config_path_attr_by_section("dashboard","idr_toggle_data_Eng"),index=False)
            return lesser_100mb_toggle
        except Exception as e:
            self.logger.log_error("Exception occurred while transforming the multi model..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
    def precision_noise_removal(self,idr_preds):

        try:

            idr_preds=idr_preds[~((idr_preds["avg_score"]>0.7) & (idr_preds["Researcher Value"]=="NoMatch")
                      & (idr_preds["AD-DoB"].astype(str)==idr_preds["CD-DoB"].astype(str)) 
                      &(idr_preds["AM-DoB"].astype(str)==idr_preds["CM-DoB"].astype(str)) 
                      & (idr_preds["AY-DoB"].astype(str)==idr_preds["CY-DoB"].astype(str))
                      & (idr_preds["A-Zip"].astype(str)==idr_preds["C-Zip"].astype(str)) 
                      & (idr_preds["AFname"].str.lower().str.replace('s/+',"")==idr_preds["CFname"].str.lower().str.replace('s/+',"")) 
                      & (idr_preds["ALname"].str.lower().str.replace('s/+',"")==idr_preds["CLname"].str.lower().str.replace('s/+',"")) 
                      & (idr_preds["A-State"].str.lower().str.replace('s/+',"")==idr_preds["C-State"].str.lower().str.replace('s/+',"")) 
                      & (idr_preds["A-City"].str.lower().str.replace('s/+',"")==idr_preds["C-City"].str.lower().str.replace('s/+',"")))]

            idr_preds=idr_preds[~((idr_preds["avg_score"]>0.7) & (idr_preds["Researcher Value"]=="NoMatch")
                      & (idr_preds["AD-DoB"]==idr_preds["CD-DoB"]) 
                      &(idr_preds["AM-DoB"]==idr_preds["CM-DoB"]) 
                      & (idr_preds["AY-DoB"]==idr_preds["CY-DoB"])
                      & (idr_preds["A-Zip"]==idr_preds["C-Zip"]) 
                      & (idr_preds["AFname"].str.lower().str.replace('s/+',"")==idr_preds["CFname"].str.lower().str.replace('s/+',"")) 
                      & (idr_preds["ALname"].str.lower().str.replace('s/+',"")==idr_preds["CLname"].str.lower().str.replace('s/+',"")) 
                      & (idr_preds["A-State"].str.lower().str.replace('s/+',"")==idr_preds["C-State"].str.lower().str.replace('s/+',"")) 
                      & (idr_preds["A-City"].str.lower().str.replace('s/+',"")==idr_preds["C-City"].str.lower().str.replace('s/+',"")))] 

            idr_preds=idr_preds[~((idr_preds["avg_score"]>0.7) & (idr_preds["Researcher Value"]=="NoMatch")
                       & (idr_preds["AD-DoB"]==idr_preds["CD-DoB"]) 
                      &(idr_preds["AM-DoB"]==idr_preds["CM-DoB"]) 
                      & (idr_preds["AY-DoB"]==idr_preds["CY-DoB"])
                      & (idr_preds["AFname"].str.lower().str.replace('s/+',"")==idr_preds["CFname"].str.lower().str.replace('s/+',"")) 
                      & (idr_preds["ALname"].str.lower().str.replace('s/+',"")==idr_preds["CLname"].str.lower().str.replace('s/+',"")) 

                        & (idr_preds["AMname"].str.lower().str.replace('s/+',"")==idr_preds["CMname"].str.lower().str.replace('s/+',"")) 
                      )] 

            idr_preds=idr_preds[~((idr_preds["Researcher Value"]=="NoMatch")
                       & (idr_preds["AD-DoB"]==idr_preds["CD-DoB"]) 
                      &(idr_preds["AM-DoB"]==idr_preds["CM-DoB"]) 
                      & (idr_preds["AY-DoB"]==idr_preds["CY-DoB"])
                      & (idr_preds["AFname"].str.lower().str.replace('s/+',"")==idr_preds["CFname"].str.lower().str.replace('s/+',"")) 
                      & (idr_preds["ALname"].str.lower().str.replace('s/+',"")==idr_preds["CLname"].str.lower().str.replace('s/+',"")) 

                        & (idr_preds["AMname"].str.lower().str.replace('s/+',"")==idr_preds["CMname"].str.lower().str.replace('s/+',"")) 
                      )] 

            idr_preds=idr_preds[~((idr_preds["Researcher Value"]=="NoMatch")
                       & (idr_preds["AD-DoB"]==idr_preds["CD-DoB"]) 
                      &(idr_preds["AM-DoB"]==idr_preds["CM-DoB"]) 
                      & (idr_preds["AY-DoB"]==idr_preds["CY-DoB"])
                      & (idr_preds["AFname"].str.lower().str.replace('s/+',"")==idr_preds["CFname"].str.lower().str.replace('s/+',"")) 
                      & (idr_preds["ALname"].str.lower().str.replace('s/+',"")==idr_preds["CLname"].str.lower().str.replace('s/+',"")) 
                                            )] 
            return idr_preds
        except Exception as e:
            self.logger.log_error("Exception occurred while removing noise from precision..."+ str(e))
            self.logger.log_error(traceback.format_exc())

