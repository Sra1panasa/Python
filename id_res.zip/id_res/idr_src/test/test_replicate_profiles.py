from idr_src.prediction.name_variation import *
from idr_src.prediction.replicate_profiles import *
from idr_src.utils.logger import Framework_Logger
import numpy as np
import pandas as pd
import json
import pytest
from unittest import mock
sample_applicant_df=np.array([['63203f7146b144e22b74545f','391481546','HE-081922-KU3QN','1236572270','1421166376','190936446','crfmtest011','midemp','abijah','05051990',None,None,'VA',None,['abijah abj', 'abijah abija', 'abijah ab'],None,[],[],None,None,{"address_line1": "1314 Heather Lane"},[{'address_line1': '1315 Heather Lane'}]]])

sample_applicant_df=pd.DataFrame(sample_applicant_df,columns=['id','request_id','reg_id','order_service_id','order_service_data_source_id','applicant_id','first_name','middle_name','last_name','dob','ssn','driving_license','county','state','alias_names','photo_path','education_details','prev_empoyment_details','ssn_trace','mvr','address.current_address','address.previous_addresses'])

sample_court_df=np.array([['ab',None,'abija',['abijah abj', 'abijah abija'],'01011969',{'address_line1': '123 Main Street, City'},None,None,'Court Name',None,None,None,None,'Alias First',None,'111-22-3333',None,'CASE111',[{'offense_literal':'Statute 1111'}],None,None,'IMPORTED','id','391481546','CP_PP']])
sample_court_df=pd.DataFrame(sample_court_df,columns=['first_name', 'middle_name', 'last_name', 'alias_names', 'dob',
       'address', 'county', 'state', 'court_name', 'court_id', 'sor_id',
       'height', 'eye_color', 'alias', 'image', 'government_id',
       'driving_license', 'criminal_case_number', 'charge_info', 'parole_info',
       'jail_time', 'suppression_status', 'id', 'request_id',
       'court_profile_flag'])
sample_court_df

rp=Replicate_Profiles()
log=Framework_Logger()


#Check if we are able to create name variations 
def test_create_variations():
    try:
        variants={'', 'bige', 'ab'}
        mock_create_variations=mock.Mock(name='mock_create_variations',return_value=variants)
        create_variations=mock_create_variations
        
        assert len(create_variations(sample_applicant_df['last_name'][0]))!=0
        log.log_info("Test if we are able to create variations is successful")
    except Exception as e:
        log.log_error("Error in creating name variations.."+str(e))
        

        
#Check if we are able to create applicant profile data from applicant data         
def test_create_applicant_profiles():
    try:
        applicant_profiles_df = pd.DataFrame(np.repeat(sample_applicant_df.values,6,axis=0))
        applicant_profiles_df.columns = sample_applicant_df.columns
        mock_create_applicant_profiles=mock.Mock(name='mock_create_applicant_profiles',return_value=applicant_profiles_df)
        rp.create_applicant_profiles=mock_create_applicant_profiles
        df=rp.create_applicant_profiles(sample_applicant_df)
        assert len(df)==6
        log.log_info("Test for creating applicant profiles is successful")
    except Exception as e:
        log.log_error("Error in creating applicant profiles.."+str(e))
        
        
#Check if we are able to create court profile data from court response data     
def test_create_court_profiles():
    try:
        mock_create_court_profiles=mock.Mock(name='mock_create_court_profiles',return_value=sample_court_df)
        rp.create_court_profiles=mock_create_court_profiles
        assert len(rp.create_court_profiles(sample_court_df))==1
        log.log_info("Test for creating court profiles is successful")
    except Excpetion as e:
        log.log_error("Error in creating court profiles..."+str(e))
#Check if we are able to create embeddings for applicant and court data        
def test_create_embedings():
    try:
        mock_create_embedings=mock.Mock(name='mock_create_embedings',return_value=(sample_applicant_df,sample_court_df))
        rp.create_embedings=mock_create_embedings
        app_df,court_df=rp.create_embedings(sample_applicant_df,sample_court_df)
        assert len(app_df)==1
        log.log_info("Test for creating embeddings is successful")
    except Exception as e:
        log.log_error("Error in creating embeddings..."+str(e))
#Check if we are able to get the cosine similarity for embeddings         
def test_create_cosine_similarty():
    cosine_similarity=np.array([[0.8599,0.993,0.55443,0.6678,0.8898,1.000,0.980]])
    cosine_similarity=pd.DataFrame(cosine_similarity,columns=['first_name', 'middle_name', 'last_name', 'dob', 'address', 'county', 'state'])
    try:
        mock_create_cosine_similarity=mock.Mock(name='mock_create_cosine_similarity',return_value=cosine_similarity)
        rp.create_cosine_similarity=mock_create_cosine_similarity
        cosine_df=rp.create_cosine_similarity(sample_applicant_df,sample_court_df)
        assert len(cosine_df)==1
        log.log_info("Test for generating cosine similarity for embeddings is successful")
    except Exception as e:
        log.log_error("Error in generating cosine similarity for embeddings ..."+str(e))
        
        
      

        
        





    


