import collections
import csv
import pandas as pd
from idr_src.utils.logger import Framework_Logger
from idr_src.utils.read_config import *
from google.cloud import storage
import mlflow
import pandas as pd
import numpy as np
from transformers import AutoTokenizer
from transformers import DataCollatorWithPadding
from transformers import AutoModelForSequenceClassification
from transformers import TrainingArguments, Trainer
import torch
import io
from sentence_transformers import SentenceTransformer
import configparser
# import cloudstorage as gcs

class NameDenormalizer(object):

    """
    This is a class create the name variation for the given name(string)
      
    """

    def __init__(self, filename=None):

        """
        The constructor for calling storage, configuration and logger class.
    
        """
        client = storage.Client()
        self.confg=GetConfigAttr()
        self.logger=Framework_Logger()
        # name_variation_file=self.confg.get_model_config_attribute("name_variation")
        filename = filename or 'gs://bkt-stg-hrgp-ds-us/ds_zaha_hrg2/id_resolution/name_variations_metadata/names.csv' # load from new bucket and config(name/metadata)
        lookup = collections.defaultdict(list)
        df = pd.read_csv(filename, keep_default_na = False)
        for ind, row in df.iterrows():
            line = row.to_list()
            matches = set(line)
            for match in matches:
                lookup[match].append(matches)
        self.lookup = lookup

    def __getitem__(self, name):
        name = name.lower()
        if name not in self.lookup:
            raise KeyError(name)
        names = set().union(*self.lookup[name])
        if name in names:
            names.remove(name)
        return names

    def get(self, name, default={}):
        try:
            return self[name]
        except KeyError:
            return default


def create_variations(original_name):

    """
        The function to create name variation for first name, last name from the applicant

        Parameters:
            original_name(str):first name or last name string from the dataframe

        Returns:
            dataframe: A dataframe of name variation generated
        """

    x = NameDenormalizer()
    variants = x.get(original_name)
    logger=Framework_Logger()
    logger.log_info('name variation generated')
    return variants

# if __name__ == "__main__":
#     original_name = "mcclean"
#     variants = create_variations(original_name)
#     print(variants)
