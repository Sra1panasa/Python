import mlflow
import pandas as pd
import numpy as np
from transformers import AutoTokenizer
from transformers import DataCollatorWithPadding
from transformers import AutoModelForSequenceClassification
from transformers import TrainingArguments, Trainer
import torch
from google.cloud import storage
import io
from sentence_transformers import SentenceTransformer
import configparser
import json
from idr_src.utils.logger import Framework_Logger
from idr_src.utils.read_config import *
from idr_src.utils.read_config import *
from idr_src.utils.pymongo_db_connector import PyMongoConnector

config_parser = GetConfigAttr()

class ExtractPayload:

    def __init__(self):
        self.confg=GetConfigAttr()
        self.bucket_name=self.confg.get_model_config_attribute("bucket_name")
        self.data_path=self.confg.get_io_config_attribute("ingested_data_path")
        self.logger=Framework_Logger()

    def process_ingested_data_id_resolution(self):
        applicant_bag_df = [];court_bag_df = []
        try:
            mongodbconnector = PyMongoConnector()
            self.logger.log_info("Mongo connector initialized")
            #Read the Payoad json from mango_db only not processed (0)
            payload_json = mongodbconnector.filter_records_dict(config_parser.get_io_config_attribute_by_section("mongoDB", "collection_criminal_data_raw") , "idr_processing_status", 0)
            #Bag of indexes
            lst_payload_indexes=[]
            for payload in payload_json:
                #Get the attributes for applicant data
                complete_data=pd.json_normalize(payload)
                lst_payload_indexes.append(payload['_id'])
                complete_data=complete_data[['orderid', 'orderitemid', 'created_timestamp', 'applicant_data.request_id', 'applicant_data.reg_id', 'applicant_data.order_service_id', 'applicant_data.order_service_data_source_id']]
                applicant_data=pd.json_normalize(payload['applicant_data'])
                #Renaming the applicant_data 
                final_dict_applicant=self.confg.payload_applicant_attribute()
                applicant_data=applicant_data.rename(columns=final_dict_applicant)
                self.logger.log_info('Applicant dataframe created')
                #Get the attributes for court data
                court_data_response=pd.json_normalize(payload['court_response'])
                court_data_source=pd.json_normalize(payload['court_response']['target_records'])
                court_data=pd.concat([court_data_response, court_data_source], axis=1, join="inner")
                #Renaming the court_data 
                final_dict_court=self.confg.payload_court_attribute()
                court_data=court_data.rename(columns=final_dict_court)
                final_court_data=pd.concat([complete_data,court_data],axis=1,join="inner")
                self.logger.log_info('Court dataframe created')
                applicant_data.reset_index(inplace=True,drop=True)
                court_data.reset_index(inplace=True,drop=True)
                #appending all the applicant data
                applicant_bag_df.append(applicant_data)
                #appending all the court data
                court_bag_df.append(final_court_data)
        except Exception as e:
            # pass
            self.logger.log_error("exception in process_ingested_data block" + str(e) )
        applicant_payload_df = pd.concat(applicant_bag_df, ignore_index=True)
        court_payload_df = pd.concat(court_bag_df, ignore_index=True)
        self.logger.log_info('Applicant and Criminal data extracted from Payload')
        #Returning applicant data and court data
        return applicant_payload_df,court_payload_df,lst_payload_indexes