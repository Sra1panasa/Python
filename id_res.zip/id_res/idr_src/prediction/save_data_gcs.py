from datetime import datetime
from idr_src.utils.read_config import *


class SaveDataGCS:

        """
        This is a class to save all the output into GCS

        """

        def __init__(self):
                self.confg=GetConfigAttr()

        def save_data_applicant(payload_df):
                # push these static fields to config files  
                extracted_payload_filename = "payload_id_res_applicant" + str(datetime.now().date()) + ".xlsx"
                processed_ingested_file_path = "gs://bkt-d-hrgp-data-us/ds_zaha_hrg2/id_resolution/predicted_results/"
                payload_df.to_excel(processed_ingested_file_path + extracted_payload_filename , index= False)
                
        def save_data_court(payload_df):
                # push these static fields to config files  
                extracted_payload_filename = "payload_id_res_court" + str(datetime.now().date()) + ".xlsx"
                processed_ingested_file_path = "gs://bkt-d-hrgp-data-us/ds_zaha_hrg2/id_resolution/predicted_results/"
                payload_df.to_excel(processed_ingested_file_path + extracted_payload_filename , index= False)
    
        def save_data_prediction(payload_df):
                # push these static fields to config files  
                extracted_payload_filename = "payload_id_res_prediction" + str(datetime.now().date()) + ".xlsx"
                processed_ingested_file_path = "gs://bkt-d-hrgp-data-us/ds_zaha_hrg2/id_resolution/predicted_results/"
                payload_df.to_excel(processed_ingested_file_path + extracted_payload_filename , index= False)