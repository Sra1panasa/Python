#%pip install mlflow
import mlflow
import pandas as pd
import numpy as np
from transformers import AutoTokenizer
from transformers import DataCollatorWithPadding
from transformers import AutoModelForSequenceClassification
from transformers import TrainingArguments, Trainer
import torch
from google.cloud import storage
import io
from sentence_transformers import SentenceTransformer,util
import configparser
from idr_src.prediction.name_variation import *
from idr_src.utils.logger import Framework_Logger
from idr_src.utils.read_config import *
from idr_src.utils.pymongo_db_connector import PyMongoConnector


config_parser = GetConfigAttr()

class IdentityResolution:

    model= SentenceTransformer('all-mpnet-base-v2')
    
    def __init__(self):
        client = storage.Client()
        self.confg=GetConfigAttr()
        bucket_name=self.confg.get_model_config_attribute("bucket_name")
        self.bucket=client.get_bucket(bucket_name)
        self.logger=Framework_Logger()
        
        
    def create_string_from_row(self,r):
        return f"{r['PERSON_FIRST_NAME']}_{r['PERSON_LAST_NAME']}_{r['PERSON_MIDDLE_NAME']}_{r['DOB']}_{r['STREET']}_{r['CITY']}_{r['ZIP']}"
    

    def create_variant_strings_from_row(self,r, name_variants):
            results = [self.create_string_from_row(r)] 
            for name_variant in list(name_variants):
                if(name_variant!=""):
                    rcopy = r.copy() 
                    rcopy["PERSON_LAST_NAME"] = name_variant
                    variant_string = self.create_string_from_row(rcopy)
                    results.append(variant_string)
            return results

    def date_extraction(self,text):
        return pd.to_datetime(text).date()
        
    def create_string_from_row_crim(self,r):
        return f"{r['RECORD_FIRST_NAME']} {r['RECORD_LAST_NAME']}_{r['RECORD_MIDDLE_NAME']}_{r['RECORD_DOB']}_{r['RECORD_ADDRESS_LINE']}_{r['RECORD_CITY']}_{r['RECORD_POSTAL_CODE']}"
    

    def create_variant_strings_from_row_crim(self,r, name_variants):
        results = [self.create_string_from_row_crim(r)] 
        for name_variant in list(name_variants):
            rcopy = r.copy() 
            rcopy["RECORD_LAST_NAME"] = name_variant
            variant_string = self.create_string_from_row_crim(rcopy)
            results.append(variant_string)
        return results
    
    
    def prediction(self,applicant_data_df,court_records_df,lst_payload_indexes):
        try:
            mongodbconnector = PyMongoConnector()
            self.logger.log_info("Mongo connector initialized")
            crim_results = []
            app_req_ids=applicant_data_df["request_id"].unique().tolist()
            court_records_df = court_records_df[court_records_df.request_id.isin(app_req_ids)].reset_index(drop=True)
            court_records_df["profile_string"]=court_records_df.apply(lambda x:self.create_string_from_row_crim(x).lower(),axis=1)
            court_records_df["embedding"]=court_records_df.apply(lambda x:IdentityResolution.model.encode(x["profile_string"], convert_to_tensor=True),axis=1)
            self.logger.log_info("Embeddings are created")
            for ind, row in applicant_data_df.iterrows():
                name_variations = create_variations(original_name=row["PERSON_LAST_NAME"])
                 # create strings from name variants
                variant_strings = self.create_variant_strings_from_row(row, name_variations)
                self.logger.log_info("variant_strings generated") 
                for variant in variant_strings:
                    # Create embedding for variant
                    embedding1 = IdentityResolution.model.encode(variant.strip().lower(), convert_to_tensor=True)
                    crim_sub = court_records_df[court_records_df.request_id == row.request_id]
                    for crim_ind, crim_row in crim_sub.iterrows():
                        crim_record=self.create_string_from_row_crim(crim_row)
                        embedding3 = IdentityResolution.model.encode(crim_record.lower(), convert_to_tensor=True)
                        crim_cosine_score = util.pytorch_cos_sim(embedding1, crim_row["embedding"])
                        crim_results.append([row.request_id,crim_row["order_service_id"], variant, crim_row["profile_string"], crim_cosine_score.item(),crim_row["hrg1_results.hrg1_action"],crim_row['orderid'], crim_row['orderitemid'],crim_row['created_timestamp'], crim_row['request_id'], crim_row['reg_id'], crim_row['order_service_id'], crim_row['order_service_data_source_id']])
                        similarity_scores_crim = pd.DataFrame(crim_results, columns=["request_id","ORDER_SERVICE_ID","Applicant Name Variations", "Record", "Score", 'hrg1_results.hrg1_action','orderid', 'orderitemid','created_timestamp', 'request_id', 'reg_id', 'order_service_id', 'order_service_data_source_id']) 
                        print('similarity_scores_crim',similarity_scores_crim)
                        #TO-DO DELETE LATER  TEMPORARY FOR TESTING
                        similarity_scores_crim['researcher_response']="Match"
                        #Threshold to decide match is above 70% and below 40% is No match and 40% to 70% is Inconclusive of similarity score
                        similarity_scores_crim['id_match_prediction']=['Match' if x>0.7 else 'NoMatch' if 0.4>=x<0.7 else 'Inconclusive' for x in similarity_scores_crim['Score']]
                        # similarity_scores_crim['match_compute_status']=similarity_scores_crim['researcher_response']==similarity_scores_crim['id_match_prediction']
                        # similarity_scores_crim['idr_outcome']=[1 if x==True else 0 for x in similarity_scores_crim['match_compute_status']]
                        # similarity_scores_crim['idr_processing_status']=1
                        #Read the date from Timestamp
                        similarity_scores_crim['created_timestamp']=similarity_scores_crim['created_timestamp'].apply(self.date_extraction)
                        #Perfomance Computation placeholder Flags
                        similarity_scores_crim['match_compute_status']=0
                        similarity_scores_crim['idr_outcome']="NA"
                        #Renaming all the columns of id resolution predicted dataframe
                        similarity_scores=similarity_scores_crim.rename(columns={'ORDER_SERVICE_ID': 'order_service_id', 'created_timestamp': 'ingestion_date','Applicant Name Variations':'applicant_profile_string','Record':'criminal_profile_string'})
                    #Writting the id resolution predicted dataframe into Mogodb
                    mongodbconnector.write_records_from_df(similarity_scores, config_parser.get_io_config_attribute_by_section("mongoDB", "collection_idr_prediction_results"))
                    collection = mongodbconnector.crimdb[config_parser.get_io_config_attribute_by_section("mongoDB", "collection_criminal_data_raw")]
                    result = collection.update_one(
                    {"_id":lst_payload_indexes[ind]},
                        {
                            "$set":{"idr_processing_status" : "1"},
                        }
                    )
                    self.logger.log_info(result.modified_count())
            self.logger.log_info("completed")
            return similarity_scores
        except Exception as e:
            self.logger.log_error("exception in prediction block : " + str(e) )






