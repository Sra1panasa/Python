
# Databricks notebook source
from idr_src.utils.logger import Framework_Logger
from idr_src.utils.read_config import *
from idr_src.utils.read_config import *
from idr_src.utils.pymongo_db_connector import PyMongoConnector
import pandas as pd
from idr_src.prediction.name_variation import *
from sentence_transformers import SentenceTransformer
import mlflow
import pandas as pd
import numpy as np
from sentence_transformers import SentenceTransformer,util
import json
import traceback
from postal.parser import parse_address
import re
import pickle
import gcsfs

class Replicate_Profiles:

    """
    This is a class for creation of applicant and court profiles.Name variation generation for both the first name and last name,
    Alias name based profile creation, Prevoius address based profile creation
      
    Attributes:
        real (int): The real part of complex number.
        imag (int): The imaginary part of complex number.
    """

    def __init__(self):
        self.log=Framework_Logger()
        self.config_parser = GetConfigAttr()
        self.model=SentenceTransformer('all-mpnet-base-v2')

    
    def create_name_variations(self,applcnt_primary_profile_df,name,first_or_lastname):

        """
        The function to create name variation for first name, last name from the applicant

        Parameters:
            applcnt_primary_profile_df(dataframe):identity resolution applicant dataframe
            name(str):
            first_or_lastname(str) :

        Returns:
            dataframe: A dataframe of name variation generated
        """
        try:
            if name:
                name_variations_list = create_variations(name)
                name_variations_list = list(filter(None, name_variations_list)) #['bige', 'ab']
                name_variant_profiles_df= pd.DataFrame()
                #DER_LNV - Derived last name Variation
                for name_variation in name_variations_list:
                    if first_or_lastname=="lastname":
                        name_variant_profiles_df=name_variant_profiles_df.append(applcnt_primary_profile_df.loc[[0]].\
                                                    assign(last_name=name_variation, applicant_profile_flag="DER_LNV"), ignore_index=True)
                                                                                
                    else:
                        name_variant_profiles_df=name_variant_profiles_df.append(applcnt_primary_profile_df.loc[[0]].assign(first_name=\
                                                                name_variation,applicant_profile_flag="DER_FNV"), ignore_index=True)
                return name_variant_profiles_df

        except Exception as e:
            self.log.log_error("Exception occurred while creating name variant profiles..."+ str(e))
            self.log.log_error(traceback.format_exc())

    
    def replicate_profiles_from_namevariation(self,applcnt_primary_profile_df):

        """
        The function to create the profiles based on name variation generated

        Parameters:
            applcnt_primary_profile_df(dataframe):identity resolution applicant dataframe

        Returns:
            dataframe: Profiles(rows) created based on name variation generated
        """

        applicant_lastname=str(applcnt_primary_profile_df['last_name'][0])
        applicant_firstname=str(applcnt_primary_profile_df['first_name'][0])
        last_name_variation_df=self.create_name_variations(applcnt_primary_profile_df,applicant_lastname,"lastname")
        first_name_variation_df=self.create_name_variations(applcnt_primary_profile_df,applicant_firstname,"firstname")
            
        name_variant_profiles_df = pd.concat([last_name_variation_df,first_name_variation_df],ignore_index=True)
            
        return name_variant_profiles_df

    
    def replicate_profiles_from_aliasnames(self,applcnt_primary_profile_df):

        """
        The function to create the profiles based on name variation generated

        Parameters:
            applcnt_primary_profile_df(dataframe):identity resolution applicant dataframe

        Returns:
            applcnt_primary_profile_df(dataframe): Profiles(rows) created based on name alias name column
        """

        try:
            alias_names_list=list(applcnt_primary_profile_df['alias_names'][0])
            alias_names_list = list(filter(None, alias_names_list))
            alias_name_profiles_df= pd.DataFrame()
            # PROV_AN - Provided Alias Name
            if alias_names_list:
                for alias_name in alias_names_list:
                    first_nd_lastname_list=alias_name.split()
                    if len(first_nd_lastname_list)==1:
                        alias_name_profiles_df=alias_name_profiles_df.append(applcnt_primary_profile_df.loc[[0]].\
                                assign(first_name=first_nd_lastname_list[0],applicant_profile_flag="PROV_AN"), ignore_index=True)
                    if len(first_nd_lastname_list)>1:
                        alias_name_profiles_df=alias_name_profiles_df.append(applcnt_primary_profile_df.loc[[0]].\
                        assign(last_name=first_nd_lastname_list[-1],first_name=first_nd_lastname_list[0],\
                        applicant_profile_flag="PROV_AN"), ignore_index=True)
            return alias_name_profiles_df
        except Exception as e:
            self.log.log_error("Exception occurred while creating alias name profiles..."+ str(e))
            self.log.log_error(traceback.format_exc())

    def replicate_profiles_from_prevaddress(self,applcnt_namevar_nd_aliasnames_df):

        """
        The function to create the profiles based on name variation generated

        Parameters:
            applcnt_namevar_nd_aliasnames_df(dataframe):identity resolution applicant dataframe

        Returns:
            applcnt_namevar_nd_aliasnames_df(dataframe): Profiles(rows) created based on prevoius address column
        """


        try:
            previous_addresses_list=applcnt_namevar_nd_aliasnames_df.iloc[0]['address.previous_addresses']

            prev_addresses_df= pd.DataFrame()
            for prevaddr in previous_addresses_list:
                # address will update for all applcnt_namevar_nd_aliasnames_df records
                prev_addresses_df=prev_addresses_df.append(applcnt_namevar_nd_aliasnames_df.\
                assign(address=json.dumps(prevaddr),applicant_profile_flag="SEC_PA")\
                                                        ,ignore_index=True)
            return prev_addresses_df
        except Exception as e:
            self.log.log_error("Exception occurred while creating profiles from previous address..."+ str(e))
            self.log.log_error(traceback.format_exc())
    
    def create_applicant_profiles(self,applcnt_primary_profile_df):

        """
        The function to create the applicant profiles based on name variations, alias name and previous address values

        Parameters:
            applcnt_primary_profile_df(dataframe):identity resolution applicant dataframe

        Returns:
            applcnt_primary_profile_df(dataframe): Profiles(rows) created based onname variations, alias name and previous address values
        """


        try:
            applcnt_primary_profile_df["applicant_profile_flag"]="PRIMARY"

            #applcnt_replcted_profils_frm_namevar_df=self.replicate_profiles_from_namevariation(applcnt_primary_profile_df)

            applcnt_replcted_profils_frm_aliasnames_df=self.replicate_profiles_from_aliasnames(applcnt_primary_profile_df)
            # remove duplicate records if last name same from alias name and name variants
            
            #applcnt_namevar_nd_aliasnames_df = pd.concat([applcnt_primary_profile_df, \
            #applcnt_replcted_profils_frm_aliasnames_df],ignore_index=True)
        
            # removing duplicates from name variations and alias names 
            
            #applcnt_namevar_nd_aliasnames_df = applcnt_namevar_nd_aliasnames_df.drop_duplicates(['first_name','middle_name',\
                                                            #'last_name'], keep='first')

                                                                                             
            applcnt_replcted_profils_frm_prevadd=self.replicate_profiles_from_prevaddress(applcnt_primary_profile_df)
           
            # total applicant profiles 
            total_replcted_applicant_profiles=pd.concat([applcnt_primary_profile_df,applcnt_replcted_profils_frm_aliasnames_df,
            applcnt_replcted_profils_frm_prevadd],ignore_index=True)

            total_replcted_applicant_profiles = total_replcted_applicant_profiles.drop_duplicates(['first_name','middle_name',\
                                                            'last_name'], keep='first')

            return total_replcted_applicant_profiles
        except Exception as e:
            self.log.log_error("Exception occurred while creating applicant profiles..."+ str(e))
            self.log.log_error(traceback.format_exc())

    

    def create_court_profiles(self,court_response_df):

        """
        The function to create the applicant profiles based on alias name values

        Parameters:
            court_response_df(dataframe):identity resolution court dataframe

        Returns:
            court_response_df(dataframe): Profiles(rows) created based alias name values
        """


        alias_name_profiles_df= pd.DataFrame()
        try:
            for index, row in court_response_df.iterrows():
                alias_names_list=row['alias_names']
                alias_names_list = list(filter(None, alias_names_list))

                if alias_names_list:
                    for alias_name in alias_names_list:
                        first_nd_lastname_list=alias_name.split() 
                        if len(first_nd_lastname_list)==1:
                            alias_name_profiles_df=alias_name_profiles_df.append(row.to_frame().transpose().\
                                assign(first_name=first_nd_lastname_list[0],\
                                    court_profile_flag="CP_AN"))
                        if len(first_nd_lastname_list)>1:
                            alias_name_profiles_df=alias_name_profiles_df.append(row.to_frame().transpose().\
                                assign(last_name=first_nd_lastname_list[-1],first_name=first_nd_lastname_list[0],\
                                    court_profile_flag="CP_AN"))
            
            alias_name_profiles_df = alias_name_profiles_df.drop_duplicates(['first_name','middle_name',\
                                                            'last_name'], keep='first')
            return alias_name_profiles_df
        except Exception as e:
            self.log.log_error("Exception occurred while creating applicant profiles..."+ str(e))
            self.log.log_error(traceback.format_exc())

    def create_embedings(self,applicant_profiles_df,court_profiles_df,extrnal_feature_list=None):

        """
        The function to load the huggingface pre-trained model and create the embeddings for both the 
        applicant and court profiles and return as dataframe

        Parameters:
            applicant_profiles_df(dataframe):identity resolution applicant dataframe
            court_response_df(dataframe):identity resolution court dataframe

        Returns:
            applicant_profiles_df(dataframe):embedding output for applicant profiles
            court_response_df(dataframe): embedding output for court profiles
        """


        try:
            
            feature_list=['first_name', 'middle_name', 'last_name', 'day_of_birth','month_of_birth','year_of_birth',\
            'address_line', 'county', 'state','city','zip_code','height','eye_color'\
                          ,'profle_string_with_none','profle_string_without_none']


            applicant_profiles_df = applicant_profiles_df.replace({np.nan:'',"nan":""}, regex=True)
            court_profiles_df = court_profiles_df.replace({np.nan:'',"nan":""},regex=True)

            if extrnal_feature_list:
                feature_list=extrnal_feature_list
            
            for feature in feature_list:

                applicant_profiles_df[feature+"_embeded"]=applicant_profiles_df[feature].apply( \
                lambda x: self.model.encode(x,convert_to_tensor=True) if x and x!="invalid" else None)

                court_profiles_df[feature+"_embeded"]=court_profiles_df[feature].apply(\
                    lambda x: self.model.encode(x,convert_to_tensor=True) if x and x!="invalid" else None)

            return applicant_profiles_df,court_profiles_df
        
        except Exception as e:
            self.log.log_error("Exception occurred while creating embedings..."+ str(e))
            self.log.log_error(traceback.format_exc())
    def create_scores_and_summary(self,appl_row,crim_row,extrnal_feature_list):

        """
        The function to load the applicant and court profiles and see any of the features are empty then retun the summary as part of summary column
        which we need to show in the dashboard

        Parameters:
            appl_row(dataframe):applicant dataframe
            crim_row(dataframe):court dataframe

        Returns:
            appl_row(dataframe):score and summary added in the dataframe
            crim_row(dataframe):score and summary added in the dataframe
        """


        try:
            cosine_similarty_score_dict={}
            features_list=['first_name', 'middle_name', 'last_name', 'day_of_birth','month_of_birth','year_of_birth',\
            'address_line', 'county', 'state','city','zip_code','height','eye_color'\
                          ,'profle_string_with_none','profle_string_without_none']

            if extrnal_feature_list:
                features_list=extrnal_feature_list

            summary="fields are none-: "
            appl_profle_string_without_none=""
            appl_profle_string_with_none=""
            crim_profle_string_with_none=""
            crim_profle_string_without_none=""
            for feature in features_list:

                """profile String creation
                if appl_row[feature] and crim_row[feature] and appl_row[feature]!="invalid" and crim_row[feature]!="invalid":
                    appl_profle_string_without_none +=appl_row[feature]+"_"
                    crim_profle_string_without_none +=crim_row[feature]+"_"

                appl_profle_string_with_none +=appl_row[feature]+"_"
                crim_profle_string_with_none +=crim_row[feature]+"_"  """

                # Summary creation
                if appl_row[feature+"_embeded"]==None or crim_row[feature+"_embeded"]==None:
                    if appl_row[feature] in [None,'']:
                        summary +="appl_"+feature+","
                    else:
                        summary +="crim_"+feature+","
                        
                    cosine_similarty_score_dict["appl_"+feature]=appl_row[feature]
                    cosine_similarty_score_dict["crim_"+feature]=crim_row[feature]
                    cosine_similarty_score_dict[feature+"_score"]=np.nan
                else:
                    cosine_similarty_score_dict["appl_"+feature]=appl_row[feature]
                    cosine_similarty_score_dict["crim_"+feature]=crim_row[feature]
                    cosine_similarty_score = util.pytorch_cos_sim(appl_row[feature+"_embeded"], crim_row[feature+"_embeded"])
                    cosine_similarty_score_dict[feature+"_score"]=cosine_similarty_score.item()

            summary = summary[:-1]
            summary += '.'
            cosine_similarty_score_dict["summary"]=summary  
            cosine_similarty_score_dict["criminal_case_number"]=crim_row['criminal_case_number']
            cosine_similarty_score_dict["applicant_profile_flag"]=appl_row['applicant_profile_flag']
            cosine_similarty_score_dict["court_profile_flag"]=crim_row['court_profile_flag']

            """
            cosine_similarty_score_dict["appl_profle_string_without_none"]=f"{appl_profle_string_without_none[:-1]}"
            cosine_similarty_score_dict["crim_profle_string_without_none"]=f"{crim_profle_string_without_none[:-1]}"
            cosine_similarty_score_dict["appl_profle_string_with_none"]=f"{appl_profle_string_with_none[:-1]}"
            cosine_similarty_score_dict["crim_profle_string_with_none"]=f"{crim_profle_string_with_none[:-1]}" """


            # if we don't need for each prediction we can exclude since at the end we are adding
            cosine_similarty_score_dict["request_id"]=appl_row['request_id']
            cosine_similarty_score_dict["payload_index"]=appl_row['payload_index']
            cosine_similarty_score_dict['researcher_resp']=crim_row['researcher_resp']
            
            cosine_similarty_score_dict["match_compute_status"]=0
            cosine_similarty_score_dict['idr_outcome']="NA"
            return cosine_similarty_score_dict
        except Exception as e:
            self.log.log_error("Exception occurred while creating scores and summary..."+ str(e))
            self.log.log_error(traceback.format_exc())

    def create_cosine_similarty(self,applicant_profiles_df,court_profiles_df,extrnal_feature_list=None):

        """
        The function to create the cosine similarity 
        Parameters:
            applicant_profiles_df(dataframe):embedded column of applicant dataframe
            court_response_df(dataframe):embedded column of court dataframe

        Returns:
            applicant_profiles_df(dataframe):simalarity output for applicant profiles
            court_response_df(dataframe): simalarity output for court profiles
        """


        try:
            total_cosine_similarty_score_list=[]
            court_profiles_df['researcher_resp'] = court_profiles_df['suppression_status'].map({'IGNORED': 'NoMatch', 'IMPORTED': 'Match'})

            for ind, appl_row in applicant_profiles_df.iterrows():
                for crim_ind, crim_row in court_profiles_df.iterrows():
                    one_record_scores_dict=self.create_scores_and_summary(appl_row,crim_row,extrnal_feature_list)
                    total_cosine_similarty_score_list.append(one_record_scores_dict)

            total_cosine_similarty_scores_df = pd.DataFrame.from_dict(total_cosine_similarty_score_list)
            return total_cosine_similarty_scores_df

        except Exception as e:
            self.log.log_error("Exception occurred while creating cosine similarities..."+ str(e))
            self.log.log_error(traceback.format_exc())



    def predict_nd_save_predicn_results(self,total_cosine_similarty_scores_df,mongodbconnector,request_id,id,\
                            order_service_data_source_id,ingested_date,reg_id,orderid,orderitemid):

        """
        The function to create the cosine similarity 
        Parameters:
            total_cosine_similarty_scores_df(int):similarity score
            mongodbconnector(table):mongodb table names from configuration
            request_id,id,order_service_data_source_id,ingested_date,reg_id,orderid,orderitemid:columns which we needs to store in mongodb

        Returns:
            all the json will be stored into mongodb
        """
        
        try:
            total_cosine_similarty_scores_df['aggr_fw_score_without_none'] = total_cosine_similarty_scores_df[['first_name_score', \
            'last_name_score','middle_name_score','day_of_birth_score','month_of_birth_score','year_of_birth_score','address_line_score', \
            'county_score', 'state_score','city_score','zip_code_score','height_score','eye_color_score']].mean(axis=1,skipna=True)



            total_cosine_similarty_scores_df['aggr_fw_score_with_none'] = total_cosine_similarty_scores_df[['first_name_score', \
            'last_name_score','middle_name_score','day_of_birth_score','month_of_birth_score','year_of_birth_score','address_line_score', \
            'county_score', 'state_score','city_score','zip_code_score','height_score','eye_color_score']].mean(axis=1)

            total_cosine_similarty_scores_df['match_profle_string_with_none']=['Match' if x>0.7 else 'NoMatch' if 0.4>=x<0.7 else 'Inconclusive' \
                                                                         for x in total_cosine_similarty_scores_df['profle_string_with_none_score']]

            total_cosine_similarty_scores_df['match_profle_string_without_none']=['Match' if x>0.7 else 'NoMatch' if 0.4>=x<0.7 else 'Inconclusive' \
                                                                         for x in total_cosine_similarty_scores_df['profle_string_without_none_score']]

            total_cosine_similarty_scores_df['match_aggr_fw_score_without_none']=['Match' if x>0.7 else 'NoMatch' if 0.4>=x<0.7 else 'Inconclusive' \
                                                                         for x in total_cosine_similarty_scores_df['aggr_fw_score_without_none']]

            total_cosine_similarty_scores_df['match_aggr_fw_score_with_none']=['Match' if x>0.7 else 'NoMatch' if 0.4>=x<0.7 else 'Inconclusive' \
                                                                         for x in total_cosine_similarty_scores_df['aggr_fw_score_with_none']]

                
            total_cosine_similarty_scores_df=self.get_cls_models_added(total_cosine_similarty_scores_df)

            pred_res_dict = dict()
            pred_res_dict['request_id']=request_id
            pred_res_dict['id']=id
            pred_res_dict['order_service_data_source_id']=order_service_data_source_id
            pred_res_dict['ingested_date']=ingested_date
            pred_res_dict['reg_id']=reg_id
            pred_res_dict['orderid']=orderid
            pred_res_dict['orderitemid']=orderitemid
            pred_res_dict["pred_res"] = total_cosine_similarty_scores_df.to_dict(orient="records")
            
            collection_name=self.config_parser.get_io_config_attribute_by_section("mongoDB", "collection_idr_prediction_results")

            if mongodbconnector:
                mongodbconnector.write_records_from_json(pred_res_dict,collection_name)
                                  
            else:
                mongodbconnector = PyMongoConnector()
                mongodbconnector.write_records_from_json(pred_res_dict,collection_name)
        except Exception as e:
            self.log.log_error("Exception occurred in predicting and saving results to mongodb..."+ str(e))
            self.log.log_error(traceback.format_exc())

    def get_middle_last_name_fixed(self,court_primry_profile_df):

        """
        The function is used to handle middle and last name which comes along with first name 
        Parameters:
            court_primry_profile_df:court response dataframe

        Returns:
            court response dataframe
        """
        try:
            for i,row in court_primry_profile_df.iterrows():
                if row['first_name'] and not row['middle_name'] and not row['last_name']:
                    firstname_striped=row['first_name'].replace("(Dft)","").replace("(Db)","").replace("Jr","").replace("Sr","").strip().strip(",").strip()
                    firstname_space_removed=re.sub(' +', ' ', firstname_striped)
                    firstname_cleaned=re.sub("[^A-Za-z ]","",firstname_space_removed)
                    firstnamelist=firstname_cleaned.split(",")
                    fn,mn,ln="","",""
                    firstnamelist = list(filter(str.strip, firstnamelist))
                    if len(firstnamelist)==1:
                        fn_mn_ln_list=firstnamelist[0].split() # it will have list length 3 or more -"FN MN LN"
                        fn_mn_ln_list = list(filter(str.strip, fn_mn_ln_list))
                        if len(fn_mn_ln_list)>2:
                            fn=fn_mn_ln_list[0]
                            mn=" ".join(fn_mn_ln_list[1:-1]).strip()
                            ln=fn_mn_ln_list[-1]
                        elif len(fn_mn_ln_list)==2:
                            fn=fn_mn_ln_list[0]
                            ln=fn_mn_ln_list[1]
                            mn=""
                        elif len(fn_mn_ln_list)==1:
                            fn=fn_mn_ln_list[0]
                            mn=""
                            ln=""
                    elif len(firstnamelist)==2:  # it will have list length 2 - "LN, FN MN"
                        ln=firstnamelist[0]
                        fn_mn=firstnamelist[1]
                        fn_mn_list=fn_mn.split()
                        fn_mn_list = list(filter(str.strip, fn_mn_list))
                        if len(fn_mn_list)>0:
                            if len(fn_mn_list)>1:
                                fn=fn_mn_list[0]
                                mn=fn_mn_list[-1]
                            elif len(fn_mn_list)==1:
                                fn=fn_mn_list[0]
                                mn=""

                    elif len(firstnamelist)>2: # it will have list length 3 or more - "LN, FN, MN"
                        ln=firstnamelist[0]
                        fn=firstnamelist[1]
                        mn=" ".join(firstnamelist[1:-1]).strip()

                    else:
                        # if none of the above condtion met then we will add incoming name as it is in first name
                        fn=row['first_name']
                        mn=""
                        ln=""

                    
                    court_primry_profile_df._set_value(i,'first_name',fn)
                    court_primry_profile_df._set_value(i,'middle_name',mn)
                    court_primry_profile_df._set_value(i,'last_name',ln)
                
            return court_primry_profile_df
        
        except Exception as e:
            self.log.log_error("Exception occurred while fixing middle and last name..."+ str(e))
            self.log.log_error(traceback.format_exc())

    

    def extract_applicant_address_fields(self,applcnt_primary_profile_df):
        try:
            applcnt_primary_profile_df.rename(columns = {'address.current_address':'address'}, inplace = True)
            address_dict=applcnt_primary_profile_df['address'][0] #current_address dict type
            
            mvr_dict=applcnt_primary_profile_df['mvr'][0]
            height,eye_color="",""
            
            if mvr_dict :
                height=mvr_dict['height']
                eye_color=mvr_dict['eye_color']

            applcnt_primary_profile_df=applcnt_primary_profile_df.assign(city=address_dict['city'],\
            county=address_dict['county'],state=address_dict['state'],zip_code=address_dict['zip_code'], \
                                        address_line=address_dict['address_line1'],height=height,eye_color=eye_color)
                                                                                        
            return applcnt_primary_profile_df

        except Exception as e:
            self.log.log_error("Exception occurred while extracting applicant address fields..."+ str(e))
            self.log.log_error(traceback.format_exc())

    def extract_crime_address_fields(self,court_primry_profile_df):
        try:
            for i,row in court_primry_profile_df.iterrows():
                address_dict=row['address']
                bod,bom,boy=self.get_dob_fixed(row['dob'])
                court_primry_profile_df.at[i,'day_of_birth']="" if not bod else bod
                court_primry_profile_df.at[i,'month_of_birth']="" if not bom else bom
                court_primry_profile_df.at[i,'year_of_birth']="" if not boy else boy
                court_primry_profile_df.at[i,'height']=row['height']
                court_primry_profile_df.at[i,'eye_color']=row['eye_color']

                addr_keys=address_dict.keys()
                if 'address_line1' in addr_keys and 'city' in addr_keys and 'county' in \
                addr_keys and 'state' in addr_keys and 'zip_code' in addr_keys :
                
                    court_primry_profile_df.at[i,'address_line']="" if not address_dict['address_line1'] \
                    else address_dict['address_line1']
                    
                    court_primry_profile_df.at[i,'city']="" if not address_dict['city'] \
                    else address_dict['city']
                    
                    court_primry_profile_df.at[i,'county']="" if not address_dict['county'] \
                    else address_dict['county']
                    
                    court_primry_profile_df.at[i,'state']="" if not address_dict['state'] \
                    else address_dict['state']
                    
                    court_primry_profile_df.at[i,'zip_code']="" if not address_dict['zip_code'] \
                    else address_dict['zip_code']

                else:
            
                    if 'address_line1' in  address_dict.keys():
                        
                        address=address_dict['address_line1']
                        
                        libpostal_addr_list=parse_address(address_dict['address_line1']) # parsing address to lib postal parse_address
                        
                        
                        libpostal_addr_dict = {k: v for (v, k) in libpostal_addr_list}  # converting to dict
                        
                        if 'city' in  libpostal_addr_dict.keys():
                            court_primry_profile_df.at[i,'city']="" if not libpostal_addr_dict['city'] else libpostal_addr_dict['city']
                            address = re.sub('(?i)'+re.escape(libpostal_addr_dict['city']), lambda m: "", address)
                            #address = address.replace(libpostal_addr_dict['city'], "")
                        else:
                            court_primry_profile_df.at[i,'city']=""
                        
                        if 'postcode' in  libpostal_addr_dict.keys():
                            court_primry_profile_df.at[i,'zip_code']="" if not  \
                            libpostal_addr_dict['postcode'] else libpostal_addr_dict['postcode']
                            address = re.sub('(?i)'+re.escape(libpostal_addr_dict['postcode']), lambda m: "", address)
                        else:
                            court_primry_profile_df.at[i,'zip_code']=""
                        
                        if 'county' in  libpostal_addr_dict.keys():
                            if not row['county']:
                                court_primry_profile_df.at[i,'county']="" if not libpostal_addr_dict['county'] else libpostal_addr_dict['county']
                                address = re.sub('(?i)'+re.escape(libpostal_addr_dict['county']), lambda m: "", address)
                            
                            else:
                                address = re.sub('(?i)'+re.escape(libpostal_addr_dict['county']), lambda m: "", address)
                    
                        if 'state' in  libpostal_addr_dict.keys():
                            if not row['state']:
                                court_primry_profile_df.at[i,'state']="" if not libpostal_addr_dict['state'] else libpostal_addr_dict['state']
                                address = re.sub('(?i)'+re.escape(libpostal_addr_dict['state']), lambda m: "", address)
                            else:
                                address = re.sub('(?i)'+re.escape(libpostal_addr_dict['state']), lambda m: "", address)
                                
                        court_primry_profile_df.at[i,'address_line']=address   
            
            
            return court_primry_profile_df
        except Exception as e:
            self.log.log_error("Exception occurred while extracting criminal address fields..."+ str(e))
            self.log.log_error(traceback.format_exc())

    
    def get_dob_fixed(self,dob):
        try:
            bom,bod,boy="","",""
            if len(dob)==8 and "*" not in dob:
                bom=dob[:2]
                bod=dob[2:4]

                if dob[4:6] in ['17','18','19','20']:
                    boy=dob[4:8]
                else:
                    boy="invalid"

            elif len(dob)==4 and "*" not in dob:   
                bom=None
                bod=None
                if  dob[0:2] in ['17','18','19','20']:
                    boy=dob
                else:
                    boy="Invalid"
            elif  "*"  in dob : 
                bom="invalid"
                bod="invalid"
                boy="invalid"

            elif not dob:
                bom=""
                bod=""
                boy=""

            return bod,bom,boy
        
        except Exception as e:
            self.log.log_error("Exception occurred while extracting fields from dob..."+ str(e))
            self.log.log_error(traceback.format_exc())


    def get_row_profile_string(self,row,extrnal_feature_list):

        try:
            feature_list=['first_name', 'middle_name', 'last_name', 'day_of_birth','month_of_birth','year_of_birth',\
                        'address_line', 'county', 'state','city','zip_code','height','eye_color']
            
            if extrnal_feature_list:
                feature_list=extrnal_feature_list

            profle_string_without_none=""
            profle_string_with_none=""
           
            for feature in feature_list:
                if row[feature] and row[feature]!="invalid":
                    profle_string_without_none +=str(row[feature])+"_"

                profle_string_with_none +=""+"_" if not row[feature] or \
                            row[feature]=="invalid" else str(row[feature])+"_"
            
            return f"{profle_string_without_none[:-1]}",f"{profle_string_with_none[:-1]}"

        except Exception as e:
            self.log.log_error("Exception occurred while extracting row profile string..."+ str(e))
            self.log.log_error(traceback.format_exc())

    def get_profile_string_added(self,df,feature_list=None):
    
        try:
            for ind, row in df.iterrows():
                ps_without_none,ps_with_none=self.get_row_profile_string(row,feature_list)
                df.at[ind,'profle_string_without_none']=ps_without_none
                df.at[ind,'profle_string_with_none']=ps_with_none        
                
            return df
        except Exception as e:
            self.log.log_error("Exception occurred in get_profile_string_added..."+ str(e))
            self.log.log_error(traceback.format_exc())

    def get_cls_models_added(self,total_cosine_similarty_scores_df):
        
        try:
            total_cosine_similarty_scores_df["first_name_score"].fillna(0,inplace=True)
            total_cosine_similarty_scores_df["middle_name_score"].fillna(0,inplace=True)
            total_cosine_similarty_scores_df["last_name_score"].fillna(0,inplace=True)
            total_cosine_similarty_scores_df["day_of_birth_score"].fillna(0,inplace=True)
            total_cosine_similarty_scores_df["month_of_birth_score"].fillna(0,inplace=True)
            total_cosine_similarty_scores_df["year_of_birth_score"].fillna(0,inplace=True)
            total_cosine_similarty_scores_df["address_line_score"].fillna(0,inplace=True)
            total_cosine_similarty_scores_df["county_score"].fillna(0,inplace=True)
            total_cosine_similarty_scores_df["state_score"].fillna(0,inplace=True)
            total_cosine_similarty_scores_df["city_score"].fillna(0,inplace=True)
            total_cosine_similarty_scores_df["zip_code_score"].fillna(0,inplace=True)
            total_cosine_similarty_scores_df["height_score"].fillna(0,inplace=True)
            total_cosine_similarty_scores_df["eye_color_score"].fillna(0,inplace=True)

            project = self.config_parser.get_io_config_attribute_by_section("project", "dsstg")
            fs = gcsfs.GCSFileSystem(project=project)
            syn_model,cls_model=None,None
            with fs.open('bkt-stg-hrgp-ds-us/experiments/synthetic_model.pkl', 'rb') as output_syn:
                syn_model=pickle.load(output_syn)
            with fs.open('bkt-stg-hrgp-ds-us/experiments/real_data_model.pkl', 'rb') as output_cls:
                cls_model=pickle.load(output_cls)      


            total_cosine_similarty_scores_df["classification_model_prediction"]=cls_model.predict(total_cosine_similarty_scores_df[['first_name_score', 'middle_name_score', 'last_name_score',\
            'day_of_birth_score', 'month_of_birth_score', 'year_of_birth_score','address_line_score', 'county_score', 'state_score', 'city_score',\
                'zip_code_score', 'height_score', 'eye_color_score']])
       
       
            total_cosine_similarty_scores_df["synthetic_model_prediction"]=syn_model.predict(total_cosine_similarty_scores_df[['first_name_score', 'middle_name_score', 'last_name_score',\
            'day_of_birth_score', 'month_of_birth_score', 'year_of_birth_score','address_line_score', 'county_score', 'state_score', 'city_score',\
                'zip_code_score', 'height_score', 'eye_color_score']])
       
            total_cosine_similarty_scores_df["classification_model_prediction"]=total_cosine_similarty_scores_df["classification_model_prediction"].replace({1:"Match",0:"NoMatch"})
            total_cosine_similarty_scores_df["synthetic_model_prediction"]=total_cosine_similarty_scores_df["synthetic_model_prediction"].replace({1:"Match",0:"NoMatch"})

            total_cosine_similarty_scores_df["cls_model_prob"]=np.max(cls_model.predict_proba(total_cosine_similarty_scores_df[['first_name_score', 'middle_name_score', 'last_name_score',\
            'day_of_birth_score', 'month_of_birth_score', 'year_of_birth_score','address_line_score', 'county_score', 'state_score', 'city_score',\
                'zip_code_score', 'height_score', 'eye_color_score']]),axis=1)

            total_cosine_similarty_scores_df["syn_model_prob"]=np.max(syn_model.predict_proba(total_cosine_similarty_scores_df[['first_name_score', 'middle_name_score', 'last_name_score',\
            'day_of_birth_score', 'month_of_birth_score', 'year_of_birth_score','address_line_score', 'county_score', 'state_score', 'city_score',\
                'zip_code_score', 'height_score', 'eye_color_score']]),axis=1)


            return total_cosine_similarty_scores_df
        except Exception as e:
            self.log.log_error("Exception occurred while reading cls models for id res..."+ str(e))
            self.log.log_error(traceback.format_exc())