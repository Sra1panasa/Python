"""
Author : Ina Jain
Version : 1.0
Comment : Connection to MondoDB and read, write functionalities is taken care 
        in this module

"""

import pandas as pd
import traceback
from idr_src.utils.logger import Framework_Logger
from idr_src.utils.read_config import *
from idr_src.utils.hvac_connector import Vault
import uuid
import pymongo

class PyMongoConnector:

    """
    This is a class to connect mangodb

    """
    

    def __init__(self, region = "us") -> None:

        """
    This is a class create the name variation for the given name(string)
      
    """

        self.confg=GetConfigAttr()
        self.logger=Framework_Logger()
        self.logger.log_info('inside mongodb connector init !!!')

        self.environment = os.environ.get('environment')
        self.region = region

        if self.environment == "dsstg":
            self.mongo_username = "datascience-apps"
            self.mongo_password = "OhIZjsOllNrX0N4S"

        else:
            vault_obj = Vault(self.environment)
            mongoDbcreds = vault_obj.get_mongoDb_creds()
            if mongoDbcreds:
                self.mongo_username = mongoDbcreds['mongoUser']
                self.mongo_password = mongoDbcreds['mongoPass']
        
        self.mongo_checkpoint = self.confg.get_io_config_attribute_by_section("mongoDB","checkpoint")
        mongo_server_end_point = self.confg.get_io_config_attribute_by_section("mongoDB",f"{self.environment}_url")
        if self.environment == "local":
            self.mongo_uri = "mongodb://%s:%s@%s"% (self.mongo_username,self.mongo_password, mongo_server_end_point)
        else:
            self.mongo_uri ="mongodb+srv://%s:%s@%s/myFirstDatabase?retryWrites=true&w=majority"% (self.mongo_username,self.mongo_password, mongo_server_end_point)
 
        self._database = self.confg.get_io_config_attribute_by_section("mongoDB","mongodb_database")
        self.triggerInterval = "15 seconds"
        
        # mongodb client 
        self.client = pymongo.MongoClient(self.mongo_uri)
        # database
        self.crimdb = self.client[self._database]
        

        
    # insert dataframe to mongodb (multiple records)
    def write_records_from_df(self, df, collection_name):

        """
        The function to write the records to mongob as dataframe format

        Parameters:
            df(dataframe):dataframe which needs to store into mongodb table
            collection_name(table):create the table in mongodb with "collection_name"

        Returns:
            dataframe: A dataframe will be created and stored into mongodb
        """

        # collection
        collection = self.crimdb[collection_name]
        result = collection.insert_many(df.to_dict("records") )
        self.logger.log_info('data frame size to be inserted : ' + str(df.shape[0]))
        self.logger.log_info('count of records inserted : ' + str(len(result.inserted_ids) ))
        
    # insert one record (json/dict) to mongodb 
    def write_records_from_json(self, data_dict, collection_name): 

        """
        The function to write the records to mongob as dataframe format

        Parameters:
            data_dict(dictionary):dictionary which needs to be store into mongodb table
            collection_name(table):create the table in mongodb with "collection_name"

        Returns:
            dataframe: A json will be created and stored into mongodb
        """

        # collection
        collection = self.crimdb[collection_name]
        result = collection.insert_one(data_dict)
        self.logger.log_info('count of records inserted : ' + str(result.inserted_id) )

    # read all records in a collection into a dataframe, 
    # use this function when data is already flattened in the collection
    def read_all(self, collection_name):

        """
        The function to write the records to mongob as dataframe format

        Parameters:
            collection_name(table):table name from the mongodb

        Returns:
            collection_name(json): read the all the json from "collection_name" table
        """

        # collection
        collection = self.crimdb[collection_name]
        cursor = collection.find({})
        df = pd.DataFrame(list(cursor))
        self.logger.log_info('count of records extracted : ' + str(df.shape[0] ))
        return df

    # read all records in a collection into a list of dict, 
    # use this function when data is a nested dict in the collection
    def read_all_dict(self, collection_name):

        """
        The function to write the records to mongob as dataframe format

        Parameters:
            collection_name(table):table name from the mongodb

        Returns:
            collection_name(json): read the all the json from "collection_name" table
        """

        # collection
        collection = self.crimdb[collection_name]
        cursor = collection.find({})
        lst_results = list(cursor)
        self.logger.log_info('count of records extracted : ' + str(len(lst_results)) )
        return lst_results

    # filter/read records based on a condition into a dataframe 
    # use this function when data is already flattened in the collection
    def filter_records(self, collection_name, col_name, value):

        """
        The function to filter the records to mongob as dataframe format

        Parameters:
            collection_name(table):table name from the mongodb
            col_name(str): column name which we needs to filter
            value(str): values which needs to filter from the column value

        Returns:
            collection_name(json): read the all the json which matches the filter condition
        """

        # collection
        collection = self.crimdb[collection_name]
        cursor = collection.find({col_name: value})
        df = pd.DataFrame(list(cursor))
        self.logger.log_info('count of records filtered : ' + str(df.shape[0] ))
        return df
        
    # filter/read records based on a condition into a list of jsons/dicts
    # use this function when data is a nested dict in the collection
    def filter_records_dict(self, collection_name, col1, value1,col2=None,value2=None):


        """
        The function to filter the records to mongob as dataframe format

        Parameters:
            collection_name(table):table name from the mongodb
            col_name(str): column name which we needs to filter
            value(str): values which needs to filter from the column value

        Returns:
            collection_name(json): read the all the json which matches the filter condition
        """

        # collection
        collection = self.crimdb[collection_name]
        if not col2:
            cursor = collection.find({col1: value1})
        else:
            cursor = collection.find({col1: value1,col2: value2})
        lst_results = list(cursor)
        self.logger.log_info('count of records filtered : ' + str(len(lst_results)) )
        return lst_results
        
    # function to update the collection
    # update_rec_lst is list of col:value pairs to be updated from the df dataframe in the order of index 
    # fetched using the command => update_dict = df[[<list of column names>]].to_dict("records")
    # id_lst is the list of corresponding index

    def upsert_records(self, collection_name, id_lst, update_rec_lst):

        """
        The function to filter the records to mongob as dataframe format

        Parameters:
            collection_name(table):table name from the mongodb
            id_lst(str): column name which we needs to filter
            update_rec_lst(str): values which needs to filter from the column value

        Returns:
            collection_name(json): read the all the json which matches the filter condition
        """

        # collection
        collection = self.crimdb[collection_name]
        for ind in range(len(id_lst)):
            _id = id_lst[ind]
            result = collection.update_one(
                    {"_id":_id},
                        {
                            "$set":update_rec_lst[ind],
                        }
            )
        self.logger.log_info('count of records updated : ' + str(len(id_lst)) )
    


    # delete all the records in a collection 
    def delete_all(self, collection_name):

        """
        The function to delete mongob json's from mongodb collection 

        Parameters:
            collection_name(table):table name from the mongodb

        Returns:
            collection_name(json): deleted all the json from "collection_name"
        """

        # collection
        collection = self.crimdb[collection_name]
        deleted_rec = collection.delete_many({})
        self.logger.log_info("documents deleted count :" + str(deleted_rec.deleted_count))
        
    # delete the collection
    def delete_collection(self, collection_name):

        """
        The function to delete mongob collection table

        Parameters:
            collection_name(table):table name from the mongodb

        Returns:
            collection_name(json): delete the "collection_name" from mongodb
        """

        # collection
        collection = self.crimdb[collection_name]
        collection.drop()
        self.logger.log_info('successfully dropped collection : ' + collection_name)

    # create new collection
    def create_collection(self, collection_name):

        """
        The function to create mongob collection table

        Parameters:
            collection_name(table):table name from the mongodb

        Returns:
            collection_name(json): created the "collection_name" from mongodb
        """

        # collection
        collection = self.crimdb[collection_name]
        self.logger.log_info('successfully created collection : ' + collection_name)
        return collection
    
    def update_idr_process_status(self,collection_name,id,all_eminated_ss_status=False):

        """
        The function to to update idr_prossessing status to 1

        Parameters:
            collection_name(table):table name from the mongodb

        Returns:
            None: Updates the collection
        """

        try:
            collection = self.crimdb[collection_name]
            filter_key = { '_id': id }
            newvalues=None
            # Values to be updated.
            if not all_eminated_ss_status:
                newvalues = { "$set": { 'idr_processing_status': 1} }
            else:
                newvalues = { "$set": { 'idr_processing_status': 2} }

            # Using update_one() method for single updation
            collection.update_one(filter_key, newvalues)
        except Exception as e:
            self.logger.log_info("Exception occurred while updating idr_process_status..."+ str(e))