import configparser
import os



class GetConfigAttr:

    """
    This is a class to maintain all the configuration, all the environment variables, model path, and attribute names

    """

    def __init__(self):
        try:
            # print(os.path.join(os.path.dirname(__file__)))
            # print(os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config', 'io_config.ini')))
            self.ioconfig = configparser.RawConfigParser()
            ioConfigFilePath=os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config', 'io_config.ini'))
            modelConfigFilePath=os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config', 'model_config.ini'))
            verConfigFilePath=os.path.realpath(os.path.join(os.path.dirname(__file__), '..', 'config', 'verification_config.ini'))
            self.ioconfig.read_file(open(ioConfigFilePath))
            self.modelConfig = configparser.RawConfigParser()   
            self.modelConfig.read_file(open(modelConfigFilePath))
            self.verConfig = configparser.RawConfigParser() 
            self.verConfig.read_file(open(verConfigFilePath))
            self.environment=os.environ.get('environment')
            self.bucket_name = self.get_io_config_attribute_by_section("gcsBucket",f"{self.environment}_bucket")

        except Exception as e:
            print(e)
            print(self.ioconfig, self.modelConfig)

    def get_io_config_attribute(self,key):
        '''Get value of the attribute from the input/ouput config'''
        return self.ioconfig.get("PATH",key)

    def get_model_config_attribute(self, key):
        '''Get value of the attribute from the model config'''
        return self.modelConfig.get("MODELPATH",key)
    
    def get_io_config_attribute_by_section(self, section, key):
        '''Get value of the attribute from the input/ouput config by section'''
        return self.ioconfig.get(section,key)

    def get_model_config_attribute_by_section(self, section, key):
        '''Get value of the attribute from the input/ouput config by section'''
        return self.modelConfig.get(section,key)

    def payload_applicant_attribute(self):
        #Renaming the applicant profiles columns (features)
        payload_json_keys = list(self.modelConfig['PAYLOAD_JSON_APPLICANT'].keys())
        code_keys = list(self.modelConfig['PAYLOAD_JSON_APPLICANT'].values())
        final_dict_applicant=dict(zip(payload_json_keys,code_keys))
        '''Get value of the attribute from the model config for Applicant'''
        return final_dict_applicant

    def payload_court_attribute(self):
        #Renaming the court profiles columns (features)
        payload_json_keys = list(self.modelConfig['PAYLOAD_JSON_COURT'].keys())
        code_keys = list(self.modelConfig['PAYLOAD_JSON_COURT'].values())
        final_dict_court=dict(zip(payload_json_keys,code_keys))
        '''Get value of the attribute from the model config for Court data'''
        return final_dict_court

    def verification_edu_emp_name_feature(self):
        payload_json_keys = list(self.verConfig['EDU_EMP_VERIFICATION_NAME'].keys())
        code_keys = list(self.verConfig['EDU_EMP_VERIFICATION_NAME'].values())
        final_dict_applicant=dict(zip(payload_json_keys,code_keys))
        return final_dict_applicant

    def verification_education_feature(self):
        payload_json_keys = list(self.verConfig['EDUCATION_VERIFICATION'].keys())
        code_keys = list(self.verConfig['EDUCATION_VERIFICATION'].values())
        final_dict_applicant=dict(zip(payload_json_keys,code_keys))
        return final_dict_applicant

    def verification_employment_feature(self):
        payload_json_keys = list(self.verConfig['EMPLOYMENT_VERIFICATION'].keys())
        code_keys = list(self.verConfig['EMPLOYMENT_VERIFICATION'].values())
        final_dict_applicant=dict(zip(payload_json_keys,code_keys))
        return final_dict_applicant

    def get_io_config_path_attr_by_section(self, section, key):
        '''Get value of the attribute from the input/ouput config by section'''
        local_path=self.ioconfig.get(section,key)
        gcs_path="gs://"+self.bucket_name+"/"+local_path
        return gcs_path

    def get_project_name(self):
        return self.get_io_config_attribute_by_section("project",f"{self.environment}")






# attr=GetConfigAttr()
# print(attr.get_model_config_attribute("bucket_name"))

# print(os.path.join(os.path.dirname(__file__), '..', 'config', 'io_config.config'))