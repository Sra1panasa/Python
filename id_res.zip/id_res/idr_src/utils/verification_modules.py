from idr_src.utils.logger import Framework_Logger
from idr_src.utils.read_config import *
from idr_src.utils.read_config import *
from idr_src.utils.pymongo_db_connector import PyMongoConnector
import pandas as pd
from idr_src.prediction.name_variation import *
from sentence_transformers import SentenceTransformer
import mlflow
import pandas as pd
import numpy as np
from transformers import AutoTokenizer
from transformers import DataCollatorWithPadding
from transformers import AutoModelForSequenceClassification
from transformers import TrainingArguments, Trainer
from sentence_transformers import SentenceTransformer,util
from datetime import datetime
import traceback
import string

class VerificationModules:
        
    def __init__(self):
        """
        This is a class for all the common methods 
        
        Attributes:
            model: Pretrained Huggingface embedding model.
            logger:Calling the logger framework
        """
        self.logger=Framework_Logger()
        self.model=SentenceTransformer('all-mpnet-base-v2')
        
    
    def rename_cols(self,df,prefix):
        """
        This is a function to rename the dataframe columns based on prefix string.
        
        Parameters:
            df (dataframe): dataframe of verification payload json
            prefix (str): column feature name (string)
            
        Returns:
            df(dataframe):renamed dataframe
            
        """
        df.columns=[prefix+"_"+col for col in df]
        return df
    
    def normalize_columns(self,df,normalize_columns):
        """
        This is a function to renaming and normalize the columns.
        
        Parameters:
            df (dataframe): dataframe of verification payload json
            normalize_columns(str): feature/column name from dataframe
            
        Returns:
            df(dataframe):renamed dataframe
            
        """
        normalized_df=pd.json_normalize(df[normalize_columns])
        normalized_df=self.rename_cols(normalized_df,normalize_columns)
        df=df.join(normalized_df)
        return df
    
    
    def alias_assign_values(self,formatted_name):
        
        """
        This is a function to renaming and normalize the columns.
        
        Parameters:
            formatted_name (str): verification dataframe feature names
            
        Returns:
            formatted_name(list):list of elements based on"~"
            
        """
        try:
            
            splitted_format=formatted_name.split("~")
            splitted_format = list(filter(str.strip, splitted_format))
            if len(splitted_format)>=3:
                return splitted_format[0]," ".join(splitted_format[1:-1]).strip(),splitted_format[-1]
            elif len(splitted_format)==2:
                return splitted_format[0],"",splitted_format[-1]
            elif len(splitted_format)==0:
                return "","",""
            else:
                return splitted_format[0],"",""
        except Exception as e:
            self.logger.log_error("Exception occurred while creating name dataframe..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
    def get_row_profile_string(self,row,feature_list):
        
        """
        This is a function to create profile string based on feature list.
        
        Parameters:
            row (dataframe row): verification dataframe feature names
            feature_list(list): list of features from dataframe
            
        Returns:
            df(dataframe):dataframe of profile string added
            
        """
       
        try:
            row=row.replace(np.nan,"")
            profle_string_without_none=""
            profle_string_with_none=""
           
            for feature in feature_list:
                if row[feature] and row[feature]!="invalid":
                    profle_string_without_none +=str(row[feature])+"_"



                profle_string_with_none +=""+"_" if not row[feature] or \
                            [feature]=="invalid" else str(row[feature])+"_"
            
            return f"{profle_string_without_none[:-1]}",f"{profle_string_with_none[:-1]}"


        except Exception as e:
            self.logger.log_error("Exception occurred while creating profile string..."+ str(e))
            self.logger.log_error(traceback.format_exc())

    def get_profile_string_added(self,df,get_row_profile_string):
        
        """
        This is a function to create profile string based on feature list.
        
        Parameters:
            df (dataframe): dataframe of features
            get_row_profile_string(row): add profile string in  every row
            
        Returns:
            df(dataframe):dataframe of profile string added
            
        """
    
        try:
            for ind, row in df.iterrows():
                ps_with_none,ps_without_none=self.get_row_profile_string(row,get_row_profile_string)
                df.at[ind,'profle_string_without_none']=ps_without_none
                df.at[ind,'profle_string_with_none']=ps_with_none        
                
            return df
        except Exception as e:
            self.logger.log_error("Exception occurred in get_profile_string_added..."+ str(e))
            self.logger.log_error(traceback.format_exc())
        
    
    def get_order_details(self,app_json):
        
        """
        This is a function to create disposition details from payload json.
        
        Parameters:
            app_json (json): order item education/employment json
                       
        Returns:
            dispo_details(tuple):tuple contains all the details of disposition info
        """
            
        order_id_list=app_json['screeningRequest']['referenceObjects']
        for id in order_id_list:
            if id['type']=='order':
                order_id=id['id']
        orderitemid=app_json['_id']
        dispo_reason=app_json['disposition']['dispositionInfo']['reason']
        dispo_recommendation=app_json['disposition']['dispositionInfo']['recommendedDisposition']


        return order_id,orderitemid,dispo_reason,dispo_recommendation
    
    
    def nsch_talx_name_data(self,json,row_name):
        """
        This is a function to create the applicant names profile and order_item education and employment dataframe based on payload json.
        
        Parameters:
            json (json): Payload json's order_item_education or employment and verification
            row_name (json_object): json object from the json
            
        Returns:
            df(dataframe):extracted dataframe from education/employment verification json name section
            
        """
        try:
            app_data=json
            names=app_data[row_name]['subject']['person']['names']
            df_app_data=pd.DataFrame(names)
            df_app_data['tag']='name'
            for ind_row, ind_value in df_app_data.iterrows():
                if ind_value['useCode']=='aliases':
                    ind_value['given'],ind_value['middle'],ind_value['family']=self.alias_assign_values(ind_value['formattedName'])
            df_app_data.loc[df_app_data['useCode']=='aliases','tag']='alias_name'
            df_app_data['_id']=app_data.get("_id").split(":")[-1]
            df_app_data['tag']='name'
            return df_app_data
        except Exception as e:
            self.logger.log_error("Exception occurred while creating name dataframe..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
    def name_data(self,json,row_name):
        """
        This is a function to create the applicant names profile and order_item education and employment dataframe based on payload json.
        
        Parameters:
            json (json): Payload json's order_item_education or employment and verification
            row_name (json_object): json object from the json
            
        Returns:
            df(dataframe):extracted dataframe from order item education/employment json name section
        """
        try:
            app_data=json
            names=app_data[row_name]['subject']['person']['names']
            df_app_data=pd.DataFrame(names)
            df_app_data['tag']='name'
            return df_app_data
        except Exception as e:
            self.logger.log_error("Exception occurred while creating name dataframe..."+ str(e))
            self.logger.log_error(traceback.format_exc())
    
    def date_summary(self,data,column_list,date_column_list):
        """
        This is a function to covert date field into standard date format (yyyy-mm)
        
        Parameters:
            data (dataframe): order item education/employment json
            column_list:columns from order item education/employment dataframe
            date_column_list:list of date columns 
                
        Returns:
            df(dataframe):convert date into yyyy-mm format and create the date summary into the dataframe
        """
        date_summary_list=[]
        for ind,row in data.iterrows():
            date_summary_dict=self.date_summary_row(row,column_list,date_column_list)
            date_summary_list.append(date_summary_dict)
        total_summary_df = pd.DataFrame.from_dict(date_summary_list)
        return total_summary_df
    
    def date_summary_row(self,row,col_list,date_column_list):
        """
        This is a function to create date summary for each row of the order item education/employment dataframe
        
        Parameters:
            row (dataframe[row]): order item education/employment dataframe rows
            column_list:columns from order item education/employment dataframe
            date_column_list:list of date columns 
                
        Returns:
            df(dataframe):convert date into yyyy-mm format and create the date summary into the dataframe rows
        """
        date_dict={}
        summary=" "
        for i in col_list:
            if i in date_column_list:
                date_value,flag=self.date_check(row[i])
                if flag=='valid_date':
                    summary=flag
                    row[i]= date_value
                else:
                    summary=flag
                date_dict[i+'_date_summary']=summary  
            date_dict[i]=row[i]
        return date_dict
                
    def date_check(self,x):
        """
        This is a function to raise the valid or invalid date flag for date field in every row of the dataframe
        
        Parameters:
            x (date_field): date field of order item education/employment dataframe
                       
        Returns:
            x(date_field):date flag raise for the rows of order item education/employment dataframe
        """
        
        if isinstance(x,dict):
            
            x={key.strip():value for key,value in x.items()}
            year=x['year']
            month=int(x['month'])
            date_value=str(year)+'-'+str(f'{month:02d}')
            flag='valid_date'
            return date_value,flag
        else:
            try :
                if len(str(x))>=10 and bool(datetime.strptime(x[:10],'%Y-%m-%d')):
                    date_value=pd.to_datetime(x[:10])
                    date_value=str(date_value.year)+'-'+str(f'{date_value.month:02d}')
                    flag='valid_date'
                    return date_value,flag
                elif len(str(x))==7 and bool(datetime.strptime(x[:7],'%Y-%m')):
                    date_value=pd.to_datetime(x[:7])
                    date_value=str(date_value.year)+'-'+str(f'{date_value.month:02d}')
                    flag='valid_date'
                    return date_value,flag
                elif x=='notKnown':
                    flag='Current'
                    return x,flag
                else:
                    flag='invalid_date'
                    return x,flag
            except :
                    flag='invalid_date'
                    return x,flag
            
    def create_embeddings(self,emp_data,edu_emp_ver_data,feature_list):

        """
        This is a function read the set of features (columns) and create the embedding and storing the embedded columns into same df
        
        Parameters:
            emp_data (dataframe): order-item-employment dataframe
            talx_emp_data (dataframe): employment verification dataframe
            feature_list(list): feature list which we are creating the embedding
            
        Returns:
            emp_data(dataframe):return dataframes with embedding in order item education/employment
            edu_emp_ver_data (dataframe):return dataframes with embedding in education/employment verification
            
        """

        try:
            for feature in feature_list:
                emp_data[feature+"_embeded"]=emp_data[feature].apply(lambda x: self.model.encode(str(x),convert_to_tensor=True) if x else None)
                edu_emp_ver_data[feature+"_embeded"]=edu_emp_ver_data[feature].apply(lambda x:self.model.encode(str(x),convert_to_tensor=True) if x else None)
            return emp_data,edu_emp_ver_data
        except Exception as e:
            self.logger.log_error("Exception occurred while creating embedings..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
            
    def check_valid_dates(self,emp_data,talx_data,prefix):
        """
        This is a function to create disposition details from payload json.
        
        Parameters:
            emp_data (dataframe): order item employment dataframe
            talx_data(dataframe): employment verfication dataframe
            prefix(str):prefix to identify the aliases
                       
        Returns:
            Flag like boolean True/False, if date is valid True, else False
        """
        if emp_data['current'][0].lower()==talx_data['current'][0].lower()=='true' and emp_data[prefix+'start_date_summary'][0]==talx_data[prefix+'start_date_summary'][0]=='valid_date':
            return True
        elif emp_data[prefix+'start_date_summary'][0]==talx_data[prefix+'start_date_summary'][0]=='valid_date' and emp_data[prefix+'end_date_summary'][0]==talx_data[prefix+'end_date_summary'][0]=='valid_date':
            return True
        else :
            return False
    
    def explode_features(self,emp_data,talx_data,column_name):
        """
        This is a function to explode the features/columns of the dataframe
        
        Parameters:
            emp_data (dataframe): order item employment dataframe
            talx_data(dataframe): employment verfication dataframe
            column_name(list):feature/column list of the dataframe
                       
        Returns:
            emp_data (dataframe): exploded output of the order item employment dataframe
            talx_data(dataframe): exploded output of the employment verfication dataframe
        """
        emp_data=emp_data.explode(column_name)
        talx_data=talx_data.explode(column_name)
        return emp_data,talx_data
    
    def create_cosine_name_similarty(self,data,val_data):
        """
        This is a function to create the cosine similarity between order_item_employment and employment education dataframe
        
        Parameters:
            data (dataframe): order_item_employment_or_education dataframe
            val_data (dataframe): education_or_emplyoment verification dataframe
            
        Returns:
            total_cosine_similarty_scores_df(dataframe): cosine similairty scores for the name section of the dataframe
            
        """
    
        try:
            total_cosine_similarty_score_list=[]
            for ind, order_item_row in data.iterrows():
                for ver_ind, ver_row in val_data.iterrows():
                    one_record_scores_dict=self.create_scores_and_summary(order_item_row,ver_row)
                    total_cosine_similarty_score_list.append(one_record_scores_dict)

            total_cosine_similarty_scores_df = pd.DataFrame.from_dict(total_cosine_similarty_score_list)
            return total_cosine_similarty_scores_df
        except Exception as e:
            self.logger.log_error("Exception occurred while creating cosine similarities for name section..."+ str(e))
            self.logger.log_error(traceback.format_exc())
    
    def create_scores_and_summary(self,appl_row,ver_row):

        """
        This is a function to create the cosine similarity between order_item_employment and employment education row of the dataframe
        
        Parameters:
            appl_row (appl_row[row]): order_item_employment_or_education dataframe
            crim_row (crim_row[row]): education_or_emplyoment verification dataframe
            
        Returns:
            total_cosine_similarty_scores_df(dataframe): cosine similairty scores for the name section for each row of the dataframe
            
        """
        try:
            cosine_similarty_score_dict={}
            features_list=['given','middle','family','profle_string_with_none','profle_string_without_none']
            summary="fields are none-: "
            for feature in features_list:
                if appl_row[feature+"_embeded"]==None or ver_row[feature+"_embeded"]==None :
                    if appl_row[feature] in [None,'']:
                        summary +="app_"+feature+","
                    else:
                        summary +="nsch_"+feature+","
                        
                    cosine_similarty_score_dict["app_"+feature]=appl_row[feature]
                    cosine_similarty_score_dict["nsch_"+feature]=ver_row[feature]
                    cosine_similarty_score_dict[feature+"_score"]=np.nan
                else:
                    cosine_similarty_score_dict["app_"+feature]=appl_row[feature]
                    cosine_similarty_score_dict["nsch_"+feature]=ver_row[feature]
                    cosine_similarty_score = util.pytorch_cos_sim(appl_row[feature+"_embeded"], ver_row[feature+"_embeded"])
                    cosine_similarty_score_dict[feature+"_score"]=cosine_similarty_score.item()

            summary = summary[:-1]
            summary += '.'
            cosine_similarty_score_dict["summary"]=summary  

            return cosine_similarty_score_dict
        except Exception as e:
            self.logger.log_error("Exception occurred while creating scores and summary..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
    def create_cosine_similarty(self,data,val_data):

        """
        This is a function to create the cosine similarity between order_item_employment and employment education dataframe
        
        Parameters:
            data (dataframe): order_item_education dataframe
            val_data (dataframe): education dataframe
        Returns:
            total_cosine_similarty_scores_df(dataframe):cosine similairty scores for the education section of the dataframe
            
        """
        try:
            total_cosine_similarty_score_list=[]
        

            for ind, order_item_row in data.iterrows():
                for ver_ind, ver_row in val_data.iterrows():
                    one_record_scores_dict=self.create_scores_and_summary_nsch(order_item_row,ver_row)
                    total_cosine_similarty_score_list.append(one_record_scores_dict) 

            total_cosine_similarty_scores_df = pd.DataFrame.from_dict(total_cosine_similarty_score_list)
            
            return total_cosine_similarty_scores_df
        except Exception as e:
            self.logger.log_error("Exception occurred while creating cosine similarities for education or employment section..."+ str(e))
            self.logger.log_error(traceback.format_exc())

            
    def create_emp_cosine_similarty(self,data,val_data,column_list,features_list,prefix):

        """
        This is a function to create the cosine similarity between order_item_employment and employment education dataframe

        Parameters:
            data (dataframe): order_item_employment_or_education dataframe
            val_data (dataframe): education_or_emplyoment dataframe
            feature_list(list): feature list which we are creating the scores.
            prefix(str):prefix value of the aliases features/columns
        Returns:
            total_cosine_similarty_score_list(dataframe): returns the cosine similarities of employment section of dataframes
            
        """
        try:
            total_cosine_similarty_score_list=[]
            for ind, order_item_row in data.iterrows():
                for ver_ind, ver_row in val_data.iterrows():
                        one_record_scores_dict=self.create_emp_scores_and_summary(order_item_row,ver_row,column_list,features_list,prefix)
                        total_cosine_similarty_score_list.append(one_record_scores_dict)
            total_cosine_similarty_scores_df = pd.DataFrame.from_dict(total_cosine_similarty_score_list)

            return total_cosine_similarty_scores_df
        except Exception as e:
            self.logger.log_error("Exception occurred while creating cosine similarities for education or employment section..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
            
    def create_scores_and_summary_nsch(self,appl_row,ver_row):

        """
        The function to load the order item education and education verification and see any of the features are empty then retun the summary as part of summary column which we need to show in the dashboard

        Parameters:
            appl_row(dataframe):order item education dataframe
            ver_row(dataframe):education verification dataframe

        Returns:
            appl_row(dataframe):score and summary added in the dataframe
            ver_row(dataframe):score and summary added in the dataframe
        """

        try:
            cosine_similarty_score_dict={}
            features_list=['institution_name','institution_communication.address_city','educationDegrees_name','educationDegrees_degreeGrantedStatus','educationDegrees_specializations_name','profle_string_with_none','profle_string_without_none']
            summary="fields are none-: "
            for feature in features_list:
                if appl_row[feature+"_embeded"]==None or ver_row[feature+"_embeded"]==None :
                    if appl_row[feature] in [None,'']:
                        summary +="app_"+feature+","
                    else:
                        summary +="nsch_"+feature+","
                        
                    cosine_similarty_score_dict["app_"+feature]=appl_row[feature]
                    cosine_similarty_score_dict["nsch_"+feature]=ver_row[feature]
                    cosine_similarty_score_dict[feature+"_score"]=np.nan
                else:
                    cosine_similarty_score_dict["app_"+feature]=appl_row[feature]
                    cosine_similarty_score_dict["nsch_"+feature]=ver_row[feature]
                    cosine_similarty_score = util.pytorch_cos_sim(appl_row[feature+"_embeded"], ver_row[feature+"_embeded"])
                    cosine_similarty_score_dict[feature+"_score"]=cosine_similarty_score.item()

            summary = summary[:-1]
            summary += '.'
            cosine_similarty_score_dict["summary"]=summary 
            cosine_similarty_score_dict["app_start_date_summary"]=appl_row['start_date_summary']
            cosine_similarty_score_dict["app_start"]=appl_row['start']
            cosine_similarty_score_dict["nsch_start"]=ver_row['start']
            cosine_similarty_score_dict["nsch_start_date_summary"]=ver_row['start_date_summary']
            cosine_similarty_score_dict["app_end_date_summary"]=appl_row['end_date_summary']
            cosine_similarty_score_dict["app_end"]=appl_row['end']
            cosine_similarty_score_dict["nsch_end"]=ver_row['end']
            cosine_similarty_score_dict["nsch_end_date_summary"]=ver_row['end_date_summary']
            return cosine_similarty_score_dict
        except Exception as e:
            self.logger.log_error("Exception occurred while creating scores and summary..."+ str(e))
            self.logger.log_error(traceback.format_exc())

            
            
    def get_row_profile_string(self,row,feature_list):
        """
        This is a function to create disposition details from payload json.
        
        Parameters:
            row (dataframe[row]): every row of the order item education/employment dataframe
            feature_list(list): feature list of the dataframe
                       
        Returns:
            return profile string with and without nan columns of the dataframe
        """
       
        try:
            row=row.replace(np.nan,"")
           
            profle_string_without_none=""
            profle_string_with_none=""
           
            for feature in feature_list:
                if row[feature] and row[feature]!="invalid":
                    profle_string_without_none +=str(row[feature])+"_"



                profle_string_with_none +=""+"_" if not row[feature] or \
                            [feature]=="invalid" else str(row[feature])+"_"
            
            return f"{profle_string_without_none[:-1]}",f"{profle_string_with_none[:-1]}"


        except Exception as e:
            self.logger.log_error("Exception occurred while extracting row profile string..."+ str(e))
            self.logger.log_error(traceback.format_exc())

    def get_profile_string_added(self,df,get_row_profile_string):
        """
        This is a function to create disposition details from payload json.
        
        Parameters:
            df (dataframe): order item education or education verificatio dataframe
            get_row_profile_string(df[row]):row of the dataframe
                       
        Returns:
            return profile string with and without nan columns of the dataframe
        """
    
        try:
            for ind, row in df.iterrows():
                ps_with_none,ps_without_none=self.get_row_profile_string(row,get_row_profile_string)
                df.at[ind,'profle_string_without_none']=ps_without_none
                df.at[ind,'profle_string_with_none']=ps_with_none        
                
            return df

        except Exception as e:
            self.logger.log_error("Exception occurred in get_profile_string_added..."+ str(e))
            self.logger.log_error(traceback.format_exc())
         
    def create_cosine_name_similarty(self,data,val_data):
        """
        This is a function to create the cosine similarity between order_item_employment and employment education dataframe
        
        Parameters:
            data (int): order_item_employment_or_education dataframe
            val_data (int): education_or_emplyoment dataframe
            
        Returns:
            total_cosine_similarty_scores_df(dataframe):returns the cosine similarity scrores for name section of the dataframe
            
        """
        try:
            total_cosine_similarty_score_list=[]
            for ind, order_item_row in data.iterrows():
                for ver_ind, ver_row in val_data.iterrows():
                    one_record_scores_dict=self.create_scores_and_summary(order_item_row,ver_row)
                    total_cosine_similarty_score_list.append(one_record_scores_dict)

            total_cosine_similarty_scores_df = pd.DataFrame.from_dict(total_cosine_similarty_score_list)
            return total_cosine_similarty_scores_df
        except Exception as e:
            self.logger.log_error("Exception occurred while creating cosine similarities for name section..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
    def cos_sim_valid_pos_date(emp_data,talx_data,feature_list,column_list):
        """
        This is a function to create disposition details from payload json.
        
        Parameters:
            emp_data (dataframe): order item employment dataframe
            talx_data(dataframe):employment verification dataframe
            feature_list(list): list of the columns from the dataframe which contains position history titles
            column_list(list):list of the columns from the order item employment dataframe
                       
        Returns:
            cosine_similarity_df(dataframe):cosine similarity output dataframe
        """
        try:
            cosine_similarity_list=[]
            for ind,row in emp_data.iterrows():
                for talx_ind,talx_row in talx_data.iterrows():
                    one_record_scores_dict=self.create_pos_scores_summary(row,talx_row,column_list,feature_list,prefix)
                    cosine_similarity_list.append(one_record_scores_dict)
                    
            cosine_similarity_df=pd.DataFrame.from_dict(cosine_similarity_list)
            
            return cosine_similarity_df
        except Exception as e:
            self.logger.log_error("Exception occurred while creating cosine similarities for  employment section..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
                    
            
            
    def check_date_match(self,orderitem_row,ver_row,prefix):
        """
        This is a function to create disposition details from payload json.
        
        Parameters:
            orderitem_row (df[row]): row of the order item employment dataframe
            ver_row:row of the employment verification dataframe
            prefix(str):prefix of aliases features
                       
        Returns:
            returns Boolean value. if match returns True, else False.
        """
        if orderitem_row['current']==str(True) or ver_row['current']==str(True):
            if orderitem_row[prefix+'start']==ver_row[prefix+'start']:
                return True
        elif orderitem_row[prefix+'start']==ver_row[prefix+'start'] and orderitem_row[prefix+'end']==ver_row[prefix+'end']:
            return True
        else :
            return False
   
        
    def chech_valid_posH_dates(self,row):
        """
        This is a function to create disposition details from payload json.
        
        Parameters:
            row (df[row]): row of the employment dataframe after computation of cosine similarity for Organization name feature
                       
        Returns:
            returns Boolean value. if date is valid returns True, else False.
        """
        
        if row['order_item_positionHistories_start_date_summary']==row['verification_positionHistories_start_date_summary']=='valid_date' and row['order_item_positionHistories_current'].lower()==row['verification_positionHistories_current'].lower()=='true':
            return True
        elif row['order_item_positionHistories_start_date_summary']==row['verification_positionHistories_start_date_summary']=='valid_date' and row['order_item_positionHistories_end_date_summary']==row['verification_positionHistories_end_date_summary']=='valid_date':
            return True
        else:
            return False
        
    def pos_cosine(self,cosine,column_list):
        """
        This is a function to create the cosine similarity between order_item_employment and employment verification dataframe
        
        Parameters:
            cosine(Dataframe) :employment dataframe after computation of cosine similarity for Organization name feature
            
        Returns:
            pos_cosine_df(dataframe):returns the cosine similarity scrores for positionHistory title section of the dataframe
            
        """
        pos_cosine_list=[]
        for index,row in cosine.iterrows():
            cosine_dict=self.pos_cosine_summary_score(row,column_list)
            pos_cosine_list.append(cosine_dict)
        pos_cosine_df=pd.DataFrame.from_dict(pos_cosine_list)

        return pos_cosine_df
    
    def check_posh_match_dates(self,row):
        """
        This is a function to check if position title start and end dates are matching from orderitem and verification of employment dataframe.
        
        Parameters:
            row (dataframe): row of the employment dataframe after computation of cosine similarity for Organization name feature
                       
        Returns:
            returns Boolean value. if date is valid returns True, else False.
        """
        if row['order_item_positionHistories_current']==row['verification_positionHistories_current']==str(True):
            if row['order_item_positionHistories_start']==row['verification_positionHistories_start']:
                return True
        elif row['order_item_positionHistories_start']==row['verification_positionHistories_start'] and row['order_item_positionHistories_end']==row['verification_positionHistories_end']:
            return True
        else:
            return False
            
        
    def pos_cosine_summary_score(self,row,column_list):
        """
        This function we compute cosine similarity score for positionHistory feature and adding date match summary and date summary .
        
        Parameters:
            row (dataframe): row of the employment dataframe after computation of cosine similarity for Organization name feature
            column_list(List): List of all the columns in employment dataframe.
                       
        Returns:
            pos_cosine_similarity_dict(dict):dict contains all the details of employment dataframe with cosine similarity scores of positionHistory features
        """
        
        try:
            pos_cosine_similarity_dict={}
#             length=len(features_list)

            summary="Field : "
            posh_date_match_summary="No match for : "
            pos_date_match=''
            
            if self.chech_valid_posH_dates(row):
               
                if self.check_posh_match_dates(row):
                    
                    if pd.isna(row['order_item_positionHistories_titleAliases_embeded']) or pd.isna(row['verification_positionHistories_titleAliases_embeded']):
                        if row['order_item_positionHistories_titleAliases_embeded'] in [None,'',float('nan')]:
                            summary= summary +"order_item_positionHistories_titleAliases"+' are None'
                        else :
                            summary= summary +"verification_positionHistories_titleAliases"+' are None'
                        similarity_score=np.nan

                    else :
                        similarity_score_item=util.pytorch_cos_sim(row['order_item_positionHistories_titleAliases_embeded'], row['verification_positionHistories_titleAliases_embeded'])
                        similarity_score=similarity_score_item.item()
                        pos_date_match='Match'
                        
                else:
                    
                    posh_date_match_summary+=str(row['order_item_positionHistories_start'])+' and '+str(row['verification_positionHistories_start'])
                    similarity_score=np.nan
                    pos_date_match="No_Match"
            else :
                posh_date_match_summary='Invalid date format :'+str(row['order_item_positionHistories_start'])
                similarity_score=np.nan
                pos_date_match='Invalid_Date'

            for feature in column_list:
                pos_cosine_similarity_dict[feature]=row[feature]
            pos_cosine_similarity_dict['pos_date_match']=pos_date_match
            pos_cosine_similarity_dict['summary']=summary
            pos_cosine_similarity_dict['posh_date_match_summary']=posh_date_match_summary

            pos_cosine_similarity_dict['positionHistories_title_Alias_Score']=similarity_score
            return pos_cosine_similarity_dict
        except Exception as e:
            self.logger.log_error("Exception occurred while creating scores and summary..."+ str(e))
            self.logger.log_error(traceback.format_exc())
      
    def create_emp_scores_and_summary(self,order_item_row,verification_row,column_list,features_list,prefix):
        '''
        Return similarity score for Organization name data if the start date and end dates are matching , if end date is unknown , the current should be True
        
        Parameters:
        orderitem_row(dict): Containing the records of orderitem data
        Verification_row(dict): Containing the records of talx data
        prefix(String) :  String contianing the prefix of the feature aliases name
         
        Returns:
            cosine_similarty_score_dict(Dict): Dictionary containing the cosine similarity scores of the organization feature and date match summary
         
        
        '''
        try:

            cosine_similarty_score_dict={}
            length=len(features_list)

            summary="Field : "
            date_match_summary="No match for : "
            for feature in column_list:
                if feature in features_list:
                    if self.check_date_match(order_item_row,verification_row,prefix):
                        if pd.isna(order_item_row[feature+"_embeded"]) or pd.isna(verification_row[feature+"_embeded"]):
                            if order_item_row[feature] in [None,'',float("nan")]:
                                if feature==features_list[length-1]:
                                    summary=summary+"order_item_"+feature+" are None "
                                else:
                                    summary=summary+"order_item_"+feature++" are None "+","
                            else:
                                if feature==features_list[length-1]:
                                    summary=summary+"verification_"+feature+" are None "
                                else:
                                    summary=summary+"verification_"+feature+" are None "+"," 

                            cosine_similarty_score_dict["order_item_"+feature]=order_item_row[feature]
                            cosine_similarty_score_dict["verification_"+feature]=verification_row[feature]
                            cosine_similarty_score_dict[feature+"_score"]=np.nan
                        else:
                            cosine_similarty_score_dict["order_item_"+feature]=order_item_row[feature]
                            cosine_similarty_score_dict["verification_"+feature]=verification_row[feature]
                            cosine_similarty_score = util.pytorch_cos_sim(order_item_row[feature+"_embeded"], verification_row[feature+"_embeded"])
                            cosine_similarty_score_dict[feature+"_score"]=cosine_similarty_score.item()
                    else :
                        date_match_summary=date_match_summary+order_item_row[prefix+'start']
                        cosine_similarty_score_dict["order_item_"+feature]=order_item_row[feature]
                        cosine_similarty_score_dict["verification_"+feature]=verification_row[feature]
                        
                else:
                    cosine_similarty_score_dict["order_item_"+feature]=order_item_row[feature]
                    cosine_similarty_score_dict["verification_"+feature]=verification_row[feature]
                    
            cosine_similarty_score_dict['summary']=summary
            cosine_similarty_score_dict['date_match_summary']=date_match_summary
            return cosine_similarty_score_dict
        except Exception as e:
            self.logger.log_error("Exception occurred while creating scores and summary..."+ str(e))
            self.logger.log_error(traceback.format_exc())
            
            
    def profile_string(self,data,column_list):
        '''
        Dataframe containing profile string and cosine similarity of the profile string from orderitem and talx 
        Parameters:
            Data(dataframe):PositonHistory title cosine similarity dataframe

        Returns:
            profile_string_data(dataframe): Final dataframe with feature list and. profile strings similarity scores
        
        '''
        try:
            profile_string_data_list=[]
            for ind,row in data.iterrows():
                profile_string_dict=self.profile_string_creation(row,column_list)
                profile_string_data_list.append(profile_string_dict)
            profile_string_data=pd.DataFrame.from_dict(profile_string_data_list)
            return profile_string_data
        except Exception as e:

            self.logger.log_error("Exception occurred while creating cosine similarities for  employment section..."+ str(e))
            self.logger.log_error(traceback.format_exc())
        
    def profile_string_app(self,row):
        '''
        Creation of profile string along orderitem data
        
        Parameters :
             row: Dataframe records having feature list data
             
         Returns :
            ps_with_nan(String): String containing profile string with nan 
            ps_without_nan(String):String containing profile string without nan
        '''
        if (not pd.isna(row['Organization_name_score'])) and (not pd.isna(row['pos_hist_name_score'])):
            ps_without_nan=row['app_organization_name']+'_'+row['app_pos_title']
            ps_with_nan=row['app_organization_name']+'_'+row['app_pos_title']
        elif pd.isna(row['pos_hist_name_score']) and (not pd.isna(row['Organization_name_score'])): 
            if row['app_pos_hist_start']==row['verification_pos_hist_start'] and (row['app_pos_hist_end']==row['verification_pos_hist_end'] or row['app_pos_hist_current'].lower()==row['verification_pos_hist_current'].lower()) :
                if row['app_pos_title']!='':
                    ps_without_nan=row['app_organization_name']+'_'+row['app_pos_title']
                    ps_with_nan=row['app_organization_name']+'_'+row['app_pos_title']
                else:
                    ps_without_nan=row['app_organization_name']
                    ps_with_nan=row['app_organization_name']+'_'+'nan'
            else:
                ps_without_nan=row['app_organization_name']
                ps_with_nan=row['app_organization_name']
        elif pd.isna(row['Organization_name_score']) and (not pd.isna(row['pos_hist_name_score'])):
            if row['app_organization_name']!='':
                ps_without_nan=row['app_organization_name']+'_'+row['app_pos_title']
                ps_with_nan=row['app_organization_name']+'_'+row['app_pos_title']
            else:
                ps_without_nan='_'+row['app_pos_title']
                ps_with_nan='nan'+'_'+row['app_pos_title']
       
        else:
            if (row['app_organization_name']=='') and row['app_pos_title']=='':
                ps_without_nan=''
                ps_with_nan='nan'+'_'+'nan'
            elif row['app_organization_name']!='' and row['app_pos_title']=='':
                ps_without_nan=row['app_organization_name']
                ps_with_nan=row['app_organization_name']+'_'+'nan'
            elif row['app_organization_name']=='' and row['app_pos_title']!='' and (row['app_pos_hist_start']==row['verification_pos_hist_start'] ):
                ps_without_nan=row['app_pos_title']
                ps_with_nan='nan'+'_'+row['app_pos_title']
            elif row['app_organization_name']=='' and row['app_pos_title']!='' and (row['app_pos_hist_start']!=row['verification_pos_hist_start'] ):
                ps_without_nan=''
                ps_with_nan='nan'+'_'
            
            elif row['app_organization_name']!='' and row['app_pos_title']!='' and row['app_pos_hist_start']==row['verification_pos_hist_start'] :
                ps_without_nan=row['app_organization_name']+'_'+row['app_pos_title']
                ps_with_nan=row['app_organization_name']+'_'+row['app_pos_title']
            elif row['app_organization_name']!='' and row['app_pos_title']!='' and row['app_pos_hist_start']!=row['verification_pos_hist_start'] :
                ps_without_nan=row['app_organization_name']+'_'
                ps_with_nan=row['app_organization_name']+'_'
            else:
                ps_with_nan=''
                ps_without_nan=''

        return ps_with_nan,ps_without_nan
        
        

    def profile_string_talx(self,row):
        '''
        Creation of profile string along talx data
        
        Parameters :
             row: Dataframe records having feature list data
             
         Returns :
            ps_with_nan(String): String containing profile string with nan 
            ps_without_nan(String):String containing profile string without nan
        '''
        if (not pd.isna(row['Organization_name_score'])) and (not pd.isna(row['pos_hist_name_score'])):
            ps_without_nan=row['verification_organization_name']+'_'+row['verification_pos_title']
            ps_with_nan=row['verification_organization_name']+'_'+row['verification_pos_title']
        elif pd.isna(row['pos_hist_name_score']) and (not pd.isna(row['Organization_name_score'])):
            if row['app_pos_hist_start']==row['verification_pos_hist_start'] and (row['app_pos_hist_end']==row['verification_pos_hist_end'] or row['app_pos_hist_current'].lower()==row['verification_pos_hist_current'].lower()) :
                if row['app_pos_title']!='':
                    ps_without_nan=row['verification_organization_name']+'_'+row['verification_pos_title']
                    ps_with_nan=row['verification_organization_name']+'_'+row['verification_pos_title']
                else:
                    ps_without_nan=row['verification_organization_name']
                    ps_with_nan=row['verification_organization_name']+'_'+'nan'
            else:
                ps_without_nan=row['verification_organization_name']
                ps_with_nan=row['verification_organization_name']
        elif pd.isna(row['Organization_name_score']) and (not pd.isna(row['pos_hist_name_score'])):
            if row['verification_organization_name']!='':
                ps_without_nan=row['verification_organization_name']+'_'+row['verification_pos_title']
                ps_with_nan=row['verification_organization_name']+'_'+row['verification_pos_title']
            else:
                ps_without_nan='_'+row['verification_pos_title']
                ps_with_nan='nan'+'_'+row['verification_pos_title']
            
        else:
            if (row['verification_organization_name']=='') and row['verification_pos_title']=='':
                ps_without_nan=''
                ps_with_nan='nan'+'_'+'nan'
            elif row['verification_organization_name']!='' and row['verification_pos_title']=='':
                ps_without_nan=row['verification_organization_name']
                ps_with_nan=row['verification_organization_name']+'_'+'nan'
            elif row['verification_organization_name']=='' and row['verification_pos_title']!='' and row['app_pos_hist_start']==row['verification_pos_hist_start'] :
                ps_without_nan=row['verification_pos_title']
                ps_with_nan='nan'+'_'+row['verification_pos_title']
            elif row['verification_organization_name']=='' and row['verification_pos_title']!='' and row['app_pos_hist_start']!=row['verification_pos_hist_start'] :
                ps_without_nan=''
                ps_with_nan='nan'+'_'
            elif row['verification_organization_name']!='' and row['verification_pos_title']!='' and row['app_pos_hist_start']==row['verification_pos_hist_start'] :
                ps_without_nan=row['verification_pos_title']+row['verification_pos_title']
                ps_with_nan=row['verification_pos_title']+'_'+row['verification_pos_title']
            elif row['verification_organization_name']!='' and row['verification_pos_title']!='' and row['app_pos_hist_start']!=row['verification_pos_hist_start'] :
                ps_without_nan=row['verification_pos_title']+'_'
                ps_with_nan=row['verification_pos_title']+'_'
                
            else:
                ps_with_nan=''
                ps_without_nan=''

        return ps_with_nan,ps_without_nan
        





    def profile_string_creation(self,row,column_list):
        '''
        Creation of profile string 
        
        Parameters :
             row: row records having feature list data
             
         Returns :
            profile_string_data_dict(Dict): Dictionary containing profile strings with nan and without nan
                                            the similarity score for profile string with nan and without nan  
            
        '''

        try:
            profile_string_data_dict={}
            app_profile_string_with_nan=""
            talx_profile_string_with_nan=""
            app_profile_string_without_nan=""
            talx_profile_string_without_nan=""

            app_profile_string_with_nan,app_profile_string_without_nan = self.profile_string_app(row)
            talx_profile_string_with_nan,talx_profile_string_without_nan=self.profile_string_talx(row)
            
            if not (app_profile_string_with_nan=='' or talx_profile_string_with_nan==''):
                

                app_profile_string_with_nan_embed=self.model.encode(app_profile_string_with_nan,convert_to_tensor=True)
                
                talx_profile_string_with_nan_embed=self.model.encode(talx_profile_string_with_nan,convert_to_tensor=True)
          
                ps_with_nan_score= util.pytorch_cos_sim(app_profile_string_with_nan_embed,talx_profile_string_with_nan_embed)
                ps_with_nan_score=ps_with_nan_score.item()
            else:
                ps_with_nan_score=np.nan
                
                
            if not (app_profile_string_without_nan==talx_profile_string_without_nan==''):
                app_profile_string_without_nan_embed=self.model.encode(app_profile_string_without_nan,convert_to_tensor=True)
                talx_profile_string_without_nan_embed=self.model.encode(talx_profile_string_without_nan,convert_to_tensor=True)
                ps_without_nan_score=util.pytorch_cos_sim(app_profile_string_without_nan_embed,talx_profile_string_without_nan_embed)
                ps_without_nan_score=ps_without_nan_score.item()
            else:
                ps_without_nan_score=np.nan

            for feature in column_list:
                profile_string_data_dict[feature]=row[feature]


            profile_string_data_dict['app_profile_string_with_nan']=app_profile_string_with_nan
            profile_string_data_dict['talx_profile_string_with_nan']=talx_profile_string_with_nan
            profile_string_data_dict['app_profile_string_without_nan']=app_profile_string_without_nan
            profile_string_data_dict['talx_profile_string_without_nan']=talx_profile_string_without_nan
            profile_string_data_dict['porfile_string_with_nan_score']=ps_with_nan_score
            profile_string_data_dict['profile_string_without_nan_score']=ps_without_nan_score

            return profile_string_data_dict




        except Exception as e:
            self.logger.log_error("Exception occurred while creating scores and summary..."+ str(e))
            self.logger.log_error(traceback.format_exc())

    