"""
Original Author : Avinash.Goje
Modified : Ina Jain
Created on : 08 April, 2022
Modified on : 04 Aug, 2022
Version : 1.0
Comment : hvac_connector is implimentation of HashiCorp Vault.
          Currently we are storing MongoDb Credentials, Kafka Credentials
Usage:

from hrg2.connectors.vault_handlers.hvac_connector import Vault
vault_obj = Vault()
mongoDbcreds = vault_obj.get_mongoDb_creds()
kafkacreds = vault_obj.get_kakfa_creds()

"""

import hvac
from configparser import ConfigParser, ExtendedInterpolation
import traceback, os, json
from idr_src.utils.logger import Framework_Logger


class Vault:

  """
    This is a class to authenticate mongodb"

  """
  def __init__(self, env) -> None:

    """
        The constructor to load environment and logging.

    """
    self.logger=Framework_Logger()
    self.env = env
    self.get_hvac_client()
    
  def get_hvac_client(self):
    #This function is to connect mongodb environment
    self.logger.log_info("Function Call Vault get_hvac_client")
    if self.env == "local":
      return

    VAULT_URL = f"https://tools-{self.env}.hireright.com"
    
    if self.env =='test':
      username = 'tdataservices'
      password = '78M3>UHINHGC*^oG-aL9c=JK'
    elif self.env == 'dev':
      username = 'ddataservices'
      password = '89M3>UKMNWC*^oG-aL7b=BG'    
    elif self.env == 'stg':
      username = 'sdataservices'
      password = "7OpjW.BT'UxEyE*4UqV8z-"    
    elif self.env == 'prod-us':
      username = 'pdataservices'
      password = "9JlI56HgWKOuE}rWNc{7"

    try:
      self._client = hvac.Client(url=VAULT_URL)
      self._client.auth.userpass.login(username=username, password=password)
    except Exception as e:
      self.logger.log_error("Exception occurred: %s" + str(traceback.format_exc()) )

  def get_mongoDb_creds(self):
    #This function check for mongodb authentication
    self.logger.log_info("Function Call Vault get_mongoDb_creds")

    if self.env == "local":
      return {'mongoPass': 'root', 'mongoUser': 'root'}

    path = 'mongo/dbcreds'
    mount_point = 'dataservices'
    try:
      response = self._client.secrets.kv.v2.read_secret_version(path=path, mount_point=mount_point)
    except Exception as e:
      self.logger.log_error("Exception occurred: %s" + str(traceback.format_exc()) )
      return None
    if 'data' in response and 'data' in response['data']:
      return response['data']['data']
    else:
      return None
  
  
  def get_kakfa_creds(self):
    #This function check for kafka credentials
    self.logger.log_info("Function Call Vault get_kakfa_creds")

    if self.env == "local":
       return {'confluentApiKey': '',
        'confluentRegistryApiKey': '', 
        'confluentRegistrySecret': '', 
        'confluentSecret': '', 
        'host': 'broker:29092', 
        'schemaRegistryUrl': 'http://schema-registry:8081'
        }

    path = 'kafka/creds'
    mount_point = 'dataservices'
    try:
      response = self._client.secrets.kv.v2.read_secret_version(path=path, mount_point=mount_point)
    except Exception as e:
      self.logger.log_error("Exception occurred: %s",traceback.format_exc())
      return None
    if 'data' in response and 'data' in response['data']:
      try:
        return response['data']['data']
      except Exception as e:
        self.logger.log_error("Exception occurred: %s",traceback.format_exc())    
        return None
    else:
       return None