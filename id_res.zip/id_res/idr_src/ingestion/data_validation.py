""" 
data is ingested to GCS bucket. 
Validate the ingested date for the 
    1. payload format, 
    2. ingested data format,
    3. mandatory fields like request id and order_service_id 
"""
# NEEDS to BE Optimized - NOTE 

import pandas as pd 
import json
from google.cloud import storage

# put this path in config 
validated_payloads = "gs://bkt-d-hrgp-data-us/ds_zaha_hrg2/ingested_data/sample_data/"
applicant_mandatory_keys=['applicant_data', 'request_id', 'reg_id', 'order_service_id', 'order_service_data_source_id',
'applicant_id', 'first_name', 'middle_name', 'last_name', 'ssn', 'driving_license', 'address', 
'current_address','previous_addresses','county', 'state', 'alias_names', 'photo_path', 'education_details', 
'prev_empoyment_details', 'ssn_trace', 'mvr','court_response','hrg1_action', 'date_submitted', 'date_closed']

crim_mandatory_keys


keys_validation=True
content_validation=True
keys_not_present=" keys not present in Json file -: "
content_not_present="content is empty for Keys  -: " 
payloads_lst = []
client = storage.Client()
for blob in client.list_blobs('bkt-d-hrgp-data-us', prefix='ds_zaha_hrg2/ingested_data/sample_data'):
    print(str(blob.name).split('/')[-1])
    print(blob)
    data = json.loads(blob.download_as_string(client=None))
    applicant_df = pd.json_normalize(data["applicant_data"])
    print(applicant_df)
    applicant_df.to_csv("test_save_path.csv", index=False)



def validate_json_file(path):

    for filename in os.listdir(path):
        if filename.endswith(".json") :
             filepath=os.path.join(path, filename)
             print(" Started Json file Validation for file - "+ filepath)
             with open(filepath, 'r') as json_file:
                json_content_dict = json.load(json_file)
                validate_json_keys(json_content_dict,req_keys)
                validate_json_content(json_content_dict)
                

def validate_json_keys(json_content_dict,req_keys):
    global keys_validation
    keys=get_keys(json_content_dict)
    for key in req_keys:
        if key in keys:
            pass
        else:
            keys_not_present+str(key)+","
            keys_validation=False
    if keys_validation:
        print("Key validation success")
    else:
        print("Key validation failed  " + keys_not_present )


def validate_json_content(json_content_dict):
    global content_validation
    global content_not_present
    for key, value in recursive_items(json_content_dict):
        if value:
            pass
        else:
            content_not_present+=str(key)+","
            content_validation=False
    
    if content_validation:
        print("Content validation success")
    else:
        print("Content validation failed " + content_not_present ) 

def get_keys(json_dict):
    result = []
    for key, value in json_dict.items():
        if type(value) is dict:
            new_keys = get_keys(value)
            result.append(key)
            for innerkey in new_keys:
                #result.append(f'{key}/{innerkey}')
                result.append(innerkey)
        else:
            result.append(key)
    return result



def recursive_items(dictionary):
    for key, value in dictionary.items():
        if type(value) is dict:
            yield (key, value)
            yield from recursive_items(value)
        elif type(value) is list and value:
            for index in range(len(value)):
                if type(value[index]) is dict:
                    for ldkey, ldvalue in value[index].items():
                        yield (ldkey, ldvalue)
        else:
            yield (key, value)


validate_json_file(path)